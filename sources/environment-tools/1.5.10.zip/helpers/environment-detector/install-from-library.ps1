﻿[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('Microsoft.PowerShell', 'Microsoft.WindowsTerminal', 'Git.Git', 'Gyan.FFmpeg', 'TheDocumentFoundation.LibreOffice', 'Microsoft.DotNet.SDK.8', 'PyYAML', 'yt-dlp')]
    [string]$PackageId,
    [Parameter(Mandatory=$true)][string]$LibraryRoot,
    [string]$PythonExe,
    [string]$PythonPrefix,
    [string]$PythonVersion,
    [switch]$ValidateOnly
)

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path -LiteralPath $LibraryRoot -ErrorAction Stop).Path.TrimEnd('\')
$manifestPath = Join-Path $root 'manifest.json'
$lockPath = Join-Path $PSScriptRoot 'installer-library.lock.json'
if (-not (Test-Path -LiteralPath $lockPath -PathType Leaf)) {
    $sourceRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
    $lockPath = Join-Path $sourceRoot 'public-hub\INSTALLER-LIBRARY.lock.json'
}
if (-not (Test-Path -LiteralPath $lockPath -PathType Leaf)) { throw 'Toolbox installer lock file is missing.' }
if ((Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash -ine
    (Get-FileHash -LiteralPath $lockPath -Algorithm SHA256).Hash) {
    throw 'Library manifest differs from the toolbox locked version.'
}
$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
if ($manifest.schemaVersion -ne 1) { throw 'Unsupported installer manifest schema.' }

function Get-VerifiedPackage {
    param([string]$Id, [string]$RequiredPythonVersion)
    $matches = @($manifest.packages | Where-Object { $_.id -eq $Id })
    if ($RequiredPythonVersion) {
        $matches = @($matches | Where-Object { $_.pythonVersion -eq $RequiredPythonVersion })
    }
    if ($matches.Count -ne 1) { throw "Expected one package for $Id $RequiredPythonVersion; found $($matches.Count)." }
    $package = $matches[0]
    $relative = [string]$package.file
    if (-not $relative.StartsWith('packages/', [StringComparison]::Ordinal)) { throw "Invalid package path: $relative" }
    $path = [IO.Path]::GetFullPath((Join-Path $root ($relative -replace '/', '\')))
    if (-not $path.StartsWith($root + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Package escapes library: $relative" }
    $file = Get-Item -LiteralPath $path -ErrorAction Stop
    if ($file.PSIsContainer -or [long]$file.Length -ne [long]$package.bytes) { throw "Package size mismatch: $relative" }
    if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ine [string]$package.sha256) {
        throw "Package SHA-256 mismatch: $relative"
    }
    return $path
}

$version = if ($PackageId -eq 'PyYAML') { $PythonVersion } else { $null }
if ($PackageId -eq 'PyYAML' -and $version -notmatch '^3\.(11|12|13|14)$') {
    throw 'The prepared PyYAML wheel supports Python 3.11 through 3.14 x64.'
}
if ($PackageId -eq 'Microsoft.PowerShell') {
    $powerShellEntry = @($manifest.packages | Where-Object { $_.id -eq $PackageId })
    if ($powerShellEntry.Count -ne 1 -or [IO.Path]::GetExtension([string]$powerShellEntry[0].file) -ine '.msi') {
        throw 'The legacy library contains MSIX PowerShell. Use the PowerShell card Install/Repair MSI action; no Store package was installed.'
    }
}
$packagePath = Get-VerifiedPackage $PackageId $version
$dependencyPath = if ($PackageId -eq 'Microsoft.WindowsTerminal') {
    Get-VerifiedPackage 'Microsoft.UI.Xaml.2.8' $null
} else { $null }
if ($ValidateOnly) {
    Write-Output "Verified $PackageId from $root"
    exit 0
}

function Invoke-Installer {
    param([string]$Executable, [string[]]$Arguments)
    $run = Start-Process -FilePath $Executable -ArgumentList $Arguments -WindowStyle Hidden -Wait -PassThru
    if ($run.ExitCode -notin @(0, 3010, 1641)) { throw "Installer failed with exit code $($run.ExitCode)." }
}

switch ($PackageId) {
    'Microsoft.DotNet.SDK.8' { Invoke-Installer $packagePath @('/install', '/quiet', '/norestart') }
    'Microsoft.PowerShell' { Invoke-Installer (Join-Path $env:SystemRoot 'System32\msiexec.exe') @('/i', ('"' + $packagePath + '"'), '/qn', '/norestart', 'ADD_PATH=1', 'ENABLE_PSREMOTING=0') }
    'Microsoft.WindowsTerminal' {
        Add-AppxPackage -Path $packagePath -DependencyPath $dependencyPath -ErrorAction Stop
    }
    'Git.Git' { Invoke-Installer $packagePath @('/VERYSILENT', '/NORESTART', '/SUPPRESSMSGBOXES') }
    'TheDocumentFoundation.LibreOffice' {
        Invoke-Installer (Join-Path $env:SystemRoot 'System32\msiexec.exe') @('/i', ('"' + $packagePath + '"'), '/qn', '/norestart')
    }
    'Gyan.FFmpeg' {
        $target = Join-Path $env:LOCALAPPDATA 'CompanyAIHelpers\FFmpeg'
        New-Item -ItemType Directory -Path $target -Force | Out-Null
        Expand-Archive -LiteralPath $packagePath -DestinationPath $target -Force
        $bin = Join-Path $target 'ffmpeg-9.0.2-full_build\bin'
        if (-not (Test-Path -LiteralPath (Join-Path $bin 'ffmpeg.exe') -PathType Leaf) -or
            -not (Test-Path -LiteralPath (Join-Path $bin 'ffprobe.exe') -PathType Leaf)) {
            throw 'FFmpeg archive is missing ffmpeg.exe or ffprobe.exe.'
        }
        $current = [Environment]::GetEnvironmentVariable('Path', 'User')
        $entries = @($current -split ';' | Where-Object { $_ })
        if ($entries -inotcontains $bin) {
            [Environment]::SetEnvironmentVariable('Path', (($entries + $bin) -join ';'), 'User')
        }
        $env:Path += ';' + $bin
    }
    { $_ -in @('PyYAML', 'yt-dlp') } {
        if (-not $PythonExe) { throw 'Python executable is required.' }
        $prefix = if ($PythonPrefix) { @($PythonPrefix) } else { @() }
        $wheels = Join-Path $root 'packages\wheels'
        $requirement = if ($PackageId -eq 'PyYAML') { 'PyYAML==6.0.3' } else { 'yt-dlp==2026.8.19' }
        & $PythonExe @prefix -m pip install --no-index --find-links $wheels --upgrade $requirement
        if ($LASTEXITCODE -ne 0) { throw "Offline pip install failed: $PackageId" }
    }
}
Write-Output "Installed $PackageId from the verified library."
