using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using EnvironmentDetector;
internal static class PowerShellSetupTests {
 static int count;
 static void Check(string name,bool value){if(!value)throw new Exception(name);count++;Console.WriteLine("PASS "+name);}
 [STAThread] static int Main(){try{
  string exe=@"C:\Program Files\PowerShell\7\pwsh.exe";string version;
  var good=new CommandResult{ExitCode=0,Output="CODEXTOOLS_PS7|7.6.9|2"};
  Check("msi_core_and_path_ready",PowerShellSetup.Evaluate(exe,true,true,good,exe).Level==CheckLevel.Ready);
  Check("store_alias_alone_not_ready",PowerShellSetup.Evaluate(exe,false,false,null,@"C:\Users\fixture\AppData\Local\Microsoft\WindowsApps\pwsh.exe").Level!=CheckLevel.Ready);
  Check("bundled_runtime_alone_not_ready",PowerShellSetup.Evaluate(exe,false,false,null,@"C:\fixture\.cache\codex-runtimes\pwsh.exe").Level!=CheckLevel.Ready);
  Check("portable_without_msi_registration_not_ready",PowerShellSetup.Evaluate(exe,true,false,good,exe).Level!=CheckLevel.Ready);
  Check("failed_start_not_ready_even_with_marker",PowerShellSetup.Evaluate(exe,true,true,new CommandResult{ExitCode=-1073741502,Output=good.Output},exe).Level!=CheckLevel.Ready);
  Check("timeout_not_ready",PowerShellSetup.Evaluate(exe,true,true,new CommandResult{ExitCode=-2,Output="timeout"},exe).Level!=CheckLevel.Ready);
  Check("unparseable_output_not_ready",!PowerShellSetup.ProbePassed(new CommandResult{ExitCode=0,Output="failed"},out version));
  Check("windows_powershell_not_accepted",!PowerShellSetup.ProbePassed(new CommandResult{ExitCode=0,Output="CODEXTOOLS_PS7|5.1.0|2"},out version));
  Check("wrong_calculation_not_accepted",!PowerShellSetup.ProbePassed(new CommandResult{ExitCode=0,Output="CODEXTOOLS_PS7|7.6.9|0"},out version));
  Check("path_pointing_to_store_not_ready",PowerShellSetup.Evaluate(exe,true,true,good,@"C:\WindowsApps\pwsh.exe").Level!=CheckLevel.Ready);
  Check("path_absent_not_ready",PowerShellSetup.Evaluate(exe,true,true,good,null).Level!=CheckLevel.Ready);
  Check("repair_action_available",AutoFixEngine.CanAutoFix(PowerShellSetup.ConfigurationId));
  Check("powershell_not_added_to_unrelated_automatic_install",RepairEngine.IsManualOnly("PowerShell 7"));
  using(var card=new ResultCard(PowerShellSetup.Evaluate(exe,false,false,null,null),false)) {
   Check("msi_repair_button_visible_for_store_only",card.Controls.OfType<Button>().Any(b=>b.Text=="安装/修复 MSI"));
  }
  string fixture=Path.Combine(Path.GetTempPath(),"CodexTools-PS-path-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(fixture);
  try{string first=Path.Combine(fixture,"first"),second=Path.Combine(fixture,"second");Directory.CreateDirectory(first);Directory.CreateDirectory(second);File.WriteAllText(Path.Combine(second,"pwsh.exe"),"fixture");
   Check("fresh_path_resolver_ignores_empty_entries",PowerShellSetup.ResolvePath(";"+first+";;\""+second+"\";")==Path.Combine(second,"pwsh.exe"));
  }finally{foreach(string f in Directory.GetFiles(fixture,"*",SearchOption.AllDirectories))File.Delete(f);foreach(string d in Directory.GetDirectories(fixture))Directory.Delete(d);Directory.Delete(fixture);}
  Check("new_process_probe_has_no_profile",PowerShellSetup.ProbeCommand.Contains("-NoProfile")&&PowerShellSetup.ProbeCommand.Contains("-NonInteractive"));
  Console.WriteLine("Checks: "+count);return 0;
 }catch(Exception error){Console.Error.WriteLine(error);return 1;}}
}
