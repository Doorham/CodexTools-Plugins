using System;
using System.Linq;
using EnvironmentDetector;
internal static class ScanPlanTests
{
    static int checks;
    static void Check(string name, bool passed) { Console.WriteLine(name + "=" + (passed ? "PASS" : "FAIL")); if (!passed) throw new Exception(name); checks++; }
    public static int Main()
    {
        string[] software = Detector.ScanNames(false), codex = Detector.ScanNames(true);
        Check("SOFTWARE_SCOPE_PRESERVES_EIGHT_ITEMS", software.Length == 8);
        Check("CODEX_SCOPE_PRESERVES_SIX_ITEMS", codex.Length == 6);
        Check("SCOPES_DO_NOT_DUPLICATE", !software.Intersect(codex).Any());
        Check("ALL_EXISTING_CHECKS_PRESERVED", software.Concat(codex).Distinct().Count() == 14);
        Check("SOFTWARE_KEEPS_PYTHON_INSTALLATION_CHECK", software.Contains("基础开发环境"));
        Check("CODEX_DOES_NOT_RUN_PYTHON_VENV_CHECK", !codex.Contains("基础开发环境"));
        Check("GIT_AND_ENCODING_STAY_IN_CODEX_SCOPE", codex.Contains("Git") && codex.Contains("编码兼容与 UTF-8 范围"));
        Check("OFFICE_AND_FFMPEG_STAY_IN_SOFTWARE_SCOPE", software.Contains(Detector.LibreOfficeName) && software.Contains("FFmpeg（含 FFprobe）"));
        Console.WriteLine("TOTAL=" + checks); return 0;
    }
}
