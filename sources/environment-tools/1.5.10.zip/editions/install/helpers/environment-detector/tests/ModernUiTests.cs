using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using EnvironmentDetector;

internal static class ModernUiTests
{
    static int count;
    static bool desktop;
    [DllImport("user32.dll")] static extern bool PrintWindow(IntPtr window, IntPtr dc, uint flags);
    [DllImport("user32.dll", EntryPoint="GetWindowLongW")] static extern int GetWindowLong(IntPtr window,int index);
    [DllImport("user32.dll")] static extern IntPtr SendMessage(IntPtr window,uint message,IntPtr wp,IntPtr lp);
    static readonly BindingFlags Flags = BindingFlags.Instance | BindingFlags.NonPublic;
    static void Check(string name, bool pass)
    {
        Console.WriteLine(name + "=" + (pass ? "PASS" : "FAIL"));
        if (!pass) throw new Exception(name);
        count++;
    }
    static List<CheckResult> Samples(bool codex)
    {
        if (codex) return new List<CheckResult> {
            new CheckResult { Name="Git", Group="基础开发环境", Importance="必需", Level=CheckLevel.Warning, Installed=true, AutoFixId=GitSetup.ConfigurationId,
                Detail="Git 已安装，提交身份尚未配置。", Guidance="填写自己的姓名和邮箱；保存后验证真实提交。" },
            new CheckResult { Name="编码兼容与 UTF-8 范围", Group="系统兼容", Importance="推荐", Level=CheckLevel.Ready,
                Detail="系统保持原生编码，UTF-8 文件按 UTF-8 读取。需要 UTF-8 的工作流程单独指定。" },
            new CheckResult { Name="Windows Terminal", Group="终端", Importance="推荐", Level=CheckLevel.Ready, Detail="终端已就绪，可使用本机已有配置。" },
            new CheckResult { Name="WebView2 运行时", Group="窗口运行环境", Importance="必需", Level=CheckLevel.Ready, Detail="运行时已就绪，可打开现代网页界面。" },
            new CheckResult { Name="PyYAML", Group="Python 组件", Importance="推荐", Level=CheckLevel.Ready, Detail="环境组件已安装，无需重复配置。" },
            new CheckResult { Name="yt-dlp", Group="Python 组件", Importance="业务可选", Level=CheckLevel.Ready, Detail="环境组件已安装，按业务需要使用。" }
        };
        return new List<CheckResult> {
            new CheckResult { Name="PowerShell 7", Group="终端工具", Importance="推荐", Level=CheckLevel.Missing, Detail="尚未检测到 PowerShell 7。", Guidance="从官方下载后安装，再重新检测。" },
            new CheckResult { Name="基础开发环境", Group="Python", Importance="必需", Level=CheckLevel.Missing, Detail="尚未检测到可用的 Python 3.11+。", Guidance="请安装官方 Windows x64 版本。" },
            new CheckResult { Name=".NET 8 桌面运行时（x64）", Group="运行环境", Importance="推荐", Level=CheckLevel.Ready, Detail="运行时已经安装，无需重复下载。" },
            new CheckResult { Name=".NET 8+ SDK", Group="开发工具", Importance="业务可选", Level=CheckLevel.Ready, Detail="开发工具已经安装。" },
            new CheckResult { Name="FFmpeg（含 FFprobe）", Group="媒体处理", Importance="业务可选", Level=CheckLevel.Missing, Detail="未检测到 FFmpeg 与 FFprobe。", Guidance="下载并解压后配置 PATH。" },
            new CheckResult { Name="LibreOffice（无头渲染）", Group="文档处理", Importance="业务可选", Level=CheckLevel.Missing, Detail="尚未检测到文档渲染工具。", Guidance="可前往官方下载 Windows 安装包。" },
            new CheckResult { Name="开发工具", Group="编辑器", Importance="业务可选", Level=CheckLevel.Ready, Detail="已检测到编辑器。" },
            new CheckResult { Name="编辑器集成", Group="扩展", Importance="业务可选", Level=CheckLevel.Ready, Detail="扩展已经就绪。" }
        };
    }
    static void Render(string output, bool dark, bool codex, int width)
    {
        UiTheme.Set(dark);
        using (var form = new MainForm(codex, false, true)) {
            form.Size = new Size(UiTheme.Px(form, width), UiTheme.Px(form, 900));
            // Show an isolated off-screen fixture so native child HWNDs actually paint.
            // Skip Shown's live scan: fixtures must not inspect or configure this machine.
            form.StartPosition = FormStartPosition.Manual; form.Location = new Point(180,120); form.ShowInTaskbar = desktop;
            typeof(MainForm).GetField("scanRunning", Flags).SetValue(form, true);
            form.Show(); Application.DoEvents();
            typeof(MainForm).GetField("scanRunning", Flags).SetValue(form, false);
            var results = Samples(codex);
            typeof(MainForm).GetField("lastResults", Flags).SetValue(form, results);
            typeof(MainForm).GetMethod("RenderResults", Flags).Invoke(form, new object[]{results});
            typeof(MainForm).GetMethod("UpdateRepairButtons", Flags).Invoke(form, null);
            form.PerformLayout();
            var panel = (FlowLayoutPanel)typeof(MainForm).GetField("resultsPanel", Flags).GetValue(form);
            panel.PerformLayout();
            var cards = panel.Controls.OfType<ResultCard>().ToList();
            Check((dark?"DARK":"LIGHT") + "_" + width + "_CARD_COUNT", cards.Count == (codex ? 6 : 8));
            Check("CARDS_INSIDE_VIEWPORT", cards.All(c => c.Right <= panel.ClientSize.Width));
            Check("ACTIONS_INSIDE_CARDS", cards.All(c => c.Controls.OfType<Button>().All(b => b.Right < c.Width && b.Bottom < c.Height && b.Left >= 0)));
            Console.WriteLine("LAYOUT=" + panel.ClientSize + " DPI_WIDTH=" + form.Width + " CARD=" + cards[0].Bounds + " NEXT=" + cards[1].Bounds);
            Check("GRID_REFLOWS", width >= 1100 ? cards[0].Top == cards[1].Top && cards[1].Left > 0 : cards[1].Top > cards[0].Top);
            if (codex) {
                var encoding = cards[1];
                Check("ENCODING_BOTH_ACTIONS", encoding.Controls.OfType<Button>().Any(b=>b.Text=="拨乱反正") && encoding.Controls.OfType<Button>().Any(b=>b.Text=="系统编码设置"));
                Check("GIT_IDENTITY_ACTION", cards[0].Controls.OfType<Button>().Any(b=>b.Text=="配置提交身份"));
            }
            Check("THEME_APPLIED", cards.All(c=>c.BackColor==UiTheme.Surface) && form.BackColor==UiTheme.Window);
            Console.WriteLine("FRAME="+form.Size+" CLIENT="+form.ClientSize);
            foreach(Control item in form.Controls) Console.WriteLine("CONTROL="+item.Name+" "+item.GetType().Name+" "+item.Bounds+" visible="+item.Visible);
            Check("CLIENT_IS_BORDERLESS", form.ClientSize == form.Size);
            Check("NATIVE_SNAP_STYLES", (GetWindowLong(form.Handle,-16)&0x00CF0000)==0x00CF0000);
            var corner=form.PointToScreen(new Point(2,2));
            var packed=new IntPtr(unchecked((int)((uint)(ushort)corner.X|((uint)(ushort)corner.Y<<16))));
            Check("NATIVE_CORNER_RESIZE", SendMessage(form.Handle,0x0084,IntPtr.Zero,packed).ToInt32()==13);
            form.Refresh(); Application.DoEvents();
            if (output != null) using (var bitmap = new Bitmap(form.ClientSize.Width, form.ClientSize.Height)) {
                // The real native client capture excludes the system non-client frame.
                // Use an on-screen fixture: off-screen clipped child HWNDs do not print reliably.
                using(var graphics=Graphics.FromImage(bitmap)) {
                    IntPtr dc=graphics.GetHdc();try {PrintWindow(form.Handle,dc,1);} finally {graphics.ReleaseHdc(dc);}
                }
                bitmap.Save(Path.Combine(output, (codex ? "environment" : "software") + "-" + (dark ? "dark" : "light") + "-" + width + "-client.png"), ImageFormat.Png);
            }
            if (desktop) { form.StartPosition=FormStartPosition.CenterScreen;form.Location=new Point(180,120);Application.Run(form); }
        }
    }
    [STAThread] static int Main(string[] args)
    {
        UiTheme.EnableDpiAwareness(); Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
        desktop=Path.GetFileNameWithoutExtension(Application.ExecutablePath).Contains("Preview");
        if(desktop){
            using(var log=new StreamWriter(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"desktop-preview-log.txt"))) {
                log.AutoFlush=true;Console.SetOut(log);
                try { Render(null,false,true,1160);return 0; }
                catch(Exception error) { log.WriteLine(error.ToString());return 1; }
            }
        }
        string output = args.Length > 0 ? args[0] : null;
        if (output != null) Directory.CreateDirectory(output);
        Render(output, false, true, 1160); Render(output, true, true, 1160);
        Render(output, false, false, 1160); Render(output, true, false, 740);
        UiTheme.Set(false);
        using(var dialog=new BusyWarningDialog(true)) {
            IntPtr handle=dialog.Handle;
            Check("BUSY_DIALOG_BORDERLESS",dialog.FormBorderStyle==FormBorderStyle.None);
            Check("BUSY_DIALOG_WAIT_RETAINED",dialog.Controls.OfType<Button>().Any(b=>b.Text=="继续等待"));
            Check("BUSY_DIALOG_CANNOT_CLOSE_FROM_CAPTION",dialog.Controls.Find("modernCaption",false).Single().Controls.OfType<Button>().All(b=>b.AccessibleName!="关闭"||!b.Visible));
        }
        Console.WriteLine("TOTAL="+count); Console.WriteLine("SYSTEM_CHANGES=0"); return 0;
    }
}
