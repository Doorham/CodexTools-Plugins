using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows.Forms;
using EnvironmentDetector;

internal static class GitReadinessUiTests
{
    static int count;
    static void Check(string name, CheckResult result, string text, bool enabled)
    {
        using (var form = new MainForm(true, false, false)) {
            var flags = BindingFlags.Instance | BindingFlags.NonPublic;
            typeof(MainForm).GetField("lastResults", flags).SetValue(form, new List<CheckResult> { result });
            typeof(MainForm).GetMethod("UpdateRepairButtons", flags).Invoke(form, null);
            var button = (Button)typeof(MainForm).GetField("repairButton", flags).GetValue(form);
            bool pass = button.Text == text && button.Enabled == enabled;
            Console.WriteLine(name + "=" + (pass ? "PASS" : "FAIL") + " [actual: " + button.Text + "]");
            if (!pass) throw new Exception(name);
            count++;
        }
    }

    [STAThread] static int Main()
    {
        Check("INSTALLED_GIT_MISSING_IDENTITY_NOT_READY", new CheckResult { Name="Git", Level=CheckLevel.Warning, Installed=true, AutoFixId=GitSetup.ConfigurationId }, "仍有项目待配置", false);
        Check("GIT_PARSE_FAILURE_NOT_READY", new CheckResult { Name="Git", Level=CheckLevel.Warning, Installed=true }, "仍有项目待配置", false);
        Check("GIT_SMOKE_FAILURE_NOT_READY", new CheckResult { Name="Git", Level=CheckLevel.Warning, Installed=true, Detail="commit self-test failed" }, "仍有项目待配置", false);
        Check("MISSING_GIT_STILL_AUTO_INSTALLABLE", new CheckResult { Name="Git", Level=CheckLevel.Missing }, "一键自动补全", true);
        Check("VERIFIED_GIT_IS_READY", new CheckResult { Name="Git", Level=CheckLevel.Ready, Installed=true }, "已配置齐全", false);
        Check("ENCODING_WARNING_NOT_READY", Detector.EvaluateEncoding("65001","65001","65001",false), "仍有项目待配置", false);
        Console.WriteLine("TOTAL=" + count);
        Console.WriteLine("SYSTEM_CHANGES=0");
        return 0;
    }
}
