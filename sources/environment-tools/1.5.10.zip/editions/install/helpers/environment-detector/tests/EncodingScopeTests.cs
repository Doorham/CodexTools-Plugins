﻿using System;
using System.Collections.Generic;
using System.IO;
using EnvironmentDetector;

internal static class EncodingScopeTests
{
    private static int checks;
    private static void Check(string name, bool result)
    {
        Console.WriteLine(name + "=" + (result ? "PASS" : "FAIL"));
        if (!result) throw new Exception(name);
        checks++;
    }

    public static int Main(string[] args)
    {
        Check("GBK_ACCEPTED", Detector.EvaluateEncoding("936", "936", "10008", false).Level == CheckLevel.Ready);
        Check("BIG5_ACCEPTED", Detector.EvaluateEncoding("950", "950", "10002", false).Level == CheckLevel.Ready);
        Check("MISSING_CODEPAGE_WARNING", Detector.EvaluateEncoding(null, null, null, false).Level == CheckLevel.Warning);
        Check("UTF8_WARNING", Detector.EvaluateEncoding("65001", "65001", "65001", true).Level == CheckLevel.Warning);
        Check("PARTIAL_UTF8_WARNING", Detector.EvaluateEncoding("936", "65001", "10008", false).Level == CheckLevel.Warning);
        Check("BACKUP_GUIDANCE", Detector.EvaluateEncoding("65001", "65001", "65001", true).Guidance.Contains("恢复原编码"));
        Check("NO_BACKUP_NATIVE_RESET_GUIDANCE", Detector.EvaluateEncoding("65001", "65001", "65001", false).Guidance.Contains("拨乱反正"));
        var input = new List<CheckResult> {
            Detector.EvaluateEncoding("65001", "65001", "65001", true),
            new CheckResult { Name = "UTF-8 全球语言支持", Level = CheckLevel.Warning },
            new CheckResult { Name = "PyYAML", Level = CheckLevel.Missing }
        };
        var targets = RepairEngine.GetAutomaticItems(input);
        Check("NO_GLOBAL_UTF8_REPAIR", targets.Count == 1 && targets[0] == "PyYAML");
        string parent = Environment.GetEnvironmentVariable("PYTHONIOENCODING");
        var run = Detector.Run(args[0], "-X utf8 -c \"import sys; print('中文路径/序列帧'); print(sys.flags.utf8_mode)\"", 10000);
        Console.WriteLine("SCOPED_PYTHON_RESULT=" + run.ExitCode + ": " + run.Output);
        Check("SCOPED_PYTHON_CHINESE", run.ExitCode == 0 && run.Output.Contains("中文路径/序列帧") && run.Output.Contains("1"));
        Check("PARENT_ENV_UNCHANGED", Environment.GetEnvironmentVariable("PYTHONIOENCODING") == parent);
        var missing = Detector.Run(Path.Combine(Path.GetTempPath(), "missing-python.exe"), "-X utf8", 1000);
        Check("LAUNCH_ERROR_REPORTED", missing.ExitCode != 0);
        Check("BACKUP_FORMAT", Utf8Repair.RunFileFormatSelfTest(args[1]));
        string root = Path.Combine(Path.GetTempPath(), "EncodingScope-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root);
        try
        {
            Check("NO_BACKUP_NO_RESTORE", Utf8Repair.SelectOriginalBackup(root) == null);
            string original = Path.Combine(root, "utf8-original-20260101.ini");
            string utf8 = Path.Combine(root, "utf8-original-20260102.ini");
            string invalid = Path.Combine(root, "utf8-original-20260103.ini");
            File.WriteAllText(original, "schemaVersion=1\nACP=936\nOEMCP=936\nMACCP=10008");
            File.WriteAllText(utf8, "schemaVersion=1\nACP=65001\nOEMCP=65001\nMACCP=65001");
            File.WriteAllText(invalid, "schemaVersion=1\nACP=99999\nOEMCP=936\nMACCP=10008");
            Check("SKIP_NEWER_UTF8_AND_INVALID", Utf8Repair.SelectOriginalBackup(root) == original);
            File.Delete(original);
            Check("REJECT_UTF8_AND_INVALID_ONLY", Utf8Repair.SelectOriginalBackup(root) == null);
        }
        finally { Directory.Delete(root, true); }
        Check("REPORT_VERSION", ReportBuilder.Build(input, true).Contains("v" + System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString(3)));
        var live = (CheckResult)typeof(Detector).GetMethod("CheckUtf8", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static).Invoke(null, null);
        Console.WriteLine("LIVE_ENCODING=" + live.Level + ": " + live.Detail);
        Console.WriteLine("TOTAL=" + checks);
        return 0;
    }
}
