using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.Win32;
using EnvironmentDetector;

internal static class NativeEncodingRepairTests
{
    const string Initiator = "S-1-5-21-111-222-333-1001";
    const string Administrator = "S-1-5-21-111-222-333-1002";
    static int checks;
    static void Check(string name, bool passed) { Console.WriteLine(name + "=" + (passed ? "PASS" : "FAIL")); if (!passed) throw new Exception(name); checks++; }
    static EncodingResetValue V(string value) { return new EncodingResetValue { Exists = value != null, Kind = RegistryValueKind.String, Value = value }; }
    static EncodingResetSnapshot State(bool utf8, string locale = "zh-CN")
    {
        var state = new EncodingResetSnapshot { UserSid = Initiator, MachineName = "synthetic-machine", LocaleName = locale, EffectiveACP = utf8 ? 65001u : 936u, EffectiveOEMCP = utf8 ? 65001u : 936u };
        state.Values["ACP"] = V(utf8 ? "65001" : "936"); state.Values["OEMCP"] = V(utf8 ? "65001" : "936"); state.Values["MACCP"] = V(utf8 ? "65001" : "10008");
        state.Values["UserPythonUtf8"] = V(null); state.Values["MachinePythonUtf8"] = V(null);
        state.NativeCodePages["ACP"] = locale == "en-US" ? 1252u : 936u;
        state.NativeCodePages["OEMCP"] = locale == "en-US" ? 437u : 936u;
        state.NativeCodePages["MACCP"] = locale == "en-US" ? 10000u : 10008u;
        return state;
    }
    static EncodingResetSnapshot Copy(EncodingResetSnapshot state)
    {
        var copy = new EncodingResetSnapshot { UserSid = state.UserSid, MachineName = state.MachineName, LocaleName = state.LocaleName, LocaleChangePending = state.LocaleChangePending, EffectiveACP = state.EffectiveACP, EffectiveOEMCP = state.EffectiveOEMCP };
        foreach (var pair in state.Values) copy.Values[pair.Key] = pair.Value.Copy();
        foreach (var pair in state.NativeCodePages) copy.NativeCodePages[pair.Key] = pair.Value;
        return copy;
    }
    sealed class Fixture
    {
        public EncodingResetSnapshot State;
        public int Writes, Backups, Reads;
        public bool AdministratorRights = true;
        public Action BeforeBackup;
        public Action<string, EncodingResetValue> OnWrite;
        public Func<EncodingResetSnapshot> OnRead;
        public List<EncodingResetChange> SavedChanges;
        public EncodingResetSnapshot SavedState;
        public Fixture(EncodingResetSnapshot state) { State = state; }
        public EncodingResetSnapshot Read() { Reads++; return OnRead == null ? Copy(State) : OnRead(); }
        public RepairResult Run()
        {
            return NativeEncodingRepair.ExecuteCore(Read, (state, changes) => {
                Backups++; if (BeforeBackup != null) BeforeBackup(); SavedState = Copy(state); SavedChanges = changes; return "synthetic-backup.json";
            }, (key, value) => { Writes++; if (OnWrite != null) OnWrite(key, value); else State.Values[key] = value.Copy(); }, AdministratorRights, key => State.Values[key].Copy());
        }
    }
    public static int Main()
    {
        try {
            var f = new Fixture(State(false)); f.AdministratorRights = false;
            Check("NATIVE_NONADMIN_NOOP", f.Run().Success && f.Writes == 0 && f.Backups == 0);
            f = new Fixture(State(true)); var result = f.Run();
            Check("ZH_CN_NATIVE_FROM_LOCALE", result.Success && f.State.Values["ACP"].Value == "936" && f.State.Values["MACCP"].Value == "10008");
            Check("SUCCESS_REPORTS_RESTART_NOT_ALREADY_ACTIVE", result.Detail.Contains("重启后才生效") && f.State.EffectiveACP == 65001);
            Check("BACKUP_BEFORE_VALUES_PRESERVED", f.Backups == 1 && f.SavedState.Values["ACP"].Value == "65001" && f.SavedState.UserSid == Initiator);
            Check("NON_HISTORICAL_TARGET_TEXT", result.Detail.Contains("当前系统区域") && result.Detail.Contains("原生默认值"));
            f = new Fixture(State(true, "en-US")); result = f.Run();
            Check("EN_US_NOT_HARDCODED_936", result.Success && f.State.Values["ACP"].Value == "1252" && f.State.Values["OEMCP"].Value == "437" && f.State.Values["MACCP"].Value == "10000");
            f = new Fixture(State(true)); f.State.Values["OEMCP"] = V("437"); f.State.EffectiveOEMCP = 437;
            Check("PARTIAL_UTF8_PRESERVES_NON65001", f.Run().Success && f.State.Values["OEMCP"].Value == "437" && f.Writes == 2);
            foreach (uint alias in new uint[] { 0, 1, 2, 65001, 99999 }) {
                f = new Fixture(State(true)); f.State.NativeCodePages["ACP"] = alias;
                Check("INVALID_TARGET_" + alias, !f.Run().Success && f.Writes == 0 && f.Backups == 0);
            }
            f = new Fixture(State(true)); f.State.Values["ACP"].Kind = RegistryValueKind.DWord;
            Check("INVALID_SOURCE_TYPE_BLOCKS", !f.Run().Success && f.Writes == 0);
            f = new Fixture(State(true)); f.State.Values["MACCP"] = V(null);
            Check("MISSING_SOURCE_CODEPAGE_BLOCKS", !f.Run().Success && f.Writes == 0);
            f = new Fixture(State(true)); f.State.LocaleChangePending = true;
            Check("PENDING_LOCALE_BLOCKS_WRITES", !f.Run().Success && f.Writes == 0 && f.Backups == 0);
            f = new Fixture(State(true)); f.State.EffectiveACP = 936;
            Check("PENDING_CODEPAGE_BLOCKS_WRITES", !f.Run().Success && f.Writes == 0 && f.Backups == 0);
            f = new Fixture(State(false)); f.State.EffectiveACP = 65001; result = f.Run();
            Check("CONFIGURED_NATIVE_PENDING_RESTART_REPORTED", result.Success && result.Detail.Contains("尚未生效") && f.Writes == 0);
            f = new Fixture(State(true)); f.AdministratorRights = false;
            Check("CHANGE_REQUIRES_ADMIN", !f.Run().Success && f.Writes == 0 && f.Backups == 0);
            f = new Fixture(State(true)); f.BeforeBackup = () => { throw new IOException("synthetic backup failure"); };
            Check("BACKUP_FAILURE_PREVENTS_ALL_WRITES", !f.Run().Success && f.Writes == 0);
            f = new Fixture(State(true)); var before = f;
            f.BeforeBackup = () => before.State.Values["ACP"] = V("1252");
            Check("CONCURRENT_PREWRITE_STATE_PRESERVED", !f.Run().Success && f.Writes == 0 && f.State.Values["ACP"].Value == "1252");
            f = new Fixture(State(true)); before = f;
            f.BeforeBackup = () => before.State.LocaleName = "en-US";
            Check("CONCURRENT_LOCALE_CHANGE_BLOCKS", !f.Run().Success && f.Writes == 0);
            f = new Fixture(State(true)); before = f;
            f.BeforeBackup = () => before.State.UserSid = Administrator;
            Check("ELEVATION_ACCOUNT_CANNOT_REPLACE_INITIATOR", !f.Run().Success && f.Writes == 0);
            f = new Fixture(State(false)); f.State.Values["UserPythonUtf8"] = V("1"); f.State.Values["MachinePythonUtf8"] = V("1"); result = f.Run();
            Check("BOTH_PERSISTENT_FORCED_VALUES_REMOVED", result.Success && !f.State.Values["UserPythonUtf8"].Exists && !f.State.Values["MachinePythonUtf8"].Exists && f.Writes == 2);
            Check("ENV_ONLY_REOPEN_NOT_SYSTEM_CHANGE", result.Detail.Contains("系统码页未改动") && !result.Detail.Contains("重启后才生效"));
            Check("USER_AND_MACHINE_SCOPE_EXPLAINED", result.Detail.Contains("发起操作用户") && result.Detail.Contains("系统级") && f.SavedState.UserSid == Initiator);
            foreach (string value in new[] { "0", "", "true", "01", "utf8", "%OTHER%" }) {
                f = new Fixture(State(false)); f.State.Values["UserPythonUtf8"] = V(value); f.State.Values["MachinePythonUtf8"] = V(value);
                Check("OTHER_OVERRIDE_PRESERVED_" + value, f.Run().Success && f.Writes == 0 && f.Backups == 0);
            }
            f = new Fixture(State(false)); f.State.Values["UserPythonUtf8"] = V("1"); f.State.Values["UserPythonUtf8"].Kind = RegistryValueKind.ExpandString;
            Check("EXPANDSTRING_ONE_REMOVED_WITH_KIND_BACKED_UP", f.Run().Success && f.SavedState.Values["UserPythonUtf8"].Kind == RegistryValueKind.ExpandString);
            f = new Fixture(State(false)); f.State.Values["UserPythonUtf8"] = V("1"); f.State.Values["UserPythonUtf8"].Kind = RegistryValueKind.DWord;
            Check("INVALID_OVERRIDE_TYPE_BLOCKS", !f.Run().Success && f.Writes == 0);
            f = new Fixture(State(true)); before = f;
            f.OnWrite = (key, value) => { if (key == "OEMCP" && value.Value == "936") throw new IOException("synthetic denied"); before.State.Values[key] = value.Copy(); };
            result = f.Run();
            Check("PARTIAL_WRITE_FAILURE_ROLLS_BACK_PRIOR_ITEM", !result.Success && f.State.Values["ACP"].Value == "65001" && f.State.Values["OEMCP"].Value == "65001");
            f = new Fixture(State(true)); before = f;
            f.OnWrite = (key, value) => { before.State.Values[key] = value.Copy(); if (key == "ACP" && value.Value == "936") throw new IOException("synthetic failure after write"); };
            Check("WRITE_THEN_THROW_IS_ROLLED_BACK", !f.Run().Success && f.State.Values["ACP"].Value == "65001");
            f = new Fixture(State(true)); before = f;
            f.OnWrite = (key, value) => { if (key != "ACP") before.State.Values[key] = value.Copy(); };
            Check("READBACK_FAILURE_PRESERVES_ALREADY_ORIGINAL", !f.Run().Success && f.State.Values["ACP"].Value == "65001" && f.Writes == 1);
            f = new Fixture(State(true)); before = f;
            f.OnWrite = (key, value) => { before.State.Values[key] = V("1252"); throw new IOException("synthetic concurrent new value"); };
            result = f.Run();
            Check("ROLLBACK_DOES_NOT_OVERWRITE_CONCURRENT_VALUE", !result.Success && f.State.Values["ACP"].Value == "1252" && f.Writes == 1 && result.Detail.Contains("未覆盖"));
            f = new Fixture(State(true)); before = f;
            f.OnWrite = (key, value) => { if (value.Value == "65001") throw new IOException("synthetic rollback denied"); before.State.Values[key] = value.Copy(); throw new IOException("synthetic after write"); };
            result = f.Run();
            Check("ROLLBACK_FAILURE_IS_REPORTED", !result.Success && result.Detail.Contains("回滚失败") && f.State.Values["ACP"].Value == "936");
            f = new Fixture(State(false)); f.State.Values["UserPythonUtf8"] = V("1"); before = f;
            f.OnWrite = (key, value) => { before.State.Values[key] = value.Copy(); if (!value.Exists) throw new IOException("synthetic clear then failure"); };
            Check("USER_CLEAR_FAILURE_RESTORES_ORIGINAL", !f.Run().Success && f.State.Values["UserPythonUtf8"].Value == "1");
            f = new Fixture(State(true)); before = f;
            f.OnWrite = (key, value) => { before.State.Values[key] = value.Copy(); if (key == "ACP" && value.Value == "936") before.State.LocaleChangePending = true; };
            Check("LOCALE_SWITCH_DURING_TRANSACTION_ROLLS_BACK", !f.Run().Success && f.State.Values["ACP"].Value == "65001" && f.State.Values["OEMCP"].Value == "65001");
            f = new Fixture(State(true)); before = f;
            f.OnRead = () => { if (before.Writes > 0) throw new IOException("synthetic user hive or locale query failure"); return Copy(before.State); };
            result = f.Run();
            Check("SNAPSHOT_FAILURE_DOES_NOT_BLOCK_MACHINE_ROLLBACK", !result.Success && f.State.Values["ACP"].Value == "65001" && f.Writes == 2 && result.Detail.Contains("均已保留或恢复"));
            f = new Fixture(State(true)); before = f;
            f.BeforeBackup = () => before.State.NativeCodePages["ACP"] = 1252;
            Check("NATIVE_TARGET_CHANGED_DURING_BACKUP_BLOCKS", !f.Run().Success && f.Writes == 0);
            bool invalidSid = false; try { NativeEncodingRepair.ValidateSid(Initiator + "\\Environment"); } catch { invalidSid = true; }
            Check("SID_PATH_INJECTION_REJECTED", invalidSid);
            Check("ORIGINAL_SID_PRESERVED", NativeEncodingRepair.ValidateSid(Initiator) == Initiator && NativeEncodingRepair.ValidateSid(Administrator) != Initiator);
            Console.WriteLine("TOTAL=" + checks); Console.WriteLine("SYSTEM_CHANGES=0"); return 0;
        }
        catch (Exception ex) { Console.WriteLine(ex.ToString()); return 1; }
    }
}
