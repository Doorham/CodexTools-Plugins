﻿using System;
using System.Net;
using EnvironmentDetector;
internal static class DownloadResolutionTests
{
    private static int checks;
    private static void Check(string name, bool passed)
    {
        Console.WriteLine(name + "=" + (passed ? "PASS" : "FAIL"));
        if (!passed) throw new Exception(name);
        checks++;
    }
    public static int Main()
    {
        // Matches the actual GitHub assets array shape; JavaScriptSerializer materializes it as ArrayList.
        string json = @"{""assets"":[
            {""name"":""PowerShell-7.6.8-win-arm64.msi"",""browser_download_url"":""https://example.invalid/arm64.msi""},
            {""name"":""PowerShell-7.6.8-win-x64.zip"",""browser_download_url"":""https://example.invalid/x64.zip""},
            {""name"":""PowerShell-7.6.8-win-x64.msi"",""browser_download_url"":""https://example.invalid/x64.msi""},
            {""name"":""PowerShell-7.6.8-win-x86.msi"",""browser_download_url"":""https://example.invalid/x86.msi""}]}";
        Check("ARRAYLIST_SELECTS_X64_MSI", DirectDownloader.ParsePowerShellReleaseUrl(json) == "https://example.invalid/x64.msi");
        Check("NO_ASSETS_RETURNS_EMPTY", DirectDownloader.ParsePowerShellReleaseUrl("{}") == null);
        Check("EMPTY_ASSETS_RETURNS_EMPTY", DirectDownloader.ParsePowerShellReleaseUrl("{\"assets\":[]}") == null);
        Check("OTHER_ARCH_NOT_SELECTED", DirectDownloader.ParsePowerShellReleaseUrl("{\"assets\":[{\"name\":\"PowerShell-win-arm64.msi\",\"browser_download_url\":\"https://example.invalid/arm64.msi\"}]}") == null);
        Check("MISSING_URL_NOT_SELECTED", DirectDownloader.ParsePowerShellReleaseUrl("{\"assets\":[{\"name\":\"PowerShell-win-x64.msi\"}]}") == null);
        bool legacyDefault;
        Check("LEGACY_TLS_DEFAULT_DISABLED", AppContext.TryGetSwitch("Switch.System.Net.DontEnableSystemDefaultTlsVersions", out legacyDefault) && !legacyDefault);
        Check("OS_DEFAULT_TLS", ServicePointManager.SecurityProtocol == SecurityProtocolType.SystemDefault);
        bool resolutionError = false;
        try { DirectDownloader.ResolveUrl(new DownloadRegistry.DownloadInfo { DynamicUrl = true, DirectUrl = "not an absolute URL" }); }
        catch (Exception) { resolutionError = true; }
        Check("RESOLUTION_ERROR_IS_NOT_SWALLOWED", resolutionError);
        DownloadRegistry.DownloadInfo sdk, desktop;
        Check("SDK_PORTAL_MIRROR_REMOVED", DownloadRegistry.TryGet(Detector.DotNetSdkName, out sdk) && String.IsNullOrEmpty(sdk.MirrorUrl) && !String.IsNullOrEmpty(sdk.DirectUrl));
        Check("DESKTOP_PORTAL_MIRROR_REMOVED", DownloadRegistry.TryGet(Detector.DesktopRuntimeName, out desktop) && String.IsNullOrEmpty(desktop.MirrorUrl) && !String.IsNullOrEmpty(desktop.DirectUrl));
        Console.WriteLine("TOTAL=" + checks);
        return 0;
    }
}