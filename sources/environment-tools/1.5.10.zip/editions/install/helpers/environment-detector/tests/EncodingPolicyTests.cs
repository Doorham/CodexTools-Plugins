﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using EnvironmentDetector;

internal static class EncodingPolicyTests
{
    static int checks;
    static void Check(string name, bool passed)
    {
        Console.WriteLine(name + "=" + (passed ? "PASS" : "FAIL"));
        if (!passed) throw new Exception(name);
        checks++;
    }
    [STAThread] public static int Main()
    {
        string root = Path.Combine(Path.GetTempPath(), "CodexTools-EncodingPolicy-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root);
        try {
            Check("NATIVE_CODEPAGE_REMAINS_READY", EncodingPolicy.IncludeUserPolicy(Detector.EvaluateEncoding("936", "936", "10008", false), null).Level == CheckLevel.Ready);
            CheckResult forced = EncodingPolicy.IncludeUserPolicy(Detector.EvaluateEncoding("936", "936", "10008", false), "1");
            Check("USER_OVERRIDE_IS_REPORTED", forced.Level == CheckLevel.Warning && forced.Detail.Contains("用户级 PYTHONUTF8=1"));
            Check("USER_OVERRIDE_HAS_SETTINGS_ACTION", forced.AutoFixId == EncodingPolicy.SettingsAction);
            Check("NATIVE_PYTHON_OVERRIDE_ZERO_IS_PRESERVED", EncodingPolicy.IncludeUserPolicy(Detector.EvaluateEncoding("936", "936", "10008", false), "0").Level == CheckLevel.Ready);
            CheckResult system = EncodingPolicy.IncludeUserPolicy(Detector.EvaluateEncoding("65001", "65001", "65001", false), null);
            Check("GLOBAL_UTF8_HAS_SETTINGS_ACTION_WITHOUT_BACKUP", system.AutoFixId == EncodingPolicy.SettingsAction);
            Check("NO_AUTOMATIC_GLOBAL_ENCODING_REPAIR", RepairEngine.GetAutomaticItems(new[] { forced, system }).Count == 0);
            string value = "1"; int changed = 0;
            string impossible = Path.Combine(root, "ordinary-file"); File.WriteAllText(impossible, "fixture");
            var blocked = EncodingPolicy.RemoveUserOverride(() => value, () => { value = null; changed++; }, prior => value = prior, impossible, "String");
            Check("BACKUP_FAILURE_PREVENTS_CLEAR", !blocked.Success && value == "1" && changed == 0);
            string backups = Path.Combine(root, "Backups");
            var cleared = EncodingPolicy.RemoveUserOverride(() => value, () => { value = null; changed++; }, prior => value = prior, backups, "String");
            Check("EXPLICIT_CLEAR_SUCCEEDS", cleared.Success && value == null && changed == 1);
            string saved = File.ReadAllText(Directory.GetFiles(backups).Single());
            Check("SCOPED_BACKUP_EXISTS", saved.Contains("PYTHONUTF8") && saved.Contains("CurrentUser") && saved.Contains("\"value\":\"1\""));
            value = "0";
            Check("NONFORCED_VALUE_NOT_REMOVED", EncodingPolicy.RemoveUserOverride(() => value, () => changed++, prior => value = prior, backups, "String").Success && value == "0" && changed == 1);
            value = "1";
            var failed = EncodingPolicy.RemoveUserOverride(() => value, () => { value = null; throw new IOException("synthetic post-clear failure"); }, prior => value = prior, backups, "String");
            Check("CLEAR_FAILURE_RESTORES_ORIGINAL", !failed.Success && value == "1");
            var concurrent = EncodingPolicy.RemoveUserOverride(() => value, () => value = "0", prior => value = prior, backups, "String");
            Check("CONCURRENT_NONEMPTY_VALUE_PRESERVED", !concurrent.Success && value == "0");
            Check("MACHINE_OVERRIDE_IS_REPORTED", EncodingPolicy.IncludeMachinePolicy(Detector.EvaluateEncoding("936", "936", "10008", false), "1").Level == CheckLevel.Warning);
            Check("MACHINE_ZERO_REMAINS_READY", EncodingPolicy.IncludeMachinePolicy(Detector.EvaluateEncoding("936", "936", "10008", false), "0").Level == CheckLevel.Ready);
            foreach (var sample in new[] { system, Detector.EvaluateEncoding("936", "936", "10008", false) }) {
                using (var card = new ResultCard(sample, false)) {
                    card.Width = 1000;
                    var buttons = card.Controls.OfType<Button>().ToArray();
                    Check("ENCODING_SETTINGS_RETAINED_" + sample.Level, buttons.Any(b => b.Text == "系统编码设置"));
                    Check("NATIVE_RESET_VISIBLE_" + sample.Level, buttons.Count(b => b.Text == "拨乱反正") == 1);
                    var reset = buttons.Single(b => b.Text == "拨乱反正");
                    var settings = buttons.Single(b => b.Text == "系统编码设置");
                    Check("ENCODING_BUTTONS_FIT_" + sample.Level, reset.Right < settings.Left && settings.Right < card.Width && reset.Bottom < card.Height);
                }
            }
        }
        finally {
            string target = Path.GetFullPath(root), temp = Path.GetFullPath(Path.GetTempPath()).TrimEnd('\\') + "\\";
            if (target.StartsWith(temp, StringComparison.OrdinalIgnoreCase) && Path.GetFileName(target).StartsWith("CodexTools-EncodingPolicy-") && Directory.Exists(target)) Directory.Delete(target, true);
        }
        Check("TEMP_STATE_CLEANED", !Directory.Exists(root));
        Console.WriteLine("TOTAL=" + checks); return 0;
    }
}
