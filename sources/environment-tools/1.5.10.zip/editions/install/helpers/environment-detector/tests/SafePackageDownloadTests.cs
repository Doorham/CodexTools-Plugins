﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using EnvironmentDetector;

internal static class SafePackageDownloadTests
{
    private static string root;
    private static int passed;

    private static int Main()
    {
        root = Path.Combine(Path.GetTempPath(), "CodexTools-download-tests-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root);
        try
        {
            SignaturesAndLengths();
            ExistingFilesAndCleanup();
            NetworkCases();
            Console.WriteLine("PASS: " + passed + " assertions; only synthetic bytes and loopback HTTP were used.");
            return 0;
        }
        catch (Exception ex) { Console.Error.WriteLine(ex); return 1; }
        finally { try { Directory.Delete(root, true); } catch { } }
    }

    private static void Check(bool condition, string name)
    {
        if (!condition) throw new Exception("FAIL: " + name);
        passed++;
        Console.WriteLine("PASS: " + name);
    }

    private static byte[] Bytes(params byte[] prefix)
    {
        byte[] result = new byte[32];
        Buffer.BlockCopy(prefix, 0, result, 0, prefix.Length);
        return result;
    }

    private static void SignaturesAndLengths()
    {
        string[] names = { "a.exe", "a.msi", "a.7z", "a.zip", "empty.zip", "spanned.zip" };
        byte[][] contents = {
            Bytes(0x4d, 0x5a), Bytes(0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1),
            Bytes(0x37, 0x7a, 0xbc, 0xaf, 0x27, 0x1c), Bytes(0x50, 0x4b, 0x03, 0x04),
            Bytes(0x50, 0x4b, 0x05, 0x06), Bytes(0x50, 0x4b, 0x07, 0x08) };
        for (int index = 0; index < names.Length; index++)
        {
            var file = new PackageDownloadFile(root, names[index]);
            File.WriteAllBytes(file.TemporaryPath, contents[index]);
            string saved = file.Complete(contents[index].Length);
            Check(File.Exists(saved) && !File.Exists(file.TemporaryPath), "signature and atomic promotion: " + names[index]);
            Check(file.Cleanup() == null && File.Exists(saved), "cleanup preserves promoted file: " + names[index]);
        }
        var html = new PackageDownloadFile(root, "html.exe");
        File.WriteAllText(html.TemporaryPath, "<!DOCTYPE html><html>Error</html>");
        ExpectInvalid(html, -1, "HTML masquerading as EXE is rejected");
        var shortHeader = new PackageDownloadFile(root, "short.msi");
        File.WriteAllBytes(shortHeader.TemporaryPath, new byte[] { 0xd0, 0xcf });
        ExpectInvalid(shortHeader, 2, "truncated signature is rejected");
        var empty = new PackageDownloadFile(root, "zero.exe");
        ExpectInvalid(empty, 0, "empty response is rejected");
        var mismatch = new PackageDownloadFile(root, "length.exe");
        File.WriteAllBytes(mismatch.TemporaryPath, contents[0]);
        ExpectInvalid(mismatch, 33, "Content-Length mismatch is rejected");
        var extra = new PackageDownloadFile(root, "extra.exe");
        File.WriteAllBytes(extra.TemporaryPath, contents[0]);
        ExpectInvalid(extra, 31, "extra bytes are rejected");
        var unknown = new PackageDownloadFile(root, "unknown.exe");
        File.WriteAllBytes(unknown.TemporaryPath, contents[0]);
        Check(File.Exists(unknown.Complete(-1)), "unknown Content-Length permits valid magic");
        bool invalidName = false;
        try { new PackageDownloadFile(root, "../escape.exe"); }
        catch (ArgumentException) { invalidName = true; }
        Check(invalidName, "directory traversal filename is rejected");
        bool invalidType = false;
        try { new PackageDownloadFile(root, "script.ps1"); }
        catch (ArgumentException) { invalidType = true; }
        Check(invalidType, "unvalidated file type is rejected");
    }

    private static void ExpectInvalid(PackageDownloadFile file, long length, string name)
    {
        bool rejected = false;
        try { file.Complete(length); }
        catch (InvalidDataException) { rejected = true; }
        Check(rejected, name);
        Check(file.Cleanup() == null && !File.Exists(file.TemporaryPath), "failed package temp is removed: " + name);
    }

    private static void ExistingFilesAndCleanup()
    {
        string existing = Path.Combine(root, "same.exe");
        byte[] original = Bytes(0x4d, 0x5a, 0x19);
        File.WriteAllBytes(existing, original);
        File.WriteAllBytes(Path.Combine(root, "same (1).exe"), original);
        var first = new PackageDownloadFile(root, "same.exe");
        var second = new PackageDownloadFile(root, "same.exe");
        Check(first.TemporaryPath != second.TemporaryPath && first.TemporaryPath.EndsWith(".part"), "concurrent attempts own unique .part files");
        File.WriteAllBytes(first.TemporaryPath, Bytes(0x4d, 0x5a, 0x22));
        string saved = first.Complete(32);
        Check(Path.GetFileName(saved) == "same (2).exe", "existing package names are skipped");
        Check(File.ReadAllBytes(existing)[2] == 0x19, "existing complete package is never overwritten");
        string unrelated = Path.Combine(root, "someone-else.part");
        File.WriteAllText(unrelated, "keep");
        Check(second.Cleanup() == null && File.Exists(unrelated) && File.Exists(saved), "cleanup touches only its own temporary file");
        var locked = new PackageDownloadFile(root, "locked.exe");
        using (var stream = new FileStream(locked.TemporaryPath, FileMode.Open, FileAccess.Write, FileShare.None))
            Check(locked.Cleanup() != null && File.Exists(locked.TemporaryPath), "locked temporary file reports cleanup failure explicitly");
        Check(locked.Cleanup() == null && !File.Exists(locked.TemporaryPath), "cleanup succeeds after temporary file is unlocked");
        var raceFirst = new PackageDownloadFile(root, "race.exe");
        var raceSecond = new PackageDownloadFile(root, "race.exe");
        File.WriteAllBytes(raceFirst.TemporaryPath, Bytes(0x4d, 0x5a, 0x11));
        File.WriteAllBytes(raceSecond.TemporaryPath, Bytes(0x4d, 0x5a, 0x22));
        Task<string> moveFirst = Task.Run(() => raceFirst.Complete(32));
        Task<string> moveSecond = Task.Run(() => raceSecond.Complete(32));
        Task.WaitAll(moveFirst, moveSecond);
        Check(moveFirst.Result != moveSecond.Result && File.ReadAllBytes(moveFirst.Result)[2] == 0x11 &&
            File.ReadAllBytes(moveSecond.Result)[2] == 0x22, "simultaneous promotions preserve both complete packages");
    }

    private static void NetworkCases()
    {
        byte[] executable = Bytes(0x4d, 0x5a);
        NetworkResult good = RunNetwork(delegate(NetworkStream stream) {
            Header(stream, executable.Length); stream.Write(executable, 0, executable.Length);
        }, 2000, 2000, 0);
        Check(good.Saved && good.Expected == 32 && good.Reason == null, "loopback complete response captures Content-Length and saves");

        NetworkResult noLength = RunNetwork(delegate(NetworkStream stream) {
            Header(stream, null); stream.Write(executable, 0, executable.Length);
        }, 2000, 2000, 0);
        Check(noLength.Saved && noLength.Expected == -1, "loopback response without Content-Length saves by magic");

        NetworkResult slow = RunNetwork(delegate(NetworkStream stream) {
            Header(stream, executable.Length);
            for (int offset = 0; offset < executable.Length; offset += 4) {
                stream.Write(executable, offset, 4); stream.Flush(); Thread.Sleep(130);
            }
        }, 200, 650, 0);
        Check(slow.Saved && slow.ElapsedMilliseconds > 700, "active slow transfer outlives response timeout without a total duration cutoff");

        NetworkResult headerTimeout = RunNetwork(delegate(NetworkStream stream) { Thread.Sleep(1200); }, 300, 2000, 0);
        Check(!headerTimeout.Saved && headerTimeout.Reason.IndexOf("响应超时") >= 0 && !headerTimeout.TempExists,
            "server response timeout gives a reason and removes its .part");

        NetworkResult idle = RunNetwork(delegate(NetworkStream stream) {
            Header(stream, 32); stream.Write(executable, 0, 2); stream.Flush(); Thread.Sleep(1200);
        }, 2000, 300, 0);
        Check(!idle.Saved && idle.Reason.IndexOf("没有收到数据") >= 0 && !idle.TempExists,
            "stalled body triggers idle timeout and removes its .part");

        NetworkResult cancelled = RunNetwork(delegate(NetworkStream stream) {
            Header(stream, 32); stream.Write(executable, 0, 2); stream.Flush(); Thread.Sleep(1200);
        }, 2000, 2000, 200);
        Check(!cancelled.Saved && cancelled.Reason == "已取消下载。" && !cancelled.TempExists,
            "user cancellation aborts promptly and removes its .part");

        NetworkResult truncated = RunNetwork(delegate(NetworkStream stream) {
            Header(stream, 128); stream.Write(executable, 0, executable.Length);
        }, 2000, 2000, 0);
        Check(!truncated.Saved && !String.IsNullOrWhiteSpace(truncated.Reason) && !truncated.TempExists,
            "truncated HTTP body never becomes a final package");

        NetworkResult page = RunNetwork(delegate(NetworkStream stream) {
            byte[] html = Encoding.ASCII.GetBytes("<html>Bad download link</html>");
            Header(stream, html.Length); stream.Write(html, 0, html.Length);
        }, 2000, 2000, 0);
        Check(!page.Saved && page.Reason.IndexOf("预期") >= 0 && !page.TempExists,
            "HTTP 200 error page never becomes an EXE");

        NetworkResult partial = RunNetwork(delegate(NetworkStream stream) {
            Header(stream, executable.Length, "206 Partial Content", "Content-Range: bytes 0-31/128\r\n");
            stream.Write(executable, 0, executable.Length);
        }, 2000, 2000, 0);
        Check(!partial.Saved && partial.Reason.IndexOf("分段") >= 0 && !partial.TempExists,
            "HTTP 206 partial package is rejected despite valid magic and matching segment length");

        NetworkResult cancelledBeforeStart = RunNetwork(delegate(NetworkStream stream) { Thread.Sleep(400); },
            2000, 2000, 0, true);
        Check(!cancelledBeforeStart.Saved && cancelledBeforeStart.Reason == "已取消下载。" && !cancelledBeforeStart.TempExists,
            "cancel before background startup is not reset by StartDownload");

        SynchronizationContext previous = SynchronizationContext.Current;
        var blockedUi = new HoldingSynchronizationContext();
        try {
            SynchronizationContext.SetSynchronizationContext(blockedUi);
            NetworkResult background = RunNetwork(delegate(NetworkStream stream) {
                Header(stream, executable.Length); stream.Write(executable, 0, executable.Length);
            }, 2000, 2000, 0, false, true);
            Check(background.Saved && !background.TempExists && blockedUi.Posts == 0,
                "background start completes validation and cleanup without a pumping UI context");
        } finally { SynchronizationContext.SetSynchronizationContext(previous); }
    }

    private sealed class HoldingSynchronizationContext : SynchronizationContext
    {
        public int Posts;
        public override void Post(SendOrPostCallback callback, object state) { Interlocked.Increment(ref Posts); }
    }

    private static void Header(NetworkStream stream, int? length, string status = "200 OK", string extraHeaders = "")
    {
        string header = "HTTP/1.1 " + status + "\r\nConnection: close\r\nContent-Type: application/octet-stream\r\n" +
            (length.HasValue ? "Content-Length: " + length.Value + "\r\n" : "") + extraHeaders + "\r\n";
        byte[] bytes = Encoding.ASCII.GetBytes(header);
        stream.Write(bytes, 0, bytes.Length);
        stream.Flush();
    }

    private sealed class NetworkResult
    {
        public bool Saved;
        public bool TempExists;
        public long Expected;
        public long ElapsedMilliseconds;
        public string Reason;
    }

    private static NetworkResult RunNetwork(Action<NetworkStream> serve, int responseTimeout, int idleTimeout, int cancelAfter,
        bool cancelBeforeStart = false, bool startOnWorker = false)
    {
        var listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        int port = ((IPEndPoint)listener.LocalEndpoint).Port;
        var server = new Thread(delegate() {
            try {
                using (TcpClient socket = listener.AcceptTcpClient())
                using (NetworkStream stream = socket.GetStream()) {
                    socket.ReceiveTimeout = 3000;
                    int matched = 0;
                    while (matched < 4) {
                        int value = stream.ReadByte();
                        if (value < 0) return;
                        int expected = matched == 0 || matched == 2 ? 13 : 10;
                        matched = value == expected ? matched + 1 : (value == 13 ? 1 : 0);
                    }
                    serve(stream);
                }
            } catch (IOException) { } catch (SocketException) { } catch (ObjectDisposedException) { }
        });
        server.IsBackground = true;
        server.Start();
        var package = new PackageDownloadFile(root, "network-" + Guid.NewGuid().ToString("N") + ".exe");
        var result = new NetworkResult();
        var done = new ManualResetEvent(false);
        Stopwatch elapsed = Stopwatch.StartNew();
        using (var client = new SafeDownloadWebClient(responseTimeout, idleTimeout))
        {
            // Never allow the machine proxy to redirect these loopback-only tests.
            client.Proxy = null;
            client.DownloadFileCompleted += delegate(object sender, AsyncCompletedEventArgs e) {
                result.Expected = client.ExpectedContentLength;
                result.Reason = client.FailureReason(e);
                try {
                    if (result.Reason == null) { package.Complete(client.ExpectedContentLength); result.Saved = true; }
                } catch (Exception ex) { result.Reason = ex.Message; }
                finally {
                    string cleanup = package.Cleanup();
                    if (cleanup != null) result.Reason = (result.Reason ?? "") + cleanup;
                    result.TempExists = File.Exists(package.TemporaryPath);
                    done.Set();
                }
            };
            System.Threading.Timer cancel = null;
            try {
                if (cancelBeforeStart) client.CancelDownload();
                Action start = delegate { client.StartDownload(new Uri("http://127.0.0.1:" + port + "/package.exe"), package.TemporaryPath); };
                if (startOnWorker) Task.Run(start); else start();
                if (cancelAfter > 0) cancel = new System.Threading.Timer(delegate { client.CancelDownload(); }, null, cancelAfter, Timeout.Infinite);
                if (!done.WaitOne(10000)) throw new Exception("Loopback test exceeded 10 seconds.");
            } finally { if (cancel != null) cancel.Dispose(); listener.Stop(); }
        }
        elapsed.Stop();
        result.ElapsedMilliseconds = elapsed.ElapsedMilliseconds;
        server.Join(2000);
        done.Dispose();
        return result;
    }
}
