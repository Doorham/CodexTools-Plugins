﻿using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using EnvironmentDetector;

internal static class GitSetupTests
{
    static int count;
    static void Check(string name, bool passed)
    {
        Console.WriteLine(name + "=" + (passed ? "PASS" : "FAIL"));
        if (!passed) throw new Exception(name);
        count++;
    }
    static string Hash(string file)
    {
        using (var hash = SHA256.Create()) return Convert.ToBase64String(hash.ComputeHash(File.ReadAllBytes(file)));
    }
    [STAThread] public static int Main()
    {
        try { return RunTests(); }
        catch (Exception ex) { Console.WriteLine("TEST_ERROR_TYPE=" + ex.GetType().FullName); Console.WriteLine("TEST_ERROR=" + ex.Message); return 1; }
    }
    static int RunTests()
    {
        string git = GitSetup.FindGit();
        Check("INDEPENDENT_GIT_FOUND", git != null);
        string tempRoot = Path.GetFullPath(Path.GetTempPath());
        string root = Path.Combine(tempRoot, "CodexTools-GitTests-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root);
        string config = Path.Combine(root, "global.gitconfig");
        string previous = Environment.GetEnvironmentVariable("GIT_CONFIG_GLOBAL");
        string previousSystem = Environment.GetEnvironmentVariable("GIT_CONFIG_NOSYSTEM");
        string previousDirectory = Environment.GetEnvironmentVariable("GIT_DIR");
        try {
            Environment.SetEnvironmentVariable("GIT_CONFIG_GLOBAL", config);
            Environment.SetEnvironmentVariable("GIT_CONFIG_NOSYSTEM", "1");
            File.WriteAllText(config, "# preserve this comment\n[core]\n\tquotepath = false\n", new UTF8Encoding(false));
            string original = Hash(config);
            Check("NATIVE_VERSION_WORKS", GitSetup.Run(git, "--version").ExitCode == 0);
            Check("GLOBAL_CONFIG_PATH_IS_NATIVE_GIT_PATH", GitSetup.GlobalFile(git) == config);
            CheckResult missing = GitSetup.Check(git, "fixture");
            Check("MISSING_IDENTITY_IS_WARNING", missing.Level == CheckLevel.Warning);
            Check("MISSING_IDENTITY_HAS_CONFIGURATION_BUTTON", missing.AutoFixId == GitSetup.ConfigurationId);
            Check("MISSING_IDENTITY_DOES_NOT_REINSTALL", !RepairEngine.GetAutomaticItems(new[] { missing }).Contains("Git"));
            var postInstall = (RepairResult)typeof(RepairEngine).GetMethod("FromCommand", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic)
                .Invoke(null, new object[] { "Git", new CommandResult { ExitCode = 0, Output = "installer returned success" } });
            Check("INSTALLER_SUCCESS_IS_NOT_FALSE_READY", !postInstall.Success);
            Check("INSTALLER_REPORTS_PENDING_IDENTITY", postInstall.Detail.Contains("提交姓名或邮箱尚未配置"));
            Check("ACTUALLY_MISSING_GIT_STILL_INSTALLABLE", RepairEngine.GetAutomaticItems(new[] { new CheckResult { Name = "Git", Level = CheckLevel.Missing } }).Contains("Git"));
            Check("NO_HOST_IDENTITY_GUESSED", !GitSetup.ReadIdentity(git).Complete);
            Check("UNCONFIGURED_COMMIT_FAILS", GitSetup.CommitSmoke(git) != null);
            Check("EMPTY_NAME_REFUSED", !GitSetup.Save(git, "", "fixture@example.invalid").Success);
            Check("INVALID_EMAIL_REFUSED", !GitSetup.Save(git, "Fixture", "invalid").Success);
            Check("NEWLINE_INJECTION_REFUSED", !GitSetup.Save(git, "Fixture\nuser.email=other", "fixture@example.invalid").Success);
            Check("INVALID_INPUT_LEAVES_CONFIG_UNCHANGED", Hash(config) == original);
            File.WriteAllText(config + ".lock", "existing native Git lock");
            Check("EXISTING_GIT_LOCK_BLOCKS_SAVE", !GitSetup.Save(git, "Fixture", "fixture@example.invalid").Success);
            Check("FOREIGN_GIT_LOCK_PRESERVED", File.ReadAllText(config + ".lock") == "existing native Git lock");
            Check("LOCK_FAILURE_LEAVES_CONFIG_UNCHANGED", Hash(config) == original);
            File.Delete(config + ".lock");
            string escapedName = "测试 \\\" 名称\\";
            Check("QUOTED_CONFIG_ARGUMENT_ROUNDTRIP", GitSetup.Run(git, "config --global --replace-all user.name " + GitSetup.Quote(escapedName)).ExitCode == 0 && GitSetup.ReadIdentity(git).Name == escapedName);
            string beforeNormalized = Hash(config);
            Check("NORMALIZED_IDENTITY_IS_NOT_SILENTLY_APPLIED", !GitSetup.Save(git, escapedName, "fixture@example.invalid").Success && Hash(config) == beforeNormalized);
            RepairResult saved = GitSetup.Save(git, "测试 Name", "fixture@example.invalid");
            if (!saved.Success) Console.WriteLine("SAVE_FAILURE_DETAIL=" + saved.Detail);
            Check("UNICODE_IDENTITY_SAVE", saved.Success);
            Check("EXACT_NAME_ROUNDTRIP", GitSetup.ReadIdentity(git).Name == "测试 Name");
            Check("EXACT_EMAIL_ROUNDTRIP", GitSetup.ReadIdentity(git).Email == "fixture@example.invalid");
            Check("UNRELATED_CONFIG_PRESERVED", GitSetup.Run(git, "config --global --get core.quotepath").Output == "false");
            Check("COMMENT_PRESERVED", File.ReadAllText(config).Contains("# preserve this comment"));
            Check("SUCCESS_CLEANS_LOCK", !File.Exists(config + ".lock"));
            Check("CONFIGURED_COMMIT_PASSES", GitSetup.CommitSmoke(git) == null);
            Check("CONFIGURED_IDENTITY_IS_READY", GitSetup.Check(git, "fixture").Level == CheckLevel.Ready);
            Check("FIXTURE_LEGACY_LOG_ENCODING_CONFIGURED", GitSetup.Run(git, "config --global i18n.logOutputEncoding GBK").ExitCode == 0);
            Check("VALIDATION_METADATA_USES_SCOPED_UTF8", GitSetup.CommitSmoke(git) == null && GitSetup.Run(git, "config --global --get i18n.logOutputEncoding").Output == "GBK");
            string hook = Path.Combine(root, "hooks"); Directory.CreateDirectory(hook);
            File.WriteAllText(Path.Combine(hook, "pre-commit"), "#!/bin/sh\nexit 77\n");
            Check("FIXTURE_HOOK_CONFIGURED", GitSetup.Run(git, "config --global core.hooksPath " + GitSetup.Quote(hook)).ExitCode == 0);
            string external = Path.Combine(root, "external"); Directory.CreateDirectory(external);
            Environment.SetEnvironmentVariable("GIT_DIR", external);
            Check("INHERITED_REPOSITORY_AND_HOOK_IGNORED", GitSetup.CommitSmoke(git) == null);
            Check("EXTERNAL_REPOSITORY_UNTOUCHED", Directory.GetFileSystemEntries(external).Length == 0);
            Environment.SetEnvironmentVariable("GIT_DIR", previousDirectory);
            Check("GLOBAL_WORKTREE_CONFIGURED", GitSetup.Run(git, "config --global core.worktree " + GitSetup.Quote(external)).ExitCode == 0);
            Check("GLOBAL_WORKTREE_CANNOT_REDIRECT_TEST", GitSetup.CommitSmoke(git) == null && Directory.GetFileSystemEntries(external).Length == 0);
            File.WriteAllText(config, "[malformed\n"); original = Hash(config);
            Check("CONFIG_PARSE_ERROR_IS_NOT_MISSING_IDENTITY", GitSetup.Check(git, "fixture").AutoFixId == null);
            Check("CONFIG_PARSE_ERROR_DOES_NOT_REINSTALL", !RepairEngine.GetAutomaticItems(new[] { GitSetup.Check(git, "fixture") }).Contains("Git"));
            Check("MALFORMED_CONFIG_SAVE_FAILS", !GitSetup.Save(git, "Fixture", "fixture@example.invalid").Success);
            Check("MALFORMED_CONFIG_PRESERVED", Hash(config) == original);
            Check("FAILED_STAGE_CLEANS_OWN_LOCK", !File.Exists(config + ".lock"));
            File.WriteAllText(config, "[core]\n\tquotepath = false\n", new UTF8Encoding(false)); original = Hash(config);
            string oldTmp = Environment.GetEnvironmentVariable("TMP");
            string notDirectory = Path.Combine(root, "not-a-temp-directory"); File.WriteAllText(notDirectory, "fixture");
            try {
                Environment.SetEnvironmentVariable("TMP", notDirectory);
                Check("VALIDATION_TEMP_FAILURE_PREVENTS_APPLY", !GitSetup.Save(git, "Fixture", "fixture@example.invalid").Success);
                Check("VALIDATION_TEMP_FAILURE_PRESERVES_LIVE_FILE", Hash(config) == original);
                Check("VALIDATION_TEMP_FAILURE_CLEANS_LOCK", !File.Exists(config + ".lock"));
            }
            finally { Environment.SetEnvironmentVariable("TMP", oldTmp); }
            string include = Path.Combine(root, "included.gitconfig");
            File.WriteAllText(include, "[user]\n\tname = Included Override\n", new UTF8Encoding(false));
            File.WriteAllText(config, "[user]\n\tname = Prior\n\temail = prior@example.invalid\n[include]\n\tpath = " + include.Replace('\\','/') + "\n", new UTF8Encoding(false)); original = Hash(config);
            Check("INCLUDE_OVERRIDE_PREVENTS_WRONG_IDENTITY", !GitSetup.Save(git, "Fixture", "fixture@example.invalid").Success);
            Check("INCLUDE_FAILURE_PRESERVES_LIVE_FILE", Hash(config) == original);
            File.Delete(config);
            Check("FRESH_CONFIG_CREATION", GitSetup.Save(git, "Fixture", "fixture@example.invalid").Success);
            File.Delete(config);
            Application.EnableVisualStyles();
            using (var dialog = new GitIdentityDialog(git)) {
                Check("DIALOG_STARTS_WITH_EMPTY_IDENTITY", dialog.Controls.OfType<TextBox>().All(t => t.Text == ""));
                TextBox[] fields = dialog.Controls.OfType<TextBox>().OrderBy(t => t.Top).ToArray();
                fields[0].Text = "Dialog Test"; fields[1].Text = "dialog-test@example.invalid";
                Button save = dialog.Controls.OfType<Button>().Single(b => b.Text == "保存并验证");
                IntPtr handle = dialog.Handle;
                typeof(Button).GetMethod("OnClick", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic).Invoke(save, new object[] { EventArgs.Empty });
                DateTime timeout = DateTime.UtcNow.AddSeconds(15);
                while (dialog.DialogResult != DialogResult.OK && DateTime.UtcNow < timeout) { Application.DoEvents(); Thread.Sleep(20); }
                Check("DIALOG_SAVE_BUTTON_COMPLETES", dialog.DialogResult == DialogResult.OK);
                Check("DIALOG_SAVES_EXPLICIT_TEST_VALUES", GitSetup.ReadIdentity(git).Name == "Dialog Test");
            }
            using (var card = new ResultCard(missing, false))
                Check("CARD_SHOWS_IDENTITY_ACTION", card.Controls.OfType<Button>().Any(b => b.Text == "配置提交身份"));
        }
        finally {
            Environment.SetEnvironmentVariable("GIT_CONFIG_GLOBAL", previous);
            Environment.SetEnvironmentVariable("GIT_CONFIG_NOSYSTEM", previousSystem);
            Environment.SetEnvironmentVariable("GIT_DIR", previousDirectory);
            string full = Path.GetFullPath(root);
            if (full.StartsWith(tempRoot.TrimEnd('\\') + "\\", StringComparison.OrdinalIgnoreCase) && Path.GetFileName(full).StartsWith("CodexTools-GitTests-") && Directory.Exists(full)) {
                foreach (string file in Directory.GetFiles(full,"*",SearchOption.AllDirectories)) File.SetAttributes(file,File.GetAttributes(file)&~FileAttributes.ReadOnly);
                Directory.Delete(full, true);
            }
        }
        Check("TEMPORARY_STATE_REMOVED", !Directory.Exists(root));
        Console.WriteLine("TOTAL=" + count);
        return 0;
    }
}
