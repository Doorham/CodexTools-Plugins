﻿[CmdletBinding()]
param([string]$PythonPath)
$ErrorActionPreference = 'Stop'
$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..\..\..')).Path
$output = Join-Path $repoRoot 'artifacts\environment-detector-1.5.10'
$csc = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
New-Item -ItemType Directory -Path $output -Force | Out-Null
$resources = @(Get-ChildItem (Join-Path $PSScriptRoot 'assets\fluent-emoji-3d') -Filter '*.png' | Sort-Object Name | ForEach-Object {
    $names = @('Moon01Full','Moon02WaningGibbous','Moon03LastQuarter','Moon04WaningCrescent','Moon05New','Moon06WaxingCrescent','Moon07FirstQuarter','Moon08WaxingGibbous')
    '/resource:' + $_.FullName + ',EnvironmentDetector.' + $names[[int]$_.Name.Substring(0,2)-1] + '.png'
})
$references = @('/reference:System.dll','/reference:System.Core.dll','/reference:System.Drawing.dll','/reference:System.Windows.Forms.dll','/reference:System.Web.Extensions.dll')
$source = @(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'src') -Filter '*.cs' | Sort-Object Name | ForEach-Object { $_.FullName })
& $csc /nologo /optimize+ /target:winexe /platform:anycpu "/out:$output\EnvironmentDetector.exe" @references @resources @source
if ($LASTEXITCODE -ne 0) { throw 'EnvironmentDetector compilation failed.' }
foreach ($name in @('PowerShellSetupTests','DownloadResolutionTests','GitSetupTests','EncodingPolicyTests','ScanPlanTests','SafePackageDownloadTests','EncodingScopeTests','NativeEncodingRepairTests','GitReadinessUiTests','ModernUiTests')) {
    & $csc /nologo /target:exe ("/main:"+$name) ("/out:"+$output+'\'+$name+'.exe') @references @resources @source (Join-Path $PSScriptRoot ('tests\'+$name+'.cs'))
    if ($LASTEXITCODE -ne 0) { throw ($name+' compilation failed.') }
    $testExe = Join-Path $output ($name+'.exe')
    if ($name -eq 'EncodingScopeTests') {
        if (-not $PythonPath) { continue }
        & $testExe $PythonPath (Join-Path $output 'backup-format.txt') | Tee-Object -FilePath (Join-Path $output ($name+'.txt'))
    } elseif ($name -eq 'ModernUiTests') {
        & $testExe (Join-Path $output 'previews') | Tee-Object -FilePath (Join-Path $output ($name+'.txt'))
    } else {
        & $testExe | Tee-Object -FilePath (Join-Path $output ($name+'.txt'))
    }
    if ($LASTEXITCODE -ne 0) { throw ($name+' failed.') }
}
Get-FileHash -LiteralPath (Join-Path $output 'EnvironmentDetector.exe')
