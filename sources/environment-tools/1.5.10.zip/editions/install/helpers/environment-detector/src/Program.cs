﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: AssemblyVersion("1.5.10.0")]
[assembly: AssemblyFileVersion("1.5.10.0")]

namespace EnvironmentDetector
{
    internal enum CheckLevel
    {
        Ready,
        Warning,
        Missing
    }

    internal sealed class CheckResult
    {
        public string Importance;
        public string Group;
        public string Name;
        public CheckLevel Level;
        public string Detail;
        public string Guidance;
        public bool Installed;
        public string AutoFixId;   // 非空 = 本项支持一键自动修复（见 AutoFixEngine）
    }

    internal sealed class CommandResult
    {
        public int ExitCode;
        public string Output;
    }

    internal sealed class RepairResult
    {
        public string Name;
        public bool Success;
        public string Detail;
    }

    internal sealed class PythonProbe
    {
        public string Executable;
        public string PrefixArguments;
        public string Version;
        public int Major;
        public int Minor;
        public bool Available;
    }

    internal sealed class VisualStudioProbe
    {
        public bool Installed;
        public bool PythonWorkload;
        public string InstallationPath;
        public string Version;
    }

    internal sealed class CodePageSnapshot
    {
        public string CreatedUtc;
        public string ACP;
        public string OEMCP;
        public string MACCP;
    }

    internal static class Detector
    {
        public const string LibreOfficeName = "LibreOffice（无头渲染）";
        public const string DotNetSdkName = ".NET 8+ SDK";
        public const string DesktopRuntimeName = ".NET 8 桌面运行时（x64）";
        public const string WebView2Name = "WebView2 运行时";

        [DllImport("kernel32.dll")]
        private static extern uint GetACP();
        [DllImport("kernel32.dll")]
        private static extern uint GetOEMCP();

        sealed class CheckStep
        {
            public string Name;
            public Func<CheckResult> Run;
        }

        static List<CheckStep> CreateScanSteps()
        {
            var visualStudio = new Lazy<VisualStudioProbe>(FindVisualStudio);
            var vsCode = new Lazy<string>(FindVsCodeExecutable);
            var cursor = new Lazy<string>(FindCursorExecutable);
            var pyCharm = new Lazy<string>(FindPyCharmExecutable);
            PythonProbe python = null;
            Func<PythonProbe> runtime = () => python ?? (python = GetPythonForRepair());
            return new List<CheckStep> {
                new CheckStep { Name = "PowerShell 7", Run = CheckPowerShell },
                new CheckStep { Name = "Windows Terminal", Run = CheckWindowsTerminal },
                new CheckStep { Name = "编码兼容与 UTF-8 范围", Run = CheckUtf8 },
                new CheckStep { Name = "开发工具", Run = () => CheckDevelopmentTool(vsCode.Value, cursor.Value, pyCharm.Value, visualStudio.Value) },
                new CheckStep { Name = "基础开发环境", Run = delegate { return CheckPython(out python); } },
                new CheckStep { Name = DesktopRuntimeName, Run = CheckDesktopRuntime },
                new CheckStep { Name = WebView2Name, Run = CheckWebView2 },
                new CheckStep { Name = DotNetSdkName, Run = CheckDotNetSdk },
                new CheckStep { Name = "编辑器集成", Run = () => CheckDevelopmentIntegration(runtime(), vsCode.Value, cursor.Value, pyCharm.Value, visualStudio.Value) },
                new CheckStep { Name = "Git", Run = CheckGit },
                new CheckStep { Name = "FFmpeg（含 FFprobe）", Run = CheckFfmpeg },
                new CheckStep { Name = LibreOfficeName, Run = CheckLibreOffice },
                new CheckStep { Name = "PyYAML", Run = () => CheckPyYaml(runtime()) },
                new CheckStep { Name = "yt-dlp", Run = () => CheckYtDlp(runtime()) }
            };
        }

        internal static string[] ScanNames(bool codexMode)
        {
            return CreateScanSteps().Where(step => codexMode != RepairEngine.SoftwareCheckItems.Contains(step.Name)).Select(step => step.Name).ToArray();
        }

        public static List<CheckResult> ScanAll()
        {
            return CreateScanSteps().Select(step => step.Run()).ToList();
        }

        internal static List<CheckResult> ScanForMode(bool codexMode, Action<string, int, int> progress = null)
        {
            var steps = CreateScanSteps().Where(step => codexMode != RepairEngine.SoftwareCheckItems.Contains(step.Name)).ToList();
            var results = new List<CheckResult>();
            for (int index = 0; index < steps.Count; index++) {
                if (progress != null) progress(steps[index].Name, index + 1, steps.Count);
                results.Add(steps[index].Run());
            }
            return results;
        }

        internal static CheckResult CheckPowerShell() { return PowerShellSetup.Check(); }

        private static CheckResult CheckWindowsTerminal()
        {
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string alias = Path.Combine(local, "Microsoft", "WindowsApps", "wt.exe");
            string package = Path.Combine(local, "Packages", "Microsoft.WindowsTerminal_8wekyb3d8bbwe");
            string executable = FindExecutables("wt.exe").FirstOrDefault();
            if (File.Exists(alias) || Directory.Exists(package) || !String.IsNullOrEmpty(executable))
            {
                string location = File.Exists(alias) ? alias : (Directory.Exists(package) ? "Microsoft Store 应用包" : executable);
                return Ready("终端环境", "Windows Terminal", "已安装 · " + location, "无需处理。");
            }
            return Missing("终端环境", "Windows Terminal", "没有发现 Windows Terminal。",
                "可在本工具中通过 winget 一键安装。");
        }

        private static CheckResult CheckUtf8()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Nls\CodePage"))
                {
                    string acp = Convert.ToString(key == null ? null : key.GetValue("ACP"));
                    string oem = Convert.ToString(key == null ? null : key.GetValue("OEMCP"));
                    string mac = Convert.ToString(key == null ? null : key.GetValue("MACCP"));
                    CheckResult result = EvaluateEncoding(acp, oem, mac, Utf8Repair.CanRestore());
                    EncodingPolicy.IncludeUserPolicy(result, EncodingPolicy.UserPythonUtf8());
                    EncodingPolicy.IncludeMachinePolicy(result, EncodingPolicy.MachinePythonUtf8());
                    if (!String.IsNullOrEmpty(acp) && !String.IsNullOrEmpty(oem) &&
                        (GetACP().ToString() != acp || GetOEMCP().ToString() != oem))
                    {
                        result.Level = CheckLevel.Warning;
                        result.Detail = "系统编码配置与当前进程代码页不同；请重启 Windows 后重新检测。" + result.Detail;
                        result.Guidance = "先保存工作，再择时重启 Windows；本工具不会自动重启。" + result.Guidance;
                    }
                    return result;
                }
            }
            catch (Exception ex)
            {
                return Warning("终端环境", "编码兼容与 UTF-8 范围", "无法读取系统代码页：" + ex.Message,
                    "请检查 Windows 区域与语言设置。");
            }
        }

        internal static CheckResult EvaluateEncoding(string acp, string oem, string mac, bool canRestore)
        {
            string values = "ACP=" + EmptyAsUnknown(acp) + "，OEMCP=" + EmptyAsUnknown(oem) + "，MACCP=" + EmptyAsUnknown(mac);
            const string scope = "UTF-8 文件按 UTF-8 读取；旧 TXT 等按原始 GBK、Big5 等编码重新打开。需要 UTF-8 的流程单独指定，不强制全部软件和文件使用同一编码。";
            if (String.IsNullOrEmpty(acp) || String.IsNullOrEmpty(oem) || String.IsNullOrEmpty(mac))
                return Warning("终端环境", "编码兼容与 UTF-8 范围", "系统代码页信息不完整 · " + values, "请核对 Windows 区域设置；不自动修改。" + scope);
            if (acp == "65001" || oem == "65001" || mac == "65001")
                return Warning("终端环境", "编码兼容与 UTF-8 范围", "系统全局 UTF-8 可能影响旧软件和 GBK 文本 · " + values,
                    (canRestore ? "可点击“恢复原编码”，按本机备份恢复后重启 Windows。" :
                    "可点击“拨乱反正”，备份后切回当前系统区域的原生代码页，再择时重启。") + scope);
            return Ready("终端环境", "编码兼容与 UTF-8 范围", "保留系统原编码，不要求全局 UTF-8 · " + values + "。" + scope,
                "无需修改 Windows 系统代码页。");
        }

        private static CheckResult CheckDevelopmentTool(string vsCode, string cursor, string pyCharm, VisualStudioProbe visualStudio)
        {
            List<string> routes = new List<string>();
            if (!String.IsNullOrEmpty(vsCode))
            {
                string version = FileVersionInfo.GetVersionInfo(vsCode).ProductVersion;
                routes.Add("VS Code " + EmptyAsUnknown(version));
            }
            if (visualStudio.Installed)
                routes.Add("Visual Studio " + EmptyAsUnknown(visualStudio.Version));
            if (!String.IsNullOrEmpty(cursor))
                routes.Add("Cursor " + GetProductVersion(cursor));
            if (!String.IsNullOrEmpty(pyCharm))
                routes.Add("PyCharm " + GetProductVersion(pyCharm));
            if (routes.Count > 0)
                return Ready("开发工具", "开发工具",
                    "已发现：" + String.Join("；", routes.ToArray()) + "。", "无需处理。");
            return Missing("开发工具", "开发工具",
                "没有发现可验证的开发工具。",
                "请用户安装任一种适用的开发工具；当前可验证 VS Code、Visual Studio、Cursor 和 PyCharm。");
        }

        private static CheckResult CheckDevelopmentIntegration(PythonProbe python, string vsCode, string cursor,
            string pyCharm, VisualStudioProbe visualStudio)
        {
            if (!python.Available)
                return EvaluateIntegrationState(python, new List<string>(), "没有可运行的 Python，无法完成编辑器集成。");

            string pythonExtension = FindEditorExtension("ms-python.python-", ".vscode", ".vscode-insiders");
            bool vsCodeRouteReady = false;
            string vsCodeRouteDetail = null;
            if (!String.IsNullOrEmpty(vsCode) && !String.IsNullOrEmpty(pythonExtension))
            {
                bool manifestConfirmed = IsMicrosoftPythonExtension(pythonExtension);
                vsCodeRouteReady = manifestConfirmed;
                vsCodeRouteDetail = manifestConfirmed
                    ? "VS Code 的 Microsoft Python 扩展清单验证通过"
                    : "VS Code 扩展目录存在，但 Microsoft Python 扩展清单验证失败";
            }

            string cursorPythonExtension = FindEditorExtension("ms-python.python-", ".cursor");
            bool cursorRouteReady = !String.IsNullOrEmpty(cursor) && IsMicrosoftPythonExtension(cursorPythonExtension);
            string cursorRouteDetail = null;
            if (!String.IsNullOrEmpty(cursor))
                cursorRouteDetail = cursorRouteReady
                    ? "Cursor 的 Microsoft Python 扩展清单验证通过"
                    : "Cursor 已安装，但没有验证到 Microsoft Python 扩展";

            bool pyCharmRouteReady = !String.IsNullOrEmpty(pyCharm);
            bool visualStudioRouteReady = visualStudio.Installed && visualStudio.PythonWorkload;
            List<string> readyRoutes = new List<string>();
            if (vsCodeRouteReady)
            {
                string pylance = FindEditorExtension("ms-python.vscode-pylance-", ".vscode", ".vscode-insiders");
                readyRoutes.Add(vsCodeRouteDetail + (String.IsNullOrEmpty(pylance) ? "" : "，Pylance 已安装"));
            }
            if (visualStudioRouteReady)
                readyRoutes.Add("Visual Studio Python 开发工作负载已安装");
            if (cursorRouteReady)
                readyRoutes.Add(cursorRouteDetail);
            if (pyCharmRouteReady)
                readyRoutes.Add("PyCharm 自带 Python 项目与解释器集成功能");

            if (readyRoutes.Count == 0)
            {
                string found = !String.IsNullOrEmpty(vsCodeRouteDetail) ? vsCodeRouteDetail + "；" : "";
                if (visualStudio.Installed && !visualStudio.PythonWorkload)
                    found += "Visual Studio 未安装 Python 开发工作负载。";
                if (!String.IsNullOrEmpty(cursorRouteDetail))
                    found += cursorRouteDetail + "。";
                if (String.IsNullOrEmpty(found)) found = "没有发现可用的 Python 编辑器集成路线。";
                // VS Code 已安装但 Microsoft Python 扩展缺失/未通过验证 → 可一键自动安装扩展。
                string autoFixId = !String.IsNullOrEmpty(vsCode) && !vsCodeRouteReady
                    ? "vscode_python_extension" : null;
                return EvaluateIntegrationState(python, readyRoutes, found, autoFixId);
            }

            return EvaluateIntegrationState(python, readyRoutes, null);
        }

        private static CheckResult EvaluateIntegrationState(PythonProbe python, List<string> readyRoutes, string problemDetail)
        {
            return EvaluateIntegrationState(python, readyRoutes, problemDetail, null);
        }

        private static CheckResult EvaluateIntegrationState(PythonProbe python, List<string> readyRoutes, string problemDetail, string autoFixId)
        {
            if (python == null || !python.Available)
                return Missing("编辑器集成", "编辑器集成",
                    String.IsNullOrWhiteSpace(problemDetail) ? "没有可运行的 Python，无法完成编辑器集成。" : problemDetail,
                    "请先安装 Python 3.11+，再完成所用开发工具的 Python 集成配置。");
            if (readyRoutes == null || readyRoutes.Count == 0)
            {
                string guidance = String.Equals(autoFixId, "vscode_python_extension", StringComparison.OrdinalIgnoreCase)
                    ? "可点击“自动配置”由本工具安装 VS Code 的 Microsoft Python 扩展；或手动安装：打开 VS Code → 扩展面板 → 搜索 “Python” 安装 Microsoft 官方扩展，再按 Ctrl+Shift+P 选择解释器。"
                    : "请为所用开发工具配置 Python 集成；支持验证 VS Code/Cursor 的 Microsoft Python 扩展、Visual Studio Python 工作负载或 PyCharm 内置集成。";
                return new CheckResult
                {
                    Importance = "必需",
                    Group = "编辑器集成",
                    Name = "编辑器集成",
                    Level = CheckLevel.Missing,
                    Detail = String.IsNullOrWhiteSpace(problemDetail) ? "没有发现可用的 Python 编辑器集成路线。" : problemDetail,
                    Guidance = guidance,
                    AutoFixId = autoFixId,
                };
            }
            bool versionReady = python.Major > 3 || (python.Major == 3 && python.Minor >= 11);
            string detail = String.Join("；", readyRoutes.ToArray()) + "；" + python.Version + " 可运行。";
            if (!versionReady)
                return Warning("编辑器集成", "编辑器集成", detail,
                    "基础联动已具备，但 Python 版本低于公司最低要求 3.11，请先升级 Python。");
            return Ready("编辑器集成", "编辑器集成", detail,
                "基础联动条件合格；具体项目首次打开时仍可按工作区选择 Python 解释器。");
        }

        public static CheckResult EvaluateIntegrationForSelfTest(PythonProbe python, bool routeReady)
        {
            return EvaluateIntegrationState(python,
                routeReady ? new List<string> { "模拟编辑器集成验证通过" } : new List<string>(),
                routeReady ? null : "模拟：开发工具存在，但 Python 集成缺失。");
        }

        public static CheckResult EvaluateIntegrationAutoFixForSelfTest(PythonProbe python)
        {
            return EvaluateIntegrationState(python, new List<string>(), "模拟：VS Code 已安装但扩展缺失。", "vscode_python_extension");
        }

        private static VisualStudioProbe FindVisualStudio()
        {
            VisualStudioProbe probe = new VisualStudioProbe();
            string programFilesX86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
            string vswhere = Path.Combine(programFilesX86, "Microsoft Visual Studio", "Installer", "vswhere.exe");
            if (!File.Exists(vswhere)) return probe;

            CommandResult any = Run(vswhere, "-latest -products * -property installationPath", 15000);
            string installation = FirstExistingDirectory(any.Output);
            if (!String.IsNullOrEmpty(installation))
            {
                string devenv = Path.Combine(installation, "Common7", "IDE", "devenv.exe");
                if (File.Exists(devenv))
                {
                    probe.Installed = true;
                    probe.InstallationPath = installation;
                    probe.Version = FileVersionInfo.GetVersionInfo(devenv).ProductVersion;
                }
            }

            CommandResult python = Run(vswhere,
                "-latest -products * -requires Microsoft.VisualStudio.Workload.Python -property installationPath", 15000);
            string pythonInstallation = FirstExistingDirectory(python.Output);
            if (!String.IsNullOrEmpty(pythonInstallation))
            {
                string devenv = Path.Combine(pythonInstallation, "Common7", "IDE", "devenv.exe");
                if (File.Exists(devenv))
                {
                    probe.Installed = true;
                    probe.PythonWorkload = true;
                    probe.InstallationPath = pythonInstallation;
                    probe.Version = FileVersionInfo.GetVersionInfo(devenv).ProductVersion;
                }
            }
            return probe;
        }

        private static string FindVsCodeExecutable()
        {
            List<string> candidates = new List<string>();
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            string programFilesX86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
            AddIfFile(candidates, Path.Combine(local, "Programs", "Microsoft VS Code", "Code.exe"));
            AddIfFile(candidates, Path.Combine(programFiles, "Microsoft VS Code", "Code.exe"));
            AddIfFile(candidates, Path.Combine(programFilesX86, "Microsoft VS Code", "Code.exe"));
            return DistinctPaths(candidates).FirstOrDefault();
        }

        private static string FindCursorExecutable()
        {
            List<string> candidates = new List<string>();
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            string programFilesX86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
            AddIfFile(candidates, Path.Combine(local, "Programs", "Cursor", "Cursor.exe"));
            AddIfFile(candidates, Path.Combine(local, "Programs", "cursor", "Cursor.exe"));
            AddIfFile(candidates, Path.Combine(programFiles, "Cursor", "Cursor.exe"));
            AddIfFile(candidates, Path.Combine(programFilesX86, "Cursor", "Cursor.exe"));
            return DistinctPaths(candidates).FirstOrDefault();
        }

        private static string FindPyCharmExecutable()
        {
            List<string> candidates = new List<string>();
            AddPyCharmFromUninstallRegistry(candidates, Registry.CurrentUser, @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall");
            AddPyCharmFromUninstallRegistry(candidates, Registry.LocalMachine, @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall");
            AddPyCharmFromUninstallRegistry(candidates, Registry.LocalMachine, @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall");

            string[] roots =
            {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "JetBrains"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs")
            };
            foreach (string root in roots)
            {
                foreach (string directory in SafeDirectories(root))
                {
                    string name = Path.GetFileName(directory) ?? "";
                    if (name.IndexOf("PyCharm", StringComparison.OrdinalIgnoreCase) < 0) continue;
                    AddIfFile(candidates, Path.Combine(directory, "bin", "pycharm64.exe"));
                    AddIfFile(candidates, Path.Combine(directory, "bin", "pycharm.exe"));
                }
            }
            return DistinctPaths(candidates).FirstOrDefault();
        }

        private static void AddPyCharmFromUninstallRegistry(List<string> candidates, RegistryKey root, string subKey)
        {
            try
            {
                using (RegistryKey uninstall = root.OpenSubKey(subKey))
                {
                    if (uninstall == null) return;
                    foreach (string childName in uninstall.GetSubKeyNames())
                    {
                        using (RegistryKey child = uninstall.OpenSubKey(childName))
                        {
                            string displayName = Convert.ToString(child == null ? null : child.GetValue("DisplayName"));
                            if (displayName.IndexOf("PyCharm", StringComparison.OrdinalIgnoreCase) < 0) continue;
                            string installLocation = Convert.ToString(child.GetValue("InstallLocation")).Trim().Trim('"');
                            AddIfFile(candidates, Path.Combine(installLocation, "bin", "pycharm64.exe"));
                            AddIfFile(candidates, Path.Combine(installLocation, "bin", "pycharm.exe"));
                            string displayIcon = Convert.ToString(child.GetValue("DisplayIcon"));
                            string iconPath = (displayIcon ?? "").Split(',')[0].Trim().Trim('"');
                            if (Path.GetFileName(iconPath).StartsWith("pycharm", StringComparison.OrdinalIgnoreCase))
                                AddIfFile(candidates, iconPath);
                        }
                    }
                }
            }
            catch { }
        }

        private static string FindEditorExtension(string folderPrefix, params string[] profileDirectories)
        {
            string profile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            foreach (string profileDirectory in profileDirectories)
            {
                string root = Path.Combine(profile, profileDirectory, "extensions");
                if (!Directory.Exists(root)) continue;
                try
                {
                    string match = Directory.GetDirectories(root)
                        .FirstOrDefault(path => Path.GetFileName(path).StartsWith(folderPrefix, StringComparison.OrdinalIgnoreCase));
                    if (!String.IsNullOrEmpty(match)) return match;
                }
                catch { }
            }
            return null;
        }

        private static bool IsMicrosoftPythonExtension(string extensionDirectory)
        {
            if (String.IsNullOrEmpty(extensionDirectory)) return false;
            try
            {
                string manifestPath = Path.Combine(extensionDirectory, "package.json");
                string manifest = File.Exists(manifestPath) ? File.ReadAllText(manifestPath) : "";
                return Regex.IsMatch(manifest, "\\\"publisher\\\"\\s*:\\s*\\\"ms-python\\\"", RegexOptions.IgnoreCase) &&
                    Regex.IsMatch(manifest, "\\\"name\\\"\\s*:\\s*\\\"python\\\"", RegexOptions.IgnoreCase);
            }
            catch { return false; }
        }

        private static string GetProductVersion(string executable)
        {
            try { return EmptyAsUnknown(FileVersionInfo.GetVersionInfo(executable).ProductVersion); }
            catch { return "未知"; }
        }

        private static CheckResult CheckPython(out PythonProbe probe)
        {
            probe = FindPython();
            if (!probe.Available)
                return EvaluatePythonState(probe, false, false, false);
            CommandResult script = Run(probe.Executable,
                JoinArguments(probe.PrefixArguments, "-c \"import sys; print('SCRIPT_OK:' + sys.executable)\""), 15000);
            CommandResult pip = Run(probe.Executable,
                JoinArguments(probe.PrefixArguments, "-m pip --version"), 20000);
            bool venvReady = false;
            string validationDirectory = CreateValidationDirectory("python-venv");
            try
            {
                CommandResult venv = Run(probe.Executable,
                    JoinArguments(probe.PrefixArguments, "-m venv " + QuoteArgument(validationDirectory)), 90000);
                string venvPython = Path.Combine(validationDirectory, "Scripts", "python.exe");
                if (venv.ExitCode == 0 && File.Exists(venvPython))
                {
                    CommandResult venvRun = Run(venvPython, "-c \"print('VENV_OK')\"", 15000);
                    venvReady = venvRun.ExitCode == 0 && (venvRun.Output ?? "").Contains("VENV_OK");
                }
            }
            finally
            {
                SafeDeleteValidationDirectory(validationDirectory);
            }

            bool scriptReady = script.ExitCode == 0 && (script.Output ?? "").Contains("SCRIPT_OK:");
            bool pipReady = pip.ExitCode == 0;
            return EvaluatePythonState(probe, scriptReady, pipReady, venvReady);
        }

        private static CheckResult EvaluatePythonState(PythonProbe probe, bool scriptReady, bool pipReady, bool venvReady)
        {
            if (probe == null || !probe.Available)
                return Missing("基础开发环境", "基础开发环境", "没有发现可正常运行的 Python 3.11+。",
                    "建议用户自行安装 Python 3.11 或更高版本，并勾选加入 PATH。");
            bool versionReady = probe.Major > 3 || (probe.Major == 3 && probe.Minor >= 11);
            bool capabilityReady = scriptReady && pipReady && venvReady;
            string detail = probe.Version + " · " + probe.Executable;
            if (!versionReady)
                return Warning("基础开发环境", "基础开发环境", detail + "；版本低于最低要求 3.11。",
                    "建议用户自行安装 Python 3.11 或更高版本。");
            if (!capabilityReady)
                return Warning("基础开发环境", "基础开发环境",
                    detail + "；真实测试未全部通过：脚本=" + PassFail(scriptReady) +
                    "，pip=" + PassFail(pipReady) + "，venv=" + PassFail(venvReady) + "。",
                    "请修复当前 Python 安装；本模块不会自动重装 Python。");
            return Ready("基础开发环境", "基础开发环境",
                detail + "；脚本、pip 与临时虚拟环境实测通过。", "无需处理。");
        }

        public static CheckResult EvaluatePythonForSelfTest(PythonProbe probe, bool scriptReady, bool pipReady, bool venvReady)
        {
            return EvaluatePythonState(probe, scriptReady, pipReady, venvReady);
        }

        public static CheckResult CheckDesktopRuntime()
        {
            List<string> candidates = FindExecutables("dotnet.exe");
            AddIfFile(candidates, Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "dotnet", "dotnet.exe"));
            string nativeProgramFiles = Environment.GetEnvironmentVariable("ProgramW6432");
            if (!String.IsNullOrEmpty(nativeProgramFiles))
                AddIfFile(candidates, Path.Combine(nativeProgramFiles, "dotnet", "dotnet.exe"));
            string selectedDotnet;
            string desktop = FindX64DesktopRuntime(DistinctPaths(candidates), IsX64Executable,
                candidate => Run(candidate, "--list-runtimes", 15000), out selectedDotnet);
            string detail = ".NET 桌面运行时 8（x64）：" + desktop + "。";
            if (!String.IsNullOrEmpty(selectedDotnet)) detail += " 检测位置：" + selectedDotnet + "。";
            if (desktop != "缺少")
                return Ready(".NET 运行环境", DesktopRuntimeName, detail, "无需处理。");
            return Missing(".NET 运行环境", DesktopRuntimeName, detail,
                "需手动安装：请前往 .NET 官网（dotnet.microsoft.com/download/dotnet）下载 .NET 8 桌面运行时（x64）安装包后自行安装。");
        }

        public static CheckResult CheckWebView2()
        {
            string version = WebView2RuntimeVersion();
            if (version != "缺少") return Ready("桌面应用运行环境", WebView2Name, "已安装 " + version + "。", "无需处理。");
            return Missing("桌面应用运行环境", WebView2Name, "未发现 WebView2 Evergreen Runtime。",
                "可在本页通过软件官方源补全 Microsoft WebView2 Runtime。现成安装包库暂不包含该组件，选用库时不会自动切换下载源。");
        }

        public static string FindX64DesktopRuntime(IEnumerable<string> candidates,
            Func<string, bool> isX64, Func<string, CommandResult> listRuntimes, out string selectedDotnet)
        {
            selectedDotnet = null;
            foreach (string candidate in candidates)
            {
                // UpdreamBridge is published for win-x64; x86 runtimes cannot satisfy it.
                if (!isX64(candidate)) continue;
                CommandResult runtimes = listRuntimes(candidate);
                Match match = Regex.Match(runtimes.Output ?? "", @"(?m)^Microsoft\.WindowsDesktop\.App (8\.\d+\.\d+)(?:\s|$)");
                if (runtimes.ExitCode == 0 && match.Success)
                {
                    selectedDotnet = candidate;
                    return match.Groups[1].Value;
                }
            }
            return "缺少";
        }

        public static bool IsX64Executable(string path)
        {
            try
            {
                using (BinaryReader reader = new BinaryReader(File.OpenRead(path)))
                {
                    if (reader.BaseStream.Length < 64 || reader.ReadUInt16() != 0x5a4d) return false;
                    reader.BaseStream.Position = 0x3c;
                    int peOffset = reader.ReadInt32();
                    if (peOffset < 64 || peOffset > reader.BaseStream.Length - 6) return false;
                    reader.BaseStream.Position = peOffset;
                    return reader.ReadUInt32() == 0x00004550 && reader.ReadUInt16() == 0x8664;
                }
            }
            catch (IOException) { return false; }
            catch (UnauthorizedAccessException) { return false; }
        }

        public static CheckResult CheckDotNetSdk()
        {
            List<string> candidates = FindExecutables("dotnet.exe");
            AddIfFile(candidates, Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "dotnet", "dotnet.exe"));
            foreach (string candidate in DistinctPaths(candidates))
            {
                if (!IsX64Executable(candidate)) continue;
                CommandResult sdks = Run(candidate, "--list-sdks", 15000);
                if (sdks.ExitCode != 0) continue;
                Match match = Regex.Match(sdks.Output ?? "", @"(?m)^((?:[8-9]|[1-9][0-9])\.\d+\.\d+)\s");
                if (match.Success)
                    return Ready(".NET 开发环境", DotNetSdkName, "已安装 " + match.Groups[1].Value + "。", "无需处理。");
            }
            return Missing(".NET 开发环境", DotNetSdkName, "未发现 .NET 8 或更高版本的 SDK。",
                "需手动安装：请前往 .NET 官网（dotnet.microsoft.com/download/dotnet）或国内镜像站下载 .NET 8 SDK 安装包后自行安装，装完重新检测。");
        }

        private static string WebView2RuntimeVersion()
        {
            const string client = @"Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}";
            string[] paths = { @"SOFTWARE\WOW6432Node\" + client, @"SOFTWARE\" + client, @"Software\" + client };
            foreach (RegistryKey root in new[] { Registry.LocalMachine, Registry.CurrentUser })
            {
                foreach (string path in paths)
                {
                    using (RegistryKey key = root.OpenSubKey(path))
                    {
                        string value = key == null ? null : key.GetValue("pv") as string;
                        Version version;
                        if (Version.TryParse(value, out version) && version.CompareTo(new Version(0, 0, 0, 0)) > 0)
                            return value;
                    }
                }
            }
            return "缺少";
        }

        internal static CheckResult CheckGit()
        {
            List<string> candidates = FindExecutables("git.exe");
            string programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            AddIfFile(candidates, Path.Combine(programFiles, "Git", "cmd", "git.exe"));
            AddIfFile(candidates, Path.Combine(local, "Programs", "Git", "cmd", "git.exe"));
            candidates = DistinctPaths(candidates);
            string independent = candidates.FirstOrDefault(path => !IsCodexRuntime(path));
            string bundled = candidates.FirstOrDefault(IsCodexRuntime);
            if (!String.IsNullOrEmpty(independent))
            {
                CommandResult versionRun = Run(independent, "--version", 15000);
                string version = FirstLine(versionRun.Output);
                if (versionRun.ExitCode != 0)
                    return Warning("基础开发环境", "Git", "Git 命令执行失败（退出码 " + versionRun.ExitCode + "）。",
                        "请检查 Git 安装；身份配置不会卸载或重新安装 Git。");
                return GitSetup.Check(independent, version);
            }
            if (!String.IsNullOrEmpty(bundled))
                return Warning("基础开发环境", "Git", "仅发现 Codex 随附 Git；普通终端不一定可用。",
                    "可在本工具中一键安装系统独立的 Git for Windows。");
            return Missing("基础开发环境", "Git", "没有发现 Git for Windows。",
                "可在本工具中一键安装 Git for Windows。");
        }

        private static CheckResult CheckFfmpeg()
        {
            string ffmpeg = FindExecutables("ffmpeg.exe").FirstOrDefault(path => !IsCodexRuntime(path));
            string ffprobe = FindExecutables("ffprobe.exe").FirstOrDefault(path => !IsCodexRuntime(path));
            if (!String.IsNullOrEmpty(ffmpeg) && !String.IsNullOrEmpty(ffprobe))
            {
                CommandResult versionRun = Run(ffmpeg, "-version", 15000);
                string version = FirstLine(versionRun.Output);
                bool mediaReady = false;
                string validationDirectory = CreateValidationDirectory("ffmpeg-media");
                string mediaFile = Path.Combine(validationDirectory, "probe.wav");
                try
                {
                    Directory.CreateDirectory(validationDirectory);
                    CommandResult encode = Run(ffmpeg,
                        "-hide_banner -loglevel error -f lavfi -i anullsrc=r=8000:cl=mono -t 0.25 -y " + QuoteArgument(mediaFile), 30000);
                    CommandResult probe = encode.ExitCode == 0
                        ? Run(ffprobe, "-v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 " + QuoteArgument(mediaFile), 15000)
                        : new CommandResult { ExitCode = -1, Output = "临时媒体生成失败" };
                    mediaReady = encode.ExitCode == 0 && probe.ExitCode == 0 && File.Exists(mediaFile) && new FileInfo(mediaFile).Length > 0;
                }
                finally
                {
                    SafeDeleteValidationDirectory(validationDirectory);
                }
                if (versionRun.ExitCode == 0 && mediaReady)
                    return Ready("多媒体工具", "FFmpeg（含 FFprobe）", version + " · 临时媒体生成与 FFprobe 读取实测通过。", "无需处理。");
                return Warning("多媒体工具", "FFmpeg（含 FFprobe）", version + " · 命令存在，但临时媒体测试失败。",
                    "需手动安装：请前往 FFmpeg 官网（ffmpeg.org/download.html，Windows 可选 Gyan.dev）或国内镜像站下载后自行安装。");
            }
            if (!String.IsNullOrEmpty(ffmpeg) || !String.IsNullOrEmpty(ffprobe))
                return Warning("多媒体工具", "FFmpeg（含 FFprobe）",
                    "安装不完整：FFmpeg=" + Present(ffmpeg) + "，FFprobe=" + Present(ffprobe),
                    "需手动安装：请前往 FFmpeg 官网（ffmpeg.org/download.html，Windows 可选 Gyan.dev）或国内镜像站下载后自行安装。");
            return Missing("多媒体工具", "FFmpeg（含 FFprobe）", "没有发现 ffmpeg.exe 与 ffprobe.exe。",
                "需手动安装：请前往 FFmpeg 官网（ffmpeg.org/download.html，Windows 可选 Gyan.dev）或国内镜像站下载后自行安装。");
        }

        private static CheckResult CheckLibreOffice()
        {
            string executable = FindLibreOfficeExecutable();
            if (String.IsNullOrEmpty(executable))
                return EvaluateLibreOfficeState(null, false, false, null);

            CommandResult versionRun = Run(executable, "--headless --version", 30000);
            string programDirectory = Path.GetDirectoryName(executable);
            bool pathReady = IsDirectoryOnConfiguredPath(programDirectory);
            return EvaluateLibreOfficeState(executable, versionRun.ExitCode == 0, pathReady,
                FirstLine(versionRun.Output));
        }

        private static CheckResult EvaluateLibreOfficeState(string executable, bool commandReady, bool pathReady, string version)
        {
            if (String.IsNullOrEmpty(executable))
                return Missing("文档处理能力", LibreOfficeName,
                    "没有发现 LibreOffice 的 soffice.com。",
                    "需手动安装：请前往 LibreOffice 官网（www.libreoffice.org/download）或国内镜像站（如清华镜像 mirrors.tuna.tsinghua.edu.cn/libreoffice）下载安装包后自行安装。");

            string detail = EmptyAsUnknown(version) + " · " + executable;
            if (!commandReady)
                return Warning("文档处理能力", LibreOfficeName,
                    detail + "；程序存在，但无头命令测试失败。",
                    "请重新安装 LibreOffice 并验证无头渲染能力：前往官网（www.libreoffice.org/download）或国内镜像站下载安装包。");
            if (!pathReady)
                return Warning("文档处理能力", LibreOfficeName,
                    detail + "；无头命令可运行，但 LibreOffice program 目录尚未加入 PATH。",
                    "可在本工具中一键补全当前用户 PATH；不会主动修改 Windows 默认文件关联。");
            return Ready("文档处理能力", LibreOfficeName,
                detail + "；无头命令实测通过，PATH 已配置。", "无需处理。");
        }

        public static CheckResult EvaluateLibreOfficeForSelfTest(bool installed, bool commandReady, bool pathReady)
        {
            return EvaluateLibreOfficeState(installed ? "mock-soffice.com" : null,
                commandReady, pathReady, installed ? "LibreOffice 26.8.0.3" : null);
        }

        public static string FindLibreOfficeExecutable()
        {
            List<string> candidates = FindExecutables("soffice.com");
            string programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            string programFilesX86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            AddIfFile(candidates, Path.Combine(programFiles, "LibreOffice", "program", "soffice.com"));
            AddIfFile(candidates, Path.Combine(programFilesX86, "LibreOffice", "program", "soffice.com"));
            AddIfFile(candidates, Path.Combine(local, "Programs", "LibreOffice", "program", "soffice.com"));
            return DistinctPaths(candidates).FirstOrDefault(path => !IsCodexRuntime(path));
        }

        public static bool IsDirectoryOnConfiguredPath(string directory)
        {
            if (String.IsNullOrWhiteSpace(directory)) return false;
            string target;
            try { target = Path.GetFullPath(directory).TrimEnd('\\'); }
            catch { return false; }
            return BuildCleanPathDirectories().Any(path =>
            {
                try { return String.Equals(Path.GetFullPath(path).TrimEnd('\\'), target, StringComparison.OrdinalIgnoreCase); }
                catch { return false; }
            });
        }

        private static CheckResult CheckPyYaml(PythonProbe python)
        {
            if (!python.Available)
                return Missing("Python 依赖", "PyYAML", "由于 Python 不可用，无法检查 PyYAML。",
                    "请先安装 Python 3.11+，再返回本工具自动安装 PyYAML。");
            CommandResult run = Run(python.Executable, JoinArguments(python.PrefixArguments, "-c \"import yaml; print(yaml.__version__)\""));
            if (run.ExitCode == 0)
                return Ready("Python 依赖", "PyYAML", "已安装 " + FirstLine(run.Output) + " · 归属 " + python.Version, "无需处理。");
            return Missing("Python 依赖", "PyYAML", "当前 Python 无法导入 yaml。",
                "可在本工具中使用当前 Python 自动安装 PyYAML。");
        }

        private static CheckResult CheckYtDlp(PythonProbe python)
        {
            string executable = FindExecutables("yt-dlp.exe").FirstOrDefault(path => !IsCodexRuntime(path));
            if (!String.IsNullOrEmpty(executable))
            {
                CommandResult direct = Run(executable, "--version");
                if (direct.ExitCode == 0)
                    return Ready("Python 依赖", "yt-dlp", "已安装 " + FirstLine(direct.Output) + " · " + executable, "无需处理。");
            }
            if (python.Available)
            {
                CommandResult module = Run(python.Executable, JoinArguments(python.PrefixArguments, "-m yt_dlp --version"));
                if (module.ExitCode == 0)
                    return Ready("Python 依赖", "yt-dlp", "Python 模块可用 " + FirstLine(module.Output) + "。", "无需处理。");
            }
            return Missing("Python 依赖", "yt-dlp", "没有发现 yt-dlp 命令或 Python 模块。",
                "可在本工具中使用当前 Python 自动安装 yt-dlp。");
        }

        private static PythonProbe FindPython()
        {
            List<string> candidates = FindExecutables("python.exe")
                .Where(path => path.IndexOf("WindowsApps", StringComparison.OrdinalIgnoreCase) < 0)
                .Where(path => !IsCodexRuntime(path)).ToList();
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            AddPythonDirectories(candidates, Path.Combine(local, "Python"));
            AddPythonDirectories(candidates, Path.Combine(local, "Programs", "Python"));
            AddPythonDirectories(candidates, programFiles);

            foreach (string executable in DistinctPaths(candidates))
            {
                CommandResult run = Run(executable, "--version");
                Match match = Regex.Match(run.Output ?? "", @"Python\s+(\d+)\.(\d+)(?:\.(\d+))?", RegexOptions.IgnoreCase);
                if (run.ExitCode == 0 && match.Success)
                {
                    return new PythonProbe
                    {
                        Executable = executable,
                        PrefixArguments = "-X utf8",
                        Version = match.Value,
                        Major = Int32.Parse(match.Groups[1].Value),
                        Minor = Int32.Parse(match.Groups[2].Value),
                        Available = true
                    };
                }
            }

            string launcher = FindExecutables("py.exe").FirstOrDefault(path => !IsCodexRuntime(path));
            if (!String.IsNullOrEmpty(launcher))
            {
                CommandResult run = Run(launcher, "-3 --version");
                Match match = Regex.Match(run.Output ?? "", @"Python\s+(\d+)\.(\d+)(?:\.(\d+))?", RegexOptions.IgnoreCase);
                if (run.ExitCode == 0 && match.Success)
                {
                    return new PythonProbe
                    {
                        Executable = launcher,
                        PrefixArguments = "-3 -X utf8",
                        Version = match.Value,
                        Major = Int32.Parse(match.Groups[1].Value),
                        Minor = Int32.Parse(match.Groups[2].Value),
                        Available = true
                    };
                }
            }
            return new PythonProbe { Available = false };
        }

        public static PythonProbe GetPythonForRepair()
        {
            return FindPython();
        }

        public static string FindIndependentExecutable(string fileName)
        {
            return FindExecutables(fileName).FirstOrDefault(path => !IsCodexRuntime(path));
        }

        public static CommandResult RunRepairCommand(string executable, string arguments)
        {
            return Run(executable, arguments, 1200000);
        }

        private static void AddPythonDirectories(List<string> candidates, string root)
        {
            if (!Directory.Exists(root)) return;
            AddIfFile(candidates, Path.Combine(root, "python.exe"));
            foreach (string directory in SafeDirectories(root))
            {
                string name = Path.GetFileName(directory) ?? "";
                if (name.StartsWith("Python", StringComparison.OrdinalIgnoreCase) ||
                    name.StartsWith("pythoncore", StringComparison.OrdinalIgnoreCase))
                    AddIfFile(candidates, Path.Combine(directory, "python.exe"));
            }
        }

        private static List<string> BuildCleanPathDirectories()
        {
            List<string> paths = new List<string>();
            AddRegistryPath(paths, Registry.LocalMachine, @"SYSTEM\CurrentControlSet\Control\Session Manager\Environment");
            AddRegistryPath(paths, Registry.CurrentUser, @"Environment");
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            paths.Add(Path.Combine(local, "Microsoft", "WindowsApps"));
            paths.Add(Path.Combine(local, "Microsoft", "WinGet", "Links"));
            return paths.Where(Directory.Exists).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        }

        private static void AddRegistryPath(List<string> paths, RegistryKey root, string subKey)
        {
            try
            {
                using (RegistryKey key = root.OpenSubKey(subKey))
                {
                    string value = Convert.ToString(key == null ? null : key.GetValue("Path", "", RegistryValueOptions.DoNotExpandEnvironmentNames));
                    foreach (string entry in (value ?? "").Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        string expanded = Environment.ExpandEnvironmentVariables(entry.Trim().Trim('"'));
                        if (!String.IsNullOrWhiteSpace(expanded)) paths.Add(expanded);
                    }
                }
            }
            catch { }
        }

        private static List<string> FindExecutables(string fileName)
        {
            List<string> files = new List<string>();
            foreach (string directory in BuildCleanPathDirectories())
                AddIfFile(files, Path.Combine(directory, fileName));
            return DistinctPaths(files);
        }

        private static List<string> DistinctPaths(IEnumerable<string> paths)
        {
            return paths.Where(path => !String.IsNullOrWhiteSpace(path) && File.Exists(path))
                .Select(Path.GetFullPath).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        }

        private static void AddIfFile(List<string> paths, string path)
        {
            try { if (File.Exists(path)) paths.Add(path); } catch { }
        }

        private static IEnumerable<string> SafeDirectories(string path)
        {
            try { return Directory.GetDirectories(path); } catch { return new string[0]; }
        }

        private static bool IsCodexRuntime(string path)
        {
            return path != null && (path.IndexOf(@"\.cache\codex-runtimes\", StringComparison.OrdinalIgnoreCase) >= 0 ||
                path.IndexOf(@"\.codex\", StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private static string FirstExistingDirectory(string output)
        {
            if (String.IsNullOrWhiteSpace(output)) return null;
            foreach (string line in output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
            {
                string candidate = line.Trim().Trim('"');
                try { if (Directory.Exists(candidate)) return candidate; } catch { }
            }
            return null;
        }

        private static string CreateValidationDirectory(string prefix)
        {
            // Keep this deliberately short: .NET Framework recursive deletion can still hit
            // the legacy MAX_PATH boundary inside a Python virtual environment.
            string root = Path.Combine(Path.GetTempPath(), "EDV");
            Directory.CreateDirectory(root);
            return Path.Combine(root, prefix + "-" + Guid.NewGuid().ToString("N"));
        }

        private static void SafeDeleteValidationDirectory(string path)
        {
            try
            {
                string root = Path.GetFullPath(Path.Combine(Path.GetTempPath(), "EDV")).TrimEnd('\\') + "\\";
                string target = Path.GetFullPath(path);
                if (!target.StartsWith(root, StringComparison.OrdinalIgnoreCase) || target.Length <= root.Length)
                    return;
                if (Directory.Exists(target)) Directory.Delete(target, true);
            }
            catch { }
        }

        private static string QuoteArgument(string value)
        {
            return "\"" + (value ?? "").Replace("\"", "\\\"") + "\"";
        }

        private static string PassFail(bool value)
        {
            return value ? "通过" : "失败";
        }

        private static CommandResult Run(string executable, string arguments)
        {
            return Run(executable, arguments, 6000);
        }

        public static CommandResult Run(string executable, string arguments, int timeoutMilliseconds)
        {
            return Run(executable, arguments, timeoutMilliseconds, null);
        }

        internal static CommandResult Run(string executable, string arguments, int timeoutMilliseconds, IDictionary<string, string> environmentOverrides)
        {
            try
            {
                ProcessStartInfo info = new ProcessStartInfo(executable, arguments ?? "");
                info.UseShellExecute = false;
                info.CreateNoWindow = true;
                info.RedirectStandardOutput = true;
                info.RedirectStandardError = true;
                // 只适配明确以 -X utf8 启动的 Python 子进程；不写用户/系统环境变量。
                string fileName = Path.GetFileName(executable);
                if (String.Equals(fileName, "git.exe", StringComparison.OrdinalIgnoreCase))
                {
                    // A validation repository must never inherit another task's index,
                    // repository path, or guessed author from the launching process.
                    foreach (string key in new[] { "GIT_DIR", "GIT_WORK_TREE", "GIT_COMMON_DIR", "GIT_INDEX_FILE", "GIT_OBJECT_DIRECTORY", "GIT_ALTERNATE_OBJECT_DIRECTORIES", "GIT_NAMESPACE", "GIT_AUTHOR_NAME", "GIT_AUTHOR_EMAIL", "GIT_COMMITTER_NAME", "GIT_COMMITTER_EMAIL", "GIT_CONFIG_PARAMETERS", "GIT_CONFIG_COUNT" })
                        info.EnvironmentVariables.Remove(key);
                    foreach (string key in info.EnvironmentVariables.Keys.Cast<string>().Where(k => k.StartsWith("GIT_CONFIG_KEY_", StringComparison.OrdinalIgnoreCase) || k.StartsWith("GIT_CONFIG_VALUE_", StringComparison.OrdinalIgnoreCase)).ToArray())
                        info.EnvironmentVariables.Remove(key);
                    info.StandardOutputEncoding = Encoding.UTF8;
                    info.StandardErrorEncoding = Encoding.UTF8;
                }
                if (environmentOverrides != null)
                    foreach (var pair in environmentOverrides) {
                        if (pair.Value == null) info.EnvironmentVariables.Remove(pair.Key);
                        else info.EnvironmentVariables[pair.Key] = pair.Value;
                    }
                if ((String.Equals(fileName, "python.exe", StringComparison.OrdinalIgnoreCase) ||
                     String.Equals(fileName, "py.exe", StringComparison.OrdinalIgnoreCase)) &&
                    Regex.IsMatch(arguments ?? "", @"(?:^|\s)-X\s+utf8(?:\s|$)"))
                {
                    info.EnvironmentVariables["PYTHONIOENCODING"] = "utf-8";
                    info.StandardOutputEncoding = Encoding.UTF8;
                    info.StandardErrorEncoding = Encoding.UTF8;
                }
                using (Process process = new Process())
                {
                    process.StartInfo = info;
                    StringBuilder stdout = new StringBuilder();
                    StringBuilder stderr = new StringBuilder();
                    process.OutputDataReceived += delegate(object sender, DataReceivedEventArgs e)
                    {
                        if (e.Data != null) lock (stdout) stdout.AppendLine(e.Data);
                    };
                    process.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs e)
                    {
                        if (e.Data != null) lock (stderr) stderr.AppendLine(e.Data);
                    };
                    process.Start();
                    process.BeginOutputReadLine();
                    process.BeginErrorReadLine();
                    if (!process.WaitForExit(timeoutMilliseconds))
                    {
                        try { process.Kill(); } catch { }
                        return new CommandResult { ExitCode = -2, Output = "检测超时" };
                    }
                    process.WaitForExit();
                    string combined = (stdout.ToString() + Environment.NewLine + stderr.ToString()).Trim();
                    return new CommandResult { ExitCode = process.ExitCode, Output = combined };
                }
            }
            catch (Exception ex)
            {
                return new CommandResult { ExitCode = -1, Output = ex.Message };
            }
        }

        private static string JoinArguments(string prefix, string arguments)
        {
            return String.IsNullOrWhiteSpace(prefix) ? arguments : prefix + " " + arguments;
        }

        private static string FirstLine(string text)
        {
            if (String.IsNullOrWhiteSpace(text)) return "版本未知";
            return text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).FirstOrDefault() ?? "版本未知";
        }

        private static string Present(string path)
        {
            return String.IsNullOrEmpty(path) ? "缺少" : "已发现";
        }

        private static string EmptyAsUnknown(string value)
        {
            return String.IsNullOrWhiteSpace(value) ? "未知" : value;
        }

        private static CheckResult Ready(string group, string name, string detail, string guidance)
        {
            return Result(group, name, CheckLevel.Ready, detail, guidance);
        }

        private static CheckResult Warning(string group, string name, string detail, string guidance)
        {
            return Result(group, name, CheckLevel.Warning, detail, guidance);
        }

        private static CheckResult Missing(string group, string name, string detail, string guidance)
        {
            return Result(group, name, CheckLevel.Missing, detail, guidance);
        }

        private static CheckResult Result(string group, string name, CheckLevel level, string detail, string guidance)
        {
            return new CheckResult
            {
                Importance = ImportanceFor(name),
                Group = group,
                Name = name,
                Level = level,
                Detail = detail,
                Guidance = guidance
            };
        }

        private static string ImportanceFor(string name)
        {
            if (name == "开发工具" || name == "基础开发环境" || name == "编辑器集成" || name == "Git")
                return "必需";
            if (name == "PyYAML" || name == "yt-dlp")
                return "业务可选";
            return "推荐";
        }
    }

    internal static class SingleWindow
    {
        // 两个模式各自独立单实例：环境补全与软件检查可同时各开一个窗口。
        public const string CodexMutexName = @"Local\CompanyAIHelpers.EnvironmentDetector.CodexMode";
        public const string SoftwareMutexName = @"Local\CompanyAIHelpers.EnvironmentDetector.SoftwareMode";

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr FindWindow(string className, string windowName);

        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr window, int command);

        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr window);

        public static void ActivateWindow(bool codexMode)
        {
            string title = codexMode ? "Codex 环境补全 · Codex 工具箱" : "软件安装检查 · Codex 工具箱";
            IntPtr window = FindWindow(null, title);
            if (window == IntPtr.Zero) return;
            ShowWindow(window, 9);
            SetForegroundWindow(window);
        }
    }

    internal static class UserPathEnvironment
    {
        private static readonly IntPtr BroadcastHandle = new IntPtr(0xffff);
        private const uint SettingChange = 0x001A;
        private const uint AbortIfHung = 0x0002;

        [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern IntPtr SendMessageTimeout(IntPtr window, uint message, UIntPtr word,
            string text, uint flags, uint timeout, out UIntPtr result);

        public static bool EnsureDirectory(string directory)
        {
            string target = Normalize(directory);
            if (String.IsNullOrEmpty(target) || !Directory.Exists(target))
                throw new DirectoryNotFoundException("LibreOffice program 目录不存在。");

            string rawUserPath;
            using (RegistryKey environment = Registry.CurrentUser.CreateSubKey("Environment"))
            {
                if (environment == null) throw new InvalidOperationException("无法打开当前用户环境变量。");
                rawUserPath = Convert.ToString(environment.GetValue("Path", "", RegistryValueOptions.DoNotExpandEnvironmentNames));
                if (Contains(rawUserPath, target))
                {
                    EnsureProcessPath(target);
                    return false;
                }
                string updated = String.IsNullOrWhiteSpace(rawUserPath)
                    ? target
                    : rawUserPath.TrimEnd().TrimEnd(';') + ";" + target;
                environment.SetValue("Path", updated, RegistryValueKind.ExpandString);
            }

            EnsureProcessPath(target);
            try
            {
                UIntPtr ignored;
                SendMessageTimeout(BroadcastHandle, SettingChange, UIntPtr.Zero, "Environment",
                    AbortIfHung, 3000, out ignored);
            }
            catch { }
            return true;
        }

        private static void EnsureProcessPath(string directory)
        {
            string current = Environment.GetEnvironmentVariable("Path", EnvironmentVariableTarget.Process) ?? "";
            if (!Contains(current, directory))
                Environment.SetEnvironmentVariable("Path", String.IsNullOrWhiteSpace(current)
                        ? directory
                        : current.TrimEnd().TrimEnd(';') + ";" + directory,
                    EnvironmentVariableTarget.Process);
        }

        private static bool Contains(string pathValue, string directory)
        {
            foreach (string entry in (pathValue ?? "").Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries))
            {
                string normalized = Normalize(Environment.ExpandEnvironmentVariables(entry.Trim().Trim('"')));
                if (String.Equals(normalized, directory, StringComparison.OrdinalIgnoreCase)) return true;
            }
            return false;
        }

        private static string Normalize(string directory)
        {
            if (String.IsNullOrWhiteSpace(directory)) return null;
            try { return Path.GetFullPath(directory).TrimEnd('\\'); }
            catch { return null; }
        }
    }

    internal static class RepairEngine
    {
        private static readonly Dictionary<string, string> WingetPackages = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "PowerShell 7", "Microsoft.PowerShell" },
            { Detector.DotNetSdkName, "Microsoft.DotNet.SDK.8" },
            { Detector.DesktopRuntimeName, "Microsoft.DotNet.DesktopRuntime.8" },
            { Detector.WebView2Name, "Microsoft.EdgeWebView2Runtime" },
            { "Windows Terminal", "Microsoft.WindowsTerminal" },
            { "Git", "Git.Git" },
            { "FFmpeg（含 FFprobe）", "Gyan.FFmpeg" },
            { Detector.LibreOfficeName, "TheDocumentFoundation.LibreOffice" }
        };

        // 软件检查项（手动安装 / 只检测引导）：显示在"软件安装检查"模块，不进入"一键自动补全"。
        public static readonly HashSet<string> SoftwareCheckItems = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "开发工具", "基础开发环境", "编辑器集成",
            "PowerShell 7",
            Detector.DotNetSdkName,
            Detector.DesktopRuntimeName,
            Detector.LibreOfficeName,
            "FFmpeg（含 FFprobe）"
        };

        public static bool IsManualOnly(string name)
        {
            return name != null && SoftwareCheckItems.Contains(name);
        }

        public static List<string> GetAutomaticItems(IEnumerable<CheckResult> results)
        {
            return results.Where(item => item.Level != CheckLevel.Ready && !(item.Name == "Git" && item.Installed))
                .Select(item => item.Name)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Where(name => !SoftwareCheckItems.Contains(name) &&
                    (WingetPackages.ContainsKey(name) || name == "PyYAML" ||
                    name == "yt-dlp"))
                .ToList();
        }

        public static List<RepairResult> Repair(IEnumerable<CheckResult> results, Action<string, int, int> progress)
        {
            List<RepairResult> repaired = new List<RepairResult>();
            List<string> targets = GetAutomaticItems(results);
            string libraryRoot = GetSelectedLibrary();
            string winget = Detector.FindIndependentExecutable("winget.exe");
            PythonProbe python = Detector.GetPythonForRepair();

            for (int index = 0; index < targets.Count; index++)
            {
                string name = targets[index];
                if (progress != null) progress(name, index + 1, targets.Count);
                if ((name == Detector.DesktopRuntimeName && Detector.CheckDesktopRuntime().Level == CheckLevel.Ready) ||
                    (name == Detector.WebView2Name && Detector.CheckWebView2().Level == CheckLevel.Ready))
                {
                    repaired.Add(new RepairResult { Name = name, Success = true, Detail = "已就绪，无需重复安装。" });
                    continue;
                }
                if (name == Detector.LibreOfficeName)
                {
                    repaired.Add(RepairLibreOffice(winget, libraryRoot));
                    continue;
                }
                if (libraryRoot != null)
                {
                    if ((name == "PyYAML" || name == "yt-dlp") && (python == null || !python.Available))
                        repaired.Add(Failed(name, "Python 不可用；请先在‘软件安装检查’中完成 Python 安装。"));
                    else
                        repaired.Add(RepairFromLibrary(name, libraryRoot, python));
                    continue;
                }
                RepairResult prerequisiteFailure = GetPrerequisiteFailure(name, winget, python);
                if (prerequisiteFailure != null)
                {
                    repaired.Add(prerequisiteFailure);
                    continue;
                }
                if (WingetPackages.ContainsKey(name))
                {
                    string packageId = WingetPackages[name];
                    string arguments = BuildWingetInstallArguments(name);
                    CommandResult run = Detector.RunRepairCommand(winget, arguments);
                    repaired.Add(FromCommand(name, run));
                    continue;
                }

                string packageName = name == "PyYAML" ? "PyYAML" : "yt-dlp";
                string pipArguments = JoinArguments(python.PrefixArguments,
                    "-m pip install --upgrade --disable-pip-version-check " + packageName);
                CommandResult pip = Detector.RunRepairCommand(python.Executable, pipArguments);
                repaired.Add(FromCommand(name, pip));
            }
            return repaired;
        }

        private static RepairResult RepairLibreOffice(string winget, string libraryRoot)
        {
            string executable = Detector.FindLibreOfficeExecutable();
            bool installedNow = false;
            if (String.IsNullOrEmpty(executable))
            {
                if (libraryRoot == null && String.IsNullOrEmpty(winget))
                    return Failed(Detector.LibreOfficeName, "系统未发现 winget，无法自动安装。");
                CommandResult install = libraryRoot != null
                    ? RunLibraryInstaller("TheDocumentFoundation.LibreOffice", libraryRoot, null)
                    : Detector.RunRepairCommand(winget,
                        "install --id TheDocumentFoundation.LibreOffice --exact --accept-source-agreements --accept-package-agreements --silent");
                if (install.ExitCode != 0) return FromCommand(Detector.LibreOfficeName, install);
                installedNow = true;
                executable = Detector.FindLibreOfficeExecutable();
            }

            if (String.IsNullOrEmpty(executable))
                return Failed(Detector.LibreOfficeName, "安装命令已结束，但仍没有发现 soffice.com。");

            CommandResult version = Detector.RunRepairCommand(executable, "--headless --version");
            if (version.ExitCode != 0 && (libraryRoot != null || !String.IsNullOrEmpty(winget)))
            {
                CommandResult reinstall = libraryRoot != null
                    ? RunLibraryInstaller("TheDocumentFoundation.LibreOffice", libraryRoot, null)
                    : Detector.RunRepairCommand(winget,
                        "install --id TheDocumentFoundation.LibreOffice --exact --force --accept-source-agreements --accept-package-agreements --silent");
                if (reinstall.ExitCode != 0) return FromCommand(Detector.LibreOfficeName, reinstall);
                installedNow = true;
                executable = Detector.FindLibreOfficeExecutable();
                if (!String.IsNullOrEmpty(executable))
                    version = Detector.RunRepairCommand(executable, "--headless --version");
            }
            if (version.ExitCode != 0)
                return Failed(Detector.LibreOfficeName,
                    "LibreOffice 已发现，但无头命令测试失败：" + Compact(version.Output));

            try
            {
                bool pathChanged = UserPathEnvironment.EnsureDirectory(Path.GetDirectoryName(executable));
                string action = installedNow ? "已安装或修复 LibreOffice" : "LibreOffice 已安装";
                action += pathChanged ? "，并已加入当前用户 PATH。" : "，当前用户 PATH 已配置。";
                action += " 工具未主动修改 Windows 默认文件关联。";
                return new RepairResult { Name = Detector.LibreOfficeName, Success = true, Detail = action };
            }
            catch (Exception ex)
            {
                return Failed(Detector.LibreOfficeName, "无头命令可运行，但 PATH 配置失败：" + ex.Message);
            }
        }

        internal static string GetSelectedLibrary()
        {
            string config = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "installer-source.txt");
            if (!File.Exists(config)) return null;
            string[] lines = File.ReadAllLines(config, Encoding.UTF8);
            if (lines.Length == 0 || !String.Equals(lines[0].Trim(), "library", StringComparison.OrdinalIgnoreCase))
                return null;
            return lines.Length > 1 ? lines[1].Trim() : "";
        }

        public static string SelectedSourceLabel()
        {
            return GetSelectedLibrary() == null ? "软件官方源" : "已校验的现成安装包库";
        }

        public static string BuildWingetInstallArguments(string name)
        {
            string arguments = "install --id " + WingetPackages[name] + " --exact --accept-source-agreements --accept-package-agreements --silent";
            if (name == Detector.DotNetSdkName || name == Detector.DesktopRuntimeName || name == Detector.WebView2Name)
                arguments += " --architecture x64";
            return arguments;
        }

        public static string GetLibraryPackageId(string name)
        {
            if (name == Detector.DesktopRuntimeName) return "Microsoft.DotNet.SDK.8";
            string id;
            if (WingetPackages.TryGetValue(name, out id)) return id;
            return name == "PyYAML" ? "PyYAML" : "yt-dlp";
        }

        private static RepairResult RepairFromLibrary(string name, string libraryRoot, PythonProbe python)
        {
            if (name == Detector.WebView2Name)
                return Failed(name, "所选现成安装包库暂不包含 WebView2；请明确选择软件官方源后补全，未自动切换来源。");
            string packageId = GetLibraryPackageId(name);
            return FromCommand(name, RunLibraryInstaller(packageId, libraryRoot, python));
        }

        private static CommandResult RunLibraryInstaller(string packageId, string libraryRoot, PythonProbe python)
        {
            string script = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "install-from-library.ps1");
            if (!File.Exists(script) || String.IsNullOrWhiteSpace(libraryRoot))
                return new CommandResult { ExitCode = 1, Output = "现成安装包配置或安装脚本缺失。" };
            string shell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),
                "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
            string args = "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File " + QuoteArgument(script) +
                " -PackageId " + QuoteArgument(packageId) + " -LibraryRoot " + QuoteArgument(libraryRoot);
            if (python != null && python.Available)
                args += " -PythonExe " + QuoteArgument(python.Executable) +
                    " -PythonPrefix " + QuoteArgument(python.PrefixArguments ?? "") +
                    " -PythonVersion " + QuoteArgument(python.Major + "." + python.Minor);
            return Detector.RunRepairCommand(shell, args);
        }

        private static string QuoteArgument(string value)
        {
            return "\"" + (value ?? "").Replace("\"", "\\\"") + "\"";
        }

        private static RepairResult GetPrerequisiteFailure(string name, string winget, PythonProbe python)
        {
            if (WingetPackages.ContainsKey(name) && String.IsNullOrEmpty(winget))
                return Failed(name, "系统未发现 winget，无法自动安装。");
            if ((name == "PyYAML" || name == "yt-dlp") && (python == null || !python.Available))
                return Failed(name, "Python 不可用；请先在‘软件安装检查’中完成 Python 安装。");
            return null;
        }

        public static RepairResult EvaluatePrerequisiteForSelfTest(string name, bool wingetAvailable, bool pythonAvailable)
        {
            return GetPrerequisiteFailure(name, wingetAvailable ? "winget.exe" : null,
                new PythonProbe { Available = pythonAvailable });
        }

        private static RepairResult FromCommand(string name, CommandResult command)
        {
            if (name == "Git" && command.ExitCode == 0) {
                CheckResult verification = Detector.CheckGit();
                return new RepairResult { Name = name, Success = verification.Level == CheckLevel.Ready,
                    Detail = verification.Level == CheckLevel.Ready ? "Git 安装及提交自检通过。" :
                        "Git 安装命令已完成；" + verification.Detail + " " + verification.Guidance };
            }
            string detail = command.ExitCode == 0 ? "处理完成。" : "处理失败（退出码 " + command.ExitCode + "）：" + Compact(command.Output);
            return new RepairResult { Name = name, Success = command.ExitCode == 0, Detail = detail };
        }

        private static RepairResult Failed(string name, string detail)
        {
            return new RepairResult { Name = name, Success = false, Detail = detail };
        }

        private static string JoinArguments(string prefix, string arguments)
        {
            return String.IsNullOrWhiteSpace(prefix) ? arguments : prefix + " " + arguments;
        }

        private static string Compact(string text)
        {
            if (String.IsNullOrWhiteSpace(text)) return "没有返回错误详情。";
            string compact = Regex.Replace(text, @"\s+", " ").Trim();
            return compact.Length <= 300 ? compact : compact.Substring(0, 300) + "…";
        }
    }

    internal static class DownloadRegistry
    {
        internal sealed class DownloadInfo
        {
            public string Name;
            public string OfficialUrl;
            public string MirrorUrl;
            public string PanUrl;       // 公司网盘，空则该项不提供网盘渠道
            public string DirectUrl;    // 稳定直链（可直接下载到“下载”文件夹）；空则只引导网页
            public string SaveName;     // 直接下载时的保存文件名
            public bool DynamicUrl;     // true = DirectUrl 是解析入口（如 GitHub API），需先解析真实下载地址
        }

        // 可引导下载的单一软件大件。DirectUrl 优先用官方“永远指向最新版”的稳定链接；
        // Python 固定在现有离线轮子支持的 3.14 维护版；LibreOffice 使用已核验的官方归档包。
        // 官网/镜像按钮用于用户自行选择其他版本；不存在的镜像不显示。
        private static readonly Dictionary<string, DownloadInfo> Entries =
            new Dictionary<string, DownloadInfo>(StringComparer.OrdinalIgnoreCase)
            {
                { "基础开发环境", new DownloadInfo {
                    Name = "Python 3.11+",
                    OfficialUrl = "https://www.python.org/downloads/windows/",
                    MirrorUrl = "https://mirrors.tuna.tsinghua.edu.cn/python/",
                    PanUrl = "",
                    DirectUrl = "https://www.python.org/ftp/python/3.14.9/python-3.14.9-amd64.exe",
                    SaveName = "python-3.14.9-amd64.exe",
                    DynamicUrl = false } },
                { "PowerShell 7", new DownloadInfo {
                    Name = "PowerShell 7",
                    OfficialUrl = "https://github.com/PowerShell/PowerShell/releases/latest",
                    MirrorUrl = "https://mirrors.tuna.tsinghua.edu.cn/github-release/PowerShell/PowerShell/",
                    PanUrl = "",
                    DirectUrl = "https://api.github.com/repos/PowerShell/PowerShell/releases/latest",
                    SaveName = "PowerShell-latest-win-x64.msi",
                    DynamicUrl = true } },
                { Detector.DotNetSdkName, new DownloadInfo {
                    Name = ".NET 8 SDK",
                    OfficialUrl = "https://dotnet.microsoft.com/download/dotnet/8.0",
                    MirrorUrl = null,
                    PanUrl = "",
                    DirectUrl = "https://aka.ms/dotnet/8.0/dotnet-sdk-win-x64.exe",
                    SaveName = "dotnet-sdk-win-x64.exe",
                    DynamicUrl = false } },
                { Detector.DesktopRuntimeName, new DownloadInfo {
                    Name = ".NET 8 桌面运行时",
                    OfficialUrl = "https://dotnet.microsoft.com/download/dotnet/8.0",
                    MirrorUrl = null,
                    PanUrl = "",
                    DirectUrl = "https://aka.ms/dotnet/8.0/windowsdesktop-runtime-win-x64.exe",
                    SaveName = "windowsdesktop-runtime-win-x64.exe",
                    DynamicUrl = false } },
                { "FFmpeg（含 FFprobe）", new DownloadInfo {
                    Name = "FFmpeg",
                    OfficialUrl = "https://www.gyan.dev/ffmpeg/builds/",
                    MirrorUrl = "",
                    PanUrl = "",
                    DirectUrl = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-full.7z",
                    SaveName = "ffmpeg-release-full.7z",
                    DynamicUrl = false } },
                { Detector.LibreOfficeName, new DownloadInfo {
                    Name = "LibreOffice",
                    OfficialUrl = "https://www.libreoffice.org/download/download-libreoffice/",
                    MirrorUrl = "https://mirrors.tuna.tsinghua.edu.cn/libreoffice/",
                    PanUrl = "",
                    DirectUrl = "https://downloadarchive.documentfoundation.org/libreoffice/old/26.8.1.1/win/x86_64/LibreOffice_26.8.1.1_Win_x86-64.msi",
                    SaveName = "LibreOffice_26.8.1.1_Win_x86-64.msi",
                    DynamicUrl = false } },
            };

        public static bool TryGet(string name, out DownloadInfo info)
        {
            return Entries.TryGetValue(name, out info);
        }
    }

    internal static class DirectDownloader
    {
        static DirectDownloader()
        {
            // 旧框架目标默认的 TLS 无法连接现代下载站；只让本进程使用 Windows 的协议选择。
            AppContext.SetSwitch("Switch.System.Net.DontEnableSystemDefaultTlsVersions", false);
            ServicePointManager.SecurityProtocol = SecurityProtocolType.SystemDefault;
        }

        // PowerShell 的 latest MSI 文件名带版本号，先经 GitHub API 解析出真实下载地址。
        public static string ResolveUrl(DownloadRegistry.DownloadInfo info)
        {
            if (!info.DynamicUrl) return info.DirectUrl;
            var request = (HttpWebRequest)WebRequest.Create(info.DirectUrl);
            request.UserAgent = "CodexTools-EnvironmentDetector";
            request.Timeout = 15000;
            request.ReadWriteTimeout = 15000;
            using (var response = request.GetResponse())
            using (var stream = response.GetResponseStream())
            using (var reader = new StreamReader(stream, Encoding.UTF8))
            {
                string resolved = ParsePowerShellReleaseUrl(reader.ReadToEnd());
                Uri uri;
                if (String.IsNullOrWhiteSpace(resolved)) throw new InvalidDataException("官方接口没有提供 Windows x64 MSI 安装包，请稍后重试或使用官网下载。");
                if (!Uri.TryCreate(resolved, UriKind.Absolute, out uri) || uri.Scheme != Uri.UriSchemeHttps)
                    throw new InvalidDataException("官方接口返回的下载地址无效。");
                return resolved;
            }
        }

        internal static string ParsePowerShellReleaseUrl(string json)
        {
            var serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            var payload = serializer.Deserialize<Dictionary<string, object>>(json);
            // JavaScriptSerializer 的嵌套 JSON 数组是 ArrayList，不实现 IEnumerable<object>。
            var assets = payload != null && payload.ContainsKey("assets")
                ? payload["assets"] as System.Collections.IEnumerable : null;
            if (assets == null) return null;
            foreach (var asset in assets)
            {
                var map = asset as Dictionary<string, object>;
                string assetName = map != null && map.ContainsKey("name") ? Convert.ToString(map["name"]) : "";
                if (assetName.EndsWith("win-x64.msi", StringComparison.OrdinalIgnoreCase)
                    && map.ContainsKey("browser_download_url"))
                    return Convert.ToString(map["browser_download_url"]);
            }
            return null;
        }

        public static string DownloadsFolder()
        {
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
        }
    }

    internal static class AutoFixEngine
    {
        public static string FindVsCodeCli()
        {
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            string programFilesX86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
            string[] candidates =
            {
                Path.Combine(local, "Programs", "Microsoft VS Code", "bin", "code.cmd"),
                Path.Combine(programFiles, "Microsoft VS Code", "bin", "code.cmd"),
                Path.Combine(programFilesX86, "Microsoft VS Code", "bin", "code.cmd"),
            };
            foreach (string candidate in candidates)
                if (File.Exists(candidate)) return candidate;
            return null;
        }

        public static bool CanAutoFix(string autoFixId)
        {
            if (autoFixId == PowerShellSetup.ConfigurationId) return true;
            if (autoFixId == EncodingPolicy.SettingsAction) return true;
            if (autoFixId == GitSetup.ConfigurationId) return GitSetup.FindGit() != null;
            return String.Equals(autoFixId, "vscode_python_extension", StringComparison.OrdinalIgnoreCase)
                && !String.IsNullOrEmpty(FindVsCodeCli());
        }

        public static RepairResult Run(string autoFixId)
        {
            if (autoFixId == PowerShellSetup.ConfigurationId) return PowerShellSetup.Repair();
            if (String.Equals(autoFixId, "vscode_python_extension", StringComparison.OrdinalIgnoreCase))
                return InstallVsCodePythonExtension();
            return new RepairResult { Name = "编辑器集成", Success = false, Detail = "未知的自动配置项。" };
        }

        private static RepairResult InstallVsCodePythonExtension()
        {
            string cli = FindVsCodeCli();
            if (String.IsNullOrEmpty(cli))
                return new RepairResult { Name = "编辑器集成", Success = false, Detail = "没有找到 VS Code 的命令行工具（code.cmd）。" };
            // .cmd 不能被 CreateProcess 直接执行，须经 cmd /c。
            CommandResult run = Detector.Run("cmd.exe",
                "/c " + Quote(cli) + " --install-extension ms-python.python", 600000);
            if (run.ExitCode != 0)
                return new RepairResult { Name = "编辑器集成", Success = false,
                    Detail = "扩展安装失败：" + Compact(run.Output) };
            return new RepairResult { Name = "编辑器集成", Success = true,
                Detail = "Microsoft Python 扩展已安装；请重新检测，并在 VS Code 中按需选择解释器。" };
        }

        private static string Quote(string value)
        {
            return "\"" + value + "\"";
        }

        private static string Compact(string text)
        {
            if (String.IsNullOrWhiteSpace(text)) return "没有返回错误详情。";
            string compact = Regex.Replace(text, @"\s+", " ").Trim();
            return compact.Length <= 300 ? compact : compact.Substring(0, 300) + "…";
        }
    }

    internal static class Utf8Repair
    {
        private const string CodePageRegistryPath = @"SYSTEM\CurrentControlSet\Control\Nls\CodePage";

        private static string BackupRoot
        {
            get
            {
                return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Backups");
            }
        }

        public static bool StartElevatedRestore()
        {
            try
            {
                ProcessStartInfo info = new ProcessStartInfo(Application.ExecutablePath, "--restore-utf8");
                info.UseShellExecute = true;
                info.Verb = "runas";
                using (Process process = Process.Start(info))
                {
                    if (process == null) return false;
                    process.WaitForExit();
                    return process.ExitCode == 0;
                }
            }
            catch
            {
                return false;
            }
        }

        public static bool CanRestore()
        {
            try
            {
                CodePageSnapshot backup = LoadSnapshot(GetLatestOriginalBackup());
                CodePageSnapshot current = ReadCurrent();
                return backup != null && current != null &&
                    (backup.ACP != current.ACP || backup.OEMCP != current.OEMCP || backup.MACCP != current.MACCP);
            }
            catch { return false; }
        }

        public static int Restore()
        {
            CodePageSnapshot beforeRestore = null;
            bool writeStarted = false;
            try
            {
                string backupPath = GetLatestOriginalBackup();
                CodePageSnapshot original = LoadSnapshot(backupPath);
                if (!IsLegacySnapshot(original)) throw new InvalidOperationException("没有找到有效的修改前非 UTF-8 编码备份。");
                beforeRestore = ReadCurrent();
                if (beforeRestore == null) throw new InvalidOperationException("无法读取当前系统代码页设置。");
                SaveSnapshot(beforeRestore, "restore-safety");
                writeStarted = true;
                WriteSnapshot(original);
                CodePageSnapshot actual = ReadCurrent();
                if (actual == null || actual.ACP != original.ACP || actual.OEMCP != original.OEMCP || actual.MACCP != original.MACCP)
                    throw new IOException("恢复后的注册表回读不一致。");
                return 0;
            }
            catch (Exception ex)
            {
                string rollback = "";
                if (writeStarted && beforeRestore != null)
                {
                    try
                    {
                        WriteSnapshot(beforeRestore);
                        rollback = " 已恢复到执行本次操作前的状态。";
                    }
                    catch (Exception rollbackError)
                    {
                        rollback = " 恢复本次操作前状态也失败：" + rollbackError.Message;
                    }
                }
                MessageBox.Show("恢复原编码失败：" + ex.Message + rollback,
                    "恢复原编码失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
        }

        public static bool RunFileFormatSelfTest(string reportPath)
        {
            string testRoot = Path.Combine(Path.GetTempPath(), "CompanyAIHelpers", "EnvironmentDetectorSelfTest", Guid.NewGuid().ToString("N"));
            try
            {
                Directory.CreateDirectory(testRoot);
                CodePageSnapshot expected = new CodePageSnapshot
                {
                    CreatedUtc = "2026-01-02T03:04:05.0000000Z",
                    ACP = "936",
                    OEMCP = "936",
                    MACCP = "10000"
                };
                string validPath = Path.Combine(testRoot, "valid.ini");
                WriteSnapshotFile(expected, validPath);
                CodePageSnapshot actual = LoadSnapshot(validPath);
                bool roundTrip = actual != null && actual.ACP == expected.ACP &&
                    actual.OEMCP == expected.OEMCP && actual.MACCP == expected.MACCP;

                string invalidPath = Path.Combine(testRoot, "invalid.ini");
                File.WriteAllText(invalidPath, "schemaVersion=1\r\nACP=not-a-codepage\r\nOEMCP=936\r\nMACCP=10000", new UTF8Encoding(false));
                bool invalidRejected = LoadSnapshot(invalidPath) == null;
                string report = "UTF8_BACKUP_ROUNDTRIP=" + (roundTrip ? "PASS" : "FAIL") + Environment.NewLine +
                    "UTF8_INVALID_BACKUP_REJECTED=" + (invalidRejected ? "PASS" : "FAIL") + Environment.NewLine +
                    "REGISTRY_WRITES=0" + Environment.NewLine;
                File.WriteAllText(reportPath, report, new UTF8Encoding(false));
                return roundTrip && invalidRejected;
            }
            finally
            {
                try { if (Directory.Exists(testRoot)) Directory.Delete(testRoot, true); } catch { }
            }
        }

        private static CodePageSnapshot ReadCurrent()
        {
            using (RegistryKey key = Registry.LocalMachine.OpenSubKey(CodePageRegistryPath))
            {
                if (key == null) return null;
                CodePageSnapshot snapshot = new CodePageSnapshot
                {
                    CreatedUtc = DateTime.UtcNow.ToString("o"),
                    ACP = Convert.ToString(key.GetValue("ACP")),
                    OEMCP = Convert.ToString(key.GetValue("OEMCP")),
                    MACCP = Convert.ToString(key.GetValue("MACCP"))
                };
                return IsValidSnapshot(snapshot) ? snapshot : null;
            }
        }

        private static void WriteSnapshot(CodePageSnapshot snapshot)
        {
            if (!IsValidSnapshot(snapshot)) throw new InvalidDataException("代码页数据无效，已拒绝写入注册表。");
            using (RegistryKey key = Registry.LocalMachine.OpenSubKey(CodePageRegistryPath, true))
            {
                if (key == null) throw new InvalidOperationException("无法打开系统代码页设置。");
                key.SetValue("ACP", snapshot.ACP, RegistryValueKind.String);
                key.SetValue("OEMCP", snapshot.OEMCP, RegistryValueKind.String);
                key.SetValue("MACCP", snapshot.MACCP, RegistryValueKind.String);
            }
        }

        private static string SaveSnapshot(CodePageSnapshot snapshot, string prefix)
        {
            Directory.CreateDirectory(BackupRoot);
            string path = Path.Combine(BackupRoot, prefix + "-" + DateTime.Now.ToString("yyyyMMdd-HHmmss-fff") + ".ini");
            WriteSnapshotFile(snapshot, path);
            return path;
        }

        private static void WriteSnapshotFile(CodePageSnapshot snapshot, string path)
        {
            if (!IsValidSnapshot(snapshot)) throw new InvalidDataException("代码页备份数据无效。");
            string[] lines =
            {
                "schemaVersion=1",
                "createdUtc=" + (snapshot.CreatedUtc ?? DateTime.UtcNow.ToString("o")),
                "ACP=" + snapshot.ACP,
                "OEMCP=" + snapshot.OEMCP,
                "MACCP=" + snapshot.MACCP
            };
            File.WriteAllLines(path, lines, new UTF8Encoding(false));
        }

        private static CodePageSnapshot LoadSnapshot(string path)
        {
            if (String.IsNullOrEmpty(path) || !File.Exists(path)) return null;
            try
            {
                Dictionary<string, string> values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (string line in File.ReadAllLines(path, new UTF8Encoding(false, true)))
                {
                    int separator = line.IndexOf('=');
                    if (separator <= 0) continue;
                    values[line.Substring(0, separator).Trim()] = line.Substring(separator + 1).Trim();
                }
                string schema;
                if (!values.TryGetValue("schemaVersion", out schema) || schema != "1") return null;
                CodePageSnapshot snapshot = new CodePageSnapshot();
                values.TryGetValue("createdUtc", out snapshot.CreatedUtc);
                values.TryGetValue("ACP", out snapshot.ACP);
                values.TryGetValue("OEMCP", out snapshot.OEMCP);
                values.TryGetValue("MACCP", out snapshot.MACCP);
                return IsValidSnapshot(snapshot) ? snapshot : null;
            }
            catch { return null; }
        }

        private static string GetLatestOriginalBackup()
        {
            return SelectOriginalBackup(BackupRoot);
        }

        internal static string SelectOriginalBackup(string root)
        {
            try
            {
                if (!Directory.Exists(root)) return null;
                return Directory.GetFiles(root, "utf8-original-*.ini")
                    .OrderByDescending(path => path, StringComparer.OrdinalIgnoreCase)
                    .FirstOrDefault(path => IsLegacySnapshot(LoadSnapshot(path)));
            }
            catch { return null; }
        }

        private static bool IsLegacySnapshot(CodePageSnapshot snapshot)
        {
            return IsValidSnapshot(snapshot) && snapshot.ACP != "65001" &&
                snapshot.OEMCP != "65001" && snapshot.MACCP != "65001";
        }

        private static bool IsValidSnapshot(CodePageSnapshot snapshot)
        {
            return snapshot != null && IsValidCodePage(snapshot.ACP) &&
                IsValidCodePage(snapshot.OEMCP) && IsValidCodePage(snapshot.MACCP);
        }

        private static bool IsValidCodePage(string value)
        {
            int codePage;
            if (!Int32.TryParse(value, out codePage) || codePage <= 0 || codePage > 65535) return false;
            try { return Encoding.GetEncoding(codePage).CodePage == codePage; }
            catch (ArgumentException) { return false; }
        }
    }

    internal static class CandidateSelfTest
    {
        public static bool Run(string reportPath)
        {
            List<string> lines = new List<string>();
            bool allPassed = true;
            Action<string, bool> record = delegate(string name, bool passed)
            {
                lines.Add(name + "=" + (passed ? "PASS" : "FAIL"));
                if (!passed) allPassed = false;
            };

            PythonProbe missingPython = new PythonProbe { Available = false };
            PythonProbe oldPython = new PythonProbe
            {
                Available = true,
                Major = 3,
                Minor = 10,
                Version = "Python 3.10.0",
                Executable = "mock-python.exe"
            };
            PythonProbe readyPython = new PythonProbe
            {
                Available = true,
                Major = 3,
                Minor = 11,
                Version = "Python 3.11.0",
                Executable = "mock-python.exe"
            };

            record("PYTHON_MISSING", Detector.EvaluatePythonForSelfTest(missingPython, false, false, false).Level == CheckLevel.Missing);
            record("PYTHON_TOO_OLD", Detector.EvaluatePythonForSelfTest(oldPython, true, true, true).Level == CheckLevel.Warning);
            record("PYTHON_PIP_BROKEN", Detector.EvaluatePythonForSelfTest(readyPython, true, false, true).Level == CheckLevel.Warning);
            record("PYTHON_VENV_BROKEN", Detector.EvaluatePythonForSelfTest(readyPython, true, true, false).Level == CheckLevel.Warning);
            record("PYTHON_READY", Detector.EvaluatePythonForSelfTest(readyPython, true, true, true).Level == CheckLevel.Ready);
            record("INTEGRATION_WITHOUT_PYTHON", Detector.EvaluateIntegrationForSelfTest(missingPython, true).Level == CheckLevel.Missing);
            record("INTEGRATION_MISSING", Detector.EvaluateIntegrationForSelfTest(readyPython, false).Level == CheckLevel.Missing);
            record("INTEGRATION_READY", Detector.EvaluateIntegrationForSelfTest(readyPython, true).Level == CheckLevel.Ready);
            record("LIBREOFFICE_MISSING", Detector.EvaluateLibreOfficeForSelfTest(false, false, false).Level == CheckLevel.Missing);
            record("LIBREOFFICE_COMMAND_BROKEN", Detector.EvaluateLibreOfficeForSelfTest(true, false, true).Level == CheckLevel.Warning);
            record("LIBREOFFICE_PATH_MISSING", Detector.EvaluateLibreOfficeForSelfTest(true, true, false).Level == CheckLevel.Warning);
            record("LIBREOFFICE_READY", Detector.EvaluateLibreOfficeForSelfTest(true, true, true).Level == CheckLevel.Ready);
            record("WINGET_MISSING", RepairEngine.EvaluatePrerequisiteForSelfTest("Git", false, true) != null);
            record("PYTHON_FOR_PACKAGE_MISSING", RepairEngine.EvaluatePrerequisiteForSelfTest("PyYAML", true, false) != null);
            record("REPAIR_PREREQUISITES_READY", RepairEngine.EvaluatePrerequisiteForSelfTest("Git", true, true) == null);
            List<string> runtimeTargets = RepairEngine.GetAutomaticItems(new[] {
                new CheckResult { Name = Detector.DotNetSdkName, Level = CheckLevel.Missing },
                new CheckResult { Name = Detector.DesktopRuntimeName, Level = CheckLevel.Missing },
                new CheckResult { Name = Detector.WebView2Name, Level = CheckLevel.Missing }
            });
            record("RUNTIME_REPAIR_TARGETS", runtimeTargets.Count == 1 && runtimeTargets[0] == Detector.WebView2Name);
            record("RUNTIME_INSTALL_X64", runtimeTargets.All(name => RepairEngine.BuildWingetInstallArguments(name).Contains("--architecture x64")));
            record("RUNTIME_LIBRARY_REUSES_SDK", RepairEngine.GetLibraryPackageId(Detector.DesktopRuntimeName) == "Microsoft.DotNet.SDK.8");
            record("MANUAL_ONLY_EXCLUDES_DOTNET", RepairEngine.IsManualOnly(Detector.DotNetSdkName) && RepairEngine.IsManualOnly(Detector.DesktopRuntimeName));
            CheckResult integrationAutoFix = Detector.EvaluateIntegrationAutoFixForSelfTest(readyPython);
            record("INTEGRATION_AUTOFIX_MARKED", integrationAutoFix.AutoFixId == "vscode_python_extension"
                && integrationAutoFix.Level == CheckLevel.Missing
                && integrationAutoFix.Guidance.Contains("自动配置"));
            record("AUTOFIX_VSCODE_CLI_PROBE", AutoFixEngine.CanAutoFix("vscode_python_extension") == (AutoFixEngine.FindVsCodeCli() != null));


            string dotnetRoot = Path.Combine(Path.GetTempPath(), "DotNetArchitectureTest-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(dotnetRoot);
            try
            {
                string x86 = Path.Combine(dotnetRoot, "x86.exe"), x64 = Path.Combine(dotnetRoot, "x64.exe");
                string brokenX64 = Path.Combine(dotnetRoot, "broken-x64.exe");
                Action<string, ushort> createPe = (path, machine) =>
                {
                    byte[] bytes = new byte[128];
                    bytes[0] = 0x4d; bytes[1] = 0x5a; bytes[0x3c] = 64;
                    bytes[64] = 0x50; bytes[65] = 0x45;
                    Array.Copy(BitConverter.GetBytes(machine), 0, bytes, 68, 2);
                    File.WriteAllBytes(path, bytes);
                };
                createPe(x86, 0x014c); createPe(x64, 0x8664); createPe(brokenX64, 0x8664);
                record("DOTNET_PE_ARCHITECTURE", !Detector.IsX64Executable(x86) && Detector.IsX64Executable(x64));
                string selected;
                int x86Calls = 0;
                Func<string, CommandResult> installed = path =>
                {
                    if (path == x86) { x86Calls++; return new CommandResult { ExitCode = 0, Output = "Microsoft.WindowsDesktop.App 6.0.2 [x86]" }; }
                    if (path == brokenX64) return new CommandResult { ExitCode = 1, Output = "" };
                    return new CommandResult { ExitCode = 0, Output = "Microsoft.WindowsDesktop.App 8.0.31 [x64]" };
                };
                string version = Detector.FindX64DesktopRuntime(new[] { x86, x64 }, Detector.IsX64Executable, installed, out selected);
                record("DOTNET_X86_FIRST_X64_READY", version == "8.0.31" && selected == x64 && x86Calls == 0);
                version = Detector.FindX64DesktopRuntime(new[] { brokenX64, x64 }, Detector.IsX64Executable, installed, out selected);
                record("DOTNET_FAILED_HOST_FALLBACK", version == "8.0.31" && selected == x64);
                version = Detector.FindX64DesktopRuntime(new[] { x86 }, Detector.IsX64Executable,
                    path => new CommandResult { ExitCode = 0, Output = "Microsoft.WindowsDesktop.App 8.0.31 [x86]" }, out selected);
                record("DOTNET_X86_ONLY_REJECTED", version == "缺少" && selected == null);
                version = Detector.FindX64DesktopRuntime(new[] { x64 }, Detector.IsX64Executable,
                    path => new CommandResult { ExitCode = 0, Output = "Microsoft.NETCore.App 8.0.31 [x64]\nMicrosoft.WindowsDesktop.App 9.0.1 [x64]" }, out selected);
                record("DOTNET_WRONG_RUNTIME_REJECTED", version == "缺少");
            }
            finally
            {
                foreach (string file in Directory.GetFiles(dotnetRoot)) File.Delete(file);
                Directory.Delete(dotnetRoot);
            }

            string utf8Report = Path.Combine(Path.GetTempPath(), "EnvironmentDetectorUtf8SelfTest-" + Guid.NewGuid().ToString("N") + ".txt");
            try
            {
                record("UTF8_BACKUP_FORMAT", Utf8Repair.RunFileFormatSelfTest(utf8Report));
            }
            finally
            {
                try { if (File.Exists(utf8Report)) File.Delete(utf8Report); } catch { }
            }
            lines.Add("SYSTEM_CHANGES=0");
            string parent = Path.GetDirectoryName(Path.GetFullPath(reportPath));
            if (!String.IsNullOrEmpty(parent)) Directory.CreateDirectory(parent);
            File.WriteAllLines(reportPath, lines.ToArray(), new UTF8Encoding(false));
            return allPassed;
        }
    }

    internal static class ModernUi
    {
        public static GraphicsPath RoundedRectangle(Rectangle bounds, int radius)
        {
            int diameter = Math.Max(2, radius * 2);
            GraphicsPath path = new GraphicsPath();
            path.AddArc(bounds.Left, bounds.Top, diameter, diameter, 180, 90);
            path.AddArc(bounds.Right - diameter, bounds.Top, diameter, diameter, 270, 90);
            path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
            path.AddArc(bounds.Left, bounds.Bottom - diameter, diameter, diameter, 90, 90);
            path.CloseFigure();
            return path;
        }
    }

    internal sealed class ModernButton : Button
    {
        public bool Primary { get; set; }
        private bool hovered;
        public ModernButton(string text, Color color)
        {
            Text = text;
            Primary = color == Color.FromArgb(37, 99, 235) || color == Color.FromArgb(22, 163, 74);
            FlatStyle = FlatStyle.Flat;
            FlatAppearance.BorderSize = 0;
            Cursor = Cursors.Hand;
            Font = new Font("Microsoft YaHei UI", 9F, FontStyle.Regular);
            Height = 40;
            SetStyle(ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            ApplyTheme();
        }
        public void ApplyTheme()
        {
            BackColor = Primary ? UiTheme.AccentSoft : UiTheme.Surface;
            ForeColor = Primary ? UiTheme.Accent : UiTheme.Text;
            Invalidate();
        }
        protected override void OnMouseEnter(EventArgs e) { hovered = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { hovered = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(Parent == null ? UiTheme.Window : Parent.BackColor);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle bounds = new Rectangle(0, 0, Width - 1, Height - 1);
            using (GraphicsPath path = ModernUi.RoundedRectangle(bounds, UiTheme.Px(this, 8)))
            using (Brush brush = new SolidBrush(Enabled ? (hovered ? UiTheme.Soft : (Primary ? UiTheme.AccentSoft : UiTheme.Surface)) : UiTheme.Soft))
            using (Pen pen = new Pen(Primary && Enabled ? UiTheme.AccentSoft : UiTheme.Border)) {
                e.Graphics.FillPath(brush, path); e.Graphics.DrawPath(pen, path);
            }
            TextRenderer.DrawText(e.Graphics, Text, Font, bounds, Enabled ? (Primary ? UiTheme.Accent : UiTheme.Text) : UiTheme.Muted,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
            if (Focused && ShowFocusCues) ControlPaint.DrawFocusRectangle(e.Graphics, Rectangle.Inflate(bounds, -4, -4), UiTheme.Accent, BackColor);
        }
    }

    internal sealed class ResultCard : Panel
    {
        private readonly Label detail;
        private readonly Label status;
        private readonly Label title;
        private readonly Label group;
        private readonly CheckResult result;
        private readonly ToolTip help = new ToolTip { AutoPopDelay = 30000, InitialDelay = 400, ReshowDelay = 100 };
        private bool layingOut;

        public ResultCard(CheckResult result, bool companyUser)
        {
            this.result = result;
            DownloadRegistry.DownloadInfo download = null;
            bool canDownload = result.Level != CheckLevel.Ready && result.AutoFixId != GitSetup.ConfigurationId &&
                DownloadRegistry.TryGet(result.Name, out download);
            bool canAutoFix = result.Level != CheckLevel.Ready && !String.IsNullOrEmpty(result.AutoFixId) && AutoFixEngine.CanAutoFix(result.AutoFixId);
            Height = 192; Width = 500;
            Margin = new Padding(0, 0, 14, 14);
            DoubleBuffered = true;
            group = new Label { Text = result.Importance + " · " + result.Group, Name = "muted", AutoSize = false,
                Font = new Font("Microsoft YaHei UI", 8.5F), BackColor = Color.Transparent, AutoEllipsis = true };
            title = new Label { Text = result.Name, Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold),
                BackColor = Color.Transparent, AutoEllipsis = true };
            status = new Label { Text = result.Level == CheckLevel.Ready ? "已就绪" : result.Level == CheckLevel.Warning ? "待配置" : "未安装",
                Font = new Font("Microsoft YaHei UI", 8.5F), TextAlign = ContentAlignment.MiddleCenter };
            detail = new Label { Text = result.Detail + (result.Level == CheckLevel.Ready ? "" : "  " + result.Guidance),
                Font = new Font("Microsoft YaHei UI", 9F), BackColor = Color.Transparent, AutoEllipsis = true };
            help.SetToolTip(detail, detail.Text); help.SetToolTip(title, title.Text);
            Controls.AddRange(new Control[] { group, title, status, detail });
            if (result.Name == "编码兼容与 UTF-8 范围") {
                AddNativeEncodingResetButton(); AddAutoFixButton(EncodingPolicy.SettingsAction, result.Name, 154);
            } else if (result.AutoFixId == PowerShellSetup.ConfigurationId) {
                AddAutoFixButton(result.AutoFixId, result.Name);
                if (DownloadRegistry.TryGet(result.Name, out download)) AddOpenUrlButton(download.OfficialUrl, "官方下载", Color.FromArgb(37,99,235), 190);
            } else if (canDownload) {
                int x = 22;
                if (!String.IsNullOrWhiteSpace(download.DirectUrl)) x = AddDirectDownloadButton(download, x);
                if (!String.IsNullOrWhiteSpace(download.MirrorUrl)) x = AddOpenUrlButton(download.MirrorUrl, "镜像下载", Color.FromArgb(22, 163, 74), x);
                if (!String.IsNullOrWhiteSpace(download.OfficialUrl)) x = AddOpenUrlButton(download.OfficialUrl, "官网下载", Color.FromArgb(37, 99, 235), x);
                if (companyUser && !String.IsNullOrWhiteSpace(download.PanUrl)) AddOpenUrlButton(download.PanUrl, "网盘下载", Color.FromArgb(245, 158, 11), x);
            } else if (canAutoFix) AddAutoFixButton(result.AutoFixId, result.Name);
            Resize += delegate { LayoutCard(title); };
            ApplyTheme(); LayoutCard(title);
        }

        public void ApplyTheme()
        {
            BackColor = UiTheme.Surface; title.ForeColor = UiTheme.Text;
            detail.ForeColor = group.ForeColor = UiTheme.Muted;
            status.ForeColor = result.Level == CheckLevel.Ready ? UiTheme.Good : result.Level == CheckLevel.Warning ? UiTheme.Warning : UiTheme.Danger;
            status.BackColor = UiTheme.Soft;
            foreach (ModernButton button in Controls.OfType<ModernButton>()) button.ApplyTheme();
            Invalidate();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) help.Dispose();
            base.Dispose(disposing);
        }

        private int AddOpenUrlButton(string url, string text, Color color, int x)
        {
            ModernButton button = new ModernButton(text, color)
            {
                Primary = false,
                Size = new Size(96, 30),
                Location = new Point(x, 108),
                Font = new Font("Microsoft YaHei UI", 9F, FontStyle.Bold)
            };
            button.Click += delegate
            {
                try { Process.Start(url); }
                catch (Exception ex) {
                    MessageBox.Show("网页未打开：" + ex.Message + "\r\n可复制以下官方地址到浏览器：\r\n" + url,
                        "打开下载页面失败", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            };
            Controls.Add(button);
            return x + 104;
        }

        private int AddDirectDownloadButton(DownloadRegistry.DownloadInfo info, int x)
        {
            ModernButton button = new ModernButton("下载", Color.FromArgb(37, 99, 235))
            {
                Size = new Size(96, 30),
                Location = new Point(x, 108),
                Font = new Font("Microsoft YaHei UI", 9F, FontStyle.Bold)
            };
            button.Click += delegate
            {
                SafeDownloadWebClient running = button.Tag as SafeDownloadWebClient;
                if (running != null)
                {
                    running.CancelDownload();
                    button.Enabled = false;
                    button.Text = "取消中…";
                    return;
                }
                button.Enabled = false;
                button.Text = "解析…";
                Task.Run(() => DirectDownloader.ResolveUrl(info))
                    .ContinueWith(task =>
                    {
                        if (button.IsDisposed) return;
                        string url = null;
                        string reason = task.IsFaulted ? task.Exception.GetBaseException().Message :
                            (task.IsCanceled ? "地址解析已取消。" : null);
                        if (reason == null) url = task.Result;
                        if (String.IsNullOrWhiteSpace(url))
                        {
                            button.Enabled = true;
                            button.Text = "下载";
                            MessageBox.Show("获取下载地址失败：" + (reason ?? "官方接口没有返回有效下载地址。") + Environment.NewLine + "也可使用官网下载入口。",
                                "下载失败", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        string saveName = info.DynamicUrl ? Path.GetFileName(new Uri(url).LocalPath) : info.SaveName;
                        StartFileDownload(button, url, saveName);
                    }, TaskScheduler.FromCurrentSynchronizationContext());
            };
            Controls.Add(button);
            return x + 104;
        }

        private static void PostDownloadUpdate(ModernButton button, Action update)
        {
            if (button.IsDisposed || !button.IsHandleCreated) return;
            try
            {
                button.BeginInvoke(new Action(delegate { if (!button.IsDisposed) update(); }));
            }
            catch (InvalidOperationException) { } // The window can close between the check and BeginInvoke.
        }

        private void StartFileDownload(ModernButton button, string url, string saveName)
        {
            PackageDownloadFile package = null;
            SafeDownloadWebClient client = null;
            try
            {
                package = new PackageDownloadFile(DirectDownloader.DownloadsFolder(), saveName);
                client = new SafeDownloadWebClient();
                PackageDownloadFile downloadFile = package;
                SafeDownloadWebClient downloadClient = client;
                int finished = 0;
                long lastProgressTick = 0;
                EventHandler onDisposed = delegate { downloadClient.CancelDownload(); };
                Action<string> finish = failure =>
                {
                    if (Interlocked.Exchange(ref finished, 1) != 0) return;
                    string destination = null;
                    try
                    {
                        if (failure == null) destination = downloadFile.Complete(downloadClient.ExpectedContentLength);
                    }
                    catch (Exception ex) { failure = ex.Message; }
                    finally
                    {
                        string cleanup = downloadFile.Cleanup();
                        if (cleanup != null) failure = (failure ?? "") + Environment.NewLine + cleanup;
                        downloadClient.Dispose();
                    }
                    string finalFailure = failure;
                    string finalDestination = destination;
                    PostDownloadUpdate(button, delegate
                    {
                        button.Disposed -= onDisposed;
                        button.Tag = null;
                        button.Enabled = true;
                        button.Text = "下载";
                        if (finalFailure == null)
                            MessageBox.Show("已下载到下载文件夹：" + finalDestination + Environment.NewLine + Environment.NewLine + "双击安装包即可安装。",
                                "下载完成", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show("下载未完成：" + finalFailure + Environment.NewLine + "可改用“镜像下载/官网下载”按钮。",
                                "下载未完成", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    });
                };
                client.DownloadProgressChanged += (s, e) =>
                {
                    long now = Stopwatch.GetTimestamp();
                    long previous = Interlocked.Read(ref lastProgressTick);
                    if (e.ProgressPercentage < 100 && previous != 0 && (now - previous) * 1000.0 / Stopwatch.Frequency < 200) return;
                    Interlocked.Exchange(ref lastProgressTick, now);
                    PostDownloadUpdate(button, delegate
                    {
                        if (button.Enabled && Object.ReferenceEquals(button.Tag, downloadClient) &&
                            Interlocked.CompareExchange(ref finished, 0, 0) == 0)
                            button.Text = e.TotalBytesToReceive > 0 ? "取消 " + e.ProgressPercentage + "%" :
                                "取消 " + (e.BytesReceived / 1048576.0).ToString("0.#") + "MB";
                    });
                };
                client.DownloadFileCompleted += (s, e) => finish(downloadClient.FailureReason(e));
                button.Tag = client;
                button.Text = "取消 0%";
                button.Enabled = true;
                button.Disposed += onDisposed;
                // Capture a worker synchronization context so cleanup survives card/window disposal.
                Task.Run(delegate
                {
                    try { downloadClient.StartDownload(new Uri(url), downloadFile.TemporaryPath); }
                    catch (Exception ex)
                    {
                        finish(downloadClient.FailureReason(new System.ComponentModel.AsyncCompletedEventArgs(ex, false, null)));
                    }
                });
            }
            catch (Exception ex)
            {
                if (client != null) client.Dispose();
                string cleanup = package == null ? null : package.Cleanup();
                button.Tag = null;
                button.Enabled = true;
                button.Text = "下载";
                MessageBox.Show("下载启动失败：" + ex.Message + (cleanup == null ? "" : Environment.NewLine + cleanup),
                    "下载失败", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        private void AddNativeEncodingResetButton()
        {
            ModernButton button = new ModernButton("拨乱反正", Color.FromArgb(37, 99, 235)) {
                Name = "nativeEncodingResetButton", Size = new Size(120, 30),
                Location = new Point(22, 108), Font = new Font("Microsoft YaHei UI", 9F, FontStyle.Bold)
            };
            button.Click += async delegate {
                MainForm main = FindForm() as MainForm;
                if (main != null) await main.RunNativeEncodingReset();
            };
            Controls.Add(button);
        }

        private void AddAutoFixButton(string autoFixId, string itemName, int x = 22)
        {
            bool powershellMsi = autoFixId == PowerShellSetup.ConfigurationId;
            bool gitIdentity = autoFixId == GitSetup.ConfigurationId;
            bool encodingSettings = autoFixId == EncodingPolicy.SettingsAction;
            string actionLabel = powershellMsi ? "安装/修复 MSI" : (encodingSettings ? "系统编码设置" : (gitIdentity ? "配置提交身份" : "自动配置"));
            ModernButton button = new ModernButton(actionLabel, Color.FromArgb(37, 99, 235))
            {
                Size = new Size(gitIdentity || encodingSettings ? 140 : 104, 30),
                Location = new Point(x, 108),
                Font = new Font("Microsoft YaHei UI", 9F, FontStyle.Bold)
            };
            button.Click += async delegate
            {
                if (encodingSettings) { EncodingPolicy.OpenSettings(FindForm()); return; }
                if (gitIdentity) {
                    using (var dialog = new GitIdentityDialog(GitSetup.FindGit())) {
                        if (dialog.ShowDialog(FindForm()) == DialogResult.OK) {
                            MainForm main = FindForm() as MainForm;
                            if (main != null) await main.RunScan();
                        }
                    }
                    return;
                }
                button.Enabled = false;
                button.Text = "配置中…";
                RepairResult fix = await Task.Run(() => AutoFixEngine.Run(autoFixId));
                button.Enabled = true;
                button.Text = actionLabel;
                if (powershellMsi) { MainForm main = FindForm() as MainForm; if (main != null) await main.RunScan(); }
                MessageBox.Show((fix.Success ? "✓ " : "× ") + fix.Detail,
                    fix.Success ? "自动配置完成" : "自动配置失败",
                    MessageBoxButtons.OK,
                    fix.Success ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
            };
            Controls.Add(button);
        }

        private int AddDownloadButton(string url, string text, Color color, int x)
        {
            ModernButton button = new ModernButton(text, color)
            {
                Primary = false,
                Size = new Size(104, 30),
                Location = new Point(x, 108),
                Font = new Font("Microsoft YaHei UI", 9F, FontStyle.Bold)
            };
            button.Click += delegate
            {
                try { Process.Start(url); }
                catch (Exception) { }
            };
            Controls.Add(button);
            return x + 112;
        }

        private void LayoutCard(Label name)
        {
            if (layingOut || detail == null || Width < 10) return;
            layingOut = true;
            try {
                int pad = UiTheme.Px(this, 20), gap = UiTheme.Px(this, 8), contentWidth = Math.Max(100, Width - pad * 2);
                status.SetBounds(Width - pad - UiTheme.Px(this, 76), pad - 2, UiTheme.Px(this, 76), UiTheme.Px(this, 26));
                group.SetBounds(pad, pad, contentWidth - status.Width - gap, UiTheme.Px(this, 23));
                title.SetBounds(pad, pad + UiTheme.Px(this, 33), contentWidth, UiTheme.Px(this, 30));
                detail.SetBounds(pad, title.Bottom + UiTheme.Px(this, 8), contentWidth, UiTheme.Px(this, 48));
                int x = pad, y = detail.Bottom + UiTheme.Px(this, 12), buttonHeight = UiTheme.Px(this, 32);
                foreach (ModernButton button in Controls.OfType<ModernButton>()) {
                    int width = Math.Max(UiTheme.Px(this, 80), TextRenderer.MeasureText(button.Text, button.Font).Width + UiTheme.Px(this, 28));
                    // Reserve enough width for download progress / cancel text without relayout on each update.
                    if (button.Text == "下载") width = UiTheme.Px(this, 108);
                    if (x + width > Width - pad && x > pad) { x = pad; y += buttonHeight + gap; }
                    button.SetBounds(x, y, width, buttonHeight); x += width + gap;
                }
                Height = Controls.OfType<ModernButton>().Any() ? y + buttonHeight + pad : detail.Bottom + pad;
            } finally { layingOut = false; }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.Clear(Parent == null ? UiTheme.Window : Parent.BackColor);
            using (GraphicsPath path = ModernUi.RoundedRectangle(new Rectangle(0, 0, Width - 1, Height - 1), UiTheme.Px(this, 12)))
            using (Brush brush = new SolidBrush(UiTheme.Surface))
            using (Pen pen = new Pen(UiTheme.Border)) { e.Graphics.FillPath(brush, path); e.Graphics.DrawPath(pen, path); }
        }
    }

    internal sealed class MoonPhaseIndicator : Control
    {
        private int phaseIndex;
        private readonly Image[] phaseImages;
        private static readonly string[] ResourceNames =
        {
            "EnvironmentDetector.Moon01Full.png",
            "EnvironmentDetector.Moon02WaningGibbous.png",
            "EnvironmentDetector.Moon03LastQuarter.png",
            "EnvironmentDetector.Moon04WaningCrescent.png",
            "EnvironmentDetector.Moon05New.png",
            "EnvironmentDetector.Moon06WaxingCrescent.png",
            "EnvironmentDetector.Moon07FirstQuarter.png",
            "EnvironmentDetector.Moon08WaxingGibbous.png"
        };

        public MoonPhaseIndicator()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.UserPaint, true);
            BackColor = Color.Transparent;
            Size = new Size(54, 54);
            phaseImages = ResourceNames.Select(LoadEmbeddedImage).ToArray();
        }

        public int PhaseIndex
        {
            get { return phaseIndex; }
            set
            {
                int normalized = ((value % 8) + 8) % 8;
                if (phaseIndex == normalized) return;
                phaseIndex = normalized;
                Invalidate();
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
            e.Graphics.CompositingQuality = CompositingQuality.HighQuality;
            e.Graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
            int side = Math.Max(1, Math.Min(Width, Height) - 4);
            Rectangle target = new Rectangle((Width - side) / 2, (Height - side) / 2, side, side);
            Image image = phaseImages[phaseIndex];
            using (ImageAttributes attributes = new ImageAttributes())
            {
                attributes.SetWrapMode(WrapMode.TileFlipXY);
                e.Graphics.DrawImage(image, target, 0, 0, image.Width, image.Height,
                    GraphicsUnit.Pixel, attributes);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && phaseImages != null)
                foreach (Image image in phaseImages) image.Dispose();
            base.Dispose(disposing);
        }

        private static Image LoadEmbeddedImage(string resourceName)
        {
            using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName))
            {
                if (stream == null) throw new InvalidOperationException("Missing embedded moon asset: " + resourceName);
                using (Image source = Image.FromStream(stream))
                {
                    Bitmap premultiplied = new Bitmap(source.Width, source.Height, PixelFormat.Format32bppPArgb);
                    using (Graphics graphics = Graphics.FromImage(premultiplied))
                    {
                        graphics.CompositingMode = CompositingMode.SourceCopy;
                        graphics.DrawImage(source, new Rectangle(0, 0, source.Width, source.Height),
                            0, 0, source.Width, source.Height, GraphicsUnit.Pixel);
                    }
                    return premultiplied;
                }
            }
        }
    }

    internal sealed class BusyStatusCard : Panel
    {
        public BusyStatusCard()
        {
            BackColor = UiTheme.Surface;
            DoubleBuffered = true;
            Height = 106;
            Padding = new Padding(0);
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            if (Width <= 0 || Height <= 0) return;
            using (GraphicsPath path = ModernUi.RoundedRectangle(new Rectangle(0, 0, Width, Height), 14))
                Region = new Region(path);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using (GraphicsPath path = ModernUi.RoundedRectangle(new Rectangle(0, 0, Width - 1, Height - 1), 14))
            using (Pen pen = new Pen(UiTheme.Border))
                e.Graphics.DrawPath(pen, path);
        }
    }

    internal sealed class BusyWarningDialog : ModernFrame
    {
        public BusyWarningDialog(bool closing)
        {
            SuspendLayout();
            Text = "环境配置正在安装";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            ControlBox = false;
            ShowInTaskbar = false;
            MaximizeBox = false;
            MinimizeBox = false;
            ClientSize = new Size(510, 236);
            BackColor = UiTheme.Window;
            Font = new Font("Microsoft YaHei UI", 9F, FontStyle.Regular, GraphicsUnit.Point);

            MoonPhaseIndicator moon = new MoonPhaseIndicator
            {
                PhaseIndex = 0,
                Size = new Size(54, 54),
                Location = new Point(27, 24)
            };
            Label title = new Label
            {
                Text = "正在安装，先不要" + (closing ? "关闭" : "切换") + "窗口",
                ForeColor = UiTheme.Text,
                Font = new Font("Microsoft YaHei UI", 14F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(96, 32)
            };
            Label detail = new Label
            {
                Text = closing
                    ? "环境补全仍在进行。请等待完成后再关闭窗口，当前任务不会被中断。"
                    : "环境补全仍在进行。请等待完成后再切换模块，当前任务不会被中断。",
                ForeColor = UiTheme.Muted,
                Font = new Font("Microsoft YaHei UI", 9.5F, FontStyle.Regular),
                Location = new Point(32, 96),
                Size = new Size(446, 50)
            };
            ModernButton waitButton = new ModernButton("继续等待", Color.FromArgb(37, 99, 235))
            {
                Width = 126,
                Left = 352,
                Top = 166,
                DialogResult = DialogResult.OK
            };
            AcceptButton = waitButton;
            Controls.Add(moon);
            Controls.Add(title);
            Controls.Add(detail);
            Controls.Add(waitButton);
            foreach (Control child in Controls) child.Top += 42;
            ClientSize = new Size(ClientSize.Width, ClientSize.Height + 42);
            UseModernFrame(false, false, false);
            AutoScaleDimensions = new SizeF(96F, 96F); AutoScaleMode = AutoScaleMode.Dpi;
            UiTheme.Apply(this);
            ResumeLayout(true);
        }
    }

    internal sealed class MainForm : ModernFrame
    {
        [DllImport("dwmapi.dll")]
        private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int size);

        private bool codexMode;
        private readonly bool companyUser;
        private readonly Label titleLabel;
        private readonly Label summary;
        private readonly Label note;
        private readonly ModernButton themeButton;
        private bool layoutResultsRunning;
        private readonly FlowLayoutPanel resultsPanel;
        private readonly ModernButton refreshButton;
        private readonly ModernButton copyButton;
        private readonly ModernButton repairButton;
        private readonly ModernButton restoreUtf8Button;
        private readonly BusyStatusCard busyStatusCard;
        private readonly MoonPhaseIndicator busyMoon;
        private readonly Label busyTitle;
        private readonly Label busyItem;
        private readonly Label busyProgress;
        private readonly bool installationPreviewMode;
        private readonly System.Windows.Forms.Timer busyAnimationTimer;
        private bool scanRunning;
        private bool backgroundOperationRunning;
        private bool busyPresentationRunning;
        private bool busyWarningOpen;
        private int moonPhaseIndex;
        private DateTime backgroundOperationStartedAt;
        private string backgroundOperationLabel = "";
        private string backgroundOperationItem = "正在准备…";
        private string busyIdleStatus = "准备中";
        private int backgroundOperationPosition;
        private int backgroundOperationTotal;
        private List<CheckResult> lastAllResults = new List<CheckResult>();
        private List<CheckResult> lastResults = new List<CheckResult>();
        private const int MoonPhaseCount = 8;

        public MainForm(bool useCodexMode, bool previewInstallation, bool companyUser)
        {
            SuspendLayout();
            codexMode = useCodexMode;
            this.companyUser = companyUser;
            installationPreviewMode = previewInstallation;
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }
            string moduleName = codexMode ? "Codex 环境补全" : "软件安装检查";
            Text = moduleName + " · Codex 工具箱";
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(740, 620);
            Size = new Size(1160, 900);
            BackColor = UiTheme.Window;
            Font = new Font("Microsoft YaHei UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            Panel header = new Panel { Dock = DockStyle.Top, Height = 138, BackColor = UiTheme.Window };
            Label eyebrow = new Label
            {
                Name = "accent", Text = "CODEX TOOLS  /  环境与软件",
                ForeColor = UiTheme.Accent,
                Font = new Font(Font.FontFamily, 8.5F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(32, 22)
            };
            titleLabel = new Label
            {
                Text = moduleName,
                ForeColor = UiTheme.Text,
                Font = new Font(Font.FontFamily, 22F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(28, 43)
            };
            summary = new Label
            {
                Text = "准备检测…",
                ForeColor = UiTheme.Good,
                Font = new Font(Font.FontFamily, 11F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(32, 94)
            };
            note = new Label
            {
                Name = "muted", Text = codexMode
                    ? "检测、补全、复查在同一个窗口完成；需要重启时会明确提示。"
                    : "只检查需要用户亲自安装的软件，不会下载或安装大型应用。",
                ForeColor = UiTheme.Muted,
                AutoSize = true,
                Location = new Point(32, 122)
            };
            header.Controls.Add(eyebrow);
            header.Controls.Add(titleLabel);
            header.Controls.Add(summary);
            header.Controls.Add(note);
            themeButton = new ModernButton(UiTheme.Dark ? "浅色" : "暗色", Color.Gray) { Width = 92, Height = 36, Top = 28, Anchor = AnchorStyles.Top | AnchorStyles.Right };
            header.Controls.Add(themeButton);
            header.Resize += delegate { themeButton.Left = header.ClientSize.Width - themeButton.Width - UiTheme.Px(header, 30); };
            themeButton.Click += delegate {
                UiTheme.Set(!UiTheme.Dark); UiTheme.Apply(this);
                themeButton.Text = UiTheme.Dark ? "浅色" : "暗色";
                if (lastResults.Count > 0 && !scanRunning) UpdateSummary(lastResults);
                if (!UiTheme.Save()) MessageBox.Show(this, "本次主题已切换，但偏好未能保存。", "主题", MessageBoxButtons.OK, MessageBoxIcon.Information);
            };

            resultsPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                BackColor = UiTheme.Window,
                AutoScroll = true,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = true,
                Padding = new Padding(0, 0, 4, 12)
            };
            resultsPanel.Resize += delegate { ResizeResultCards(); };

            busyStatusCard = new BusyStatusCard
            {
                Dock = DockStyle.Top,
                Visible = false,
                Margin = new Padding(0, 0, 0, 12)
            };
            busyMoon = new MoonPhaseIndicator
            {
                PhaseIndex = 0,
                Size = new Size(56, 56),
                Location = new Point(20, 23),
                BackColor = Color.Transparent
            };
            busyTitle = new Label
            {
                Text = "正在补全运行环境",
                ForeColor = UiTheme.Text,
                Font = new Font(Font.FontFamily, 12F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(91, 17),
                BackColor = Color.Transparent
            };
            busyItem = new Label
            {
                Text = "当前项目：正在准备…",
                ForeColor = UiTheme.Muted,
                Font = new Font(Font.FontFamily, 9F, FontStyle.Regular),
                AutoEllipsis = true,
                Location = new Point(92, 49),
                Size = new Size(520, 24),
                BackColor = Color.Transparent
            };
            busyProgress = new Label
            {
                Text = "处理进度：准备中 · 已用时间：00:00",
                ForeColor = UiTheme.Accent,
                Font = new Font(Font.FontFamily, 8.5F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(92, 75),
                BackColor = Color.Transparent
            };
            busyStatusCard.Controls.Add(busyMoon);
            busyStatusCard.Controls.Add(busyTitle);
            busyStatusCard.Controls.Add(busyItem);
            busyStatusCard.Controls.Add(busyProgress);
            busyStatusCard.Resize += delegate { busyItem.Width = Math.Max(300, busyStatusCard.ClientSize.Width - busyItem.Left - 24); };

            Panel sectionHeader = new Panel { Dock = DockStyle.Top, Height = 50, BackColor = UiTheme.Window };
            Label sectionTitle = new Label
            {
                Text = codexMode ? "运行环境" : "软件与工具",
                ForeColor = UiTheme.Text,
                Font = new Font(Font.FontFamily, 11F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(0, 12)
            };
            Label sectionHint = new Label
            {
                Name = "muted", Text = "按项目检查 · 按需处理",
                ForeColor = UiTheme.Muted,
                AutoSize = true,
                Top = 15,
                Anchor = AnchorStyles.Top | AnchorStyles.Right
            };
            sectionHeader.Controls.Add(sectionTitle);
            sectionHeader.Controls.Add(sectionHint);
            sectionHeader.Resize += delegate { sectionHint.Left = sectionHeader.ClientSize.Width - sectionHint.Width; };

            Panel resultsHost = new Panel { Dock = DockStyle.Fill, BackColor = UiTheme.Window };
            resultsHost.Controls.Add(resultsPanel);
            resultsHost.Controls.Add(busyStatusCard);
            Panel content = new Panel { Dock = DockStyle.Fill, BackColor = UiTheme.Window, Padding = new Padding(28, 6, 28, 8) };
            content.Controls.Add(resultsHost);
            content.Controls.Add(sectionHeader);

            Panel footer = new Panel { Dock = DockStyle.Bottom, Height = 86, BackColor = UiTheme.Window };
            refreshButton = new ModernButton("重新检测", Color.FromArgb(37, 99, 235)) { Width = 126, Left = 28, Top = 21 };
            copyButton = new ModernButton("复制报告", Color.FromArgb(51, 65, 85)) { Width = 126, Left = 166, Top = 21, Enabled = false };
            repairButton = new ModernButton("一键自动补全", Color.FromArgb(22, 163, 74)) { Width = 158, Left = 304, Top = 21, Visible = codexMode, Enabled = false };
            restoreUtf8Button = new ModernButton("恢复原编码", Color.FromArgb(71, 85, 105))
            {
                Width = 146,
                Left = 474,
                Top = 21,
                Visible = codexMode && Utf8Repair.CanRestore(),
                Enabled = codexMode && Utf8Repair.CanRestore()
            };
            Label privacy = new Label
            {
                Name = "muted", Text = "只读检测 · 不上传数据",
                AutoSize = true,
                ForeColor = UiTheme.Muted,
                Top = 34,
                Anchor = AnchorStyles.Top | AnchorStyles.Right
            };
            footer.Controls.Add(refreshButton);
            footer.Controls.Add(copyButton);
            footer.Controls.Add(repairButton);
            footer.Controls.Add(restoreUtf8Button);
            footer.Controls.Add(privacy);
            footer.Resize += delegate {
                privacy.Left = footer.ClientSize.Width - privacy.Width - UiTheme.Px(footer, 30);
                int right = restoreUtf8Button.Visible ? restoreUtf8Button.Right : repairButton.Visible ? repairButton.Right : copyButton.Right;
                privacy.Visible = privacy.Left > right + UiTheme.Px(footer, 20);
            };

            Controls.Add(content);
            Controls.Add(footer);
            Controls.Add(header);
            UiTheme.Apply(this);

            refreshButton.Click += async delegate { await RunScan(); };
            copyButton.Click += delegate { CopyReport(); };
            repairButton.Click += async delegate { await RunAutomaticRepair(); };
            restoreUtf8Button.Click += async delegate { await RunRestoreUtf8(); };
            busyAnimationTimer = new System.Windows.Forms.Timer { Interval = 280 };
            busyAnimationTimer.Tick += delegate { AdvanceBusyAnimation(); };
            Shown += async delegate
            {
                if (installationPreviewMode)
                    await RunInstallationPreview();
                else
                    await RunScan();
            };
            UseModernFrame(true, true, true);
            UiTheme.Apply(this);
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            ResumeLayout(true);
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            busyAnimationTimer.Stop();
            busyAnimationTimer.Dispose();
            base.OnFormClosed(e);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing && backgroundOperationRunning)
            {
                e.Cancel = true;
                ShowBusyWarning(true);
                return;
            }
            base.OnFormClosing(e);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            try
            {
                int enabled = UiTheme.Dark ? 1 : 0;
                DwmSetWindowAttribute(Handle, 20, ref enabled, sizeof(int));
                int rounded = 2;
                DwmSetWindowAttribute(Handle, 33, ref rounded, sizeof(int));
            }
            catch { }
        }

        internal async Task RunScan()
        {
            if (scanRunning) return;
            scanRunning = true;
            refreshButton.Enabled = false;
            copyButton.Enabled = false;
            repairButton.Enabled = false;
            if (codexMode)
            {
                repairButton.Text = "正在检查…";
                repairButton.BackColor = Color.FromArgb(51, 65, 85);
            }
            summary.ForeColor = UiTheme.Accent;
            summary.Text = "正在检测 " + Detector.ScanNames(codexMode).Length + (codexMode ? " 项可补全环境…" : " 项软件与集成…");
            resultsPanel.Controls.Clear();
            StartBusyPresentation(codexMode ? "正在检测可补全环境" : "正在检查软件与集成", 0, "检测中");
            SetBusyProgress("准备检测", 0, Detector.ScanNames(codexMode).Length);
            try
            {
                List<CheckResult> allResults = await Task.Run(() => Detector.ScanForMode(codexMode, SetBusyProgress));
                lastAllResults = allResults;
                ShowResultsForCurrentMode();
            }
            catch (Exception ex)
            {
                summary.ForeColor = UiTheme.Danger;
                summary.Text = "检测失败：" + ex.Message;
            }
            finally
            {
                StopBusyPresentation();
                refreshButton.Enabled = true;
                copyButton.Enabled = lastResults.Count > 0;
                scanRunning = false;
                UpdateRepairButtons();
            }
        }

        private void StartBusyPresentation(string title, int total, string idleStatus = "准备中")
        {
            busyPresentationRunning = true;
            backgroundOperationStartedAt = DateTime.UtcNow;
            backgroundOperationItem = "正在准备…";
            busyIdleStatus = idleStatus;
            backgroundOperationPosition = 0;
            backgroundOperationTotal = Math.Max(0, total);
            moonPhaseIndex = 0;
            busyTitle.Text = title;
            busyMoon.PhaseIndex = moonPhaseIndex;
            busyStatusCard.Visible = true;
            UpdateBusyPresentation();
            busyAnimationTimer.Start();
        }

        private void SetBusyProgress(string item, int position, int total)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new Action<string, int, int>(SetBusyProgress), item, position, total);
                return;
            }
            backgroundOperationItem = item;
            backgroundOperationPosition = position;
            backgroundOperationTotal = total;
            UpdateBusyPresentation();
        }

        private void AdvanceBusyAnimation()
        {
            if (!busyPresentationRunning) return;
            moonPhaseIndex = (moonPhaseIndex + 1) % MoonPhaseCount;
            busyMoon.PhaseIndex = moonPhaseIndex;
            UpdateBusyPresentation();
        }

        private void UpdateBusyPresentation()
        {
            TimeSpan elapsed = DateTime.UtcNow - backgroundOperationStartedAt;
            busyItem.Text = "当前项目：" + backgroundOperationItem;
            string position = backgroundOperationPosition > 0 && backgroundOperationTotal > 0
                ? backgroundOperationPosition + " / " + backgroundOperationTotal
                : busyIdleStatus;
            busyProgress.Text = "处理进度：" + position + " · 已用时间：" +
                ((int)elapsed.TotalMinutes).ToString("00") + ":" + elapsed.Seconds.ToString("00");
        }

        private void StopBusyPresentation()
        {
            busyPresentationRunning = false;
            busyAnimationTimer.Stop();
            busyStatusCard.Visible = false;
            backgroundOperationItem = "正在准备…";
            busyIdleStatus = "准备中";
            backgroundOperationPosition = 0;
            backgroundOperationTotal = 0;
        }

        private void ShowBusyWarning(bool closing)
        {
            if (busyWarningOpen || IsDisposed) return;
            busyWarningOpen = true;
            try
            {
                using (BusyWarningDialog dialog = new BusyWarningDialog(closing))
                    dialog.ShowDialog(this);
            }
            finally
            {
                busyWarningOpen = false;
            }
        }

        private async Task RunInstallationPreview()
        {
            string[] previewItems =
            {
                "PowerShell 7",
                "Git for Windows",
                "FFmpeg（含 FFprobe）",
                "LibreOffice（无头渲染）",
                "PyYAML 与 yt-dlp"
            };
            backgroundOperationRunning = true;
            backgroundOperationLabel = "正在模拟…";
            refreshButton.Enabled = false;
            copyButton.Enabled = false;
            repairButton.Enabled = false;
            restoreUtf8Button.Enabled = false;
            summary.ForeColor = UiTheme.Accent;
            summary.Text = "安装界面模拟中：不会修改这台电脑…";
            note.Text = "仅模拟等待动画、项目进度和窗口保护；不会运行任何安装或系统配置命令。";
            StartBusyPresentation("验收模拟：正在补全运行环境", previewItems.Length);
            try
            {
                for (int index = 0; index < previewItems.Length; index++)
                {
                    SetBusyProgress(previewItems[index], index + 1, previewItems.Length);
                    await Task.Delay(8000);
                }
            }
            finally
            {
                backgroundOperationRunning = false;
                backgroundOperationLabel = "";
                StopBusyPresentation();
                refreshButton.Enabled = true;
                summary.ForeColor = UiTheme.Good;
                summary.Text = "模拟验收完成：没有安装软件，也没有修改系统设置。";
                note.Text = "现在可以正常切换模块或关闭窗口；需要再次验收时可重新启动模拟模式。";
                UpdateRepairButtons();
            }
        }

        private void UpdateRepairButtons()
        {
            repairButton.Visible = codexMode;
            if (codexMode)
            {
                if (backgroundOperationRunning)
                {
                    repairButton.Text = backgroundOperationLabel;
                    repairButton.BackColor = Color.FromArgb(51, 65, 85);
                    repairButton.Enabled = false;
                    restoreUtf8Button.Visible = Utf8Repair.CanRestore();
                    restoreUtf8Button.Enabled = false;
                    return;
                }
                bool needsRepair = RepairEngine.GetAutomaticItems(lastResults).Count > 0;
                bool hasManualOnly = lastResults != null && lastResults.Any(item =>
                    item.Level != CheckLevel.Ready && RepairEngine.IsManualOnly(item.Name));
                if (needsRepair)
                {
                    repairButton.Text = "一键自动补全";
                    repairButton.BackColor = Color.FromArgb(22, 163, 74);
                    repairButton.Enabled = true;
                }
                else if (hasManualOnly)
                {
                    repairButton.Text = "手动项请自行下载";
                    repairButton.BackColor = Color.FromArgb(51, 65, 85);
                    repairButton.Enabled = false;
                }
                else if (lastResults != null && lastResults.Any(item => item.Level != CheckLevel.Ready))
                {
                    repairButton.Text = "仍有项目待配置";
                    repairButton.BackColor = Color.FromArgb(51, 65, 85);
                    repairButton.Enabled = false;
                }
                else
                {
                    repairButton.Text = "已配置齐全";
                    repairButton.BackColor = Color.FromArgb(51, 65, 85);
                    repairButton.Enabled = false;
                }
            }
            else
            {
                repairButton.Enabled = false;
            }
            restoreUtf8Button.Visible = codexMode && Utf8Repair.CanRestore();
            restoreUtf8Button.Enabled = restoreUtf8Button.Visible;
        }

        internal async Task RunNativeEncodingReset()
        {
            if (scanRunning || backgroundOperationRunning) return;
            scanRunning = true;
            backgroundOperationRunning = true;
            backgroundOperationLabel = "正在拨乱反正…";
            resultsPanel.Enabled = false;
            refreshButton.Enabled = copyButton.Enabled = repairButton.Enabled = restoreUtf8Button.Enabled = false;
            StartBusyPresentation("正在检测并修复全局编码", 1);
            SetBusyProgress("备份并切回系统原生编码", 1, 1);
            try {
                string originalSid = NativeEncodingRepair.CurrentUserSid();
                bool changesNeeded = await Task.Run(() => NativeEncodingRepair.NeedsRepair(originalSid));
                if (!changesNeeded) {
                    RepairResult result = await Task.Run(() => NativeEncodingRepair.Execute(originalSid));
                    MessageBox.Show(this, result.Detail, "拨乱反正", MessageBoxButtons.OK,
                        result.Success ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
                } else {
                    await Task.Run(() => {
                        var start = new ProcessStartInfo(Application.ExecutablePath,
                            "--reset-native-encoding " + originalSid) {
                            UseShellExecute = true, Verb = "runas", WindowStyle = ProcessWindowStyle.Hidden,
                            WorkingDirectory = AppDomain.CurrentDomain.BaseDirectory
                        };
                        using (Process worker = Process.Start(start)) {
                            if (worker == null) throw new IOException("编码修复进程未启动。");
                            worker.WaitForExit();
                        }
                    });
                }
            } catch (System.ComponentModel.Win32Exception ex) {
                MessageBox.Show(this, ex.NativeErrorCode == 1223 ? "已取消管理员授权，未执行修复。" : ex.Message,
                    "拨乱反正未执行", MessageBoxButtons.OK, MessageBoxIcon.Information);
            } catch (Exception ex) {
                MessageBox.Show(this, ex.Message, "拨乱反正未完成", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            } finally {
                scanRunning = false;
                backgroundOperationRunning = false;
                backgroundOperationLabel = "";
                resultsPanel.Enabled = true;
                StopBusyPresentation();
                refreshButton.Enabled = copyButton.Enabled = true;
                UpdateRepairButtons();
            }
            await RunScan();
        }

        private async Task RunRestoreUtf8()
        {
            if (!Utf8Repair.CanRestore())
            {
                MessageBox.Show("没有找到可用的修改前编码备份。", "无法恢复", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string message = "将把系统代码页恢复为启用 UTF-8 之前保存的值。\r\n\r\n" +
                "恢复完成后必须重启 Windows 才能完整生效。是否继续？";
            if (MessageBox.Show(message, "确认恢复原编码", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            scanRunning = true;
            backgroundOperationRunning = true;
            backgroundOperationLabel = "正在恢复…";
            refreshButton.Enabled = false;
            copyButton.Enabled = false;
            repairButton.Enabled = false;
            restoreUtf8Button.Enabled = false;
            summary.ForeColor = UiTheme.Accent;
            summary.Text = "正在恢复修改前编码…";
            StartBusyPresentation("正在恢复系统编码", 1);
            SetBusyProgress("恢复原编码", 1, 1);
            bool success;
            try
            {
                success = await Task.Run(() => Utf8Repair.StartElevatedRestore());
            }
            finally
            {
                scanRunning = false;
                backgroundOperationRunning = false;
                backgroundOperationLabel = "";
                StopBusyPresentation();
            }
            MessageBox.Show(success
                    ? "原编码已恢复。必须重启 Windows 才能完整生效。"
                    : "恢复没有完成；系统已尽力保持执行前状态。",
                success ? "恢复完成" : "恢复失败", MessageBoxButtons.OK,
                success ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
            await RunScan();
        }

        private async Task RunAutomaticRepair()
        {
            List<string> targets = RepairEngine.GetAutomaticItems(lastResults);
            if (targets.Count == 0)
            {
                MessageBox.Show("当前没有可自动补全的项目。", "无需处理", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string message = "安装包来源：" + RepairEngine.SelectedSourceLabel() + "。\r\n\r\n本工具将自行补全以下项目：\r\n\r\n• " + String.Join("\r\n• ", targets.ToArray()) +
                "\r\n\r\n过程中可能显示 Windows 权限确认。是否继续？";
            if (MessageBox.Show(message, "确认一键自动补全", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            List<CheckResult> repairInput = lastResults.ToList();
            backgroundOperationRunning = true;
            backgroundOperationLabel = "正在补全…";
            refreshButton.Enabled = false;
            copyButton.Enabled = false;
            repairButton.Enabled = false;
            summary.ForeColor = UiTheme.Accent;
            summary.Text = "正在自动补全，请不要关闭窗口…";
            StartBusyPresentation("正在补全运行环境", targets.Count);
            try
            {
                List<RepairResult> results = await Task.Run(() => RepairEngine.Repair(repairInput,
                    (name, position, total) => SetBusyProgress(name, position, total)));
                StringBuilder report = new StringBuilder();
                foreach (RepairResult result in results)
                    report.AppendLine((result.Success ? "✓ " : "× ") + result.Name + "：" + result.Detail);
                MessageBox.Show(report.ToString(), "自动补全结果", MessageBoxButtons.OK,
                    results.All(item => item.Success) ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
            }
            finally
            {
                backgroundOperationRunning = false;
                backgroundOperationLabel = "";
                StopBusyPresentation();
            }
            await RunScan();
        }

        private void ShowResultsForCurrentMode()
        {
            lastResults = lastAllResults
                .Where(item => codexMode != RepairEngine.SoftwareCheckItems.Contains(item.Name))
                .ToList();
            RenderResults(lastResults);
        }

        private void RenderResults(List<CheckResult> results)
        {
            resultsPanel.SuspendLayout();
            resultsPanel.Controls.Clear();
            foreach (CheckResult result in results)
                resultsPanel.Controls.Add(new ResultCard(result, companyUser));
            ResizeResultCards();
            resultsPanel.ResumeLayout();

            UpdateSummary(results);
        }

        private void UpdateSummary(List<CheckResult> results)
        {
            int ready = results.Count(item => item.Level == CheckLevel.Ready);
            int warning = results.Count(item => item.Level == CheckLevel.Warning);
            int missing = results.Count(item => item.Level == CheckLevel.Missing);
            summary.ForeColor = missing > 0
                ? UiTheme.Danger
                : (warning > 0 ? UiTheme.Warning : UiTheme.Good);
            summary.Text = "检测完成  ·  " + ready + " 项合格  ·  " + warning + " 项需处理  ·  " + missing + " 项缺少";
        }

        private void ResizeResultCards()
        {
            if (layoutResultsRunning || resultsPanel == null) return;
            layoutResultsRunning = true;
            try {
                int gap = UiTheme.Px(resultsPanel, 14);
                int available = Math.Max(300, resultsPanel.ClientSize.Width - resultsPanel.Padding.Horizontal - SystemInformation.VerticalScrollBarWidth - gap);
                int columns = available >= UiTheme.Px(resultsPanel, 960) ? 2 : 1;
                int width = (available - (columns - 1) * gap) / columns;
                foreach (Control control in resultsPanel.Controls) {
                    control.Margin = new Padding(0, 0, gap, gap);
                    control.Width = width;
                }
            } finally { layoutResultsRunning = false; }
        }

        private void CopyReport()
        {
            Clipboard.SetText(ReportBuilder.Build(lastResults, codexMode));
            copyButton.Text = "已复制";
            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer { Interval = 1500 };
            timer.Tick += delegate { copyButton.Text = "复制报告"; timer.Stop(); timer.Dispose(); };
            timer.Start();
        }
    }

    internal static class ReportBuilder
    {
        public static string Build(IEnumerable<CheckResult> results, bool codexMode)
        {
            StringBuilder report = new StringBuilder();
            report.AppendLine((codexMode ? "Codex 环境补全 v" : "软件安装检查 v") + Assembly.GetExecutingAssembly().GetName().Version.ToString(3));
            report.AppendLine("检测时间：" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            report.AppendLine(codexMode
                ? "范围：可由本工具自行安装或配置的环境"
                : "范围：开发工具、Python、PowerShell、.NET、FFmpeg、LibreOffice 等需手动下载安装的软件");
            report.AppendLine();
            foreach (CheckResult result in results)
            {
                string status = result.Level == CheckLevel.Ready ? "合格" : (result.Level == CheckLevel.Warning ? "需处理" : "缺少");
                report.AppendLine("[" + result.Importance + "][" + status + "] " + result.Name);
                report.AppendLine("  检测：" + result.Detail);
                if (result.Level != CheckLevel.Ready) report.AppendLine("  建议：" + result.Guidance);
            }
            report.AppendLine();
            report.AppendLine(codexMode
                ? "一键自动补全不会启用全局 UTF-8。仅恢复原编码后需要重启 Windows。"
                : "以上软件、工作负载和编辑器扩展只做检测，不会自动安装；请用户完成安装后再重新检测。");
            return report.ToString();
        }
    }

    internal static class Program
    {
        [STAThread]
        private static void Main(string[] args)
        {
            UiTheme.EnableDpiAwareness();
            UiTheme.Load();
            bool codexMode = Path.GetFileNameWithoutExtension(Application.ExecutablePath)
                .IndexOf("CodexEnvironmentHelper", StringComparison.OrdinalIgnoreCase) >= 0;
            List<string> effectiveArguments = new List<string>(args ?? new string[0]);
            if (effectiveArguments.Count >= 2 &&
                String.Equals(effectiveArguments[0], "--mode", StringComparison.OrdinalIgnoreCase))
            {
                string requestedMode = effectiveArguments[1];
                if (!String.Equals(requestedMode, "software", StringComparison.OrdinalIgnoreCase) &&
                    !String.Equals(requestedMode, "codex", StringComparison.OrdinalIgnoreCase))
                {
                    Environment.ExitCode = 2;
                    return;
                }
                codexMode = String.Equals(requestedMode, "codex", StringComparison.OrdinalIgnoreCase);
                effectiveArguments.RemoveRange(0, 2);
                args = effectiveArguments.ToArray();
            }
            bool previewInstallation = args.Length == 1 &&
                String.Equals(args[0], "--preview-installation", StringComparison.OrdinalIgnoreCase);
            if (previewInstallation)
            {
                codexMode = true;
                args = new string[0];
            }
            bool companyUser = false;
            if (args.Length >= 2 && String.Equals(args[0], "--company", StringComparison.OrdinalIgnoreCase))
            {
                companyUser = args[1] == "1";
                List<string> remaining = new List<string>(args);
                remaining.RemoveRange(0, 2);
                args = remaining.ToArray();
            }
            if (args.Length == 1 && String.Equals(args[0], "--enable-utf8", StringComparison.OrdinalIgnoreCase))
            {
                // 兼容旧调用但拒绝全局启用，不弹阻塞对话框、不写注册表。
                Environment.ExitCode = 2;
                return;
            }
            if (args.Length == 2 && String.Equals(args[0], "--reset-native-encoding", StringComparison.OrdinalIgnoreCase))
            {
                Application.EnableVisualStyles();
                RepairResult result;
                try { result = NativeEncodingRepair.Execute(args[1]); }
                catch (Exception ex) { result = new RepairResult { Name = "文字编码", Success = false, Detail = ex.Message }; }
                MessageBox.Show(result.Detail, result.Success ? "拨乱反正完成" : "拨乱反正未完成",
                    MessageBoxButtons.OK, result.Success ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
                Environment.ExitCode = result.Success ? 0 : 1;
                return;
            }
            if (args.Length == 1 && String.Equals(args[0], "--restore-utf8", StringComparison.OrdinalIgnoreCase))
            {
                Environment.ExitCode = Utf8Repair.Restore();
                return;
            }
            if (args.Length == 2 && String.Equals(args[0], "--self-test-utf8", StringComparison.OrdinalIgnoreCase))
            {
                Environment.ExitCode = Utf8Repair.RunFileFormatSelfTest(args[1]) ? 0 : 1;
                return;
            }
            if (args.Length == 2 && String.Equals(args[0], "--self-test-scenarios", StringComparison.OrdinalIgnoreCase))
            {
                Environment.ExitCode = CandidateSelfTest.Run(args[1]) ? 0 : 1;
                return;
            }
            if (args.Length == 2 && String.Equals(args[0], "--report", StringComparison.OrdinalIgnoreCase))
            {
                List<CheckResult> results = Detector.ScanForMode(codexMode);
                File.WriteAllText(args[1], ReportBuilder.Build(results, codexMode), new UTF8Encoding(false));
                return;
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            bool createdNew;
            string mutexName = codexMode ? SingleWindow.CodexMutexName : SingleWindow.SoftwareMutexName;
            using (Mutex mutex = new Mutex(true, mutexName, out createdNew))
            {
                if (!createdNew)
                {
                    SingleWindow.ActivateWindow(codexMode);
                    return;
                }
                try
                {
                    Application.Run(new MainForm(codexMode, previewInstallation, companyUser));
                }
                finally
                {
                    mutex.ReleaseMutex();
                }
            }
        }
    }
}
