using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Web.Script.Serialization;
using Microsoft.Win32;

namespace EnvironmentDetector {
 internal static class PowerShellSetup {
  internal const string ConfigurationId="powershell_msi";
  internal const string ProbeCommand="-NoLogo -NoProfile -NonInteractive -Command \"if($PSVersionTable.PSEdition -ne 'Core' -or $PSVersionTable.PSVersion.Major -lt 7){exit 3};[Console]::Write('CODEXTOOLS_PS7|'+$PSVersionTable.PSVersion.ToString()+'|'+(1+1))\"";
  internal static string Executable {get{return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"PowerShell","7","pwsh.exe");}}
  internal static string FreshPath {get{return (Environment.GetEnvironmentVariable("Path",EnvironmentVariableTarget.Machine)??"")+";"+(Environment.GetEnvironmentVariable("Path",EnvironmentVariableTarget.User)??"");}}
  internal static bool RegisteredMsi() {
   foreach(RegistryView view in new[]{RegistryView.Registry64,RegistryView.Registry32})try {
    using(var machine=RegistryKey.OpenBaseKey(RegistryHive.LocalMachine,view))using(var root=machine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall")) {
     if(root==null)continue;
     foreach(string name in root.GetSubKeyNames())using(var key=root.OpenSubKey(name)) {
      if(key==null)continue;string display=Convert.ToString(key.GetValue("DisplayName",""));
      if(display.StartsWith("PowerShell 7",StringComparison.OrdinalIgnoreCase)&&Convert.ToString(key.GetValue("WindowsInstaller",0))=="1")return true;
     }
    }
   }catch(System.Security.SecurityException){}catch(UnauthorizedAccessException){}
   return false;
  }
  internal static string ResolvePath(string path) {
   foreach(string entry in (path??"").Split(';'))try {
    string directory=Environment.ExpandEnvironmentVariables(entry.Trim().Trim('"'));
    if(String.IsNullOrWhiteSpace(directory))continue;
    string candidate=Path.Combine(directory,"pwsh.exe");if(File.Exists(candidate))return Path.GetFullPath(candidate);
   }catch(ArgumentException){}catch(NotSupportedException){}catch(PathTooLongException){}
   return null;
  }
  internal static bool ProbePassed(CommandResult probe,out string version) {
   version=null;if(probe==null||probe.ExitCode!=0)return false;
   string[] parts=(probe.Output??"").Trim().Split('|');Version parsed;
   if(parts.Length!=3||parts[0]!="CODEXTOOLS_PS7"||parts[2]!="2"||!Version.TryParse(parts[1],out parsed)||parsed.Major<7)return false;
   version=parts[1];return true;
  }
  internal static CheckResult Evaluate(string executable,bool exists,bool registered,CommandResult probe,string resolved) {
   string version=null;bool executableReady=exists&&registered&&ProbePassed(probe,out version);
   bool ready=executableReady&&String.Equals(executable,resolved,StringComparison.OrdinalIgnoreCase);
   string detail=!exists?"未发现独立 MSI 版 pwsh.exe；商店别名和 Codex 随附版本不作为完整开发环境。":
    !registered?"发现程序文件，但未发现 PowerShell 7 的 MSI 安装登记。":
    !executableReady?"MSI 版启动/计算自检失败"+(probe==null?"。":"（退出码 "+probe.ExitCode+"）："+probe.Output):
    !ready?"MSI 版可运行，但新进程 PATH 未优先找到它。":
    "独立 MSI 版 "+version+" · "+executable+"；新进程 PATH、PowerShell Core 和 1+1=2 自检通过。";
   return new CheckResult{Group="终端环境",Name="PowerShell 7",Level=ready?CheckLevel.Ready:CheckLevel.Warning,Installed=exists,
    Detail=detail,Guidance=ready?"已配置完整；安装前已打开的 DSH/终端需重开后继承 PATH。":
    "点击“安装/修复 MSI”补齐官方独立版与系统 PATH；不会卸载商店版或修改全局编码、执行策略、远程管理设置。",AutoFixId=ConfigurationId};
  }
  internal static CheckResult Check() {
   string executable=Executable;bool exists=File.Exists(executable),registered=RegisteredMsi();
   var probe=exists&&registered?Detector.Run(executable,ProbeCommand,10000,new Dictionary<string,string>{{"Path",FreshPath}}):null;
   return Evaluate(executable,exists,registered,probe,ResolvePath(FreshPath));
  }
  static string Quote(string value) {
   var result=new StringBuilder("\"");int slashes=0;
   foreach(char c in value??""){if(c=='\\'){slashes++;continue;}result.Append('\\',c=='"'?slashes*2+1:slashes);result.Append(c);slashes=0;}
   return result.Append('\\',slashes*2).Append('"').ToString();
  }
  internal static RepairResult Repair() {
   if(Check().Level==CheckLevel.Ready)return new RepairResult{Name="PowerShell 7",Success=true,Detail="独立 MSI 版、PATH 与命令自检已通过，无需重复安装；已有终端/DSH 如仍使用旧环境，请重开。"};
   string script=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"configure-powershell-msi.ps1");
   if(!File.Exists(script))return new RepairResult{Name="PowerShell 7",Detail="MSI 配置脚本缺失，请更新本插件。"};
   string resultPath=Path.Combine(Path.GetTempPath(),"CodexTools-PowerShell-"+Guid.NewGuid().ToString("N")+".json");
   try {
    string shell=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),@"System32\WindowsPowerShell\v1.0\powershell.exe");
    string args="-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "+Quote(script)+" -ResultPath "+Quote(resultPath);
    string library=RepairEngine.GetSelectedLibrary();if(library!=null)args+=" -LibraryRoot "+Quote(library);
    var start=new ProcessStartInfo(shell,args){UseShellExecute=true,WindowStyle=ProcessWindowStyle.Hidden};
    if(!new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator))start.Verb="runas";
    int code;using(var process=Process.Start(start)){if(process==null)throw new IOException("配置进程未启动。");process.WaitForExit();code=process.ExitCode;}
    string error="配置进程未返回结果（退出码 "+code+"）。";
    if(File.Exists(resultPath)){var result=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(resultPath,Encoding.UTF8));if(result.ContainsKey("message"))error=Convert.ToString(result["message"]);}
    CheckResult check=Check();bool success=code==0&&check.Level==CheckLevel.Ready;
    return new RepairResult{Name="PowerShell 7",Success=success,Detail=success?check.Detail+" 请重开安装前已启动的 DSH/终端后再使用。":error+" "+check.Detail};
   }catch(Exception error){return new RepairResult{Name="PowerShell 7",Success=false,Detail="MSI 配置未完成："+error.Message};}
   finally{try{if(File.Exists(resultPath))File.Delete(resultPath);}catch(IOException){}catch(UnauthorizedAccessException){}}
  }
 }
}
