﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EnvironmentDetector
{
    internal sealed class GitIdentity
    {
        public string Name;
        public string Email;
        public string Error;
        public bool Complete { get { return !String.IsNullOrWhiteSpace(Name) && !String.IsNullOrWhiteSpace(Email); } }
    }

    internal static class GitSetup
    {
        public const string ConfigurationId = "git_identity";

        public static string FindGit()
        {
            string found = Detector.FindIndependentExecutable("git.exe");
            if (!String.IsNullOrEmpty(found)) return found;
            string[] candidates = {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Git", "cmd", "git.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "Git", "cmd", "git.exe") };
            return candidates.FirstOrDefault(File.Exists);
        }

        public static string Quote(string value)
        {
            StringBuilder result = new StringBuilder("\"");
            int slashes = 0;
            foreach (char character in value ?? "") {
                if (character == '\\') { slashes++; continue; }
                if (character == '"') result.Append('\\', slashes * 2 + 1);
                else result.Append('\\', slashes);
                result.Append(character); slashes = 0;
            }
            return result.Append('\\', slashes * 2).Append('"').ToString();
        }

        public static CommandResult Run(string executable, string arguments, string globalFile = null)
        {
            var overrides = new Dictionary<string, string>();
            if (globalFile != null) overrides["GIT_CONFIG_GLOBAL"] = globalFile;
            return Detector.Run(executable, arguments, 30000, overrides);
        }

        static CommandResult RunSmoke(string executable, string arguments, string globalFile)
        {
            var overrides = new Dictionary<string, string> { { "GIT_ATTR_NOSYSTEM", "1" }, { "GIT_ATTR_SOURCE", null } };
            if (globalFile != null) overrides["GIT_CONFIG_GLOBAL"] = globalFile;
            return Detector.Run(executable, arguments, 30000, overrides);
        }

        public static GitIdentity ReadIdentity(string executable, string globalFile = null)
        {
            CommandResult name = Run(executable, "config --global --includes --get user.name", globalFile);
            CommandResult email = Run(executable, "config --global --includes --get user.email", globalFile);
            return new GitIdentity {
                Name = name.ExitCode == 0 ? name.Output.Trim() : "",
                Email = email.ExitCode == 0 ? email.Output.Trim() : "",
                Error = name.ExitCode > 1 || name.ExitCode < 0 ? "姓名配置读取失败（退出码 " + name.ExitCode + "）。" :
                    (email.ExitCode > 1 || email.ExitCode < 0 ? "邮箱配置读取失败（退出码 " + email.ExitCode + "）。" : null) };
        }

        public static string CommitSmoke(string executable, string globalFile = null, GitIdentity expected = null)
        {
            string root = Path.GetFullPath(Path.Combine(Path.GetTempPath(), "EDV"));
            Directory.CreateDirectory(root);
            string fixture = Path.Combine(root, "git-commit-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(fixture);
            try {
                string empty = Path.Combine(fixture, "empty-template");
                Directory.CreateDirectory(empty);
                string attributes = Path.Combine(fixture, "empty.attributes");
                File.WriteAllText(attributes, "", new UTF8Encoding(false));
                string prefix = "-C " + Quote(fixture) + " --git-dir=" + Quote(Path.Combine(fixture, ".git")) + " --work-tree=" + Quote(fixture) +
                    " -c commit.gpgsign=false -c user.useConfigOnly=true -c core.hooksPath=" + Quote(empty) +
                    " -c core.attributesFile=" + Quote(attributes) + " -c core.fsmonitor=false -c core.autocrlf=false -c core.safecrlf=false -c i18n.commitEncoding=utf-8 -c i18n.logOutputEncoding=utf-8 ";
                string[] commands = {
                    prefix + "init --quiet --template=" + Quote(empty),
                    prefix + "add -- smoke.txt",
                    prefix + "commit --quiet -m " + Quote("Verify Git installation"),
                    prefix + "--no-pager log -1 --format=%s%x00%an%x00%ae%x00%cn%x00%ce" };
                string[] stages = { "init", "add", "commit", "log" };
                File.WriteAllText(Path.Combine(fixture, "smoke.txt"), "Git installation verification.\n", new UTF8Encoding(false));
                for (int index = 0; index < commands.Length; index++) {
                    CommandResult command = RunSmoke(executable, commands[index], globalFile);
                    if (command.ExitCode != 0) return stages[index] + " 自检失败（退出码 " + command.ExitCode + "）。";
                    if (index == 3) {
                        string[] fields = command.Output.TrimEnd('\r', '\n').Split('\0');
                        if (fields.Length != 5 || fields[0] != "Verify Git installation") return "log 未返回测试提交。";
                        if (expected != null && (fields[1] != expected.Name || fields[2] != expected.Email || fields[3] != expected.Name || fields[4] != expected.Email))
                            return "实际提交身份与输入不一致，请检查姓名规范化或 author / committer 覆盖。";
                    }
                }
                return null;
            }
            finally {
                string target = Path.GetFullPath(fixture);
                if (target.StartsWith(root.TrimEnd('\\') + "\\", StringComparison.OrdinalIgnoreCase) && Directory.Exists(target)) {
                    foreach (string file in Directory.GetFiles(target, "*", SearchOption.AllDirectories))
                        File.SetAttributes(file, File.GetAttributes(file) & ~FileAttributes.ReadOnly);
                    Directory.Delete(target, true);
                }
            }
        }

        public static CheckResult Check(string executable, string version)
        {
            GitIdentity identity = ReadIdentity(executable);
            if (identity.Error != null) return new CheckResult {
                Group = "基础开发环境", Name = "Git", Level = CheckLevel.Warning, Installed = true,
                Detail = version + "；Git 配置解析或读取未完成：" + identity.Error,
                Guidance = "请检查现有 Git 配置文件后重新检测；重装不会修复配置语法，也不会自动覆盖它。" };
            string failure = null;
            if (identity.Complete) {
                try { failure = CommitSmoke(executable); }
                catch (Exception ex) { failure = "提交自检未完成：" + ex.Message; }
            }
            bool ready = identity.Complete && failure == null;
            return new CheckResult {
                Group = "基础开发环境", Name = "Git", Level = ready ? CheckLevel.Ready : CheckLevel.Warning, Installed = true,
                Detail = version + " · " + executable + (ready ? "；身份已配置，init / add / commit / log 自检通过。" :
                    (!identity.Complete ? "；程序已安装，提交姓名或邮箱尚未配置。" : "；" + failure)),
                Guidance = ready ? "无需处理。" : (!identity.Complete ? "点击“配置提交身份”填写自己的姓名和邮箱；保存后会验证提交，不重复安装 Git。" :
                    "提交身份已经存在，请检查自检失败的步骤及临时目录权限；不会通过重复安装覆盖现有配置。"),
                AutoFixId = !identity.Complete ? ConfigurationId : null };
        }

        public static string GlobalFile(string executable)
        {
            CommandResult paths = Run(executable, "var GIT_CONFIG_GLOBAL");
            if (paths.ExitCode == 0) {
                string[] candidates = paths.Output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                if (candidates.Length > 0) return Path.GetFullPath(candidates.FirstOrDefault(File.Exists) ?? candidates[0]);
            }
            string explicitFile = Environment.GetEnvironmentVariable("GIT_CONFIG_GLOBAL");
            if (!String.IsNullOrEmpty(explicitFile)) return Path.GetFullPath(explicitFile);
            string home = Environment.GetEnvironmentVariable("HOME");
            if (String.IsNullOrEmpty(home)) home = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string primary = Path.Combine(home, ".gitconfig");
            string xdg = Environment.GetEnvironmentVariable("XDG_CONFIG_HOME");
            string secondary = Path.Combine(String.IsNullOrEmpty(xdg) ? Path.Combine(home, ".config") : xdg, "git", "config");
            return Path.GetFullPath(!File.Exists(primary) && File.Exists(secondary) ? secondary : primary);
        }

        public static RepairResult Save(string executable, string name, string email)
        {
            var result = new RepairResult { Name = "Git", Success = false };
            name = (name ?? "").Trim(); email = (email ?? "").Trim();
            if (String.IsNullOrEmpty(name) || name.Any(c => Char.IsControl(c) || c == '<' || c == '>') ||
                !Regex.IsMatch(email, @"^[^\s@<>]+@[^\s@<>]+$") || email.Any(Char.IsControl)) {
                result.Detail = "请填写有效的提交姓名和邮箱；尚未修改 Git 配置。"; return result;
            }
            string staging = null; bool ownsLock = false;
            try {
                string target = GlobalFile(executable);
                if (File.Exists(target) && (File.GetAttributes(target) & FileAttributes.ReparsePoint) != 0)
                    throw new IOException("全局配置是链接，请使用 Git 原生命令配置该文件。");
                Directory.CreateDirectory(Path.GetDirectoryName(target));
                // Native Git writers honor this same lock. Keep the live file untouched
                // while Git updates both staged keys and tests a real commit.
                staging = target + ".lock";
                using (FileStream file = new FileStream(staging, FileMode.CreateNew, FileAccess.Write, FileShare.Read)) {
                    ownsLock = true;
                    if (File.Exists(target)) using (FileStream source = File.OpenRead(target)) source.CopyTo(file);
                }
                foreach (string argument in new[] { "user.name " + Quote(name), "user.email " + Quote(email) }) {
                    CommandResult write = Run(executable, "config --file " + Quote(staging) + " --replace-all " + argument);
                    if (write.ExitCode != 0) throw new IOException("身份配置写入失败（退出码 " + write.ExitCode + "）。");
                }
                GitIdentity check = ReadIdentity(executable, staging);
                if (check.Name != name || check.Email != email) throw new IOException("身份配置回读不一致，请检查 Git include 配置。");
                string failure = CommitSmoke(executable, staging, new GitIdentity { Name = name, Email = email });
                if (failure != null) throw new IOException(failure);
                if (File.Exists(target)) File.Replace(staging, target, null);
                else File.Move(staging, target);
                result.Success = true;
                result.Detail = "提交身份已保存，临时仓库提交和日志自检通过。";
            }
            catch (Exception ex) { result.Detail = "配置未完成，原 Git 配置保持不变：" + ex.Message; }
            finally {
                if (ownsLock && File.Exists(staging)) {
                    try { File.Delete(staging); }
                    catch (Exception ex) { result.Success = false; result.Detail += " 临时锁清理未完成：" + ex.Message; }
                }
            }
            return result;
        }
    }

    internal sealed class GitIdentityDialog : ModernFrame
    {
        readonly TextBox name = new TextBox();
        readonly TextBox email = new TextBox();
        readonly Label state = new Label();
        readonly ModernButton save = new ModernButton("保存并验证", Color.FromArgb(37, 99, 235));
        readonly ModernButton cancel = new ModernButton("取消", Color.Gray);
        bool saving;

        public GitIdentityDialog(string executable)
        {
            SuspendLayout();
            Text = "配置 Git 提交身份"; ClientSize = new Size(620, 330);
            StartPosition = FormStartPosition.CenterParent; FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = MinimizeBox = false; ShowInTaskbar = false;
            Font = new Font("Microsoft YaHei UI", 10); BackColor = UiTheme.Window; ForeColor = UiTheme.Text;
            Controls.Add(new Label { Text = "姓名和邮箱会记录在 Git 提交中。请填写你自己的信息。", AutoSize = true, Location = new Point(24, 24) });
            Controls.Add(new Label { Text = "提交姓名", AutoSize = true, Location = new Point(24, 78) });
            Controls.Add(new Label { Text = "提交邮箱", AutoSize = true, Location = new Point(24, 126) });
            name.SetBounds(124, 74, 466, 30); email.SetBounds(124, 122, 466, 30);
            GitIdentity current = GitSetup.ReadIdentity(executable); name.Text = current.Name; email.Text = current.Email;
            state.SetBounds(24, 175, 566, 66); state.Text = "保存前先验证真实提交；验证失败时保留原配置。";
            state.Name = "muted"; state.ForeColor = UiTheme.Muted;
            save.Text = "保存并验证"; save.SetBounds(336, 264, 124, 38);
            cancel.Text = "取消"; cancel.SetBounds(472, 264, 118, 38); cancel.DialogResult = DialogResult.Cancel;
            Controls.AddRange(new Control[] { name, email, state, save, cancel });
            AcceptButton = save; CancelButton = cancel;
            foreach (Control child in Controls) child.Top += 42;
            ClientSize = new Size(ClientSize.Width, ClientSize.Height + 42);
            UseModernFrame(false, false, true);
            AutoScaleDimensions = new SizeF(96F, 96F); AutoScaleMode = AutoScaleMode.Dpi;
            UiTheme.Apply(this);
            ResumeLayout(true);
            FormClosing += delegate(object sender, FormClosingEventArgs args) { if (saving) args.Cancel = true; };
            save.Click += async delegate {
                string proposedName = name.Text, proposedEmail = email.Text;
                saving = true; save.Enabled = cancel.Enabled = name.Enabled = email.Enabled = false;
                state.Text = "正在验证提交…";
                RepairResult result;
                try { result = await Task.Run(() => GitSetup.Save(executable, proposedName, proposedEmail)); }
                catch (Exception ex) { result = new RepairResult { Success = false, Detail = "配置未完成：" + ex.Message }; }
                finally { saving = false; save.Enabled = cancel.Enabled = name.Enabled = email.Enabled = true; }
                state.Text = result.Detail;
                if (result.Success) { DialogResult = DialogResult.OK; Close(); }
                else state.ForeColor = UiTheme.Danger;
            };
        }
    }
}
