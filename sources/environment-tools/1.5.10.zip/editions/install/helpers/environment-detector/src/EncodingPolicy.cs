﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Win32;

namespace EnvironmentDetector
{
    internal static class EncodingPolicy
    {
        public const string SettingsAction = "system_encoding_settings";

        public static CheckResult IncludeUserPolicy(CheckResult result, string forcedPythonUtf8)
        {
            if (forcedPythonUtf8 == "1") {
                result.Level = CheckLevel.Warning;
                result.Detail += " 用户级 PYTHONUTF8=1 还会强制所有 Python 进程使用 UTF-8。";
                result.Guidance += "可点击“拨乱反正”备份并清理此全局覆盖，需要 UTF-8 的流程继续单独指定。";
            }
            if (result.Level != CheckLevel.Ready) result.AutoFixId = SettingsAction;
            return result;
        }

        public static string UserPythonUtf8()
        {
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey("Environment"))
                return Convert.ToString(key == null ? null : key.GetValue("PYTHONUTF8", null, RegistryValueOptions.DoNotExpandEnvironmentNames));
        }

        public static string MachinePythonUtf8()
        {
            using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Session Manager\Environment"))
                return Convert.ToString(key == null ? null : key.GetValue("PYTHONUTF8", null, RegistryValueOptions.DoNotExpandEnvironmentNames));
        }

        public static CheckResult IncludeMachinePolicy(CheckResult result, string forcedPythonUtf8)
        {
            if (forcedPythonUtf8 == "1") {
                result.Level = CheckLevel.Warning;
                result.Detail += " 系统级 PYTHONUTF8=1 会影响所有用户新启动的 Python。";
                result.Guidance += "可点击“拨乱反正”备份并清理系统级覆盖。";
                result.AutoFixId = SettingsAction;
            }
            return result;
        }

        internal static RepairResult RemoveUserOverride(Func<string> read, Action clear, Action<string> restore, string backupRoot, string valueKind)
        {
            var result = new RepairResult { Name = "文字编码", Success = false };
            string previous = read();
            if (previous != "1") return new RepairResult { Name = "文字编码", Success = true, Detail = "没有需要清理的用户级 PYTHONUTF8=1。" };
            string backup;
            try {
                Directory.CreateDirectory(backupRoot);
                backup = Path.Combine(backupRoot, "user-python-utf8-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N") + ".json");
                string json = new JavaScriptSerializer().Serialize(new Dictionary<string, string> {
                    { "format", "environment-detector-user-encoding/v1" }, { "name", "PYTHONUTF8" },
                    { "value", previous }, { "kind", valueKind }, { "scope", "CurrentUser\\Environment" },
                    { "createdUtc", DateTime.UtcNow.ToString("o") } });
                using (var stream = new FileStream(backup, FileMode.CreateNew, FileAccess.Write, FileShare.Read)) {
                    byte[] data = new UTF8Encoding(false).GetBytes(json); stream.Write(data, 0, data.Length);
                }
            }
            catch (Exception ex) { result.Detail = "原值备份失败，未清理变量：" + ex.Message; return result; }
            try {
                clear();
                if (!String.IsNullOrEmpty(read())) throw new IOException("变量回读仍存在，请检查其他正在配置环境的程序。");
                result.Success = true;
                result.Detail = "用户级强制 UTF-8 已备份并清理。新启动的程序生效；现有终端或应用可能仍继承旧值。";
            }
            catch (Exception ex) {
                result.Detail = "清理未完成：" + ex.Message;
                try {
                    if (String.IsNullOrEmpty(read())) restore(previous);
                    result.Detail += read() == previous ? " 原值已保留或恢复。" : " 当前值已改变，请核对本地备份。";
                }
                catch (Exception rollback) { result.Detail += " 原值恢复也未完成：" + rollback.Message; }
            }
            return result;
        }

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        static extern IntPtr SendMessageTimeout(IntPtr window, uint message, UIntPtr wParam, string lParam, uint flags, uint timeout, out UIntPtr result);

        public static void OpenSettings(IWin32Window owner)
        {
            string change = "";
            try {
                if (UserPythonUtf8() == "1") {
                    DialogResult answer = MessageBox.Show(owner,
                        "检测到用户级 PYTHONUTF8=1，它会强制所有 Python 进程使用 UTF-8。\r\n\r\n是否先备份并移除这一个变量？需要 UTF-8 的工具流程仍会单独指定。\r\n\r\n选择“否”将保留变量，仅打开 Windows 系统编码设置。",
                        "按场景使用文字编码", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
                    if (answer == DialogResult.Cancel) return;
                    if (answer == DialogResult.Yes) {
                        RepairResult cleared;
                        using (RegistryKey environment = Registry.CurrentUser.OpenSubKey("Environment", true)) {
                            if (environment == null) throw new IOException("用户环境变量位置不可用。");
                            RegistryValueKind kind = environment.GetValueKind("PYTHONUTF8");
                            cleared = RemoveUserOverride(
                                () => Convert.ToString(environment.GetValue("PYTHONUTF8", null, RegistryValueOptions.DoNotExpandEnvironmentNames)),
                                () => environment.DeleteValue("PYTHONUTF8", false),
                                value => environment.SetValue("PYTHONUTF8", value, kind),
                                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Backups"), kind.ToString());
                        }
                        if (!cleared.Success) { MessageBox.Show(owner, cleared.Detail, "编码设置未完成", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                        UIntPtr unused;
                        SendMessageTimeout(new IntPtr(0xffff), 0x001a, UIntPtr.Zero, "Environment", 2, 2000, out unused);
                        change = cleared.Detail + "\r\n\r\n";
                    }
                }
                MessageBox.Show(owner, change +
                    "接下来打开 Windows“区域”，切换到“管理”页。\r\n\r\n在“更改系统区域设置”中保留你原来的系统区域，取消“Beta: 使用 Unicode UTF-8 提供全球语言支持”。由 Windows 恢复该区域的原生代码页。\r\n\r\n系统会提示重启，请先保存工作，自行安排重启。本工具不会自动重启或猜测代码页。\r\n\r\n旧 TXT 请在编辑器中选择“以编码重新打开”，使用原始 GBK 等编码；UTF-8 文件仍按 UTF-8 读取。",
                    "系统原生编码与按需 UTF-8", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Process.Start(new ProcessStartInfo(Path.Combine(Environment.SystemDirectory, "control.exe"), "/name Microsoft.RegionAndLanguage") { UseShellExecute = true });
            }
            catch (Exception ex) { MessageBox.Show(owner, change + "系统编码设置未打开：" + ex.Message, "请检查系统区域设置", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        }
    }
}
