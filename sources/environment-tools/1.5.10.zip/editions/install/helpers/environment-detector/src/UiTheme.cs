using System;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace EnvironmentDetector
{
    // Presentation only: no environment settings or scan/repair state are changed here.
    internal static class UiTheme
    {
        public static bool Dark { get; private set; }
        public static Color Window { get { return Dark ? Color.FromArgb(23, 24, 32) : Color.FromArgb(244, 245, 248); } }
        public static Color Surface { get { return Dark ? Color.FromArgb(34, 36, 46) : Color.White; } }
        public static Color Soft { get { return Dark ? Color.FromArgb(44, 46, 58) : Color.FromArgb(236, 238, 245); } }
        public static Color Text { get { return Dark ? Color.FromArgb(240, 240, 247) : Color.FromArgb(37, 39, 53); } }
        public static Color Muted { get { return Dark ? Color.FromArgb(171, 176, 196) : Color.FromArgb(104, 112, 135); } }
        public static Color Border { get { return Dark ? Color.FromArgb(58, 61, 77) : Color.FromArgb(223, 226, 236); } }
        public static Color Accent { get { return Dark ? Color.FromArgb(187, 166, 255) : Color.FromArgb(103, 65, 217); } }
        public static Color AccentSoft { get { return Dark ? Color.FromArgb(56, 45, 81) : Color.FromArgb(237, 231, 255); } }
        public static Color Good { get { return Dark ? Color.FromArgb(92, 207, 174) : Color.FromArgb(19, 132, 111); } }
        public static Color Warning { get { return Dark ? Color.FromArgb(237, 188, 105) : Color.FromArgb(163, 105, 17); } }
        public static Color Danger { get { return Dark ? Color.FromArgb(247, 143, 153) : Color.FromArgb(188, 63, 80); } }
        public static string PreferencePath { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "CodexTools", "EnvironmentDetector", "ui-theme.txt"); } }

        public static void Load()
        {
            try {
                string host = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "CodexTools", "CodexTools", "theme.txt");
                string selected = File.Exists(PreferencePath) ? PreferencePath : host;
                Dark = File.Exists(selected) && File.ReadAllText(selected).Trim() == "dark";
            }
            catch { Dark = false; }
        }

        public static void Set(bool dark) { Dark = dark; }

        public static bool Save()
        {
            try { Directory.CreateDirectory(Path.GetDirectoryName(PreferencePath)); File.WriteAllText(PreferencePath, Dark ? "dark" : "light"); return true; }
            catch { return false; }
        }

        [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
        [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int size);

        public static void EnableDpiAwareness()
        {
            // Legacy .NET Framework host: scale controls at system DPI instead of letting
            // Windows stretch a 96-DPI bitmap. Mixed-monitor dynamic scaling is not claimed.
            try { SetProcessDPIAware(); } catch (EntryPointNotFoundException) { } catch (DllNotFoundException) { }
        }

        public static int Px(Control control, int logical)
        {
            using (Graphics g = control.CreateGraphics()) return (int)Math.Round(logical * g.DpiX / 96F);
        }

        public static void Apply(Control control)
        {
            ResultCard card = control as ResultCard;
            if (card != null) { card.ApplyTheme(); return; }
            ModernButton button = control as ModernButton;
            if (button != null) { button.ApplyTheme(); return; }
            control.ForeColor = control.Name == "muted" ? Muted : control.Name == "accent" ? Accent : Text;
            if (control is TextBox) control.BackColor = Surface;
            else if (!(control is Label) && !(control is MoonPhaseIndicator))
                control.BackColor = control is BusyStatusCard ? Surface : Window;
            foreach (Control child in control.Controls) Apply(child);
            Form form = control as Form;
            if (form != null && form.IsHandleCreated) {
                try { int dark = Dark ? 1 : 0; DwmSetWindowAttribute(form.Handle, 20, ref dark, sizeof(int)); }
                catch { }
            }
            control.Invalidate();
        }
    }
}
