﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Threading;

namespace EnvironmentDetector
{
    // Owns only its unique temporary file. Existing downloads are never replaced.
    internal sealed class PackageDownloadFile
    {
        private readonly object sync = new object();
        private readonly string folder;
        private readonly string saveName;
        private bool promoted;
        public string TemporaryPath { get; private set; }

        public PackageDownloadFile(string folder, string saveName)
        {
            if (String.IsNullOrWhiteSpace(saveName) || Path.GetFileName(saveName) != saveName)
                throw new ArgumentException("下载文件名无效。", "saveName");
            string extension = Path.GetExtension(saveName).ToLowerInvariant();
            if (extension != ".exe" && extension != ".msi" && extension != ".7z" && extension != ".zip")
                throw new ArgumentException("不支持校验此下载文件类型：" + extension, "saveName");
            this.folder = Path.GetFullPath(folder);
            this.saveName = saveName;
            Directory.CreateDirectory(this.folder);
            TemporaryPath = Path.Combine(this.folder, saveName + "." + Guid.NewGuid().ToString("N") + ".part");
            using (new FileStream(TemporaryPath, FileMode.CreateNew, FileAccess.Write, FileShare.None)) { }
        }

        public string Complete(long expectedLength)
        {
            lock (sync)
            {
                if (promoted) throw new InvalidOperationException("此下载已经保存。 ");
                Validate(TemporaryPath, saveName, expectedLength);
                string stem = Path.GetFileNameWithoutExtension(saveName);
                string extension = Path.GetExtension(saveName);
                for (int index = 0; index < 10000; index++)
                {
                    string name = index == 0 ? saveName : stem + " (" + index + ")" + extension;
                    string destination = Path.Combine(folder, name);
                    try
                    {
                        // File.Move is atomic on this volume and refuses to overwrite a race winner.
                        File.Move(TemporaryPath, destination);
                        promoted = true;
                        return destination;
                    }
                    catch (IOException)
                    {
                        if (!File.Exists(destination) && !Directory.Exists(destination)) throw;
                    }
                }
                throw new IOException("同名下载文件过多，请整理下载文件夹后重试。");
            }
        }

        internal static void Validate(string path, string saveName, long expectedLength)
        {
            using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                long length = stream.Length;
                if (length == 0) throw new InvalidDataException("服务器返回了空文件。");
                if (expectedLength >= 0 && length != expectedLength)
                    throw new InvalidDataException("下载长度不完整：应为 " + expectedLength + " 字节，实际为 " + length + " 字节。");
                byte[] header = new byte[8];
                int count = stream.Read(header, 0, header.Length);
                string extension = Path.GetExtension(saveName).ToLowerInvariant();
                bool matches = extension == ".exe" ? Matches(header, count, new byte[] { 0x4d, 0x5a }) :
                    extension == ".msi" ? Matches(header, count, new byte[] { 0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1 }) :
                    extension == ".7z" ? Matches(header, count, new byte[] { 0x37, 0x7a, 0xbc, 0xaf, 0x27, 0x1c }) :
                    extension == ".zip" && (Matches(header, count, new byte[] { 0x50, 0x4b, 0x03, 0x04 }) ||
                        Matches(header, count, new byte[] { 0x50, 0x4b, 0x05, 0x06 }) ||
                        Matches(header, count, new byte[] { 0x50, 0x4b, 0x07, 0x08 }));
                if (!matches)
                    throw new InvalidDataException("返回内容不是预期的 " + extension + " 安装包／压缩包，可能是网页、错误页或损坏文件。");
            }
        }

        private static bool Matches(byte[] actual, int count, byte[] expected)
        {
            if (count < expected.Length) return false;
            for (int index = 0; index < expected.Length; index++)
                if (actual[index] != expected[index]) return false;
            return true;
        }

        // A cleanup failure is returned to the caller so the UI never silently claims deletion.
        public string Cleanup()
        {
            lock (sync)
            {
                if (promoted) return null;
                try { File.Delete(TemporaryPath); return null; }
                catch (Exception ex)
                {
                    return "临时文件未能删除：" + TemporaryPath + Environment.NewLine + ex.Message;
                }
            }
        }
    }

    // Keeps the existing WebClient events; the watchdog follows real stream reads, not UI repaint timing.
    internal sealed class SafeDownloadWebClient : WebClient
    {
        private readonly int responseTimeoutMilliseconds;
        private readonly int idleTimeoutMilliseconds;
        private readonly object sync = new object();
        private System.Threading.Timer watchdog;
        private long lastActivity;
        private long expectedContentLength = -1;
        private int responseStarted;
        private int cancellation; // 0 = none, 1 = user, 2 = timeout
        private bool active;
        private bool started;

        public SafeDownloadWebClient() : this(30000, 60000) { }

        internal SafeDownloadWebClient(int responseTimeoutMilliseconds, int idleTimeoutMilliseconds)
        {
            if (responseTimeoutMilliseconds <= 0 || idleTimeoutMilliseconds <= 0)
                throw new ArgumentOutOfRangeException("Timeout values must be positive.");
            this.responseTimeoutMilliseconds = responseTimeoutMilliseconds;
            this.idleTimeoutMilliseconds = idleTimeoutMilliseconds;
            Headers[HttpRequestHeader.UserAgent] = "CodexTools-EnvironmentDetector";
        }

        public long ExpectedContentLength { get { return Interlocked.Read(ref expectedContentLength); } }

        public void StartDownload(Uri address, string temporaryPath)
        {
            if (address == null || (address.Scheme != Uri.UriSchemeHttps && address.Scheme != Uri.UriSchemeHttp))
                throw new ArgumentException("下载地址必须为 HTTP 或 HTTPS。", "address");
            lock (sync)
            {
                if (started || IsBusy) throw new InvalidOperationException("每个下载客户端只能启动一次。");
                started = true;
                active = true;
                Interlocked.Exchange(ref responseStarted, 0);
                Interlocked.Exchange(ref expectedContentLength, -1);
                Interlocked.Exchange(ref lastActivity, Stopwatch.GetTimestamp());
                watchdog = new System.Threading.Timer(CheckIdle, null, 100, 100);
            }
            try
            {
                DownloadFileAsync(address, temporaryPath);
                // A button can be cancelled/disposed while its background start is still queued.
                if (Interlocked.CompareExchange(ref cancellation, 0, 0) != 0) CancelAsync();
            }
            catch { StopWatchdog(); throw; }
        }

        public void CancelDownload()
        {
            Interlocked.CompareExchange(ref cancellation, 1, 0);
            CancelAsync();
        }

        public string FailureReason(AsyncCompletedEventArgs result)
        {
            int reason = Interlocked.CompareExchange(ref cancellation, 0, 0);
            if (reason == 2)
                return Interlocked.CompareExchange(ref responseStarted, 0, 0) == 0
                    ? "连接或等待服务器响应超时，请检查网络或改用其他下载渠道。"
                    : "下载连续 " + (idleTimeoutMilliseconds / 1000.0).ToString("0.#") + " 秒没有收到数据，已停止。";
            if (reason == 1 || result.Cancelled) return "已取消下载。";
            Exception error = result.Error;
            if (error == null) return null;
            // WebClient wraps validation/transport errors; show the concrete cause instead of its generic wrapper.
            while (error.InnerException != null) error = error.InnerException;
            return error.Message;
        }

        protected override WebRequest GetWebRequest(Uri address)
        {
            WebRequest request = base.GetWebRequest(address);
            request.Timeout = responseTimeoutMilliseconds;
            HttpWebRequest http = request as HttpWebRequest;
            if (http != null) http.ReadWriteTimeout = idleTimeoutMilliseconds;
            return request;
        }

        protected override WebResponse GetWebResponse(WebRequest request)
        {
            return TrackResponse(base.GetWebResponse(request));
        }

        protected override WebResponse GetWebResponse(WebRequest request, IAsyncResult result)
        {
            return TrackResponse(base.GetWebResponse(request, result));
        }

        private WebResponse TrackResponse(WebResponse response)
        {
            HttpWebResponse http = response as HttpWebResponse;
            if (http != null && (http.StatusCode == HttpStatusCode.PartialContent ||
                !String.IsNullOrEmpty(http.Headers[HttpResponseHeader.ContentRange])))
            {
                response.Close();
                throw new InvalidDataException("服务器返回了分段内容，无法确认安装包完整；请改用其他下载渠道。");
            }
            Interlocked.Exchange(ref expectedContentLength, response.ContentLength);
            Interlocked.Exchange(ref lastActivity, Stopwatch.GetTimestamp());
            Interlocked.Exchange(ref responseStarted, 1);
            return new TrackedResponse(response, RecordRead, StopWatchdog);
        }

        private void RecordRead(int bytes)
        {
            if (bytes > 0) Interlocked.Exchange(ref lastActivity, Stopwatch.GetTimestamp());
            else StopWatchdog(); // EOF: network is finished even if the UI callback is still queued.
        }

        private void CheckIdle(object state)
        {
            lock (sync)
            {
                if (!active || Interlocked.CompareExchange(ref cancellation, 0, 0) != 0) return;
                int timeout = Interlocked.CompareExchange(ref responseStarted, 0, 0) == 0
                    ? responseTimeoutMilliseconds : idleTimeoutMilliseconds;
                double elapsed = (Stopwatch.GetTimestamp() - Interlocked.Read(ref lastActivity)) * 1000.0 / Stopwatch.Frequency;
                if (elapsed < timeout) return;
                if (Interlocked.CompareExchange(ref cancellation, 2, 0) == 0) CancelAsync();
            }
        }

        private void StopWatchdog()
        {
            lock (sync)
            {
                active = false;
                if (watchdog != null) { watchdog.Dispose(); watchdog = null; }
            }
        }

        protected override void OnDownloadFileCompleted(AsyncCompletedEventArgs e)
        {
            StopWatchdog();
            base.OnDownloadFileCompleted(e);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) { StopWatchdog(); CancelAsync(); }
            base.Dispose(disposing);
        }

        private sealed class TrackedResponse : WebResponse
        {
            private readonly WebResponse inner;
            private readonly Action<int> recordRead;
            private readonly Action stop;
            private Stream stream;
            public TrackedResponse(WebResponse inner, Action<int> recordRead, Action stop)
            { this.inner = inner; this.recordRead = recordRead; this.stop = stop; }
            public override long ContentLength { get { return inner.ContentLength; } set { inner.ContentLength = value; } }
            public override string ContentType { get { return inner.ContentType; } set { inner.ContentType = value; } }
            public override WebHeaderCollection Headers { get { return inner.Headers; } }
            public override Uri ResponseUri { get { return inner.ResponseUri; } }
            public override Stream GetResponseStream()
            {
                if (stream == null) stream = new TrackedStream(inner.GetResponseStream(), recordRead, stop);
                return stream;
            }
            public override void Close() { stop(); inner.Close(); }
        }

        private sealed class TrackedStream : Stream
        {
            private readonly Stream inner;
            private readonly Action<int> recordRead;
            private readonly Action stop;
            public TrackedStream(Stream inner, Action<int> recordRead, Action stop)
            { this.inner = inner; this.recordRead = recordRead; this.stop = stop; }
            public override bool CanRead { get { return inner.CanRead; } }
            public override bool CanSeek { get { return inner.CanSeek; } }
            public override bool CanWrite { get { return inner.CanWrite; } }
            public override long Length { get { return inner.Length; } }
            public override long Position { get { return inner.Position; } set { inner.Position = value; } }
            public override int Read(byte[] buffer, int offset, int count)
            {
                try { int read = inner.Read(buffer, offset, count); recordRead(read); return read; }
                catch { stop(); throw; }
            }
            public override IAsyncResult BeginRead(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
            {
                try { return inner.BeginRead(buffer, offset, count, callback, state); }
                catch { stop(); throw; }
            }
            public override int EndRead(IAsyncResult asyncResult)
            {
                try { int read = inner.EndRead(asyncResult); recordRead(read); return read; }
                catch { stop(); throw; }
            }
            public override void Flush() { inner.Flush(); }
            public override long Seek(long offset, SeekOrigin origin) { return inner.Seek(offset, origin); }
            public override void SetLength(long value) { inner.SetLength(value); }
            public override void Write(byte[] buffer, int offset, int count) { inner.Write(buffer, offset, count); }
            protected override void Dispose(bool disposing)
            { if (disposing) { stop(); inner.Dispose(); } base.Dispose(disposing); }
        }
    }
}
