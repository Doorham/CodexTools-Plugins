using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using Microsoft.Win32;

namespace EnvironmentDetector
{
    internal sealed class EncodingResetValue
    {
        public bool Exists;
        public RegistryValueKind Kind;
        public string Value;
        public EncodingResetValue Copy() { return new EncodingResetValue { Exists = Exists, Kind = Kind, Value = Value }; }
        public bool Same(EncodingResetValue other) { return other != null && Exists == other.Exists && (!Exists || (Kind == other.Kind && Value == other.Value)); }
    }

    internal sealed class EncodingResetSnapshot
    {
        public string UserSid;
        public string MachineName;
        public string LocaleName;
        public bool LocaleChangePending;
        public uint EffectiveACP;
        public uint EffectiveOEMCP;
        public Dictionary<string, EncodingResetValue> Values = new Dictionary<string, EncodingResetValue>();
        public Dictionary<string, uint> NativeCodePages = new Dictionary<string, uint>();
    }

    internal sealed class EncodingResetChange
    {
        public string Key;
        public EncodingResetValue Before;
        public EncodingResetValue After;
    }

    internal static class NativeEncodingRepair
    {
        const string CodePagePath = @"SYSTEM\CurrentControlSet\Control\Nls\CodePage";
        const string MachineEnvironmentPath = @"SYSTEM\CurrentControlSet\Control\Session Manager\Environment";
        static readonly string[] CodePages = { "ACP", "OEMCP", "MACCP" };
        static readonly string[] Keys = { "ACP", "OEMCP", "MACCP", "UserPythonUtf8", "MachinePythonUtf8" };

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        static extern int GetSystemDefaultLocaleName(StringBuilder value, int length);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        static extern int GetLocaleInfoEx(string locale, uint type, StringBuilder value, int length);
        [DllImport("kernel32.dll")] static extern uint GetSystemDefaultLCID();
        [DllImport("kernel32.dll")] static extern uint GetACP();
        [DllImport("kernel32.dll")] static extern uint GetOEMCP();
        [DllImport("kernel32.dll")] [return: MarshalAs(UnmanagedType.Bool)] static extern bool IsValidCodePage(uint codePage);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        static extern IntPtr SendMessageTimeout(IntPtr window, uint message, UIntPtr wParam, string lParam, uint flags, uint timeout, out UIntPtr result);

        public static string CurrentUserSid() { return WindowsIdentity.GetCurrent().User.Value; }
        public static bool IsAdministrator() { return new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator); }

        internal static string ValidateSid(string value)
        {
            if (String.IsNullOrWhiteSpace(value)) throw new ArgumentException("无法确定发起操作的用户。");
            string canonical = new SecurityIdentifier(value).Value;
            if (!String.Equals(value, canonical, StringComparison.Ordinal)) throw new ArgumentException("用户 SID 格式不正确。");
            return canonical;
        }

        public static bool NeedsRepair(string userSid)
        {
            EncodingResetSnapshot state = ReadSnapshot(ValidateSid(userSid));
            return CodePages.Any(key => state.Values[key].Value == "65001") ||
                state.Values["UserPythonUtf8"].Value == "1" || state.Values["MachinePythonUtf8"].Value == "1";
        }

        public static RepairResult Execute(string originalUserSid)
        {
            try {
                string sid = ValidateSid(originalUserSid);
                using (var mutex = new Mutex(false, @"Global\CodexTools-NativeEncodingRepair")) {
                    bool acquired = false;
                    try {
                        try { acquired = mutex.WaitOne(0); } catch (AbandonedMutexException) { acquired = true; }
                        if (!acquired) return Failure("另一个编码修复正在运行，请等待它结束。");
                        RepairResult result = ExecuteCore(() => ReadSnapshot(sid),
                            (state, changes) => WriteBackup(state, changes),
                            (key, value) => WriteValue(sid, key, value), IsAdministrator(), key => ReadSingleValue(sid, key));
                        if (result.Success && (result.Detail.Contains("已清理发起操作用户") || result.Detail.Contains("已清理这台电脑系统级"))) {
                            UIntPtr unused;
                            SendMessageTimeout(new IntPtr(0xffff), 0x001a, UIntPtr.Zero, "Environment", 2, 2000, out unused);
                        }
                        return result;
                    }
                    finally { if (acquired) mutex.ReleaseMutex(); }
                }
            }
            catch (Exception ex) { return Failure("未修改编码设置：" + ex.Message); }
        }

        internal static List<EncodingResetChange> MakePlan(EncodingResetSnapshot state)
        {
            ValidateSid(state.UserSid);
            if (String.IsNullOrWhiteSpace(state.LocaleName)) throw new InvalidOperationException("无法确定当前系统区域。");
            var changes = new List<EncodingResetChange>();
            foreach (string key in CodePages) {
                EncodingResetValue current = state.Values[key];
                uint parsed;
                if (!current.Exists || current.Kind != RegistryValueKind.String || !UInt32.TryParse(current.Value, out parsed) || parsed < 3 || !IsValidCodePage(parsed))
                    throw new InvalidOperationException(key + " 当前值或注册表类型异常，停止自动修复。");
                if (current.Value != "65001") continue;
                uint target;
                if (!state.NativeCodePages.TryGetValue(key, out target) || target < 3 || target == 65001 || !IsValidCodePage(target))
                    throw new InvalidOperationException("Windows 未提供 " + key + " 的有效原生码页，停止自动修复。");
                changes.Add(new EncodingResetChange { Key = key, Before = current.Copy(), After = new EncodingResetValue { Exists = true, Kind = RegistryValueKind.String, Value = target.ToString(CultureInfo.InvariantCulture) } });
            }
            foreach (string key in new[] { "UserPythonUtf8", "MachinePythonUtf8" }) {
                EncodingResetValue current = state.Values[key];
                if (current.Exists && (current.Value == null || (current.Kind != RegistryValueKind.String && current.Kind != RegistryValueKind.ExpandString)))
                    throw new InvalidOperationException("PYTHONUTF8 注册表类型异常，停止自动修复。");
                if (current.Exists && current.Value == "1")
                    changes.Add(new EncodingResetChange { Key = key, Before = current.Copy(), After = new EncodingResetValue { Exists = false } });
            }
            return changes;
        }

        internal static bool Pending(EncodingResetSnapshot state)
        {
            return state.LocaleChangePending || state.Values["ACP"].Value != state.EffectiveACP.ToString(CultureInfo.InvariantCulture) ||
                state.Values["OEMCP"].Value != state.EffectiveOEMCP.ToString(CultureInfo.InvariantCulture);
        }

        static bool ContextStable(EncodingResetSnapshot before, EncodingResetSnapshot after)
        {
            return before.UserSid == after.UserSid && before.MachineName == after.MachineName && before.LocaleName == after.LocaleName &&
                before.LocaleChangePending == after.LocaleChangePending && before.EffectiveACP == after.EffectiveACP && before.EffectiveOEMCP == after.EffectiveOEMCP &&
                CodePages.All(key => before.NativeCodePages.ContainsKey(key) == after.NativeCodePages.ContainsKey(key) &&
                    (!before.NativeCodePages.ContainsKey(key) || before.NativeCodePages[key] == after.NativeCodePages[key]));
        }

        static bool Stable(EncodingResetSnapshot before, EncodingResetSnapshot after)
        {
            return ContextStable(before, after) && Keys.All(key => before.Values[key].Same(after.Values[key]));
        }

        internal static RepairResult ExecuteCore(Func<EncodingResetSnapshot> read,
            Func<EncodingResetSnapshot, List<EncodingResetChange>, string> backup,
            Action<string, EncodingResetValue> write, bool administrator, Func<string, EncodingResetValue> readValue)
        {
            var attempted = new List<EncodingResetChange>();
            string backupPath = null;
            try {
                EncodingResetSnapshot original = read();
                List<EncodingResetChange> changes = MakePlan(original);
                if (changes.Count == 0)
                    return Success(Pending(original) ? "配置已是原生编码，但上一次系统区域或码页变更尚未生效。请保存工作后重启 Windows，再重新检测。本次没有修改。" :
                        "当前系统已使用原生编码，也没有需要清理的全局 PYTHONUTF8=1，无需修改或再次重启。按需 UTF-8 的工具流程继续保留。");
                if (Pending(original)) return Failure("检测到尚未生效的系统区域或码页变更。请先保存工作并重启 Windows，再使用“拨乱反正”。本次没有修改。");
                if (!administrator) return Failure("需要 Windows 管理员权限才能完成本次修复。本次没有修改。");
                backupPath = backup(original, changes);
                if (String.IsNullOrWhiteSpace(backupPath)) throw new IOException("备份没有返回有效路径。");
                if (!Stable(original, read())) throw new IOException("备份期间编码或环境设置已被其他程序修改，请重新检测。");
                foreach (EncodingResetChange change in changes) {
                    EncodingResetSnapshot current = read();
                    if (!ContextStable(original, current)) throw new IOException("修复期间系统区域或生效环境已改变。");
                    if (!change.Before.Same(current.Values[change.Key])) throw new IOException(change.Key + " 在写入前已改变。");
                    attempted.Add(change);
                    write(change.Key, change.After);
                    if (!change.After.Same(read().Values[change.Key])) throw new IOException(change.Key + " 写入后的回读不一致。");
                }
                EncodingResetSnapshot final = read();
                if (!ContextStable(original, final) || changes.Any(change => !change.After.Same(final.Values[change.Key])))
                    throw new IOException("最终核对发现用户、系统区域或目标值已发生变化。");
                var completed = new List<string>();
                if (changes.Any(change => CodePages.Contains(change.Key))) completed.Add("已按当前系统区域（" + original.LocaleName + "）的原生默认值写入编码配置。请保存工作后自行重启 Windows，重启后才生效。");
                if (changes.Any(change => change.Key == "UserPythonUtf8")) completed.Add("已清理发起操作用户的 PYTHONUTF8=1。");
                if (changes.Any(change => change.Key == "MachinePythonUtf8")) completed.Add("已清理这台电脑系统级的 PYTHONUTF8=1（影响所有用户新启动的程序）。");
                if (!changes.Any(change => CodePages.Contains(change.Key))) completed.Add("系统码页未改动；请重新打开受影响的程序，使环境变量清理生效。");
                completed.Add("不会自动重启，也不会转换已有文件。原值备份：" + backupPath);
                return Success(String.Join("\r\n", completed));
            }
            catch (Exception ex) {
                var rollback = new List<string>();
                foreach (EncodingResetChange change in attempted.AsEnumerable().Reverse()) {
                    try {
                        EncodingResetValue actual = readValue(change.Key);
                        if (change.Before.Same(actual)) continue;
                        if (!change.After.Same(actual)) { rollback.Add(change.Key + " 已出现其他新值，未覆盖"); continue; }
                        write(change.Key, change.Before);
                        if (!change.Before.Same(readValue(change.Key))) rollback.Add(change.Key + " 回滚回读不一致");
                    }
                    catch (Exception undo) { rollback.Add(change.Key + " 回滚失败：" + undo.Message); }
                }
                string detail = "修复未完成：" + ex.Message;
                if (attempted.Count > 0) detail += rollback.Count == 0 ? " 本次已尝试写入的项目均已保留或恢复原值。" : " " + String.Join("；", rollback);
                else detail += " 未写入系统或用户设置。";
                if (backupPath != null) detail += "\r\n原值备份：" + backupPath;
                return Failure(detail);
            }
        }

        static EncodingResetSnapshot ReadSnapshot(string sid)
        {
            var state = new EncodingResetSnapshot { UserSid = sid, MachineName = Environment.MachineName, EffectiveACP = GetACP(), EffectiveOEMCP = GetOEMCP() };
            var locale = new StringBuilder(85);
            if (GetSystemDefaultLocaleName(locale, locale.Capacity) == 0) throw new IOException("无法读取 Windows 当前系统区域。");
            state.LocaleName = locale.ToString();
            using (RegistryKey machine = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
            using (RegistryKey users = RegistryKey.OpenBaseKey(RegistryHive.Users, RegistryView.Registry64))
            using (RegistryKey user = users.OpenSubKey(sid)) {
                if (user == null) throw new IOException("发起操作用户的注册表尚未加载，未改动其他用户。");
                using (RegistryKey key = machine.OpenSubKey(CodePagePath)) {
                    if (key == null) throw new IOException("系统码页位置不可用。");
                    foreach (string name in CodePages) state.Values[name] = ReadValue(key, name);
                }
                using (RegistryKey key = machine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Nls\Language")) {
                    EncodingResetValue value = ReadValue(key, "Default");
                    uint configured;
                    if (!value.Exists || value.Kind != RegistryValueKind.String || !UInt32.TryParse(value.Value, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out configured))
                        throw new IOException("无法核对系统区域是否存在待生效变更。");
                    state.LocaleChangePending = configured != GetSystemDefaultLCID();
                }
                using (RegistryKey key = user.OpenSubKey("Environment")) state.Values["UserPythonUtf8"] = ReadValue(key, "PYTHONUTF8");
                using (RegistryKey key = machine.OpenSubKey(MachineEnvironmentPath)) state.Values["MachinePythonUtf8"] = ReadValue(key, "PYTHONUTF8");
            }
            uint[] types = { 0x1004, 0x000B, 0x1011 };
            for (int index = 0; index < CodePages.Length; index++) {
                var value = new StringBuilder(16); uint number;
                if (GetLocaleInfoEx(state.LocaleName, types[index], value, value.Capacity) == 0 || !UInt32.TryParse(value.ToString(), out number))
                    throw new IOException("无法从 Windows 查询当前系统区域的原生码页。");
                state.NativeCodePages[CodePages[index]] = number;
            }
            return state;
        }

        static EncodingResetValue ReadValue(RegistryKey key, string name)
        {
            if (key == null || !key.GetValueNames().Contains(name, StringComparer.OrdinalIgnoreCase)) return new EncodingResetValue { Exists = false };
            RegistryValueKind kind = key.GetValueKind(name);
            object raw = key.GetValue(name, null, RegistryValueOptions.DoNotExpandEnvironmentNames);
            return new EncodingResetValue { Exists = true, Kind = kind, Value = raw as string };
        }

        static void WriteValue(string sid, string name, EncodingResetValue value)
        {
            bool isUser = name == "UserPythonUtf8";
            bool isMachineEnvironment = name == "MachinePythonUtf8";
            if (!isUser && !isMachineEnvironment && !CodePages.Contains(name)) throw new InvalidOperationException("修复目标不在允许范围内。");
            using (RegistryKey root = RegistryKey.OpenBaseKey(isUser ? RegistryHive.Users : RegistryHive.LocalMachine, RegistryView.Registry64))
            using (RegistryKey key = root.OpenSubKey(isUser ? sid + @"\Environment" : (isMachineEnvironment ? MachineEnvironmentPath : CodePagePath), true)) {
                if (key == null) throw new IOException("目标注册表位置已不可用。");
                string valueName = isUser || isMachineEnvironment ? "PYTHONUTF8" : name;
                if (value.Exists) key.SetValue(valueName, value.Value, value.Kind); else key.DeleteValue(valueName, false);
                key.Flush();
            }
        }

        static EncodingResetValue ReadSingleValue(string sid, string name)
        {
            bool isUser = name == "UserPythonUtf8";
            bool isMachineEnvironment = name == "MachinePythonUtf8";
            if (!isUser && !isMachineEnvironment && !CodePages.Contains(name)) throw new InvalidOperationException("回读目标不在允许范围内。");
            using (RegistryKey root = RegistryKey.OpenBaseKey(isUser ? RegistryHive.Users : RegistryHive.LocalMachine, RegistryView.Registry64)) {
                if (isUser) {
                    using (RegistryKey user = root.OpenSubKey(sid)) {
                        if (user == null) throw new IOException("发起操作用户的注册表已卸载。");
                        using (RegistryKey key = user.OpenSubKey("Environment")) return ReadValue(key, "PYTHONUTF8");
                    }
                }
                using (RegistryKey key = root.OpenSubKey(isMachineEnvironment ? MachineEnvironmentPath : CodePagePath)) {
                    if (key == null) throw new IOException("目标注册表位置已不可用。");
                    return ReadValue(key, isMachineEnvironment ? "PYTHONUTF8" : name);
                }
            }
        }

        static string WriteBackup(EncodingResetSnapshot state, List<EncodingResetChange> changes)
        {
            string root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "CodexTools", "EncodingRepair", "Backups");
            Directory.CreateDirectory(root);
            string path = Path.Combine(root, "native-encoding-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N") + ".json");
            string json = new JavaScriptSerializer().Serialize(new {
                schema = "codextools-native-encoding-backup/v1", createdUtc = DateTime.UtcNow.ToString("o"),
                targetPolicy = "Current system locale native defaults, not a historical original-code-page snapshot",
                before = state, changes = changes
            });
            byte[] bytes = new UTF8Encoding(false).GetBytes(json);
            using (var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.Read)) {
                stream.Write(bytes, 0, bytes.Length); stream.Flush(true);
            }
            byte[] actual = File.ReadAllBytes(path);
            if (!bytes.SequenceEqual(actual)) throw new IOException("原值备份回读不一致，未修改设置。");
            return path;
        }

        static RepairResult Success(string detail) { return new RepairResult { Name = "拨乱反正", Success = true, Detail = detail }; }
        static RepairResult Failure(string detail) { return new RepairResult { Name = "拨乱反正", Success = false, Detail = detail }; }
    }
}
