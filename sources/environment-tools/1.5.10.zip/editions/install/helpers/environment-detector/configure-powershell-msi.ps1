﻿[CmdletBinding()]
param([string]$ResultPath,[string]$LibraryRoot,[string]$InstallerPath,[switch]$ValidateOnly)
$ErrorActionPreference='Stop'
$version='7.6.9'
$fileName='PowerShell-7.6.9-win-x64.msi'
$expectedHash='50d33c7494aaf82b987cfd4de3f232d04f91fdd4c0deeca8a669cced3e7cf8f9'
$url='https://github.com/PowerShell/PowerShell/releases/download/v7.6.9/PowerShell-7.6.9-win-x64.msi'
$executable=Join-Path $env:ProgramFiles 'PowerShell\7\pwsh.exe'
$exitCode=1
$message=''

function Test-MsiRegistration {
    return [bool]@(Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like 'PowerShell 7*' -and $_.WindowsInstaller -eq 1 }).Count
}
function Test-CoreCommand {
    $output=& $executable -NoLogo -NoProfile -NonInteractive -Command 'if($PSVersionTable.PSEdition -ne "Core" -or $PSVersionTable.PSVersion.Major -lt 7){exit 3};[Console]::Write("CODEXTOOLS_PS7|"+$PSVersionTable.PSVersion.ToString()+"|"+(1+1))' 2>&1
    if ($LASTEXITCODE -ne 0 -or ($output -join '').Trim() -notmatch '^CODEXTOOLS_PS7\|7\.\d+\.\d+(?:\.\d+)?\|2$') { throw 'PowerShell Core startup/calculation verification failed.' }
}
function Get-VerifiedMsi {
    $cache=Join-Path $env:LOCALAPPDATA 'CodexTools\EnvironmentDetector\installer-cache'
    New-Item -ItemType Directory -Path $cache -Force | Out-Null
    $target=Join-Path $cache $fileName
    if ($InstallerPath) { $target=(Resolve-Path -LiteralPath $InstallerPath).Path }
    elseif ($LibraryRoot) {
        $choices=@((Join-Path $LibraryRoot $fileName),(Join-Path $LibraryRoot ('packages\'+$fileName)))
        $target=$choices | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
        if (-not $target) { throw "Selected library has no verified $fileName. Use the official source or place that MSI in this library; MSIX is not installed." }
    }
    elseif (-not (Test-Path -LiteralPath $target)) {
        $temporary=$target+'.download-'+[Guid]::NewGuid().ToString('N')
        try {
            [Net.ServicePointManager]::SecurityProtocol=[Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
            $ProgressPreference='SilentlyContinue'
            Invoke-WebRequest -Uri $url -OutFile $temporary -UseBasicParsing -TimeoutSec 120 -Headers @{'User-Agent'='CodexTools-PowerShell-MSI'}
            Move-Item -LiteralPath $temporary -Destination $target
        } finally { if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force } }
    }
    if ([IO.Path]::GetExtension($target) -ine '.msi') { throw 'Only the official standalone MSI package is accepted.' }
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ine $expectedHash) { throw 'PowerShell MSI checksum mismatch; package was not executed.' }
    $signature=Get-AuthenticodeSignature -LiteralPath $target
    if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'CN=Microsoft Corporation(?:,|$)') { throw 'Microsoft MSI signature verification failed; package was not executed.' }
    return $target
}

try {
    if ($ValidateOnly) { $verified=Get-VerifiedMsi; $message='Verified Microsoft MSI '+$version+'; no installation or PATH change.'; $exitCode=0 }
    else {
        $registered=Test-MsiRegistration
        $usable=$false
        if ($registered -and (Test-Path -LiteralPath $executable)) { try { Test-CoreCommand;$usable=$true } catch {} }
        if (-not $usable) {
            $package=Get-VerifiedMsi
            $log=Join-Path $env:TEMP ('CodexTools-PowerShell-MSI-'+[Guid]::NewGuid().ToString('N')+'.log')
            $arguments=@('/i',('"'+$package+'"'),'/qn','/norestart','ADD_PATH=1','ENABLE_PSREMOTING=0','/L*v',('"'+$log+'"'))
            if ($registered) {
                $sameVersion=@(Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like 'PowerShell 7*' -and $_.DisplayVersion -like ($version+'*') }).Count -gt 0
                if ($sameVersion) { $arguments+=@('REINSTALL=ALL','REINSTALLMODE=vomus') }
            }
            $installer=Start-Process -FilePath (Join-Path $env:WINDIR 'System32\msiexec.exe') -ArgumentList $arguments -WindowStyle Hidden -Wait -PassThru
            if ($installer.ExitCode -notin @(0,3010)) { throw "MSI failed: $($installer.ExitCode). Log: $log" }
        }
        if (-not (Test-MsiRegistration) -or -not (Test-Path -LiteralPath $executable)) { throw 'MSI installation registration or pwsh.exe is missing.' }
        Test-CoreCommand
        $directory=Split-Path -Parent $executable
        # Move only this PowerShell directory; all other PATH entries retain their order and content.
        $oldPath=[Environment]::GetEnvironmentVariable('Path','Machine')
        $remaining=@($oldPath.Split(';') | Where-Object { [Environment]::ExpandEnvironmentVariables($_.Trim().Trim('"')).TrimEnd('\') -ine $directory.TrimEnd('\') })
        $updated=(@($directory)+$remaining) -join ';'
        $env:Path=$oldPath+';'+[Environment]::GetEnvironmentVariable('Path','User')
        if ((Get-Command pwsh.exe -ErrorAction SilentlyContinue).Source -ine $executable -and $updated -cne $oldPath) { [Environment]::SetEnvironmentVariable('Path',$updated,'Machine') }
        $env:Path=[Environment]::GetEnvironmentVariable('Path','Machine')+';'+[Environment]::GetEnvironmentVariable('Path','User')
        $resolved=(Get-Command pwsh.exe -ErrorAction Stop).Source
        if ($resolved -ine $executable) { throw "Fresh PATH resolves a different PowerShell: $resolved" }
        Test-CoreCommand
        $message='Standalone MSI registration, PowerShell Core, PATH and 1+1=2 verified. Reopen previously running terminals/DSH to inherit PATH.'
        $exitCode=0
    }
} catch { $message=$_.Exception.Message }
if ($ResultPath) { [IO.File]::WriteAllText($ResultPath,(@{ok=($exitCode -eq 0);message=$message;version=$version;format='MSI'} | ConvertTo-Json -Compress),[Text.UTF8Encoding]::new($false)) }
Write-Output $message
exit $exitCode
