﻿[CmdletBinding()]
param([switch]$Repair, [switch]$ValidateOnly, [string]$CacheDirectory = (Join-Path $env:LOCALAPPDATA 'CodexTools/EnvironmentDetector/installer-cache'))
$ErrorActionPreference = 'Stop'
$expected = '0e6918c273eabbdbbd800ee0dacbbf130a14c13c2e4cec861b06dd59e015bf94'
$name = 'LibreOffice_26.8.3.1_Win_x86-64.msi'
$urls = @(
    'https://mirrors.tuna.tsinghua.edu.cn/libreoffice/libreoffice/stable/26.8.3/win/x86_64/LibreOffice_26.8.3_Win_x86-64.msi'
    "https://downloadarchive.documentfoundation.org/libreoffice/old/26.8.3.1/win/x86_64/$name"
)
try {
    [IO.Directory]::CreateDirectory($CacheDirectory) | Out-Null
    $package = Join-Path $CacheDirectory $name
    if (!(Test-Path -LiteralPath $package) -or (Get-FileHash -LiteralPath $package).Hash -ne $expected) {
        $ProgressPreference = 'SilentlyContinue'
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        foreach ($url in $urls) {
            $partial = Join-Path $CacheDirectory ([Guid]::NewGuid().ToString('N')+'.part')
            try {
                $curl = Join-Path $env:SystemRoot 'System32/curl.exe'
                if (Test-Path -LiteralPath $curl) {
                    & $curl --fail --location --silent --show-error --connect-timeout 12 --speed-limit 1024 --speed-time 20 --max-time 600 --output $partial $url
                    if ($LASTEXITCODE -ne 0) { throw "Download failed: curl exit $LASTEXITCODE" }
                } else {
                    Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $partial -TimeoutSec 180
                }
                if ((Get-FileHash -LiteralPath $partial).Hash -ne $expected) { throw 'MSI SHA256 mismatch' }
                Copy-Item -LiteralPath $partial -Destination $package -Force
                break
            } catch {
                if ($url -eq $urls[-1]) { throw }
            } finally {
                if (Test-Path -LiteralPath $partial) { Remove-Item -LiteralPath $partial -Force }
            }
        }
    }
    $handle = [IO.File]::Open($package,'Open','Read','Read')
    try {
        if ((Get-FileHash -LiteralPath $package).Hash -ne $expected) { throw 'MSI SHA256 mismatch' }
        if ($ValidateOnly) { Write-Output 'Verified LibreOffice 26.8.3.1 MSI'; exit 0 }
        $arguments = @('/i', ('"'+$package+'"'), '/qn', '/norestart')
        if ($Repair) {
            $sameVersion = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like 'LibreOffice*' -and $_.DisplayVersion -eq '26.8.3.1' }
            if ($sameVersion) { $arguments += @('REINSTALL=ALL','REINSTALLMODE=vomus') }
        }
        $process = Start-Process -FilePath (Join-Path $env:WINDIR 'System32/msiexec.exe') -ArgumentList $arguments -Verb RunAs -WindowStyle Hidden -PassThru -Wait
        if ($process.ExitCode -notin @(0,3010)) { throw "Windows Installer exit code $($process.ExitCode)" }
    } finally { $handle.Dispose() }
} catch { [Console]::Error.WriteLine($_.Exception.Message); exit 1 }
exit 0
