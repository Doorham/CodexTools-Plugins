﻿using System;
using System.Net;
using EnvironmentDetector;
internal static class DownloadResolutionTests
{
    private static int checks;
    private static void Check(string name, bool passed)
    {
        Console.WriteLine(name + "=" + (passed ? "PASS" : "FAIL"));
        if (!passed) throw new Exception(name);
        checks++;
    }
    public static int Main()
    {
        // Matches the actual GitHub assets array shape; JavaScriptSerializer materializes it as ArrayList.
        string json = @"{""assets"":[
            {""name"":""PowerShell-7.6.8-win-arm64.msi"",""browser_download_url"":""https://example.invalid/arm64.msi""},
            {""name"":""PowerShell-7.6.8-win-x64.zip"",""browser_download_url"":""https://example.invalid/x64.zip""},
            {""name"":""PowerShell-7.6.8-win-x64.msi"",""browser_download_url"":""https://example.invalid/x64.msi""},
            {""name"":""PowerShell-7.6.8-win-x86.msi"",""browser_download_url"":""https://example.invalid/x86.msi""}]}";
        Check("ARRAYLIST_SELECTS_X64_MSI", DirectDownloader.ParsePowerShellReleaseUrl(json) == "https://example.invalid/x64.msi");
        Check("NO_ASSETS_RETURNS_EMPTY", DirectDownloader.ParsePowerShellReleaseUrl("{}") == null);
        Check("EMPTY_ASSETS_RETURNS_EMPTY", DirectDownloader.ParsePowerShellReleaseUrl("{\"assets\":[]}") == null);
        Check("OTHER_ARCH_NOT_SELECTED", DirectDownloader.ParsePowerShellReleaseUrl("{\"assets\":[{\"name\":\"PowerShell-win-arm64.msi\",\"browser_download_url\":\"https://example.invalid/arm64.msi\"}]}") == null);
        Check("MISSING_URL_NOT_SELECTED", DirectDownloader.ParsePowerShellReleaseUrl("{\"assets\":[{\"name\":\"PowerShell-win-x64.msi\"}]}") == null);
        bool legacyDefault;
        Check("LEGACY_TLS_DEFAULT_DISABLED", AppContext.TryGetSwitch("Switch.System.Net.DontEnableSystemDefaultTlsVersions", out legacyDefault) && !legacyDefault);
        Check("OS_DEFAULT_TLS", ServicePointManager.SecurityProtocol == SecurityProtocolType.SystemDefault);
        bool resolutionError = false;
        try { DirectDownloader.ResolveUrl(new DownloadRegistry.DownloadInfo { DynamicUrl = true, DirectUrl = "not an absolute URL" }); }
        catch (Exception) { resolutionError = true; }
        Check("RESOLUTION_ERROR_IS_NOT_SWALLOWED", resolutionError);
        DownloadRegistry.DownloadInfo sdk, desktop;
        Check("SDK_PORTAL_MIRROR_REMOVED", DownloadRegistry.TryGet(Detector.DotNetSdkName, out sdk) && String.IsNullOrEmpty(sdk.MirrorUrl) && !String.IsNullOrEmpty(sdk.DirectUrl));
        Check("DESKTOP_PORTAL_MIRROR_REMOVED", DownloadRegistry.TryGet(Detector.DesktopRuntimeName, out desktop) && String.IsNullOrEmpty(desktop.MirrorUrl) && !String.IsNullOrEmpty(desktop.DirectUrl));
        DownloadRegistry.DownloadInfo powershell, python, office;
        Check("MSI_CHANNEL_DOES_NOT_FOLLOW_77_LATEST", DownloadRegistry.TryGet("PowerShell 7", out powershell) && !powershell.DynamicUrl
            && powershell.DirectUrl.EndsWith("/v7.6.10/PowerShell-7.6.10-win-x64.msi")
            && powershell.SaveName == "PowerShell-" + PowerShellSetup.MinimumMsiVersion + "-win-x64.msi");
        Check("POWERSHELL_MIRROR_HAS_THE_SAME_MSI", powershell.MirrorUrl.Contains("/v7.6.10/PowerShell-7.6.10-win-x64.msi/"));
        Check("PYTHON_MIRROR_MATCHES_MAINTAINED_BRANCH", DownloadRegistry.TryGet("基础开发环境", out python)
            && python.DirectUrl.EndsWith(python.SaveName) && python.MirrorUrl.EndsWith(python.SaveName)
            && python.SaveName == "python-3.14.10-amd64.exe");
        Check("OFFICE_MIRROR_POINTS_TO_WINDOWS_INSTALLER", DownloadRegistry.TryGet(Detector.LibreOfficeName, out office)
            && office.MirrorUrl.Contains("/libreoffice/libreoffice/stable/26.8.3/win/x86_64/")
            && office.MirrorUrl.EndsWith(".msi") && office.DirectUrl.EndsWith(office.SaveName));
        Check("SDK_DOWNLOAD_IS_SUPPORTED_LTS", sdk.DirectUrl.Contains("/dotnet/10.0/") && sdk.OfficialUrl.EndsWith("/10.0"));
        Check("EOL_SDK_NOT_READY", Detector.SupportedSdkVersion("8.0.428 [fixture]\n9.0.310 [fixture]\n") == null);
        Check("CURRENT_LTS_SDK_READY", Detector.SupportedSdkVersion("8.0.428 [fixture]\n10.0.404 [fixture]\n") == "10.0.404");
        Check("NEWER_STABLE_SDK_ACCEPTED", Detector.SupportedSdkVersion("11.0.100 [fixture]\n") == "11.0.100");
        Check("PREVIEW_SDK_NOT_STABLE", Detector.SupportedSdkVersion("10.0.100-preview.1 [fixture]\n") == null);
        Check("FAILED_SDK_OUTPUT_NOT_READY", Detector.SupportedSdkVersion("failed to launch") == null);
        string selected;
        Check("LEGACY_DESKTOP_REQUIREMENT_PRESERVED", Detector.FindX64DesktopRuntime(new[] { "fixture" }, path => true,
            path => new CommandResult { ExitCode = 0, Output = "Microsoft.WindowsDesktop.App 8.0.34 [fixture]\nMicrosoft.WindowsDesktop.App 10.0.12 [fixture]\n" }, out selected) == "8.0.34");
        Check("DESKTOP10_CANNOT_IMPERSONATE_DESKTOP8", Detector.FindX64DesktopRuntime(new[] { "fixture" }, path => true,
            path => new CommandResult { ExitCode = 0, Output = "Microsoft.WindowsDesktop.App 10.0.12 [fixture]\n" }, out selected) == "缺少");
        Console.WriteLine("TOTAL=" + checks);
        return 0;
    }
}
