using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using EnvironmentDetector;

internal static class SoftwareActionTests
{
    static void Check(bool passed, string description) {
        if (!passed) throw new Exception(description);
        Console.WriteLine("PASS " + description);
    }

    static void Office(bool exists, bool works, bool installerWorks, bool pathWorks, bool expected, string sequence) {
        var calls = new List<string>();
        var result = RepairEngine.ConfigureLibreOffice(
            () => exists ? @"C:\fixture\program\soffice.com" : null,
            path => { calls.Add("probe"); return new CommandResult { ExitCode = works ? 0 : 1 }; },
            repair => {
                calls.Add(repair ? "repair" : "install");
                exists = works = installerWorks;
                return new CommandResult { ExitCode = installerWorks ? 0 : 1 };
            },
            path => { calls.Add("path"); return pathWorks; });
        Check(result.Success == expected && String.Join(",", calls) == sequence, sequence + " => " + expected);
    }

    [STAThread] static int Main() {
        Office(false, false, true, true, true, "install,probe,path");
        Office(true, false, true, true, true, "probe,repair,probe,path");
        Office(true, true, false, true, true, "probe,path");
        Office(false, false, false, true, false, "install");
        Office(true, true, false, false, false, "probe,path");
        UiTheme.EnableDpiAwareness();
        Application.EnableVisualStyles();
        foreach (string name in Detector.ScanNames(false).Where(RepairEngine.HasPackageAction)) {
            var missing = new CheckResult { Name = name, Level = CheckLevel.Missing };
            using (var card = new ResultCard(missing, false)) {
                Check(card.Controls.Find("installPackage",false).Single().Enabled &&
                    RepairEngine.GetAutomaticItems(new[]{missing}).SequenceEqual(new[]{name}), "action routed " + name);
            }
        }
        // Exercise an actual click only where it can finish without changing installed software.
        if (Detector.CheckItem(Detector.LibreOfficeName).Level != CheckLevel.Ready) return 0;
        using (var form = new MainForm(false, false, false)) {
            var flags = BindingFlags.NonPublic | BindingFlags.Instance;
            var type = typeof(MainForm);
            var scanning = type.GetField("scanRunning", flags);
            var busy = type.GetField("backgroundOperationRunning", flags);
            scanning.SetValue(form, true);
            form.ShowInTaskbar = false;
            form.Show();
            Application.DoEvents();
            scanning.SetValue(form,false);
            var rows = new List<CheckResult>{new CheckResult { Name=Detector.LibreOfficeName, Level=CheckLevel.Warning }};
            type.GetField("lastResults",flags).SetValue(form,rows);
            type.GetMethod("RenderResults",flags).Invoke(form,new object[]{rows});
            var button=(Button)form.Controls.Find("installPackage",true).Single();
            button.PerformClick();
            Check((bool)busy.GetValue(form), "real click starts single-item repair");
            var deadline=DateTime.UtcNow.AddSeconds(60);
            while ((bool)busy.GetValue(form) || (bool)scanning.GetValue(form)) {
                Application.DoEvents();
                if (DateTime.UtcNow > deadline) throw new TimeoutException("Click did not finish");
                Thread.Sleep(20);
            }
            var verified=(List<CheckResult>)type.GetField("lastResults",flags).GetValue(form);
            Check(verified.Count==8 && verified.Single(x=>x.Name==Detector.LibreOfficeName).Level==CheckLevel.Ready,
                "click completed, full software page refreshed and LibreOffice ready");
        }
        return 0;
    }
}
