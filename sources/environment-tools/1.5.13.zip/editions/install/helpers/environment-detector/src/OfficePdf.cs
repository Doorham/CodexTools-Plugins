﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace EnvironmentDetector
{
    internal static class OfficePdf
    {
        internal static bool IsPdf(string path)
        {
            if (!File.Exists(path)) return false;
            using (var stream = File.OpenRead(path))
            {
                if (stream.Length < 50) return false;
                var header = new byte[5];
                stream.Read(header, 0, header.Length);
                if (Encoding.ASCII.GetString(header) != "%PDF-") return false;
                var tail = new byte[(int)Math.Min(2048L, stream.Length)];
                stream.Seek(-tail.Length, SeekOrigin.End);
                stream.Read(tail, 0, tail.Length);
                var end = Regex.Match(Encoding.ASCII.GetString(tail), @"startxref\s+(\d+)\s+%%EOF\s*\z");
                long offset;
                if (!end.Success || !Int64.TryParse(end.Groups[1].Value, out offset) || offset < 5 || offset >= stream.Length) return false;
                stream.Position = offset;
                var bytes = new byte[(int)Math.Min(stream.Length - offset, 2048)];
                stream.Read(bytes, 0, bytes.Length);
                string table = Encoding.ASCII.GetString(bytes);
                return table.StartsWith("xref", StringComparison.Ordinal) ||
                    Regex.IsMatch(table, @"^\d+\s+\d+\s+obj\b[\s\S]*?/Type\s*/XRef\b");
            }
        }

        internal static CommandResult Convert(string executable, string input, string destination)
        {
            string temp = Path.Combine(Path.GetTempPath(), "EDPDF-" + Guid.NewGuid().ToString("N"));
            try
            {
                Directory.CreateDirectory(temp);
                if (input == null)
                {
                    input = Path.Combine(temp, "LibreOffice-check.rtf");
                    File.WriteAllText(input, @"{\rtf1\ansi\deff0 {\fonttbl {\f0 Arial;}}\f0\fs32 CodexTools LibreOffice PDF verification\par\fs22 This page was exported by LibreOffice Writer.}", Encoding.ASCII);
                }
                input = Path.GetFullPath(input);
                if (!File.Exists(input)) throw new FileNotFoundException("未找到待转换文档。");
                if (destination != null && File.Exists(destination)) throw new IOException("目标 PDF 已存在，请选择新文件名。");
                string profile = new Uri(Path.Combine(temp, "profile")).AbsoluteUri;
                // CrashReporter otherwise resolves a proxy bypass host (including reverse DNS) before local export.
                var start = new ProcessStartInfo(executable, "-env:CrashDumpEnable=false \"-env:UserInstallation=" + profile +
                    "\" --headless --norestore --convert-to pdf --outdir \"" + temp + "\" \"" + input + "\"")
                    { UseShellExecute = false, CreateNoWindow = true };
                start.EnvironmentVariables.Remove("CRASH_DUMP_ENABLE");
                using (var process = Process.Start(start))
                {
                    if (!process.WaitForExit(60000))
                    {
                        var stop = new ProcessStartInfo(Path.Combine(Environment.SystemDirectory, "taskkill.exe"),
                            "/T /F /PID " + process.Id) { UseShellExecute = false, CreateNoWindow = true };
                        using (var killer = Process.Start(stop)) killer.WaitForExit(5000);
                        throw new TimeoutException("LibreOffice 转 PDF 超时（60 秒）。");
                    }
                    if (process.ExitCode != 0) throw new IOException("LibreOffice 退出码 " + process.ExitCode);
                }
                string output = Path.Combine(temp, Path.GetFileNameWithoutExtension(input) + ".pdf");
                if (!IsPdf(output)) throw new InvalidDataException("转换未生成完整的 PDF。");
                if (destination != null)
                {
                    string staged = Path.GetFullPath(destination) + "." + Guid.NewGuid().ToString("N") + ".part";
                    try { File.Copy(output, staged); File.Move(staged, destination); }
                    finally { if (File.Exists(staged)) File.Delete(staged); }
                }
                return new CommandResult { ExitCode = 0, Output = "已实际转出 PDF 并校验文件。" };
            }
            catch (Exception ex) { return new CommandResult { ExitCode = 1, Output = ex.Message }; }
            finally { try { if (Directory.Exists(temp)) Directory.Delete(temp, true); } catch (IOException) {} catch (UnauthorizedAccessException) {} }
        }
    }
}
