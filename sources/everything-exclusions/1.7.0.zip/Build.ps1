[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$OutputDirectory,[Parameter(Mandatory=$true)][string]$WebViewLibrary)
$ErrorActionPreference = 'Stop'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
$core = Join-Path $WebViewLibrary 'Microsoft.Web.WebView2.Core.dll'
$forms = Join-Path $WebViewLibrary 'Microsoft.Web.WebView2.WinForms.dll'
& $compiler /nologo /target:winexe /platform:x64 /optimize+ ('/out:' + (Join-Path $OutputDirectory 'EverythingExclusions.exe')) /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Web.Extensions.dll /r:System.Core.dll ('/r:'+$core) ('/r:'+$forms) (Join-Path $PSScriptRoot 'src\Program.cs') (Join-Path $PSScriptRoot 'src\Tests.cs') (Join-Path $PSScriptRoot 'src\MergeTests.cs') (Join-Path $PSScriptRoot 'src\ShellPreview.cs') (Join-Path $PSScriptRoot 'src\SharedProfiles.cs') (Join-Path $PSScriptRoot 'src\HangRepair.cs') (Join-Path $PSScriptRoot 'src\HangRepairTests.cs') (Join-Path $PSScriptRoot 'src\Promotion.cs') (Join-Path $PSScriptRoot 'src\PromotionTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Plugin compilation failed.' }
Copy-Item -LiteralPath $core,$forms,(Join-Path $WebViewLibrary 'runtimes\win-x64\native\WebView2Loader.dll') -Destination $OutputDirectory -Force
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'ui') -Destination $OutputDirectory -Recurse -Force
