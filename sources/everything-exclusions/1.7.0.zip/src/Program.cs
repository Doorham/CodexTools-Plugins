using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

[assembly: System.Reflection.AssemblyTitle("Everything 路径排除")]
[assembly: System.Reflection.AssemblyVersion("1.7.0.0")]
[assembly: System.Reflection.AssemblyFileVersion("1.7.0.0")]

namespace EverythingExclusions {
    internal static class Program {
        [STAThread] static int Main(string[] args) {
            // This standalone plugin uses its own adjacent DLLs, never the toolbox's _MEI directory.
            if (!Native.SetDllDirectory(null)) return 1;
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (args.Length == 4 && args[0] == "--self-test") return Tests.Run(args[1], args[2], args[3]);
            if (args.Length == 1 && args[0] == "--repair-hang") return HangRepair.Open();
            if (args.Length == 2 && args[0] == "--repair-self-test") return HangRepairTests.Run(args[1]);
            if (args.Length == 3 && args[0] == "--repair-integration-test") return HangRepairTests.Run(args[1], args[2]);
            bool created;
            using (var mutex = new Mutex(true, "Local\\Doorham.EverythingExclusions.1", out created)) {
                if (!created) {
                    IntPtr existing = Native.FindWindow(null, "Everything 路径排除");
                    if (existing != IntPtr.Zero) { Native.ShowWindow(existing, 9); Native.SetForegroundWindow(existing); }
                    return 0;
                }
                try {
                    string state = StateRoot(AppDomain.CurrentDomain.BaseDirectory, Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData));
                    Application.Run(new MainForm(new Controller(state, null)));
                    return 0;
                } catch (Exception e) { MessageBox.Show(e.Message, "Everything 路径排除", MessageBoxButtons.OK, MessageBoxIcon.Error); return 1; }
            }
        }
        internal static string StateRoot(string runtimeRoot, string localRoot) {
            string current = Path.Combine(runtimeRoot, "state");
            if (File.Exists(Path.Combine(current, "cards.json"))) return current;
            string legacy = Path.Combine(localRoot, "CodexTools", "CodexTools", "PrivatePlugins", "private-everything-exclusions", "state");
            return File.Exists(Path.Combine(legacy, "cards.json")) ? legacy : current;
        }
    }
    internal static class Util {
        internal static readonly UTF8Encoding Utf8 = new UTF8Encoding(false, true);
        internal static string Normalize(string path) {
            string full = Path.GetFullPath(path);
            string root = Path.GetPathRoot(full);
            return full.Length > root.Length ? full.TrimEnd('\\', '/') : full;
        }
        internal static bool Same(string a, string b) { return String.Equals(Normalize(a), Normalize(b), StringComparison.OrdinalIgnoreCase); }
        internal static bool Contains(string parent,string path,bool includeSelf=true) {
            string upper=Normalize(parent),lower=Normalize(path);
            if(String.Equals(upper,lower,StringComparison.OrdinalIgnoreCase))return includeSelf;
            return lower.StartsWith(upper.TrimEnd('\\','/')+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase);
        }
        internal static string Quote(string value) {
            return "\"" + Regex.Replace(value, "(\\\\*)\"", "$1$1\\\"").TrimEnd('\\') + new string('\\', value.Reverse().TakeWhile(c => c == '\\').Count() * 2) + "\"";
        }
        internal static void Atomic(string path, string content) {
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            string temp = path + ".tmp-" + Guid.NewGuid().ToString("N");
            try {
                File.WriteAllText(temp, content, Utf8);
                if (File.Exists(path)) File.Replace(temp, path, null); else File.Move(temp, path);
            } finally { if (File.Exists(temp)) File.Delete(temp); }
        }
    }
    internal sealed class Ini {
        internal readonly string Text;
        internal Ini(string text) { Text = text.TrimStart('\ufeff'); }
        internal string Get(string key, string fallback) {
            bool active = false; string found = fallback;
            foreach (string line in Regex.Split(Text, "\r?\n")) {
                string t = line.Trim();
                if (t.StartsWith("[")) active = t.Equals("[Everything]", StringComparison.OrdinalIgnoreCase);
                if (!active) continue;
                int eq = line.IndexOf('=');
                if (eq > 0 && line.Substring(0, eq).Trim().Equals(key, StringComparison.OrdinalIgnoreCase)) found = line.Substring(eq + 1);
            }
            return found;
        }
        internal string Set(string key, string value) {
            string newline = Text.Contains("\r\n") ? "\r\n" : "\n";
            var lines = Regex.Split(Text, "\r?\n").ToList();
            bool active = false; int found = -1, section = -1, end = -1;
            for (int i = 0; i < lines.Count; i++) {
                string t = lines[i].Trim();
                if (t.StartsWith("[")) {
                    if (active && end < 0) end = i;
                    active = t.Equals("[Everything]", StringComparison.OrdinalIgnoreCase);
                    if (active) section = i;
                }
                int eq = lines[i].IndexOf('=');
                if (active && eq > 0 && lines[i].Substring(0, eq).Trim().Equals(key, StringComparison.OrdinalIgnoreCase)) found = i;
            }
            if (found >= 0) lines[found] = key + "=" + value;
            else if (section >= 0) lines.Insert(end >= 0 ? end : lines.Count, key + "=" + value);
            else { lines.Add("[Everything]"); lines.Add(key + "=" + value); }
            return String.Join(newline, lines);
        }
        internal static List<string> ParseList(string value) {
            var result = new List<string>(); var item = new StringBuilder(); bool quoted = false;
            for (int i = 0; i < value.Length; i++) {
                char c = value[i];
                if (c == '"') { quoted = !quoted; continue; }
                if (quoted && c == '\\' && i + 1 < value.Length && (value[i+1] == '\\' || value[i+1] == '"')) { item.Append(value[++i]); continue; }
                if (c == ',' && !quoted) { if (item.Length > 0) result.Add(item.ToString()); item.Clear(); }
                else item.Append(c);
            }
            if (quoted) throw new InvalidDataException("Everything 的排除列表格式不完整，尚未修改。");
            if (item.Length > 0) result.Add(item.ToString());
            return result;
        }
        internal static string EncodeList(IEnumerable<string> values) {
            return String.Join(",", values.Select(v => v.IndexOfAny(new char[] { ',', '"' }) >= 0 ? "\"" + v.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"" : v));
        }
    }
    internal sealed class WindowSnapshot { internal string Search; }
    internal static class Native {
        [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] internal static extern bool SetDllDirectory(string path);
        internal delegate bool EnumProc(IntPtr h, IntPtr p);
        [DllImport("user32.dll", CharSet=CharSet.Unicode)] internal static extern IntPtr FindWindow(string cls, string title);
        [DllImport("user32.dll")] internal static extern bool ShowWindow(IntPtr h, int command);
        [DllImport("user32.dll")] internal static extern bool SetForegroundWindow(IntPtr h);
        [DllImport("user32.dll")] internal static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
        [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc callback, IntPtr p);
        [DllImport("user32.dll")] static extern bool EnumChildWindows(IntPtr h, EnumProc callback, IntPtr p);
        [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
        [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder text, int count);
        [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder text, int count);
        [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern IntPtr SendMessageTimeout(IntPtr h, uint msg, IntPtr w, StringBuilder text, uint flags, uint timeout, out IntPtr result);
        internal static string Class(IntPtr h) { var b = new StringBuilder(256); GetClassName(h,b,b.Capacity); return b.ToString(); }
        internal static IntPtr Ipc(string instance) {
            if (String.IsNullOrEmpty(instance)) return FindWindow("EVERYTHING_TASKBAR_NOTIFICATION", null);
            IntPtr found = IntPtr.Zero;
            EnumWindows((h,p) => { string cls = Class(h); if (cls.StartsWith("EVERYTHING_TASKBAR_NOTIFICATION", StringComparison.Ordinal) && cls.IndexOf(instance,StringComparison.OrdinalIgnoreCase)>=0) found=h; return true; }, IntPtr.Zero);
            return found;
        }
        internal static List<WindowSnapshot> Capture(int pid) {
            var result = new List<WindowSnapshot>();
            EnumWindows((h,p) => {
                uint owner; GetWindowThreadProcessId(h,out owner);
                if (owner != pid || !IsWindowVisible(h) || !Class(h).Equals("EVERYTHING",StringComparison.OrdinalIgnoreCase)) return true;
                string search = null;
                EnumChildWindows(h,(child,unused) => {
                    if (search == null && Class(child).Equals("Edit",StringComparison.OrdinalIgnoreCase)) {
                        var b = new StringBuilder(32768); IntPtr ignored;
                        if (SendMessageTimeout(child,0x000D,(IntPtr)b.Capacity,b,2,500,out ignored) != IntPtr.Zero) search=b.ToString();
                    }
                    return true;
                },IntPtr.Zero);
                result.Add(new WindowSnapshot { Search = search ?? "" });
                return true;
            },IntPtr.Zero);
            return result;
        }
    }
    internal sealed class EverythingClient {
        internal string Executable, Config, Instance, BackupRoot;
        internal int ReloadCount;
        internal List<string> LastRemoved=new List<string>();
        internal static EverythingClient Detect(string state) {
            string exe = null; IntPtr ipc = Native.Ipc(""); uint pid;
            if (ipc != IntPtr.Zero) {
                Native.GetWindowThreadProcessId(ipc,out pid);
                try { exe=Process.GetProcessById((int)pid).MainModule.FileName; } catch { }
            }
            if (exe == null) {
                string[] candidates={Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"Everything","Everything.exe"),Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),"Everything","Everything.exe")};
                exe=candidates.FirstOrDefault(File.Exists);
            }
            if (exe == null) throw new FileNotFoundException("未找到 Everything，请先安装并打开 Everything。");
            var version=FileVersionInfo.GetVersionInfo(exe);
            if (version.FileMajorPart != 1 || version.FileMinorPart != 4) throw new NotSupportedException("当前插件适配 Everything 1.4；检测到其他版本，尚未改动设置。");
            string bootstrap=Path.Combine(Path.GetDirectoryName(exe),"Everything.ini");
            bool appdata=!File.Exists(bootstrap) || new Ini(File.ReadAllText(bootstrap,Encoding.UTF8)).Get("app_data","1").Trim() != "0";
            string config=appdata ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"Everything","Everything.ini") : bootstrap;
            if (!File.Exists(config)) throw new FileNotFoundException("未找到 Everything 配置，请先正常打开一次 Everything。");
            return new EverythingClient { Executable=exe,Config=config,Instance="",BackupRoot=Path.Combine(state,"config-backups") };
        }
        internal Process Launch(string arguments) {
            string prefix=String.IsNullOrEmpty(Instance) ? "" : "-instance " + Util.Quote(Instance) + " -config " + Util.Quote(Config) + " ";
            return Process.Start(new ProcessStartInfo(Executable,prefix+arguments) { UseShellExecute=false,CreateNoWindow=true,WindowStyle=ProcessWindowStyle.Hidden });
        }
        internal int RunningPid() {
            IntPtr ipc=Native.Ipc(Instance); uint pid;
            if(ipc==IntPtr.Zero) return 0;
            Native.GetWindowThreadProcessId(ipc,out pid);return (int)pid;
        }
        internal void WaitReady() {
            var watch=Stopwatch.StartNew();
            while(RunningPid()==0) { if(watch.ElapsedMilliseconds>10000) throw new TimeoutException("Everything 尚未重新启动，请正常打开 Everything 后重试。"); Thread.Sleep(70); }
        }
        internal List<string> Excluded() { return Ini.ParseList(new Ini(File.ReadAllText(Config,Encoding.UTF8)).Get("exclude_folders","")); }
        internal List<string> Change(IEnumerable<string> additions,IEnumerable<string> removals,IEnumerable<string> newClaims=null) {
            using (var gate = new Mutex(false, "Local\\Doorham.EverythingSettings.1")) {
                bool acquired; try { acquired = gate.WaitOne(0); } catch (AbandonedMutexException) { acquired = true; }
                if (!acquired) throw new IOException("Everything 设置正在修改，请稍后重试。");
                try { return ChangeCore(additions, removals, newClaims); } finally { gate.ReleaseMutex(); }
            }
        }
        private List<string> ChangeCore(IEnumerable<string> additions,IEnumerable<string> removals,IEnumerable<string> newClaims) {
            additions=additions.Distinct(StringComparer.OrdinalIgnoreCase).ToArray();removals=removals.Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
            var claims=newClaims==null?new string[0]:newClaims.ToArray();LastRemoved=new List<string>();var actuallyRemoved=new List<string>();
            int pid=RunningPid(); var windows=pid==0 ? new List<WindowSnapshot>() : Native.Capture(pid);
            bool stopped=false,written=false; byte[] original=null; var changed=new List<string>();
            try {
                if(pid!=0) {
                    using(var command=Launch("-exit")) { if(command!=null) command.WaitForExit(5000); }
                    var timer=Stopwatch.StartNew();
                    while(RunningPid()!=0) { if(timer.ElapsedMilliseconds>12000) throw new TimeoutException("Everything 没有正常退出，未修改配置。请关闭其对话框后重试。"); Thread.Sleep(80); }
                    stopped=true;
                }
                original=File.ReadAllBytes(Config);
                var ini=new Ini(Encoding.UTF8.GetString(original));
                if(ini.Get("exclude_list_enabled","1").Trim()=="0") throw new InvalidOperationException("Everything 的排除列表目前已关闭，请先在其选项中启用排除列表。");
                var current=Ini.ParseList(ini.Get("exclude_folders",""));
                if(claims.Any(path=>current.Any(rule=>SameLiteral(rule,path))))throw new IOException("所选目录刚刚被其他设置加入排除列表，已保留原卡片和规则，请重新拖入后确认。");
                actuallyRemoved=current.Where(rule=>removals.Any(path=>SameLiteral(rule,path))).ToList();
                foreach(string path in removals) current.RemoveAll(item => SameLiteral(item,path));
                foreach(string path in additions) if(!current.Any(item=>SameLiteral(item,path))) { current.Add(path);changed.Add(path); }
                string updated=ini.Set("exclude_folders",Ini.EncodeList(current));
                if(updated!=ini.Text) {
                    Directory.CreateDirectory(BackupRoot);
                    string backup=Path.Combine(BackupRoot,DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fff")+"-"+Guid.NewGuid().ToString("N")+".json");
                    string temp=Config+".codextools-"+Guid.NewGuid().ToString("N")+".tmp";
                    try {
                        bool bom=original.Length>=3 && original[0]==239 && original[1]==187 && original[2]==191;
                        File.WriteAllText(temp,updated,new UTF8Encoding(bom,true));
                        File.WriteAllText(backup,new JavaScriptSerializer().Serialize(new { exclude_folders=ini.Get("exclude_folders",""),exclude_list_enabled=ini.Get("exclude_list_enabled","1") }),Util.Utf8);
                        File.Replace(temp,Config,null); written=true;
                    } finally { if(File.Exists(temp)) File.Delete(temp); }
                    if(!additions.All(path=>Excluded().Any(item=>SameLiteral(item,path))) || removals.Any(path=>Excluded().Any(item=>SameLiteral(item,path)))) throw new IOException("Everything 排除规则回读不一致。");
                }
                if(stopped || pid==0) {
                    Launch("-startup"); WaitReady(); ReloadCount++;
                    // Restore search text only in memory; never persist or log it.
                    foreach(var window in windows) {
                        try { Launch("-newwindow -search "+Util.Quote(window.Search)); }
                        catch(System.ComponentModel.Win32Exception) { }
                    }
                }
            } catch(Exception operationError) {
                try {
                    if(written && original!=null) {
                        if(RunningPid()!=0) {
                            using(var command=Launch("-exit")) {if(command!=null)command.WaitForExit(5000);}
                            var wait=Stopwatch.StartNew();
                            while(RunningPid()!=0) {if(wait.ElapsedMilliseconds>12000)throw new IOException("Everything 未退出，未覆盖运行中配置。");Thread.Sleep(80);}
                        }
                        File.WriteAllBytes(Config,original);
                    }
                    if(stopped && RunningPid()==0) {Launch("-startup");WaitReady();}
                } catch(Exception recoveryError) {
                    throw new IOException("操作未完成，自动恢复也未完成："+recoveryError.Message+"。原操作："+operationError.Message,operationError);
                }
                throw;
            }
            LastRemoved=actuallyRemoved;return changed;
        }
        internal static bool SameLiteral(string rule,string path) {
            if(rule.IndexOfAny(new char[]{'*','?'})>=0 || rule.StartsWith("regex:",StringComparison.OrdinalIgnoreCase)) return false;
            try{return Util.Same(rule,path);}catch{return false;}
        }
    }
    internal sealed class ChosenFile {internal string File,Scope;}
    internal sealed class DropOption {internal string Id,File,Folder,Parent;internal int Count;}
    internal sealed class DropPick {public string id {get;set;} public string scope {get;set;}}
    internal sealed class DropConfirmation {public string token {get;set;} public DropPick[] choices {get;set;}}
    internal sealed class CardItem {
        public string Id {get;set;} public string Folder {get;set;} public string FileName {get;set;} public string Cover {get;set;} public string Source {get;set;} public string Scope {get;set;} public List<string> MergedFolders {get;set;}
        public string FolderName { get { string s=Folder.TrimEnd('\\','/'); string name=Path.GetFileName(s); return String.IsNullOrEmpty(name) ? Folder : name; } }
    }
    internal sealed class CardState { public int Version {get;set;} public List<CardItem> Cards {get;set;} }
    internal sealed partial class Controller {
        internal readonly string StateRoot;
        internal EverythingClient Client;
        internal List<CardItem> Cards;
        internal readonly SharedProfiles Shared;
        internal int LastMerged {get;private set;}
        internal Controller(string root,EverythingClient client,SharedProfiles shared=null) {
            StateRoot=root;Client=client;Shared=shared??SharedProfiles.Default();Directory.CreateDirectory(root);
            string path=Path.Combine(root,"cards.json");
            if(File.Exists(path)) {
                var data=new JavaScriptSerializer().Deserialize<CardState>(File.ReadAllText(path,Encoding.UTF8));
                if(data==null || data.Version!=1 || data.Cards==null || data.Cards.Any(c=>String.IsNullOrEmpty(c.Id)||String.IsNullOrEmpty(c.Folder)||!Path.IsPathRooted(c.Folder)||!Regex.IsMatch(c.Id,"^[a-f0-9]{32}$")||c.Cover!=c.Id+".png")) throw new InvalidDataException("卡片记录无法读取，已保留原文件，未改动 Everything。");
                Cards=data.Cards;
            } else Cards=new List<CardItem>();
        }
        internal EverythingClient Backend() { if(Client==null) Client=EverythingClient.Detect(StateRoot); return Client; }
        internal void Save() { Util.Atomic(Path.Combine(StateRoot,"cards.json"),new JavaScriptSerializer().Serialize(new CardState {Version=1,Cards=Cards})); }
        internal static string ParentOf(string folder) {
            string full=Util.Normalize(folder);if(Util.Same(full,Path.GetPathRoot(full)))return null;
            var parent=Directory.GetParent(full);return parent==null?null:Util.Normalize(parent.FullName);
        }
        internal int Add(string[] files) {return Add(files.Select(file=>new ChosenFile{File=file,Scope="directory"}));}
        internal int Add(IEnumerable<ChosenFile> files) {
            LastMerged=0;var candidates=new List<CardItem>();
            foreach(ChosenFile selected in files) {
                string file=selected.File;if(selected.Scope!="directory"&&selected.Scope!="parent")throw new InvalidDataException("请选择有效的屏蔽范围。");
                if(!File.Exists(file)) throw new FileNotFoundException("请拖入磁盘上存在的文件。");
                string folder=Util.Normalize(Path.GetDirectoryName(Path.GetFullPath(file)));
                if(selected.Scope=="parent"){folder=ParentOf(folder);if(folder==null)throw new InvalidDataException("所在目录已经是根目录，没有可选的上一级目录。");}
                if(candidates.Any(c=>Util.Same(c.Folder,folder)))continue;
                var previous=Cards.FirstOrDefault(c=>Util.Same(c.Folder,folder));if(previous!=null){candidates.Add(previous);continue;}
                string id=Guid.NewGuid().ToString("N");
                var card=new CardItem {Id=id,Folder=folder,FileName=Path.GetFileName(file),Cover=id+".png",Scope=selected.Scope};
                ShellPreview.Save(file,Path.Combine(StateRoot,card.Cover));
                candidates.Add(card);
            }
            return Commit(candidates);
        }
        internal int Import(SharedProfile profile) {
            LastMerged=0;var paths=SharedProfiles.Paths(profile.Paths);string author=SharedProfiles.AuthorName(profile.Author);var candidates=new List<CardItem>();
            foreach(string folder in paths) {
                var previous=Cards.FirstOrDefault(c=>Util.Same(c.Folder,folder));if(previous!=null){candidates.Add(previous);continue;}
                string id=Guid.NewGuid().ToString("N");var card=new CardItem{Id=id,Folder=folder,FileName="",Cover=id+".png",Source=author,Scope="shared"};
                ShellPreview.SaveFolder(Path.Combine(StateRoot,card.Cover));candidates.Add(card);
            }
            return Commit(candidates);
        }
        static CardItem Copy(CardItem card,List<string> merged) {
            return new CardItem{Id=card.Id,Folder=card.Folder,FileName=card.FileName,Cover=card.Cover,Source=card.Source,Scope=card.Scope,MergedFolders=merged.Count==0?null:merged};
        }
        void DeleteCachedCover(CardItem card) {
            try {string path=Path.Combine(StateRoot,card.Cover);if(File.Exists(path))File.Delete(path);}
            catch(IOException) {} catch(UnauthorizedAccessException) {}
        }
        int Commit(List<CardItem> candidates) {
            LastMerged=0;if(candidates.Count==0)return 0;
            var before=Cards.ToList();var fresh=candidates.Where(c=>!before.Any(old=>old.Id==c.Id)).ToList();bool keepRecoveryFiles=false;
            try {
                var current=Backend().Excluded();var possible=new List<CardItem>();
                foreach(var candidate in candidates) {
                    // An existing active plugin-owned ancestor already represents this request.
                    var owner=before.Where(c=>Util.Contains(c.Folder,candidate.Folder)&&current.Any(rule=>EverythingClient.SameLiteral(rule,c.Folder))).OrderBy(c=>Util.Normalize(c.Folder).Length).FirstOrDefault();
                    if(owner!=null)possible.Add(owner);
                    else if(before.Any(c=>c.Id==candidate.Id)||!current.Any(rule=>EverythingClient.SameLiteral(rule,candidate.Folder)))possible.Add(candidate);
                    // Never claim a literal path that was excluded outside this plugin.
                }
                var unique=possible.GroupBy(c=>Util.Normalize(c.Folder),StringComparer.OrdinalIgnoreCase).Select(group=>group.First()).ToList();
                var anchors=unique.Where(c=>!unique.Any(other=>Util.Contains(other.Folder,c.Folder,false))).ToList();
                if(anchors.Count==0)return 0;
                var redundant=before.Where(c=>anchors.Any(parent=>Util.Contains(parent.Folder,c.Folder,false))).ToList();
                var newAnchors=anchors.Where(c=>!before.Any(old=>old.Id==c.Id)).ToList();
                var absent=anchors.Where(c=>!current.Any(rule=>EverythingClient.SameLiteral(rule,c.Folder))).ToList();
                if(newAnchors.Count==0&&redundant.Count==0&&absent.Count==0)return 0;
                var removedRules=redundant.Select(c=>c.Folder).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
                var replacements=new Dictionary<string,CardItem>();
                foreach(var parent in anchors) {
                    var paths=new List<string>();if(parent.MergedFolders!=null)paths.AddRange(parent.MergedFolders);
                    foreach(var child in redundant.Where(c=>Util.Contains(parent.Folder,c.Folder,false))) {
                        paths.Add(child.Folder);if(child.MergedFolders!=null)paths.AddRange(child.MergedFolders);
                    }
                    paths=paths.Where(path=>Util.Contains(parent.Folder,path,false)).Select(Util.Normalize).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
                    replacements[parent.Id]=Copy(parent,paths);
                }
                var final=before.Where(c=>!redundant.Any(old=>old.Id==c.Id)).Select(c=>replacements.ContainsKey(c.Id)?replacements[c.Id]:c).ToList();
                final.AddRange(newAnchors.Select(c=>replacements[c.Id]));
                // Claim validation runs after Everything flushes its latest settings and exits.
                // Add the broad paths and remove owned descendants in one configuration transaction.
                var added=Backend().Change(anchors.Select(c=>c.Folder),removedRules,newAnchors.Select(c=>c.Folder));
                var actualRemoved=Backend().LastRemoved.ToArray();
                Cards=final;
                try {Save();}
                catch(Exception saveError) {
                    Cards=before;
                    try {Backend().Change(actualRemoved,added);}
                    catch(Exception recoveryError) {
                        keepRecoveryFiles=true;
                        throw new IOException("卡片保存失败，规则自动恢复也未完成；已保留原卡片和封面。恢复错误："+recoveryError.Message+"；原错误："+saveError.Message,recoveryError);
                    }
                    throw;
                }
                LastMerged=redundant.Count;
                foreach(var child in redundant)DeleteCachedCover(child);
                return newAnchors.Count;
            } finally {
                if(!keepRecoveryFiles)foreach(var unused in fresh.Where(c=>!Cards.Any(saved=>saved.Id==c.Id)))DeleteCachedCover(unused);
            }
        }
        internal void Remove(CardItem card) {
            if(!Cards.Any(c=>c.Id==card.Id)) return;
            bool exists=Backend().Excluded().Any(p=>EverythingClient.SameLiteral(p,card.Folder));
            if(exists) Backend().Change(new string[0],new[]{card.Folder});
            Cards.RemoveAll(c=>c.Id==card.Id);
            try { Save(); } catch { Cards.Add(card);if(exists) Backend().Change(new[]{card.Folder},new string[0]);throw; }
            string cover=Path.Combine(StateRoot,card.Cover);if(File.Exists(cover)) File.Delete(cover);
        }
    }

    internal sealed partial class MainForm : Form {
        const string Origin="https://everything-exclusions.local/";
        internal readonly Controller Model;
        internal readonly WebView2 Browser=new WebView2();
        internal readonly TaskCompletionSource<bool> Ready=new TaskCompletionSource<bool>();
        internal bool Busy; internal string LastError;
        string status="已准备好，等待拖入文件";bool statusError;
        bool pageReady,shareLoading,shareAvailable;
        string shareStatus="正在读取共享配置…";
        List<SharedProfile> sharedItems=new List<SharedProfile>();
        List<DropOption> pendingDrop;string pendingToken;
        [DllImport("user32.dll")] static extern bool ReleaseCapture();
        [DllImport("user32.dll")] static extern IntPtr SendMessage(IntPtr h,int message,IntPtr w,IntPtr l);
        internal MainForm(Controller model) {
            Model=model;Text="Everything 路径排除";ClientSize=new Size(1050,800);MinimumSize=new Size(460,330);
            StartPosition=FormStartPosition.CenterScreen;BackColor=Color.FromArgb(24,30,41);Padding=new Padding(5);
            FormBorderStyle=FormBorderStyle.None;AutoScaleMode=AutoScaleMode.Dpi;
            Browser.Dock=DockStyle.Fill;Browser.DefaultBackgroundColor=Color.FromArgb(12,15,21);Controls.Add(Browser);
            Shown+=async(s,e)=>await InitializeBrowser();
            FormClosing+=(s,e)=>{if(Busy){e.Cancel=true;SetStatus("正在应用规则，请稍候。",false);}};
        }
        // Give the HWND the standard Windows snap contract while keeping WinForms' own
        // client-size calculations borderless, matching WM_NCCALCSIZE below.
        [DllImport("user32.dll",EntryPoint="GetWindowLongPtrW")] static extern IntPtr GetWindowStyle(IntPtr window,int index);
        [DllImport("user32.dll",EntryPoint="SetWindowLongPtrW",SetLastError=true)] static extern IntPtr SetWindowStyle(IntPtr window,int index,IntPtr value);
        [DllImport("user32.dll",SetLastError=true)] static extern bool SetWindowPos(IntPtr window,IntPtr after,int x,int y,int width,int height,uint flags);
        protected override void OnHandleCreated(EventArgs e) {base.OnHandleCreated(e);ApplySnapStyles();}
        protected override void OnShown(EventArgs e) {base.OnShown(e);ApplySnapStyles();}
        void ApplySnapStyles() {
            long style=GetWindowStyle(Handle,-16).ToInt64();
            SetWindowStyle(Handle,-16,new IntPtr(style|0x00CF0000L));
            SetWindowPos(Handle,IntPtr.Zero,0,0,0,0,0x0037);
        }
        [DllImport("user32.dll")] static extern bool IsZoomed(IntPtr window);
        [StructLayout(LayoutKind.Sequential)] struct WindowStyleChange {public uint Old,New;}
        [StructLayout(LayoutKind.Sequential)] struct WindowRect {public int Left,Top,Right,Bottom;}
        [StructLayout(LayoutKind.Sequential)] struct WindowMinMax {
            public Point Reserved,MaxSize,MaxPosition,MinTrackSize,MaxTrackSize;
        }
        static IntPtr ScreenPoint(Point point) {
            return new IntPtr(unchecked((int)((uint)(ushort)point.X|((uint)(ushort)point.Y<<16))));
        }
        protected override void WndProc(ref Message m) {
            if(m.Msg==0x007C && m.WParam.ToInt64()==-16 && m.LParam!=IntPtr.Zero) {
                // WinForms can refresh native styles after handle creation; retain the shell contract.
                var change=(WindowStyleChange)Marshal.PtrToStructure(m.LParam,typeof(WindowStyleChange));
                change.New|=0x00CF0000u;Marshal.StructureToPtr(change,m.LParam,false);m.Result=IntPtr.Zero;return;
            }
            if(m.Msg==0x0083 && m.WParam!=IntPtr.Zero) {
                if(IsZoomed(m.HWnd)) {
                    // Windows keeps its invisible resize border outside a maximized window.
                    // Keep the visible client area inside the taskbar-aware working area.
                    var rect=(WindowRect)Marshal.PtrToStructure(m.LParam,typeof(WindowRect));
                    var work=Screen.FromRectangle(Rectangle.FromLTRB(rect.Left,rect.Top,rect.Right,rect.Bottom)).WorkingArea;
                    rect.Left=work.Left;rect.Top=work.Top;rect.Right=work.Right;rect.Bottom=work.Bottom;
                    Marshal.StructureToPtr(rect,m.LParam,false);
                }
                m.Result=IntPtr.Zero;return;
            }
            if(m.Msg==0x0024) {
                base.WndProc(ref m);
                if(m.LParam!=IntPtr.Zero) {
                    var bounds=Screen.FromHandle(m.HWnd);var work=bounds.WorkingArea;var monitor=bounds.Bounds;
                    var limits=(WindowMinMax)Marshal.PtrToStructure(m.LParam,typeof(WindowMinMax));
                    limits.MaxPosition=new Point(work.Left-monitor.Left,work.Top-monitor.Top);
                    limits.MaxSize=new Point(work.Width,work.Height);
                    Marshal.StructureToPtr(limits,m.LParam,false);m.Result=IntPtr.Zero;
                }
                return;
            }
            if(m.Msg==0x0084 && WindowState==FormWindowState.Normal) {
                Point p=PointToClient(new Point(unchecked((short)(m.LParam.ToInt64()&0xffff)),unchecked((short)((m.LParam.ToInt64()>>16)&0xffff))));int gap=7;
                bool left=p.X<gap,right=p.X>=ClientSize.Width-gap,top=p.Y<gap,bottom=p.Y>=ClientSize.Height-gap;
                int hit=left?(top?13:(bottom?16:10)):(right?(top?14:(bottom?17:11)):(top?12:(bottom?15:0)));
                if(hit!=0){m.Result=(IntPtr)hit;return;}
            }
            base.WndProc(ref m);
        }
        async Task InitializeBrowser() {
            try {
                string ui=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"ui");
                if(!File.Exists(Path.Combine(ui,"index.html")))throw new FileNotFoundException("界面文件缺失，请使用完整插件目录。");
                var env=await CoreWebView2Environment.CreateAsync(null,Path.Combine(Model.StateRoot,"webview"),null);
                await Browser.EnsureCoreWebView2Async(env);
                Browser.CoreWebView2.Settings.AreDefaultContextMenusEnabled=false;
                Browser.CoreWebView2.Settings.AreDevToolsEnabled=false;
                Browser.CoreWebView2.Settings.IsStatusBarEnabled=false;
                Browser.CoreWebView2.SetVirtualHostNameToFolderMapping("everything-exclusions.local",ui,CoreWebView2HostResourceAccessKind.DenyCors);
                Browser.CoreWebView2.NavigationStarting+=(s,e)=>{if(!e.Uri.StartsWith(Origin,StringComparison.OrdinalIgnoreCase))e.Cancel=true;};
                Browser.CoreWebView2.NewWindowRequested+=(s,e)=>{e.Handled=true;};
                Browser.CoreWebView2.WebMessageReceived+=async(s,e)=>{
                    if(!e.Source.StartsWith(Origin,StringComparison.OrdinalIgnoreCase))return;
                    try {
                        var message=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(e.WebMessageAsJson);
                        if(message==null||!message.ContainsKey("type"))return;
                        string type=Convert.ToString(message["type"]);
                        if(type=="ready") {pageReady=true;PushState();Ready.TrySetResult(true);await RefreshShared();}
                        else if(type=="drop") {
                            var paths=e.AdditionalObjects.OfType<CoreWebView2File>().Select(file=>file.Path).ToArray();
                            if(paths.Length>0)await DropFiles(paths);else SetStatus("未取得文件路径，请从 Everything 或资源管理器拖入文件。",true);
                        } else if(type=="remove" && message.ContainsKey("id")) {
                            string id=Convert.ToString(message["id"]);var card=Model.Cards.FirstOrDefault(item=>item.Id==id);
                            if(card!=null)await RemoveCard(card);
                        } else if(type=="promote" && message.ContainsKey("id"))PreparePromotion(Convert.ToString(message["id"]));
                        else if(type=="confirmPromotion" && message.ContainsKey("token"))await ConfirmPromotion(Convert.ToString(message["token"]));
                        else if(type=="cancelPromotion" && message.ContainsKey("token"))CancelPromotion(Convert.ToString(message["token"]));
                        else if(type=="confirmDrop")await ConfirmDrop(new JavaScriptSerializer().Deserialize<DropConfirmation>(e.WebMessageAsJson));
                        else if(type=="cancelDrop" && message.ContainsKey("token"))CancelDrop(Convert.ToString(message["token"]));
                        else if(type=="refreshProfiles")await RefreshShared();
                        else if(type=="uploadProfile" && message.ContainsKey("author"))await UploadProfile(Convert.ToString(message["author"]));
                        else if(type=="syncProfile" && message.ContainsKey("key"))await SyncProfile(Convert.ToString(message["key"]));
                        else if(type=="minimize")WindowState=FormWindowState.Minimized;
                        else if(type=="maximize")SendMessage(Handle,0x0112,(IntPtr)(WindowState==FormWindowState.Maximized?0xF120:0xF030),IntPtr.Zero);
                        else if(type=="close")Close();
                        else if(type=="dragWindow") {ReleaseCapture();SendMessage(Handle,0x00A1,(IntPtr)2,ScreenPoint(Cursor.Position));}
                    } catch(Exception error){LastError=error.ToString();SetStatus(error.Message,true);}
                };
                Browser.CoreWebView2.NavigationCompleted+=(s,e)=>{
                    if(!e.IsSuccess){var error=new IOException("界面加载失败："+e.WebErrorStatus);LastError=error.ToString();Ready.TrySetException(error);}
                };
                Browser.Source=new Uri(Origin+"index.html");
            } catch(Exception error) {
                LastError=error.ToString();Ready.TrySetException(error);
                var label=new Label {Dock=DockStyle.Fill,ForeColor=Color.FromArgb(235,179,115),BackColor=Color.FromArgb(12,15,21),Padding=new Padding(32),Text="界面启动失败\n\n"+error.Message};
                Controls.Add(label);label.BringToFront();
            }
        }
        void SetStatus(string value,bool error) {status=value;statusError=error;PushState();}
        void SetBusy(bool value) {Busy=value;PushState();}
        internal void PushState() {
            if(!pageReady||Browser.CoreWebView2==null)return;
            var cards=Model.Cards.Select(card=>{
                string file=Path.Combine(Model.StateRoot,card.Cover);
                return new {id=card.Id,title=card.FolderName,fileName=card.FileName,path=card.Folder,parent=Controller.ParentOf(card.Folder),source=card.Source,mergedCount=card.MergedFolders==null?0:card.MergedFolders.Count,mergedPaths=card.MergedFolders??new List<string>(),scope=card.Scope??(String.IsNullOrEmpty(card.Source)?"directory":"shared"),cover=File.Exists(file)?"data:image/png;base64,"+Convert.ToBase64String(File.ReadAllBytes(file)):""};
            }).ToArray();
            Browser.CoreWebView2.PostWebMessageAsJson(new JavaScriptSerializer {MaxJsonLength=Int32.MaxValue}.Serialize(new {type="state",cards=cards,busy=Busy,status=status,error=statusError,profiles=sharedItems.Select(p=>new{key=p.Key,author=p.Author,count=p.Paths.Count,updated=p.UpdatedUtc}).ToArray(),shareLoading=shareLoading,shareAvailable=shareAvailable,shareStatus=shareStatus}));
        }
        internal async Task RefreshShared() {
            if(shareLoading)return;shareLoading=true;PushState();
            try {var catalog=await Task.Run(()=>Model.Shared.List());sharedItems=catalog.Profiles;shareAvailable=true;shareStatus=catalog.Invalid>0?"有 "+catalog.Invalid+" 份配置无法读取，已跳过。":(sharedItems.Count==0?"还没有共享配置，上传后会出现在这里。":"同步会添加目录，并保留你已有的屏蔽项。");}
            catch(Exception error){shareAvailable=false;shareStatus=error.Message;sharedItems.Clear();}
            finally{shareLoading=false;PushState();}
        }
        internal async Task UploadProfile(string author) {
            if(Busy)return;LastError=null;SetBusy(true);SetStatus("正在上传屏蔽目录…",false);
            try {
                var paths=Model.Cards.Select(c=>c.Folder).ToArray();var result=await Task.Run(()=>Model.Shared.Upload(author,paths));
                SetStatus((result.Created?"已创建":"已更新")+"「"+result.Profile.Author+"」：新增 "+result.Added+" 个目录，共 "+result.Profile.Paths.Count+" 个。",false);
                Browser.CoreWebView2.PostWebMessageAsJson("{\"type\":\"uploadResult\",\"ok\":true}");await RefreshShared();
            } catch(Exception error){LastError=error.ToString();SetStatus(error.Message,true);Browser.CoreWebView2.PostWebMessageAsJson(new JavaScriptSerializer().Serialize(new{type="uploadResult",ok=false,error=error.Message}));}
            finally{SetBusy(false);}
        }
        internal async Task SyncProfile(string key) {
            if(Busy)return;LastError=null;SetBusy(true);SetStatus("正在同步屏蔽目录，Everything 将重新加载…",false);
            try {var result=await Task.Run(()=>{var profile=Model.Shared.Read(key);int count=Model.Import(profile);return new{author=profile.Author,count=count,merged=Model.LastMerged};});shareStatus="已同步「"+result.author+"」，新增 "+result.count+" 个屏蔽目录"+(result.merged>0?"，合并 "+result.merged+" 张下级卡片":"")+"。";SetStatus(shareStatus,false);}
            catch(Exception error){LastError=error.ToString();SetStatus(error.Message,true);}
            finally{SetBusy(false);Activate();}
        }
        internal Task DropFiles(string[] files) {
            if(Busy)return Task.FromResult(false);LastError=null;
            try {
                if(pendingDrop!=null || pendingPromotion!=null)throw new InvalidOperationException("请先确认或取消当前的屏蔽范围选择。");
                var groups=new List<DropOption>();
                foreach(string input in files) {
                    if(!File.Exists(input))throw new FileNotFoundException("请拖入磁盘上存在的文件。");
                    string file=Path.GetFullPath(input),folder=Util.Normalize(Path.GetDirectoryName(file));
                    var found=groups.FirstOrDefault(option=>Util.Same(option.Folder,folder));
                    if(found!=null){found.Count++;continue;}
                    groups.Add(new DropOption{Id=Guid.NewGuid().ToString("N"),File=file,Folder=folder,Parent=Controller.ParentOf(folder),Count=1});
                }
                if(groups.Count==0)return Task.FromResult(false);
                pendingDrop=groups;pendingToken=Guid.NewGuid().ToString("N");
                SetStatus("请选择屏蔽所在目录，或所在目录的上一级；确认后生效。",false);
                Browser.CoreWebView2.PostWebMessageAsJson(new JavaScriptSerializer{MaxJsonLength=Int32.MaxValue}.Serialize(new{type="dropChoice",token=pendingToken,items=groups.Select(o=>new{id=o.Id,fileName=Path.GetFileName(o.File),folder=o.Folder,parent=o.Parent,count=o.Count}).ToArray()}));
            } catch(Exception error){LastError=error.ToString();SetStatus(error.Message,true);}
            return Task.FromResult(true);
        }
        internal void CancelDrop(string token) {
            if(Busy||pendingDrop==null||token!=pendingToken)return;
            pendingDrop=null;pendingToken=null;SetStatus("已取消，未添加屏蔽目录。",false);
        }
        internal async Task ConfirmDrop(DropConfirmation request) {
            if(Busy)return;LastError=null;
            try {
                if(pendingDrop==null||request==null||request.token!=pendingToken||request.choices==null||request.choices.Length!=pendingDrop.Count||request.choices.Any(c=>c==null)||request.choices.Select(c=>c.id).Distinct().Count()!=pendingDrop.Count)throw new InvalidDataException("屏蔽范围选择已失效，请重新拖入文件。");
                var selected=new List<ChosenFile>();
                foreach(var choice in request.choices) {
                    var option=pendingDrop.FirstOrDefault(o=>o.Id==choice.id);
                    if(option==null||(choice.scope!="directory"&&choice.scope!="parent")||(choice.scope=="parent"&&option.Parent==null))throw new InvalidDataException("请选择有效的屏蔽范围。");
                    selected.Add(new ChosenFile{File=option.File,Scope=choice.scope});
                }
                SetBusy(true);SetStatus("正在添加屏蔽目录，Everything 将重新加载…",false);
                int count=await Task.Run(()=>Model.Add(selected));pendingDrop=null;pendingToken=null;
                SetStatus(count>0?"已屏蔽 "+count+" 个目录"+(Model.LastMerged>0?"，合并 "+Model.LastMerged+" 张下级卡片":"")+"。":(Model.LastMerged>0?"已合并 "+Model.LastMerged+" 张下级卡片，保留上级屏蔽范围。":"所选目录已被现有屏蔽范围覆盖，或已在 Everything 原有排除列表中。"),false);
                Browser.CoreWebView2.PostWebMessageAsJson("{\"type\":\"dropResult\",\"ok\":true}");
            } catch(Exception error){LastError=error.ToString();SetStatus(error.Message,true);Browser.CoreWebView2.PostWebMessageAsJson(new JavaScriptSerializer().Serialize(new{type="dropResult",ok=false,error=error.Message}));}
            finally{SetBusy(false);Activate();}
        }
        internal async Task RemoveCard(CardItem card) {
            if(Busy)return;LastError=null;SetBusy(true);SetStatus("正在撤销排除，Everything 将重新加载…",false);
            try {await Task.Run(()=>Model.Remove(card));SetStatus("已撤销「"+card.FolderName+"」的排除，索引刷新后可重新搜索。",false);}
            catch(Exception error){LastError=error.ToString();SetStatus(error.Message,true);}
            finally{SetBusy(false);Activate();}
        }
        internal Task<string> Evaluate(string script) {return Browser.CoreWebView2.ExecuteScriptAsync(script);}
        internal async Task CapturePreview(string path) {
            using(var stream=File.Create(path))await Browser.CoreWebView2.CapturePreviewAsync(CoreWebView2CapturePreviewImageFormat.Png,stream);
        }
    }
}
