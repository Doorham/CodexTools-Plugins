using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EverythingExclusions {
    // Owned by the WinForms UI thread. FIFO covers the complete operation,
    // including worker tasks, rollback and the subsequent UI state update.
    internal sealed class OperationQueue {
        sealed class Item {
            internal string Key;
            internal Func<Task> Action;
            internal Func<string[],Func<string[]>,Task> RemovalAction;
            internal readonly TaskCompletionSource<bool> Completion=new TaskCompletionSource<bool>();
        }
        readonly int owner=Thread.CurrentThread.ManagedThreadId;
        readonly SynchronizationContext context=new WindowsFormsSynchronizationContext();
        readonly Queue<Item> waiting=new Queue<Item>();
        readonly Dictionary<string,Item> pending=new Dictionary<string,Item>();
        bool running;
        List<Item> activeRemovals;
        bool removalsFrozen;
        internal Action Changed;
        internal int WaitingCount {get{return waiting.Count;}}
        internal int ActiveRemovalCount {get{return activeRemovals==null?0:activeRemovals.Count;}}
        internal bool IsBusy {get{return pending.Count>0;}}
        internal string[] Keys {get{return pending.Keys.ToArray();}}
        void VerifyOwner() {
            if(Thread.CurrentThread.ManagedThreadId!=owner)throw new InvalidOperationException("操作必须从界面线程入队。");
        }
        internal Task<bool> Enqueue(string key,Func<Task> action) {
            return Add(new Item{Key=key,Action=action});
        }
        internal Task<bool> EnqueueRemoval(string key,Func<string[],Func<string[]>,Task> action) {
            if(String.IsNullOrEmpty(key)||!key.StartsWith("remove:",StringComparison.Ordinal)||key.Length==7)
                throw new ArgumentException("清除操作缺少卡片标识。");
            return Add(new Item{Key=key,RemovalAction=action});
        }
        Task<bool> Add(Item item) {
            VerifyOwner();
            Item existing;
            if(pending.TryGetValue(item.Key,out existing))return existing.Completion.Task;
            if(pending.Count>=64)throw new InvalidOperationException("等待操作过多，请等当前队列完成后再操作。");
            pending.Add(item.Key,item);waiting.Enqueue(item);
            if(Changed!=null)Changed();
            if(!running){running=true;StartNext();}
            return item.Completion.Task;
        }
        void CollectRemovals() {
            // Only adjacent removals belong to this transaction. Other operation
            // types are an ordering boundary, including confirmations and sync.
            while(waiting.Count>0&&waiting.Peek().RemovalAction!=null)activeRemovals.Add(waiting.Dequeue());
        }
        string[] RemovalIds() {return activeRemovals.Select(item=>item.Key.Substring(7)).ToArray();}
        string[] FreezeRemovals() {
            VerifyOwner();
            if(activeRemovals==null)throw new InvalidOperationException("当前没有可合并的清除任务。");
            if(!removalsFrozen){CollectRemovals();removalsFrozen=true;if(Changed!=null)Changed();}
            return RemovalIds();
        }
        // A failed/cancelled write must not launch more exit prompts for queued writes.
        internal int CancelWaiting() {
            VerifyOwner();int count=waiting.Count;
            while(waiting.Count>0) {
                var item=waiting.Dequeue();pending.Remove(item.Key);item.Completion.TrySetResult(false);
            }
            if(Changed!=null)Changed();
            return count;
        }
        void StartNext() {
            VerifyOwner();
            if(waiting.Count==0){running=false;return;}
            var item=waiting.Dequeue();Task operation;
            if(item.RemovalAction!=null){activeRemovals=new List<Item>{item};removalsFrozen=false;CollectRemovals();}
            if(Changed!=null)Changed();
            var previous=SynchronizationContext.Current;
            try {
                // WebView and synthetic messages need an explicit UI context:
                // an ambient context is not guaranteed by every event source.
                SynchronizationContext.SetSynchronizationContext(context);
                operation=item.RemovalAction==null?item.Action():item.RemovalAction(RemovalIds(),FreezeRemovals);
            } catch(Exception error) {
                var failed=new TaskCompletionSource<bool>();failed.SetException(error);operation=failed.Task;
            } finally {SynchronizationContext.SetSynchronizationContext(previous);}
            if(operation.IsCompleted)Complete(item,operation);
            else operation.ContinueWith(done=>context.Post(_=>Complete(item,done),null),
                CancellationToken.None,TaskContinuationOptions.ExecuteSynchronously,TaskScheduler.Default);
        }
        void Complete(Item item,Task operation) {
            VerifyOwner();
            var completed=item.RemovalAction==null?new[]{item}:activeRemovals.ToArray();
            foreach(var member in completed)pending.Remove(member.Key);
            activeRemovals=null;removalsFrozen=false;
            if(Changed!=null)Changed();
            foreach(var member in completed) {
                if(operation.IsCanceled)member.Completion.TrySetCanceled();
                else if(operation.IsFaulted)member.Completion.TrySetException(operation.Exception.InnerExceptions);
                else member.Completion.TrySetResult(true);
            }
            StartNext();
        }
    }

    internal sealed partial class MainForm {
        internal readonly OperationQueue Operations=new OperationQueue();
        object displayedCards;
        static bool QueuedMessage(string type) {
            return type=="remove" || type=="drop" || type=="promote" || type=="confirmPromotion" ||
                type=="confirmDrop" || type=="uploadProfile" || type=="syncProfile";
        }
        internal Task<bool> QueueMessage(string type,Dictionary<string,object> message,string[] files=null) {
            string value="";
            foreach(string field in new[]{"id","token","key","author"})
                if(message.ContainsKey(field)){value=Convert.ToString(message[field]);break;}
            string key=type+":"+(type=="drop"?Guid.NewGuid().ToString("N"):value);
            if(type=="remove"&&message.ContainsKey("id"))return Operations.EnqueueRemoval(key,async(initial,freeze)=>{
                LastError=null;
                try {await RemoveCards(initial,freeze);}
                catch(Exception error){LastError=error.ToString();SetStatus(error.Message,true);}
                CancelAfterError();
            });
            return Operations.Enqueue(key,async()=>{
                LastError=null;
                try {
                    // Resolve card IDs and confirmation tokens when their turn starts,
                    // after any earlier removal/promotion has committed or rolled back.
                    if(type=="drop") {
                        if(files!=null && files.Length>0)await DropFiles(files);
                        else SetStatus("未取得文件路径，请从 Everything 或资源管理器拖入文件。",true);
                    } else if(type=="promote")PreparePromotion(value);
                    else if(type=="confirmPromotion")await ConfirmPromotion(value);
                    else if(type=="confirmDrop")await ConfirmDrop(new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<DropConfirmation>(
                        new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(message)));
                    else if(type=="uploadProfile")await UploadProfile(value);
                    else if(type=="syncProfile")await SyncProfile(value);
                } catch(Exception error){LastError=error.ToString();SetStatus(error.Message,true);}
                CancelAfterError();
            });
        }
        void CancelAfterError() {
            if(LastError==null)return;
            int cancelled=Operations.CancelWaiting();
            if(cancelled>0)SetStatus(status+" 后续 "+cancelled+" 项操作已取消，请处理后重试。",true);
        }
    }
}
