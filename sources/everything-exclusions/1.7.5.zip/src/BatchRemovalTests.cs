using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EverythingExclusions {
 internal static partial class Tests {
  static void BatchQueueUnitChecks() {
   var queue=new OperationQueue();var hold=new TaskCompletionSource<bool>();var finished=new TaskCompletionSource<bool>();
   string[] initial=null,frozen=null;int actions=0,owner=Thread.CurrentThread.ManagedThreadId;bool sameThread=true;
   Func<string[],Func<string[]>,Task> delayed=async (ids,freeze)=>{
    actions++;initial=ids;await hold.Task;sameThread&=Thread.CurrentThread.ManagedThreadId==owner;
    frozen=freeze();await finished.Task;sameThread&=Thread.CurrentThread.ManagedThreadId==owner;
   };
   var a=queue.EnqueueRemoval("remove:a",delayed);
   var b=queue.EnqueueRemoval("remove:b",delayed);
   var duplicate=queue.EnqueueRemoval("remove:b",delayed);
   var c=queue.EnqueueRemoval("remove:c",delayed);
   Check("batch_queue_accepts_later_removes_during_active_wait",initial.SequenceEqual(new[]{"a"})&&queue.WaitingCount==2&&queue.Keys.Length==3);
   Check("batch_queue_duplicate_waiting_remove_keeps_one_completion",Object.ReferenceEquals(b,duplicate));
   hold.SetResult(true);WaitBatchCondition(()=>frozen!=null,"Queue did not freeze its batch");
   Check("batch_queue_freeze_absorbs_contiguous_later_removes",frozen.SequenceEqual(new[]{"a","b","c"})&&queue.WaitingCount==0&&queue.ActiveRemovalCount==3);
   var activeDuplicate=queue.EnqueueRemoval("remove:b",delayed);
   Check("batch_queue_keeps_all_active_keys_until_commit",Object.ReferenceEquals(activeDuplicate,b)&&queue.Keys.OrderBy(value=>value).SequenceEqual(new[]{"remove:a","remove:b","remove:c"})&&!a.IsCompleted&&!b.IsCompleted&&!c.IsCompleted);
   finished.SetResult(true);Pump(Task.WhenAll(a,b,c));
   Check("batch_queue_one_action_completes_every_absorbed_request",actions==1&&a.Result&&b.Result&&c.Result&&!queue.IsBusy&&queue.ActiveRemovalCount==0&&sameThread);

   queue=new OperationQueue();var afterFreeze=new TaskCompletionSource<bool>();var snapshots=new List<string[]>();
   Func<string[],Func<string[]>,Task> after=async (ids,freeze)=>{snapshots.Add(freeze());if(snapshots.Count==1)await afterFreeze.Task;};
   a=queue.EnqueueRemoval("remove:frozen-a",after);
   b=queue.EnqueueRemoval("remove:next-b",after);
   Check("batch_queue_after_freeze_request_waits_for_next_transaction",snapshots.Count==1&&snapshots[0].SequenceEqual(new[]{"frozen-a"})&&queue.WaitingCount==1&&!b.IsCompleted);
   afterFreeze.SetResult(true);Pump(Task.WhenAll(a,b));
   Check("batch_queue_after_freeze_request_is_next_batch",snapshots.Count==2&&snapshots[1].SequenceEqual(new[]{"next-b"})&&!queue.IsBusy);

   queue=new OperationQueue();hold=new TaskCompletionSource<bool>();var trace=new List<string>();
   var blocker=queue.Enqueue("generic:hold",()=>hold.Task);
   Func<string[],Func<string[]>,Task> record=(ids,freeze)=>{trace.Add("remove:"+String.Join(",",freeze()));return Task.FromResult(true);};
   a=queue.EnqueueRemoval("remove:a",record);b=queue.EnqueueRemoval("remove:b",record);
   var barrier=queue.Enqueue("generic:barrier",()=>{trace.Add("barrier");return Task.FromResult(true);});
   c=queue.EnqueueRemoval("remove:c",record);var d=queue.EnqueueRemoval("remove:d",record);
   hold.SetResult(true);Pump(Task.WhenAll(blocker,a,b,barrier,c,d));
   Check("batch_queue_initial_waiters_coalesce_without_crossing_fifo_barrier",trace.SequenceEqual(new[]{"remove:a,b","barrier","remove:c,d"}));

   queue=new OperationQueue();hold=new TaskCompletionSource<bool>();finished=new TaskCompletionSource<bool>();trace.Clear();
   Func<string[],Func<string[]>,Task> waitForBoundary=async (ids,freeze)=>{await hold.Task;trace.Add("remove:"+String.Join(",",freeze()));await finished.Task;};
   a=queue.EnqueueRemoval("remove:a",waitForBoundary);b=queue.EnqueueRemoval("remove:b",waitForBoundary);
   barrier=queue.Enqueue("generic:barrier",()=>{trace.Add("barrier");return Task.FromResult(true);});
   c=queue.EnqueueRemoval("remove:c",record);
   hold.SetResult(true);WaitBatchCondition(()=>trace.Count==1,"Active batch did not freeze before barrier");
   Check("batch_queue_late_waiters_stop_at_intervening_operation",trace[0]=="remove:a,b"&&queue.WaitingCount==2&&queue.ActiveRemovalCount==2);
   finished.SetResult(true);Pump(Task.WhenAll(a,b,barrier,c));
   Check("batch_queue_fifo_order_survives_late_batch_collection",trace.SequenceEqual(new[]{"remove:a,b","barrier","remove:c"}));

   queue=new OperationQueue();hold=new TaskCompletionSource<bool>();blocker=queue.Enqueue("hold-failure",()=>hold.Task);
   Func<string[],Func<string[]>,Task> fail=(ids,freeze)=>{freeze();throw new IOException("Synthetic batch write failure");};
   a=queue.EnqueueRemoval("remove:a",fail);b=queue.EnqueueRemoval("remove:b",fail);
   hold.SetResult(true);Pump(blocker);bool threw=false;
   try{Pump(Task.WhenAll(a,b));}catch(IOException){threw=true;}
   Check("batch_queue_fault_settles_all_absorbed_completions",threw&&a.IsFaulted&&b.IsFaulted&&!queue.IsBusy&&queue.Keys.Length==0);

   queue=new OperationQueue();hold=new TaskCompletionSource<bool>();blocker=queue.Enqueue("hold-limit",()=>hold.Task);
   var pending=new List<Task<bool>>();for(int i=0;i<63;i++)pending.Add(queue.EnqueueRemoval("remove:limit-"+i,record));
   bool limited=false;try{queue.EnqueueRemoval("remove:overflow",record);}catch(InvalidOperationException){limited=true;}
   Check("batch_queue_keeps_accepted_request_limit_before_collection",limited&&queue.Keys.Length==64&&queue.WaitingCount==63);
   queue.CancelWaiting();hold.SetResult(true);Pump(blocker);Pump(Task.WhenAll(pending));
   Check("batch_queue_cancelled_waiters_do_not_leave_pending_keys",pending.All(task=>!task.Result)&&!queue.IsBusy&&queue.ActiveRemovalCount==0);
  }

  static void WaitBatchCondition(Func<bool> ready,string message) {
   var timer=Stopwatch.StartNew();
   while(!ready()){Application.DoEvents();Thread.Sleep(10);if(timer.ElapsedMilliseconds>10000)throw new TimeoutException(message);}
  }

  static void BatchRemovalChecks(string root,MainForm form,Controller model,string es,string instance,string data) {
   var client=model.Backend();string boundary=Path.GetFullPath(root).TrimEnd('\\','/')+Path.DirectorySeparatorChar;
   if(String.IsNullOrEmpty(instance)||client.Instance!=instance||!Path.GetFullPath(client.Config).StartsWith(boundary,StringComparison.OrdinalIgnoreCase)||!Path.GetFullPath(model.StateRoot).StartsWith(boundary,StringComparison.OrdinalIgnoreCase))throw new Exception("Batch checks require the isolated named Everything fixture.");
   ClearMergeCards(form,model);
   string parent=Path.Combine(data,"batch-removal-fixture");
   string fileA=MergeFile(Path.Combine(parent,"a"),"batch-removal-a.txt"),fileB=MergeFile(Path.Combine(parent,"b"),"batch-removal-b.txt"),fileC=MergeFile(Path.Combine(parent,"c"),"batch-removal-c.txt");
   Pump(Drop(form,new[]{fileA,fileB,fileC}));
   string idA=model.Cards.Single(card=>Util.Same(card.Folder,Path.GetDirectoryName(fileA))).Id,idB=model.Cards.Single(card=>Util.Same(card.Folder,Path.GetDirectoryName(fileB))).Id;
   int reload=client.ReloadCount;var previousProgress=model.ExitProgress;
   using(var entered=new ManualResetEvent(false))using(var target=Process.GetProcessById(client.RunningPid())) {
    bool resumed=false;
    Check("batch_exit_wait_fixture_process_suspended",NtSuspendProcess(target.Handle)==0);
    model.ExitProgress=message=>{entered.Set();if(previousProgress!=null)previousProgress(message);};
    try {
     var first=form.QueueMessage("remove",new Dictionary<string,object>{{"id",idA}});
     WaitBatchCondition(()=>entered.WaitOne(0),"Batch did not reach Everything exit wait");
     var second=form.QueueMessage("remove",new Dictionary<string,object>{{"id",idB}});
     Check("batch_actual_exit_wait_accepts_second_remove",!first.IsCompleted&&!second.IsCompleted&&model.Cards.Count==3&&form.Operations.Keys.Contains("remove:"+idB));
     Check("batch_exit_wait_fixture_process_resumed",NtResumeProcess(target.Handle)==0);resumed=true;Pump(Task.WhenAll(first,second));
     WaitDom(form,"!currentState.busy && currentState.cards.length===1");
     Check("batch_actual_exit_wait_removes_both_with_one_reload",form.LastError==null&&client.ReloadCount==reload+1&&model.Cards.Count==1&&Util.Same(model.Cards[0].Folder,Path.GetDirectoryName(fileC)));
     WaitCount(es,instance,"batch-removal-a",1);WaitCount(es,instance,"batch-removal-b",1);WaitCount(es,instance,"batch-removal-c",0);
     Check("batch_actual_exit_wait_updates_all_requested_rules",true);
    } finally {if(!resumed&&!target.HasExited)NtResumeProcess(target.Handle);model.ExitProgress=previousProgress;client.ExitProgress=previousProgress;}
   }

   ClearMergeCards(form,model);Pump(Drop(form,new[]{fileA,fileB,fileC}));
   var before=model.Cards.ToArray();
   // Simulate an external removal before the batch: rollback must not recreate it.
   client.Change(new string[0],new[]{before[1].Folder});
   string stateFile=Path.Combine(model.StateRoot,"cards.json"),stateHash=Hash(stateFile);var rules=MergeRules(client);
   var coverHashes=before.ToDictionary(card=>card.Cover,card=>Hash(Path.Combine(model.StateRoot,card.Cover)));
   string[] ids=before.Take(2).Select(card=>card.Id).ToArray();bool failed=false;
   using(var heldState=new FileStream(stateFile,FileMode.Open,FileAccess.Read,FileShare.Read)) {
    try{Pump(Task.Run(()=>model.RemoveBatch(ids)));}catch(IOException){failed=true;}catch(UnauthorizedAccessException){failed=true;}
   }
   Check("batch_state_save_failure_restores_all_cards_in_original_order",failed&&model.Cards.SequenceEqual(before)&&Hash(stateFile)==stateHash);
   Check("batch_state_save_failure_restores_all_removed_rules",MergeRules(client).SequenceEqual(rules));
   Check("batch_rollback_does_not_recreate_previously_absent_rule",!HasMergeRule(client,before[1].Folder));
   Check("batch_state_save_failure_keeps_every_original_cover",coverHashes.All(pair=>File.Exists(Path.Combine(model.StateRoot,pair.Key))&&Hash(Path.Combine(model.StateRoot,pair.Key))==pair.Value));
   reload=client.ReloadCount;
   Pump(Task.Run(()=>model.RemoveBatch(new[]{ids[0],ids[0],ids[1],new string('f',32)})));
   Check("batch_retry_deduplicates_ids_and_reloads_once",model.Cards.Count==1&&client.ReloadCount==reload+1&&model.Cards[0].Id==before[2].Id);
   Check("batch_success_cleans_only_committed_cover_files",!File.Exists(Path.Combine(model.StateRoot,before[0].Cover))&&!File.Exists(Path.Combine(model.StateRoot,before[1].Cover))&&File.Exists(Path.Combine(model.StateRoot,before[2].Cover)));
   reload=client.ReloadCount;stateHash=Hash(stateFile);
   Pump(Task.Run(()=>model.RemoveBatch(new[]{ids[0],ids[1],new string('f',32)})));
   Check("batch_stale_ids_are_noop_without_reload_or_state_write",client.ReloadCount==reload&&Hash(stateFile)==stateHash&&model.Cards.Count==1);
   Pump(Task.Run(()=>model.Add(new[]{fileA})));CardItem late=model.Cards.Single(card=>Util.Same(card.Folder,Path.GetDirectoryName(fileA)));reload=client.ReloadCount;int freezes=0;
   Pump(Task.Run(()=>model.RemoveBatch(new[]{new string('f',32)},()=>{freezes++;return new[]{late.Id};})));
   Check("batch_stale_initial_id_still_accepts_valid_id_at_freeze",freezes==1&&model.Cards.Count==1&&client.ReloadCount==reload+1&&!model.Cards.Any(card=>card.Id==late.Id));
   CardItem last=model.Cards.Single();string lockedCover=Path.Combine(model.StateRoot,last.Cover);reload=client.ReloadCount;
   using(var heldCover=new FileStream(lockedCover,FileMode.Open,FileAccess.Read,FileShare.Read))Pump(Task.Run(()=>model.RemoveBatch(new[]{last.Id})));
   Check("batch_locked_cache_cleanup_does_not_fail_committed_removal",model.Cards.Count==0&&client.ReloadCount==reload+1&&!HasMergeRule(client,last.Folder)&&File.Exists(lockedCover));
   if(!Path.GetFullPath(lockedCover).StartsWith(boundary,StringComparison.OrdinalIgnoreCase))throw new Exception("Batch fixture cleanup escaped its boundary.");
   File.Delete(lockedCover);
   ClearMergeCards(form,model);
  }
 }
}
