using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace EverythingExclusions {
    internal sealed partial class Controller {
        // Card IDs are re-resolved at the transaction boundary. The callback
        // closes a single queue batch; it is never stored on the shared client.
        internal int RemoveBatch(string[] initialIds,Func<string[]> freezeIds=null) {
            var before=Cards.ToList();
            var initial=new HashSet<string>(initialIds??new string[0],StringComparer.Ordinal);
            var targets=before.Where(card=>initial.Contains(card.Id)).ToList();
            bool frozen=false;
            Action freeze=()=>{
                if(frozen)return;
                frozen=true;
                var ids=new HashSet<string>(freezeIds==null?initial:(IEnumerable<string>)(freezeIds()??new string[0]),StringComparer.Ordinal);
                targets=before.Where(card=>ids.Contains(card.Id)).ToList();
            };

            // A stale first ID need not open or stop Everything. Still let the
            // queue close this batch and supply any valid following IDs.
            if(targets.Count==0)freeze();
            if(targets.Count==0)return 0;
            var backend=Backend();
            var current=backend.Excluded();
            bool needsChange=targets.Any(card=>current.Any(rule=>EverythingClient.SameLiteral(rule,card.Folder)));
            var actuallyRemoved=new string[0];
            if(needsChange&&!frozen) {
                backend.Change(new string[0],targets.Select(card=>card.Folder),null,()=>{
                    freeze();return targets.Select(card=>card.Folder).ToArray();
                });
                actuallyRemoved=backend.LastRemoved.ToArray();
            } else {
                freeze();
                if(targets.Count==0)return 0;
                // Nothing initially required a settings write, but IDs taken
                // while closing the batch may name an existing owned rule.
                if(targets.Any(card=>current.Any(rule=>EverythingClient.SameLiteral(rule,card.Folder)))) {
                    backend.Change(new string[0],targets.Select(card=>card.Folder));
                    actuallyRemoved=backend.LastRemoved.ToArray();
                }
            }
            if(targets.Count==0)return 0;
            var removedIds=new HashSet<string>(targets.Select(card=>card.Id),StringComparer.Ordinal);
            Cards=before.Where(card=>!removedIds.Contains(card.Id)).ToList();
            try {Save();}
            catch(Exception saveError) {
                Cards=before;
                try {
                    // Restore only literal rules actually removed from the
                    // latest flushed settings, not every requested folder.
                    if(actuallyRemoved.Length>0)backend.Change(actuallyRemoved,new string[0]);
                } catch(Exception recoveryError) {
                    throw new IOException("批量撤销未完成，规则自动恢复也未完成；原卡片和缩略图已保留。恢复错误："+recoveryError.Message+"；原错误："+saveError.Message,recoveryError);
                }
                throw;
            }
            // Cached images are disposable only after the complete batch is
            // persisted. A locked image cannot turn a committed batch into an error.
            foreach(var card in targets)DeleteCachedCover(card);
            return targets.Count;
        }
    }

    internal sealed partial class MainForm {
        internal async Task RemoveCards(string[] initialIds,Func<string[]> freezeIds) {
            if(Busy)return;
            LastError=null;SetBusy(true);SetStatus("正在批量撤销排除，等待期间可继续选择其他目录…",false);
            try {
                Func<string[]> freezeOnUi=freezeIds==null?(Func<string[]>)null:()=>{
                    if(InvokeRequired)return (string[])Invoke(freezeIds);
                    return freezeIds();
                };
                int count=await Task.Run(()=>Model.RemoveBatch(initialIds,freezeOnUi));
                SetStatus(count>0?"已批量撤销 "+count+" 个目录的排除，索引刷新后可重新搜索。":"所选目录已处理，无需重复撤销。",false);
            } catch(Exception error) {
                LastError=error.ToString();
                int count=Operations.ActiveRemovalCount>0?Operations.ActiveRemovalCount:(initialIds??new string[0]).Distinct().Count();
                SetStatus("本批 "+count+" 项清除未完成。"+error.Message,true);
            }
            finally{SetBusy(false);Activate();}
        }
    }
}
