# Everything 路径排除公共插件维护

公共组件 ID everything-exclusions，开发者 Doorham。只使用已有 process_app/支持文件协议，插件更新不升级客户端。每轮改动写本目录 DEVLOG.md，并对齐 plugin.json、程序资源版本和 CHANGELOG，不把功能日志抄进客户端日志。

源码在 src，界面在 ui，Build.ps1 只输出到指定 artifacts。公共包严格按清单只取程序、UI、依赖及文档，不复制安装目录 state、缓存、用户配置或凭证。运行程序和本机状态在固定 EverythingExclusions 目录，不能改成下载插件目录中的 state。

旧开发目录与 private- ID 仅作升级兼容；原位读取旧卡片，不迁移、删除或上传真实数据。发布后保留插件独立版本与校验记录，禁止每新增卡片都要求重新发布客户端。
