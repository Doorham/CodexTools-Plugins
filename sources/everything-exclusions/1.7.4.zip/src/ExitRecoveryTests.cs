using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

namespace EverythingExclusions {
    internal static partial class Tests {
        [DllImport("ntdll.dll")]static extern int NtSuspendProcess(IntPtr handle);
        [DllImport("ntdll.dll")]static extern int NtResumeProcess(IntPtr handle);
        static void ExitRecoveryChecks(string root,MainForm form,Controller model,string es,string instance,string data) {
            var client=model.Backend();
            string parent=Path.Combine(data,"exit-recovery");
            string first=MergeFile(Path.Combine(parent,"a"),"exit-recovery-a.txt"),second=MergeFile(Path.Combine(parent,"b"),"exit-recovery-b.txt");
            Pump(Drop(form,new[]{first,second}));
            var card=model.Cards.Single(c=>Util.Same(c.Folder,Path.GetDirectoryName(first)));
            var plan=model.PlanPromotion(card.Id);
            string state=Hash(Path.Combine(model.StateRoot,"cards.json")),config=Hash(client.Config);
            var covers=MergeCovers(model);int oldPid=client.RunningPid();
            var processIds=Process.GetProcessesByName("Everything").Select(p=>p.Id).OrderBy(id=>id).ToArray();
            var confirm=model.ConfirmForcedExit;int wait=client.ExitWaitMilliseconds;int prompts=0;
            using(var target=Process.GetProcessById(oldPid)) {
                IntPtr handle=target.Handle;
                Check("exit_fixture_is_separate_named_instance",!String.IsNullOrEmpty(client.Instance)&&Util.Same(target.MainModule.FileName,client.Executable));
                Check("exit_fixture_suspend_succeeds",NtSuspendProcess(handle)==0);
                try {
                    client.ExitWaitMilliseconds=300;
                    model.ConfirmForcedExit=message=>{prompts++;return false;};
                    bool cancelled=false;
                    try {model.Promote(plan);}catch(OperationCanceledException){cancelled=true;}
                    Check("exit_cancel_preserves_running_target",cancelled&&!target.HasExited&&prompts==1);
                    Check("exit_cancel_preserves_config_cards_and_covers",Hash(client.Config)==config&&Hash(Path.Combine(model.StateRoot,"cards.json"))==state&&MergeCovers(model).SequenceEqual(covers));
                    Check("exit_cancel_cleans_owned_command_process",Process.GetProcessesByName("Everything").Select(p=>p.Id).OrderBy(id=>id).SequenceEqual(processIds));
                    model.ConfirmForcedExit=message=>{prompts++;return true;};
                    model.Promote(plan);
                    Check("exit_confirm_restarts_only_original_fixture",target.HasExited&&client.RunningPid()!=0&&client.RunningPid()!=oldPid&&prompts==2);
                    Check("exit_confirm_completes_parent_promotion",model.Cards.Any(c=>Util.Same(c.Folder,parent))&&!model.Cards.Any(c=>Util.Same(c.Folder,Path.GetDirectoryName(first)))&&model.LastMerged==2);
                    Check("exit_confirm_preserves_original_files",File.Exists(first)&&File.Exists(second));
                    Check("exit_confirm_backs_up_saved_config",Directory.GetFiles(client.BackupRoot,"before-forced-exit-*.ini").Any(p=>Hash(p)==config));
                    WaitCount(es,instance,"exit-recovery-",0);
                    Check("exit_restarted_index_honors_parent_rule",true);
                } finally {
                    if(!target.HasExited)NtResumeProcess(handle);
                    client.ExitWaitMilliseconds=wait;model.ConfirmForcedExit=confirm;client.ConfirmForcedExit=confirm;
                }
            }
            ClearMergeCards(form,model);
        }
    }
}
