using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EverythingExclusions {
    // Owned by the WinForms UI thread. FIFO covers the complete operation,
    // including worker tasks, rollback and the subsequent UI state update.
    internal sealed class OperationQueue {
        sealed class Item {
            internal string Key;
            internal Func<Task> Action;
            internal readonly TaskCompletionSource<bool> Completion=new TaskCompletionSource<bool>();
        }
        readonly int owner=Thread.CurrentThread.ManagedThreadId;
        readonly SynchronizationContext context=new WindowsFormsSynchronizationContext();
        readonly Queue<Item> waiting=new Queue<Item>();
        readonly Dictionary<string,Item> pending=new Dictionary<string,Item>();
        bool running;
        internal Action Changed;
        internal int WaitingCount {get{return waiting.Count;}}
        internal bool IsBusy {get{return pending.Count>0;}}
        internal string[] Keys {get{return pending.Keys.ToArray();}}
        void VerifyOwner() {
            if(Thread.CurrentThread.ManagedThreadId!=owner)throw new InvalidOperationException("操作必须从界面线程入队。");
        }
        internal Task<bool> Enqueue(string key,Func<Task> action) {
            VerifyOwner();
            Item existing;
            if(pending.TryGetValue(key,out existing))return existing.Completion.Task;
            if(pending.Count>=64)throw new InvalidOperationException("等待操作过多，请等当前队列完成后再操作。");
            var item=new Item{Key=key,Action=action};
            pending.Add(key,item);waiting.Enqueue(item);
            if(Changed!=null)Changed();
            if(!running){running=true;StartNext();}
            return item.Completion.Task;
        }
        // A failed/cancelled write must not launch more exit prompts for queued writes.
        internal int CancelWaiting() {
            VerifyOwner();int count=waiting.Count;
            while(waiting.Count>0) {
                var item=waiting.Dequeue();pending.Remove(item.Key);item.Completion.TrySetResult(false);
            }
            if(Changed!=null)Changed();
            return count;
        }
        void StartNext() {
            VerifyOwner();
            if(waiting.Count==0){running=false;return;}
            var item=waiting.Dequeue();Task operation;
            if(Changed!=null)Changed();
            var previous=SynchronizationContext.Current;
            try {
                // WebView and synthetic messages need an explicit UI context:
                // an ambient context is not guaranteed by every event source.
                SynchronizationContext.SetSynchronizationContext(context);
                operation=item.Action();
            } catch(Exception error) {
                var failed=new TaskCompletionSource<bool>();failed.SetException(error);operation=failed.Task;
            } finally {SynchronizationContext.SetSynchronizationContext(previous);}
            if(operation.IsCompleted)Complete(item,operation);
            else operation.ContinueWith(done=>context.Post(_=>Complete(item,done),null),
                CancellationToken.None,TaskContinuationOptions.ExecuteSynchronously,TaskScheduler.Default);
        }
        void Complete(Item item,Task operation) {
            VerifyOwner();pending.Remove(item.Key);
            if(Changed!=null)Changed();
            if(operation.IsCanceled)item.Completion.TrySetCanceled();
            else if(operation.IsFaulted)item.Completion.TrySetException(operation.Exception.InnerExceptions);
            else item.Completion.TrySetResult(true);
            StartNext();
        }
    }

    internal sealed partial class MainForm {
        internal readonly OperationQueue Operations=new OperationQueue();
        object displayedCards;
        static bool QueuedMessage(string type) {
            return type=="remove" || type=="drop" || type=="promote" || type=="confirmPromotion" ||
                type=="confirmDrop" || type=="uploadProfile" || type=="syncProfile";
        }
        internal Task<bool> QueueMessage(string type,Dictionary<string,object> message,string[] files=null) {
            string value="";
            foreach(string field in new[]{"id","token","key","author"})
                if(message.ContainsKey(field)){value=Convert.ToString(message[field]);break;}
            string key=type+":"+(type=="drop"?Guid.NewGuid().ToString("N"):value);
            return Operations.Enqueue(key,async()=>{
                LastError=null;
                try {
                    // Resolve card IDs and confirmation tokens when their turn starts,
                    // after any earlier removal/promotion has committed or rolled back.
                    if(type=="remove" && message.ContainsKey("id")) {
                        var card=Model.Cards.FirstOrDefault(item=>item.Id==value);
                        if(card!=null)await RemoveCard(card);
                    } else if(type=="drop") {
                        if(files!=null && files.Length>0)await DropFiles(files);
                        else SetStatus("未取得文件路径，请从 Everything 或资源管理器拖入文件。",true);
                    } else if(type=="promote")PreparePromotion(value);
                    else if(type=="confirmPromotion")await ConfirmPromotion(value);
                    else if(type=="confirmDrop")await ConfirmDrop(new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<DropConfirmation>(
                        new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(message)));
                    else if(type=="uploadProfile")await UploadProfile(value);
                    else if(type=="syncProfile")await SyncProfile(value);
                } catch(Exception error){LastError=error.ToString();SetStatus(error.Message,true);}
                if(LastError!=null) {
                    int cancelled=Operations.CancelWaiting();
                    if(cancelled>0)SetStatus(status+" 后续 "+cancelled+" 项操作已取消，请处理后重试。",true);
                }
            });
        }
    }
}
