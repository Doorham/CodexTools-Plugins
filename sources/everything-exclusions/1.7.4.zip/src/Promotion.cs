using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace EverythingExclusions {
    internal sealed class PromotionPlan {
        internal string CardId, Parent;
        internal string[] Children;
    }
    internal sealed partial class Controller {
        internal PromotionPlan PlanPromotion(string id) {
            var card = Cards.SingleOrDefault(c => c.Id == id);
            if (card == null) throw new InvalidOperationException("卡片已变化，请重新选择。");
            string parent = ParentOf(card.Folder);
            if (parent == null) throw new InvalidOperationException("已经是磁盘或共享根目录，没有上一级。");
            return new PromotionPlan { CardId=id, Parent=parent,
                Children=Cards.Where(c => Util.Contains(parent,c.Folder,false)).Select(c=>c.Id).OrderBy(value=>value).ToArray() };
        }
        internal void Promote(PromotionPlan plan) {
            var current = PlanPromotion(plan.CardId);
            if (!Util.Same(current.Parent,plan.Parent) || !current.Children.SequenceEqual(plan.Children))
                throw new InvalidOperationException("待合并的卡片已变化，请取消后重新点击吞噬上级。");
            var original = Cards.Single(c => c.Id == plan.CardId);
            var existing = Cards.FirstOrDefault(c => Util.Same(c.Folder,plan.Parent));
            var rules = Backend().Excluded();
            if (existing == null && rules.Any(rule=>EverythingClient.SameLiteral(rule,plan.Parent)))
                throw new InvalidOperationException("该父目录已在 Everything 的外部排除规则中，已保留原规则和卡片，未接管。");
            if (Cards.Any(c => Util.Contains(c.Folder,plan.Parent,false) && rules.Any(rule=>EverythingClient.SameLiteral(rule,c.Folder))))
                throw new InvalidOperationException("已有更上级的卡片覆盖该范围，请从那张卡片管理，未扩大本次范围。");
            if (existing != null) { Commit(new List<CardItem>{existing}); return; }
            string id=Guid.NewGuid().ToString("N");
            var parent = new CardItem { Id=id, Folder=plan.Parent, FileName=original.FileName,
                Cover=id+".jpg", Source=original.Source, Scope="parent", SharedCoverHash=original.SharedCoverHash };
            string oldCover=Path.Combine(StateRoot,original.Cover), newCover=Path.Combine(StateRoot,parent.Cover);
            if (File.Exists(oldCover)) File.WriteAllBytes(newCover,ShellPreview.JpegBytes(oldCover));
            else ShellPreview.SaveFolder(newCover);
            // The existing transaction owns descendant rules, history, persistence and rollback.
            Commit(new List<CardItem>{parent});
        }
    }
    internal sealed partial class MainForm {
        PromotionPlan pendingPromotion;
        string promotionToken;
        internal void PreparePromotion(string id) {
            if (Busy) return;
            if (pendingDrop!=null || pendingPromotion!=null) throw new InvalidOperationException("请先完成当前的范围选择。");
            LastError=null;
            pendingPromotion=Model.PlanPromotion(id); promotionToken=Guid.NewGuid().ToString("N");
            var plan=pendingPromotion;
            Browser.CoreWebView2.PostWebMessageAsJson(new JavaScriptSerializer().Serialize(new {
                type="promotionChoice",token=promotionToken,parent=plan.Parent,
                paths=Model.Cards.Where(c=>plan.Children.Contains(c.Id)).Select(c=>c.Folder).ToArray(),
                root=Controller.ParentOf(plan.Parent)==null,
                existing=Model.Cards.Any(c=>Util.Same(c.Folder,plan.Parent))
            }));
        }
        internal void CancelPromotion(string token) {
            if (Busy || token!=promotionToken) return;
            pendingPromotion=null;promotionToken=null;SetStatus("已取消吞噬上级，排除范围保持原样。",false);
        }
        internal async Task ConfirmPromotion(string token) {
            if (Busy) return;LastError=null;
            try {
                if (pendingPromotion==null || token!=promotionToken) throw new InvalidOperationException("确认已失效，请重新点击吞噬上级。");
                var plan=pendingPromotion;
                SetBusy(true);SetStatus("正在吞噬上级并合并卡片，Everything 将重新加载…",false);
                await Task.Run(()=>Model.Promote(plan));
                pendingPromotion=null;promotionToken=null;
                SetStatus("已屏蔽「"+plan.Parent+"」，合并 "+Model.LastMerged+" 张下级卡片。",false);
                Browser.CoreWebView2.PostWebMessageAsJson("{\"type\":\"promotionResult\",\"ok\":true}");
            } catch(Exception error) {
                LastError=error.ToString();SetStatus(error.Message,true);
                Browser.CoreWebView2.PostWebMessageAsJson(new JavaScriptSerializer().Serialize(new{type="promotionResult",ok=false,error=error.Message}));
            } finally {SetBusy(false);Activate();}
        }
    }
}
