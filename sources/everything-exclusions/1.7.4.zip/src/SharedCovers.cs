using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;
namespace EverythingExclusions {
 // Cover metadata lives below covers/, so version-1 clients keep reading the
 // original path-only profiles and cannot erase pictures during an upload.
 internal sealed class SharedCoverIndex {
  public int Version {get;set;}
  public string ProfileKey {get;set;}
  public string UpdatedUtc {get;set;}
  public Dictionary<string,string> Covers {get;set;}
 }
 internal static class SharedCovers {
  internal const int MaxBytes=96*1024,MaxWidth=432,MaxHeight=250,MaxUploadBytes=64*1024*1024,MaxIndexBytes=4*1024*1024;
  internal static string Hash(byte[] bytes) {using(var hash=SHA256.Create())return BitConverter.ToString(hash.ComputeHash(bytes)).Replace("-","").ToLowerInvariant();}
  internal static bool ValidHash(string hash) {return hash!=null&&Regex.IsMatch(hash,"^[a-f0-9]{64}$");}
  static byte[] ReadBounded(string path,int maximum) {
   using(var stream=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete)) {
    if(stream.Length>maximum)throw new InvalidDataException("共享封面文件超过大小限制。");
    using(var result=new MemoryStream()) {
     byte[] buffer=new byte[4096];int count;
     while((count=stream.Read(buffer,0,Math.Min(buffer.Length,maximum-(int)result.Length+1)))>0) {
      if(result.Length+count>maximum)throw new InvalidDataException("共享封面文件超过大小限制。");
      result.Write(buffer,0,count);
     }
     return result.ToArray();
    }
   }
  }
  internal static void ValidateJpeg(byte[] bytes) {
   if(bytes==null||bytes.Length<12||bytes.Length>MaxBytes||bytes[0]!=255||bytes[1]!=216||bytes[bytes.Length-2]!=255||bytes[bytes.Length-1]!=217)
    throw new InvalidDataException("共享封面必须是 96 KB 以内的 JPG 缩略图。");
   // Read dimensions before invoking GDI+, bounding allocation even for an
   // untrusted shared file with a tiny compressed size and enormous dimensions.
   int position=2,width=0,height=0;
   while(position<bytes.Length-1) {
    if(bytes[position++]!=255)throw new InvalidDataException("JPG 封面标记损坏。");
    while(position<bytes.Length&&bytes[position]==255)position++;
    if(position>=bytes.Length)break;
    int marker=bytes[position++];
    if(marker==217||marker==218)break;
    if(marker==216||marker==1||(marker>=208&&marker<=215))continue;
    if(position+2>bytes.Length)break;
    int length=(bytes[position]<<8)|bytes[position+1];
    if(length<2||position+length>bytes.Length)throw new InvalidDataException("JPG 封面内容不完整。");
    bool frame=marker>=192&&marker<=207&&marker!=196&&marker!=200&&marker!=204;
    if(frame) {
     if(length<8)throw new InvalidDataException("JPG 封面尺寸无效。");
     height=(bytes[position+3]<<8)|bytes[position+4];width=(bytes[position+5]<<8)|bytes[position+6];break;
    }
    position+=length;
   }
   if(width<1||height<1||width>MaxWidth||height>MaxHeight)throw new InvalidDataException("共享封面不能超过 432 × 250 像素。");
   try {
    using(var stream=new MemoryStream(bytes,false))using(var image=Image.FromStream(stream,false,true)) {
     if(image.RawFormat.Guid!=ImageFormat.Jpeg.Guid||image.Width!=width||image.Height!=height)throw new InvalidDataException("JPG 封面格式或尺寸不一致。");
     using(var decoded=new Bitmap(image)) {if(decoded.Width!=width||decoded.Height!=height)throw new InvalidDataException("JPG 封面无法解码。");}
    }
   } catch(InvalidDataException){throw;}catch(Exception error) {throw new InvalidDataException("JPG 封面无法读取。",error);}
  }
  internal static string IndexPath(string root,string key) {
   if(!ValidHash(key))throw new InvalidDataException("共享封面署名无效。");
   return Path.Combine(root,"covers",key+".json");
  }
  internal static string BlobPath(string root,string hash) {
   if(!ValidHash(hash))throw new InvalidDataException("共享封面标识无效。");
   return Path.Combine(root,"covers","blobs",hash+".jpg");
  }
  internal static Dictionary<string,string> ReadIndex(string root,string key,IEnumerable<string> paths,bool requireMembership) {
   string file=IndexPath(root,key);var result=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
   if(!File.Exists(file))return result;
   SharedCoverIndex index;
   try {index=new JavaScriptSerializer{MaxJsonLength=MaxIndexBytes}.Deserialize<SharedCoverIndex>(Util.Utf8.GetString(ReadBounded(file,MaxIndexBytes)));}
   catch(Exception error){throw new InvalidDataException("共享封面索引无法读取，原文件已保留。",error);}
   DateTimeOffset date;
   if(index==null||index.Version!=1||index.ProfileKey!=key||index.Covers==null||index.Covers.Count>10000||!DateTimeOffset.TryParse(index.UpdatedUtc,out date))
    throw new InvalidDataException("共享封面索引格式无效。");
   var allowed=new HashSet<string>(paths,StringComparer.OrdinalIgnoreCase);
   foreach(var pair in index.Covers) {
    string folder=SharedProfiles.Paths(new[]{pair.Key})[0];
    if(!ValidHash(pair.Value)||result.ContainsKey(folder))throw new InvalidDataException("共享封面索引包含无效或重复条目。");
    if(!allowed.Contains(folder)) {if(requireMembership)throw new InvalidDataException("共享封面索引与屏蔽目录不一致，原文件已保留。");continue;}
    result.Add(folder,pair.Value);
   }
   return result;
  }
  internal static string SerializeIndex(string key,Dictionary<string,string> covers) {
   string json=new JavaScriptSerializer{MaxJsonLength=MaxIndexBytes}.Serialize(new SharedCoverIndex {Version=1,ProfileKey=key,UpdatedUtc=DateTimeOffset.UtcNow.ToString("o"),Covers=covers});
   if(Util.Utf8.GetByteCount(json)>MaxIndexBytes)throw new InvalidDataException("共享封面索引过大，请减少单次共享目录。");
   return json;
  }
  internal static byte[] ReadBlob(string root,string hash) {
   string file=BlobPath(root,hash);var info=new FileInfo(file);
   if(!info.Exists||info.Length>MaxBytes)throw new InvalidDataException("共享封面文件缺失或过大。");
   byte[] bytes=ReadBounded(file,MaxBytes);
   if(Hash(bytes)!=hash)throw new InvalidDataException("共享封面摘要不一致。");
   ValidateJpeg(bytes);return bytes;
  }
  internal static bool StoreBlob(string root,string hash,byte[] bytes) {
   string file=BlobPath(root,hash);
   try {ReadBlob(root,hash);return false;}catch(IOException){}catch(InvalidDataException){}catch(UnauthorizedAccessException){}
   Directory.CreateDirectory(Path.GetDirectoryName(file));string temp=file+".tmp-"+Guid.NewGuid().ToString("N");
   try {
    File.WriteAllBytes(temp,bytes);
    try {if(File.Exists(file))File.Replace(temp,file,null);else File.Move(temp,file);}
    catch(IOException) { // Another signature can have installed the identical blob.
     ReadBlob(root,hash);
    }
    ReadBlob(root,hash);return true;
   } finally {if(File.Exists(temp))File.Delete(temp);}
  }
 }
}
