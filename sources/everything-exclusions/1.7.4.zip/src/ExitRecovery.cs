using System;
using System.Diagnostics;
using System.IO;

namespace EverythingExclusions {
    internal sealed partial class EverythingClient {
        internal Func<string,bool> ConfirmForcedExit;
        internal Action<string> ExitProgress;
        internal int ExitWaitMilliseconds=12000;

        internal void StopForChange(int pid) {
            using(var target=Process.GetProcessById(pid)) {
                // Retain the original process handle through the prompt; never target a reused PID.
                IntPtr handle=target.Handle;
                if(target.HasExited)return;
                if(!Util.Same(target.MainModule.FileName,Executable))
                    throw new IOException("Everything 进程路径已变化，未修改配置。");
                if(ExitProgress!=null)ExitProgress("正在等待 Everything 正常退出并保存设置…");
                Process command=null;
                try {
                    command=Launch("-exit");
                    target.WaitForExit(ExitWaitMilliseconds);
                } finally {
                    // A blocked CLI sender must not survive to send its old exit request to a new instance.
                    if(command!=null) {
                        try {
                            if(command.Id!=pid && !command.HasExited) {
                                command.Kill();
                                if(!command.WaitForExit(3000))throw new IOException("退出命令尚未结束，未修改配置。");
                            }
                        } finally {command.Dispose();}
                    }
                }
                if(target.HasExited)return;
                const string question="Everything 未响应正常退出请求，当前排除配置尚未修改。\r\n\r\n是否结束这个 Everything 进程并继续当前操作？\r\n\r\n将先备份已保存的配置。Everything 尚未保存的窗口设置和索引变化可能丢失；磁盘中的原文件不会删除。\r\n\r\n选择“否”会取消本次操作，保留原排除规则和卡片。";
                if(ConfirmForcedExit==null)throw new TimeoutException("Everything 无法正常退出，未修改配置或卡片。请先恢复 Everything 后重试。");
                if(!ConfirmForcedExit(question))throw new OperationCanceledException("已取消，原排除规则和卡片保持不变。");
                if(target.HasExited)return;
                Directory.CreateDirectory(BackupRoot);
                string backup=Path.Combine(BackupRoot,"before-forced-exit-"+DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fff")+"-"+Guid.NewGuid().ToString("N")+".ini");
                File.Copy(Config,backup,false);
                if(ExitProgress!=null)ExitProgress("已备份配置，正在结束卡住的 Everything 并继续操作…");
                target.Kill();
                if(!target.WaitForExit(5000))throw new IOException("Everything 未能退出，尚未修改配置。");
            }
        }
    }
}
