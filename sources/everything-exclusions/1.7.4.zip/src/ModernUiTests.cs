using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace EverythingExclusions {
 internal static partial class Tests {
  [DllImport("user32.dll")] static extern IntPtr GetWindowDpiAwarenessContext(IntPtr hwnd);
  [DllImport("user32.dll")] static extern bool AreDpiAwarenessContextsEqual(IntPtr a,IntPtr b);
  [DllImport("user32.dll")] static extern uint GetDpiForWindow(IntPtr hwnd);
  [DllImport("user32.dll")] static extern IntPtr SendMessage(IntPtr hwnd,int msg,IntPtr w,IntPtr l);
  [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr hwnd,out DpiRect rect);
  [DllImport("user32.dll")] static extern bool GetClientRect(IntPtr hwnd,out DpiRect rect);
  [DllImport("user32.dll")] static extern bool PrintWindow(IntPtr hwnd,IntPtr dc,uint flags);
  [StructLayout(LayoutKind.Sequential)] struct DpiRect {public int Left,Top,Right,Bottom;}

  static void ModernUiChecks(string root,MainForm form) {
   Check("window_is_per_monitor_v2_not_bitmap_virtualized",AreDpiAwarenessContextsEqual(GetWindowDpiAwarenessContext(form.Handle),new IntPtr(-4)));
   int dpi=(int)GetDpiForWindow(form.Handle);
   double ratio=Convert.ToDouble(Js(form,"devicePixelRatio"));
   Check("webview_device_pixels_match_native_window_dpi",Math.Abs(ratio-dpi/96.0)<.02 && Math.Abs(form.Browser.ZoomFactor-1)<.001);
   Check("no_page_or_card_scaling_blurs_text",Convert.ToBoolean(Js(form,"[document.documentElement,document.body,...document.querySelectorAll('.card')].every(e=>getComputedStyle(e).transform==='none'&&getComputedStyle(e).zoom==='1')")));
   Js(form,"explicitTheme='light';applyTheme('light');true");
   Check("light_surface_and_text_are_explicit",Convert.ToBoolean(Js(form,"getComputedStyle(document.body).backgroundColor==='rgb(243, 244, 248)'&&getComputedStyle(document.body).color==='rgb(37, 41, 54)'")));
   Check("main_copy_uses_readable_font_size",Convert.ToBoolean(Js(form,"parseFloat(getComputedStyle(document.querySelector('.intro p')).fontSize)>=13&&parseFloat(getComputedStyle(document.querySelector('.folder-title')).fontSize)>=13")));
   Check("default_grid_keeps_five_columns",Convert.ToBoolean(Js(form,"getComputedStyle(document.getElementById('cards')).gridTemplateColumns.split(' ').length===5")));
   Pump(form.CapturePreview(Path.Combine(root,"modern-light.png")));
   Js(form,"document.getElementById('theme-toggle').click();true");
   Check("theme_button_switches_and_saves_own_preference",Convert.ToBoolean(Js(form,"document.documentElement.dataset.theme==='dark'&&localStorage.getItem('everything-exclusions-theme')==='dark'&&document.getElementById('theme-toggle').getAttribute('aria-pressed')==='true'")));
   Check("dark_surface_keeps_contrast",Convert.ToBoolean(Js(form,"getComputedStyle(document.body).backgroundColor==='rgb(23, 25, 32)'&&getComputedStyle(document.body).color==='rgb(238, 240, 246)'")));
   Pump(form.CapturePreview(Path.Combine(root,"modern-dark.png")));
   Size previous=form.ClientSize;
   form.ClientSize=new Size((int)(460*ratio),(int)(380*ratio));Application.DoEvents();
   Check("narrow_window_has_no_horizontal_scroll",Convert.ToBoolean(Js(form,"document.querySelector('main').scrollWidth<=document.querySelector('main').clientWidth")));
   Js(form,"document.getElementById('open-sharing').click();true");WaitDom(form,"document.getElementById('sharing-dialog').open");
   Check("narrow_dialog_stays_inside_viewport",Convert.ToBoolean(Js(form,"(()=>{const r=document.getElementById('sharing-dialog').getBoundingClientRect();return r.left>=0&&r.right<=innerWidth&&r.top>=0&&r.bottom<=innerHeight;})()")));
   Pump(form.CapturePreview(Path.Combine(root,"modern-narrow.png")));
   Js(form,"document.getElementById('close-sharing').click();true");form.ClientSize=previous;Application.DoEvents();
   foreach(int percent in new[]{125,150}) {
    string parameters="{\"width\":1040,\"height\":790,\"deviceScaleFactor\":"+(percent/100.0).ToString(System.Globalization.CultureInfo.InvariantCulture)+",\"mobile\":false}";
    Pump(form.Browser.CoreWebView2.CallDevToolsProtocolMethodAsync("Emulation.setDeviceMetricsOverride",parameters));
    Check("render_scale_"+percent+"_retains_five_columns_and_css_text",Convert.ToBoolean(Js(form,"getComputedStyle(document.getElementById('cards')).gridTemplateColumns.split(' ').length===5&&parseFloat(getComputedStyle(document.querySelector('.folder-title')).fontSize)>=13&&document.querySelector('main').scrollWidth<=document.querySelector('main').clientWidth")));
    Check("render_scale_"+percent+"_uses_requested_device_pixel_ratio",Math.Abs(Convert.ToDouble(Js(form,"devicePixelRatio"))-percent/100.0)<.001);
    Pump(form.CapturePreview(Path.Combine(root,"modern-render-"+percent+".png")));
   }
   Pump(form.Browser.CoreWebView2.CallDevToolsProtocolMethodAsync("Emulation.clearDeviceMetricsOverride","{}"));
   Rectangle original=form.Bounds;
   foreach(int targetDpi in new[]{120,144}) {
    var r=new DpiRect{Left=original.Left,Top=original.Top,Right=original.Left+(int)(1050*targetDpi/96.0),Bottom=original.Top+(int)(800*targetDpi/96.0)};
    IntPtr memory=Marshal.AllocHGlobal(Marshal.SizeOf(typeof(DpiRect)));
    try {Marshal.StructureToPtr(r,memory,false);SendMessage(form.Handle,0x02E0,new IntPtr(targetDpi|(targetDpi<<16)),memory);}
    finally {Marshal.FreeHGlobal(memory);}
    Check("dpi_message_"+targetDpi+"_updates_native_frame_metrics",form.CurrentDpi==targetDpi&&form.MinimumSize.Width==(int)Math.Round(460*targetDpi/96.0)&&form.Padding.Left==(int)Math.Round(5*targetDpi/96.0));
   }
   var restore=new DpiRect{Left=original.Left,Top=original.Top,Right=original.Right,Bottom=original.Bottom};
   IntPtr pointer=Marshal.AllocHGlobal(Marshal.SizeOf(typeof(DpiRect)));try{Marshal.StructureToPtr(restore,pointer,false);SendMessage(form.Handle,0x02E0,new IntPtr(dpi|(dpi<<16)),pointer);}finally{Marshal.FreeHGlobal(pointer);}
   Js(form,"explicitTheme='light';applyTheme('light');true");
   File.WriteAllText(Path.Combine(root,"dpi-evidence.json"),new JavaScriptSerializer().Serialize(new{nativeDpi=dpi,devicePixelRatio=ratio,awareness="PerMonitorV2",pageZoom=form.Browser.ZoomFactor,renderScales=new[]{125,150},renderScaleMethod="CDP isolated rendering; not physical monitor changes",nativeScaleMethod="Synthetic WM_DPICHANGED messages; not mixed-monitor real-world validation"}),Util.Utf8);
  }
  static void ModernRepairChecks(string root) {
   using(var repair=new HangRepairForm(false)) {
    repair.Show();Application.DoEvents();
    DpiRect window,client;GetWindowRect(repair.Handle,out window);GetClientRect(repair.Handle,out client);
    Check("repair_window_has_no_native_caption_or_nonclient_frame",window.Right-window.Left==client.Right-client.Left&&window.Bottom-window.Top==client.Bottom-client.Top);
    Check("repair_window_is_per_monitor_v2",AreDpiAwarenessContextsEqual(GetWindowDpiAwarenessContext(repair.Handle),new IntPtr(-4)));
    Control caption=repair.Controls["modernCaption"];
    double scale=GetDpiForWindow(repair.Handle)/96.0;
    Check("repair_layout_scales_from_96_dpi",Math.Abs(repair.ClientSize.Width-560*scale)<3&&Math.Abs(caption.Height-36*scale)<2);
    Check("repair_window_has_custom_caption_and_three_flat_controls",caption!=null&&caption.Controls.Count==4&&caption.Controls[1] is Button&&caption.Controls[2] is Button&&caption.Controls[3] is Button);
    using(var bitmap=new Bitmap(repair.ClientSize.Width,repair.ClientSize.Height))using(var graphics=Graphics.FromImage(bitmap)) {
     IntPtr dc=graphics.GetHdc();bool rendered;try{rendered=PrintWindow(repair.Handle,dc,1);}finally{graphics.ReleaseHdc(dc);}
     Check("repair_client_render_succeeded",rendered);bitmap.Save(Path.Combine(root,"modern-repair.png"),System.Drawing.Imaging.ImageFormat.Png);
    }
    ((Button)caption.Controls[2]).PerformClick();Application.DoEvents();
    Check("repair_maximize_uses_working_area",repair.WindowState==FormWindowState.Maximized&&Screen.FromHandle(repair.Handle).WorkingArea.Contains(repair.RectangleToScreen(repair.ClientRectangle)));
    ((Button)caption.Controls[2]).PerformClick();Application.DoEvents();Check("repair_restore_works",repair.WindowState==FormWindowState.Normal);
    ((Button)caption.Controls[3]).PerformClick();Application.DoEvents();Check("repair_flat_close_works",repair.IsDisposed);
   }
  }
  internal static int RunModernUi(string root) {
   MainForm form=null;bool ok=false;string error=null;
   try {
    root=Path.GetFullPath(root);string allowed=Path.Combine(Path.GetPathRoot(root),"Works","CodexTools","artifacts")+Path.DirectorySeparatorChar;
    if(!root.StartsWith(allowed,StringComparison.OrdinalIgnoreCase)||Directory.Exists(root))throw new Exception("Fresh isolated artifacts directory required.");
    Directory.CreateDirectory(root);progressPath=Path.Combine(root,"test-progress.txt");
    var model=new Controller(Path.Combine(root,"state"),new EverythingClient(),new SharedProfiles(Path.Combine(root,"shared"),root));
    foreach(string name in new[]{"产品序列帧","工程缓存","音效素材","设计草稿","旧版输出"})model.Cards.Add(new CardItem{Id=Guid.NewGuid().ToString("N"),Folder=Path.Combine(root,"示例",name),FileName="示例文件.png",Cover="",Scope="directory"});
    form=new MainForm(model);SynchronizationContext.SetSynchronizationContext(new WindowsFormsSynchronizationContext());form.Show();Pump(form.Ready.Task);WaitDom(form,"document.body.dataset.ready==='true'");
    ModernUiChecks(root,form);Check("ui_checks_never_created_rules_or_saved_cards",!File.Exists(Path.Combine(model.StateRoot,"cards.json"))&&model.Client.ReloadCount==0);ModernRepairChecks(root);ok=true;
   }catch(Exception ex){error=ex.ToString();}
   finally{if(form!=null){form.Close();form.Dispose();}if(Directory.Exists(root))File.WriteAllText(Path.Combine(root,"verification.json"),new JavaScriptSerializer().Serialize(new{ok=ok,version=typeof(Program).Assembly.GetName().Version.ToString(3),checks=checks,checkCount=checks.Count,error=error,fixtureOnly=true}),Util.Utf8);}
   return ok?0:1;
  }
 }
}
