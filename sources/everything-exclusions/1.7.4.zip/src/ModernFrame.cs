using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace EverythingExclusions
{
    // Native snap contract reused from the shipped Everything shell. WinForms stays
    // borderless for client-size calculations; HWND retains Windows resize/snap styles.
    internal class ModernFrame : Form
    {
        private bool configured, resizable;
        private uint frameStyle;
        private Panel caption;
        private Label captionTitle;
        private CaptionButton minimize, maximize, close;
        [DllImport("user32.dll", EntryPoint="GetWindowLongPtrW")] static extern IntPtr GetStyle64(IntPtr window, int index);
        [DllImport("user32.dll", EntryPoint="SetWindowLongPtrW")] static extern IntPtr SetStyle64(IntPtr window, int index, IntPtr value);
        [DllImport("user32.dll", EntryPoint="GetWindowLongW")] static extern int GetStyle32(IntPtr window, int index);
        [DllImport("user32.dll", EntryPoint="SetWindowLongW")] static extern int SetStyle32(IntPtr window, int index, int value);
        [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr window, IntPtr after, int x, int y, int width, int height, uint flags);
        [DllImport("user32.dll")] static extern bool IsZoomed(IntPtr window);
        [DllImport("user32.dll")] static extern bool ReleaseCapture();
        [DllImport("user32.dll")] static extern IntPtr SendMessage(IntPtr window, uint message, IntPtr wp, IntPtr lp);
        [StructLayout(LayoutKind.Sequential)] struct WindowStyleChange { public uint Old, New; }
        [StructLayout(LayoutKind.Sequential)] struct WindowRect { public int Left, Top, Right, Bottom; }
        [StructLayout(LayoutKind.Sequential)] struct WindowMinMax { public Point Reserved, MaxSize, MaxPosition, MinTrackSize, MaxTrackSize; }

        protected void UseModernFrame(bool allowResize, bool allowMinimize, bool allowClose)
        {
            configured = true; resizable = allowResize;
            frameStyle = allowResize ? 0x00CF0000u : 0x00C80000u;
            if (!allowMinimize) frameStyle &= ~0x00020000u;
            FormBorderStyle = FormBorderStyle.None;
            Padding = new Padding(5);
            caption = new Panel { Name="modernCaption", Dock=DockStyle.Top, Height=36, BackColor=BackColor };
            captionTitle = new Label { AutoEllipsis=true, Text=Text, Font=new Font("Microsoft YaHei UI", 9F), TextAlign=ContentAlignment.MiddleLeft, BackColor=Color.Transparent };
            minimize = new CaptionButton(this, 0) { Available=allowMinimize, Visible=allowMinimize, AccessibleName="最小化" };
            maximize = new CaptionButton(this, 1) { Available=allowResize, Visible=allowResize, AccessibleName="最大化或还原" };
            close = new CaptionButton(this, 2) { Available=allowClose, Visible=allowClose, AccessibleName="关闭" };
            minimize.Click += delegate { WindowState=FormWindowState.Minimized; };
            maximize.Click += delegate { ToggleMaximize(); };
            close.Click += delegate { Close(); };
            MouseEventHandler drag = delegate(object sender, MouseEventArgs e) {
                if (e.Button != MouseButtons.Left) return;
                if (e.Clicks == 2 && resizable) { ToggleMaximize(); return; }
                if (e.Clicks != 1) return;
                ReleaseCapture(); Point p=Cursor.Position;
                SendMessage(Handle, 0x00A1, (IntPtr)2, new IntPtr(unchecked((int)((uint)(ushort)p.X|((uint)(ushort)p.Y<<16)))));
            };
            caption.MouseDown += drag; captionTitle.MouseDown += drag;
            caption.Controls.AddRange(new Control[]{captionTitle,minimize,maximize,close});
            caption.Resize += delegate {
                int buttonWidth=(int)Math.Round(caption.Height*1.3), right=caption.ClientSize.Width;
                foreach (CaptionButton button in new[]{close,maximize,minimize}) {
                    if (!button.Available) continue;
                    right-=buttonWidth; button.SetBounds(right,0,buttonWidth,caption.Height);
                }
                int left=caption.Height/2; captionTitle.SetBounds(left,0,Math.Max(0,right-left),caption.Height);
            };
            Controls.Add(caption);
            TextChanged += delegate { if (captionTitle != null) captionTitle.Text=Text; };
            if (IsHandleCreated) ApplySnapStyles();
        }
        private void ToggleMaximize() { if (resizable) SendMessage(Handle,0x0112,(IntPtr)(WindowState==FormWindowState.Maximized?0xF120:0xF030),IntPtr.Zero); }
        private void ApplySnapStyles()
        {
            if (!configured) return;
            long old=IntPtr.Size==8?GetStyle64(Handle,-16).ToInt64():GetStyle32(Handle,-16);
            long value=(old & ~0x00CF0000L)|frameStyle;
            if(IntPtr.Size==8)SetStyle64(Handle,-16,new IntPtr(value));else SetStyle32(Handle,-16,unchecked((int)value));
            SetWindowPos(Handle,IntPtr.Zero,0,0,0,0,0x0037);
        }
        protected override void OnHandleCreated(EventArgs e) { base.OnHandleCreated(e); ApplySnapStyles(); }
        protected override void OnShown(EventArgs e) { base.OnShown(e); ApplySnapStyles(); }
        protected override void WndProc(ref Message m)
        {
            if(configured && m.Msg==0x007C && m.WParam.ToInt64()==-16 && m.LParam!=IntPtr.Zero) {
                var change=(WindowStyleChange)Marshal.PtrToStructure(m.LParam,typeof(WindowStyleChange));
                change.New=(change.New & ~0x00CF0000u)|frameStyle; Marshal.StructureToPtr(change,m.LParam,false);m.Result=IntPtr.Zero;return;
            }
            if(configured && m.Msg==0x0083 && m.WParam!=IntPtr.Zero) {
                if(IsZoomed(m.HWnd)) {
                    var rect=(WindowRect)Marshal.PtrToStructure(m.LParam,typeof(WindowRect));
                    var work=Screen.FromRectangle(Rectangle.FromLTRB(rect.Left,rect.Top,rect.Right,rect.Bottom)).WorkingArea;
                    rect.Left=work.Left;rect.Top=work.Top;rect.Right=work.Right;rect.Bottom=work.Bottom;Marshal.StructureToPtr(rect,m.LParam,false);
                }
                m.Result=IntPtr.Zero;return;
            }
            if(configured && m.Msg==0x0024) {
                base.WndProc(ref m);
                if(m.LParam!=IntPtr.Zero) {
                    var screen=Screen.FromHandle(m.HWnd);var work=screen.WorkingArea;var monitor=screen.Bounds;
                    var limits=(WindowMinMax)Marshal.PtrToStructure(m.LParam,typeof(WindowMinMax));
                    limits.MaxPosition=new Point(work.Left-monitor.Left,work.Top-monitor.Top);limits.MaxSize=new Point(work.Width,work.Height);
                    Marshal.StructureToPtr(limits,m.LParam,false);m.Result=IntPtr.Zero;
                }
                return;
            }
            if(configured && resizable && m.Msg==0x0084 && WindowState==FormWindowState.Normal) {
                Point p=PointToClient(new Point(unchecked((short)(m.LParam.ToInt64()&0xffff)),unchecked((short)((m.LParam.ToInt64()>>16)&0xffff))));
                int gap=Math.Max(5,Padding.Left);
                bool left=p.X<gap,right=p.X>=ClientSize.Width-gap,top=p.Y<gap,bottom=p.Y>=ClientSize.Height-gap;
                int hit=left?(top?13:(bottom?16:10)):(right?(top?14:(bottom?17:11)):(top?12:(bottom?15:0)));
                if(hit!=0){m.Result=(IntPtr)hit;return;}
            }
            base.WndProc(ref m);
        }

        private sealed class CaptionButton : Button
        {
            internal bool Available=true;
            readonly ModernFrame owner; readonly int glyph; bool hovered;
            public CaptionButton(ModernFrame owner,int glyph) { this.owner=owner;this.glyph=glyph;TabStop=false;FlatStyle=FlatStyle.Flat;FlatAppearance.BorderSize=0;SetStyle(ControlStyles.UserPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true); }
            protected override void OnMouseEnter(EventArgs e){hovered=true;Invalidate();base.OnMouseEnter(e);}
            protected override void OnMouseLeave(EventArgs e){hovered=false;Invalidate();base.OnMouseLeave(e);}
            protected override void OnPaint(PaintEventArgs e) {
                Color background=owner.BackColor, foreground=owner.ForeColor;
                if(hovered) {background=glyph==2?Color.FromArgb(211,55,72):ControlPaint.Light(owner.BackColor,.12F);if(glyph==2)foreground=Color.White;}
                e.Graphics.Clear(background);e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;
                float side=Math.Max(9,Height*.28F),x=(Width-side)/2,y=(Height-side)/2;
                using(var pen=new Pen(foreground,Math.Max(1,Height/36F))) {
                    if(glyph==0)e.Graphics.DrawLine(pen,x,y+side*.65F,x+side,y+side*.65F);
                    else if(glyph==2){e.Graphics.DrawLine(pen,x,y,x+side,y+side);e.Graphics.DrawLine(pen,x+side,y,x,y+side);}
                    else if(owner.WindowState==FormWindowState.Maximized){e.Graphics.DrawRectangle(pen,x+side*.23F,y,side*.77F,side*.77F);using(var brush=new SolidBrush(background))e.Graphics.FillRectangle(brush,x,y+side*.23F,side*.77F,side*.77F);e.Graphics.DrawRectangle(pen,x,y+side*.23F,side*.77F,side*.77F);}
                    else e.Graphics.DrawRectangle(pen,x,y,side,side);
                }
            }
        }
    }
}
