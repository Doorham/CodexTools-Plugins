using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
namespace EverythingExclusions {
 internal static class ShellPreview {
  [StructLayout(LayoutKind.Sequential)] struct SizeNative {public int Width,Height;public SizeNative(int w,int h){Width=w;Height=h;}}
  [ComImport,Guid("bcc18b79-ba16-442f-80c4-8a59c30c463b"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IImageFactory {[PreserveSig] int GetImage(SizeNative size,uint flags,out IntPtr bitmap);}
  [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)] struct FileInfoNative {
   public IntPtr Icon;public int IconIndex;public uint Attributes;
   [MarshalAs(UnmanagedType.ByValTStr,SizeConst=260)] public string DisplayName;
   [MarshalAs(UnmanagedType.ByValTStr,SizeConst=80)] public string TypeName;
  }
  [DllImport("shell32.dll",CharSet=CharSet.Unicode,PreserveSig=true)] static extern int SHCreateItemFromParsingName(string path,IntPtr context,ref Guid iid,[MarshalAs(UnmanagedType.Interface)] out IImageFactory factory);
  [DllImport("shell32.dll",CharSet=CharSet.Unicode)] static extern IntPtr SHGetFileInfo(string path,uint attributes,out FileInfoNative info,uint size,uint flags);
  [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr bitmap);
  [DllImport("user32.dll")] static extern bool DestroyIcon(IntPtr icon);
  static Bitmap CachedThumbnail(string path) {
   IImageFactory factory=null;IntPtr handle=IntPtr.Zero;
   try {
    Guid iid=typeof(IImageFactory).GUID;
    if(SHCreateItemFromParsingName(Path.GetFullPath(path),IntPtr.Zero,ref iid,out factory)<0||factory==null)return null;
    // THUMBNAILONLY | INCACHEONLY: use Windows' existing thumbnail; never decode file contents here.
    if(factory.GetImage(new SizeNative(432,250),0x08|0x10,out handle)<0||handle==IntPtr.Zero)return null;
    return Bitmap.FromHbitmap(handle);
   } catch {return null;}
   finally {if(handle!=IntPtr.Zero)DeleteObject(handle);if(factory!=null)Marshal.ReleaseComObject(factory);}
  }
  static Bitmap FileIcon(string path,bool folder=false) {
   FileInfoNative info=new FileInfoNative();
   try {
    // USEFILEATTRIBUTES resolves the registered file-type icon without opening the representative file.
    string extension=Path.GetExtension(path);
    if(SHGetFileInfo(folder?"folder":("file"+extension),folder?0x10u:0x80u,out info,(uint)Marshal.SizeOf(typeof(FileInfoNative)),0x100|0x10)!=IntPtr.Zero&&info.Icon!=IntPtr.Zero)
     using(Icon icon=Icon.FromHandle(info.Icon))return icon.ToBitmap();
   } catch {}
   finally {if(info.Icon!=IntPtr.Zero)DestroyIcon(info.Icon);}
   return SystemIcons.Application.ToBitmap();
  }
  internal static void Save(string path,string destination) {
   Bitmap image=CachedThumbnail(path);bool icon=image==null;if(icon)image=FileIcon(path);
   SaveCanvas(image,icon,destination);
  }
  internal static void SaveFolder(string destination) {SaveCanvas(FileIcon("folder",true),true,destination);}
  internal static byte[] JpegBytes(string cachePath) {
   var info=new FileInfo(cachePath);
   if(!info.Exists)return null;
   if(info.Length>4*1024*1024)throw new InvalidDataException("本地缩略图缓存过大，未上传。");
   byte[] bytes=File.ReadAllBytes(cachePath);
   if(String.Equals(Path.GetExtension(cachePath),".jpg",StringComparison.OrdinalIgnoreCase)) {
    SharedCovers.ValidateJpeg(bytes);return bytes;
   }
   // Read only the small plugin-owned cache, never the original representative file.
   using(var input=new MemoryStream(bytes))using(var image=Image.FromStream(input,true,true)) {
    if(image.Width>432||image.Height>250)throw new InvalidDataException("本地缩略图尺寸过大，未上传。");
    using(var canvas=new Bitmap(image.Width,image.Height,PixelFormat.Format24bppRgb))using(var graphics=Graphics.FromImage(canvas))using(var output=new MemoryStream()) {
     graphics.Clear(Color.FromArgb(13,18,26));graphics.DrawImageUnscaled(image,0,0);
     WriteJpeg(canvas,output);byte[] jpeg=output.ToArray();SharedCovers.ValidateJpeg(jpeg);return jpeg;
    }
   }
  }
  static void WriteJpeg(Image image,Stream output) {
   var codec=ImageCodecInfo.GetImageEncoders().First(c=>c.FormatID==ImageFormat.Jpeg.Guid);
   using(var parameters=new EncoderParameters(1)) {
    parameters.Param[0]=new EncoderParameter(System.Drawing.Imaging.Encoder.Quality,80L);
    image.Save(output,codec,parameters);
   }
  }
  static void SaveCanvas(Bitmap image,bool icon,string destination) {
   using(image)using(var canvas=new Bitmap(432,250))using(Graphics g=Graphics.FromImage(canvas)) {
    g.Clear(Color.FromArgb(13,18,26));g.InterpolationMode=InterpolationMode.HighQualityBicubic;
    double scale=icon?Math.Min(2,Math.Min(80.0/image.Width,80.0/image.Height)):Math.Min(432.0/image.Width,250.0/image.Height);
    int width=Math.Max(1,(int)(image.Width*scale)),height=Math.Max(1,(int)(image.Height*scale));
    g.DrawImage(image,(432-width)/2,(250-height)/2,width,height);
    if(String.Equals(Path.GetExtension(destination),".jpg",StringComparison.OrdinalIgnoreCase))using(var output=File.Create(destination))WriteJpeg(canvas,output);
    else canvas.Save(destination,ImageFormat.Png);
   }
  }
 }
}
