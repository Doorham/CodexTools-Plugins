using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace EverythingExclusions {
 internal static partial class Tests {
  static void PromotionChecks(string root,MainForm form,Controller model,string es,string instance,string data) {
   var client=model.Backend();var json=new JavaScriptSerializer();
   string parent=Path.Combine(data,"吞噬上级测试"),a=Path.Combine(parent,"缓存"),b=Path.Combine(parent,"预览"),outside=parent+"-other";
   string fa=MergeFile(a,"promotion-a.txt"),fb=MergeFile(b,"promotion-b.txt"),fo=MergeFile(outside,"promotion-outside.txt");
   Pump(Drop(form,new[]{fa,fb,fo}));WaitDom(form,"document.querySelectorAll('.card').length===3");
   var first=model.Cards.Single(c=>Util.Same(c.Folder,a));string coverHash=Hash(Path.Combine(model.StateRoot,first.Cover));
   string selector="document.querySelector('[data-promote=\""+first.Id+"\"]')";
   Check("promotion_button_visible_on_each_card",Convert.ToBoolean(Js(form,"document.querySelectorAll('.promote').length===3 && [...document.querySelectorAll('.promote')].every(b=>b.textContent==='吞噬上级'&&!b.disabled)")));
   string stateHash=Hash(Path.Combine(model.StateRoot,"cards.json"));int reload=client.ReloadCount;
   Js(form,selector+".click();true");WaitDom(form,"document.getElementById('promotion-dialog').open");
   Check("promotion_preview_target_and_sibling_count",Convert.ToBoolean(Js(form,"document.getElementById('promotion-parent').textContent==="+json.Serialize(parent)+" && document.querySelectorAll('#promotion-paths li').length===2")));
   Check("promotion_preview_does_not_change_state",Hash(Path.Combine(model.StateRoot,"cards.json"))==stateHash&&client.ReloadCount==reload);
   Pump(form.CapturePreview(Path.Combine(root,"promotion-confirmation.png")));
   Js(form,"document.getElementById('cancel-promotion').click();true");WaitDom(form,"!document.getElementById('promotion-dialog').open");
   Check("promotion_cancel_preserves_cards_and_rules",Hash(Path.Combine(model.StateRoot,"cards.json"))==stateHash&&client.ReloadCount==reload);
   // Promotion needs the registered directory and cached cover, not the original source file.
   File.Delete(fa);
   Js(form,selector+".click();true");WaitDom(form,"document.getElementById('promotion-dialog').open");
   Js(form,"document.getElementById('confirm-promotion').click();true");WaitDom(form,"!document.getElementById('promotion-dialog').open && !document.body.classList.contains('busy')");
   var promoted=model.Cards.Single(c=>Util.Same(c.Folder,parent));
   Check("promotion_merges_siblings_in_one_reload",model.Cards.Count==2&&model.LastMerged==2&&client.ReloadCount==reload+1);
   Check("promotion_removes_owned_child_rules",HasMergeRule(client,parent)&&!HasMergeRule(client,a)&&!HasMergeRule(client,b)&&HasMergeRule(client,outside));
   Check("promotion_keeps_cover_without_source_file",Hash(Path.Combine(model.StateRoot,promoted.Cover))==coverHash&&promoted.FileName=="promotion-a.txt");
   Check("promotion_persists_history",new Controller(model.StateRoot,client).Cards.Single(c=>c.Id==promoted.Id).MergedFolders.Count==2);
   Check("promotion_preserves_disk_files",File.Exists(fb)&&File.Exists(fo));
   WaitCount(es,instance,"promotion-b",0);WaitCount(es,instance,"promotion-outside",0);
   Pump(form.CapturePreview(Path.Combine(root,"promotion-result.png")));
   // Reuse an already registered parent instead of producing another card.
   string deeper=Path.Combine(parent,"deep"),deepFile=MergeFile(deeper,"promotion-deep.txt");
   string staleId=Guid.NewGuid().ToString("N");var stale=new CardItem{Id=staleId,Folder=deeper,Cover=staleId+".png",FileName=Path.GetFileName(deepFile)};
   File.Copy(Path.Combine(model.StateRoot,promoted.Cover),Path.Combine(model.StateRoot,stale.Cover));model.Cards.Add(stale);model.Save();client.Change(new[]{deeper},new string[0]);
   model.Promote(model.PlanPromotion(stale.Id));
   Check("promotion_reuses_existing_parent",model.Cards.Count==2&&model.Cards.Any(c=>c.Id==promoted.Id)&&!HasMergeRule(client,deeper));
   var plan=model.PlanPromotion(promoted.Id);model.Promote(plan);
   Check("promotion_steps_up_once_and_carries_history",model.Cards.Count==1&&Util.Same(model.Cards[0].Folder,data)&&model.Cards[0].MergedFolders.Any(p=>Util.Same(p,a)));
   ClearMergeCards(form,model);
   // A broad external rule is never silently claimed by a managed card.
   Pump(Drop(form,new[]{fb}));var child=model.Cards.Single();client.Change(new[]{parent},new string[0]);stateHash=Hash(Path.Combine(model.StateRoot,"cards.json"));
   bool rejected=false;try{model.Promote(model.PlanPromotion(child.Id));}catch(InvalidOperationException){rejected=true;}
   Check("promotion_preserves_external_parent",rejected&&Hash(Path.Combine(model.StateRoot,"cards.json"))==stateHash&&HasMergeRule(client,parent)&&HasMergeRule(client,b));
   ClearMergeCards(form,model);client.Change(new string[0],new[]{parent});
   // Verify save failure uses the existing transaction rollback.
   Pump(Drop(form,new[]{fb,fo}));var rollback=model.Cards.Single(c=>Util.Same(c.Folder,b));var originals=model.Cards.ToArray();var rules=MergeRules(client);var covers=MergeCovers(model);
   string stateFile=Path.Combine(model.StateRoot,"cards.json"),saved=stateFile+".promotion-saved";
   File.Move(stateFile,saved);Directory.CreateDirectory(stateFile);rejected=false;
   try{model.Promote(model.PlanPromotion(rollback.Id));}catch(IOException){rejected=true;}catch(UnauthorizedAccessException){rejected=true;}
   finally{Directory.Delete(stateFile);File.Move(saved,stateFile);}
   Check("promotion_save_failure_rolls_back",rejected&&model.Cards.SequenceEqual(originals)&&MergeRules(client).SequenceEqual(rules)&&MergeCovers(model).SequenceEqual(covers));
   ClearMergeCards(form,model);
   var rootCard=new CardItem{Id=Guid.NewGuid().ToString("N"),Folder=Path.GetPathRoot(data),Cover="missing.png"};model.Cards.Add(rootCard);form.PushState();
   WaitDom(form,"document.querySelector('.promote').disabled");rejected=false;try{model.PlanPromotion(rootCard.Id);}catch(InvalidOperationException){rejected=true;}
   Check("promotion_root_disabled_in_ui_and_backend",rejected&&Controller.ParentOf(@"\\server\share\")==null);
   model.Cards.Clear();form.PushState();
  }
 }
}
