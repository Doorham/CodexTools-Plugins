using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;
using System.Collections.Generic;

namespace EverythingExclusions {
    internal static class HangRepairTests {
        internal static int Run(string output, string executable = null) {
            var checks = new Dictionary<string, bool>();
            Action<string, bool> check = (name, ok) => { checks[name] = ok; if (!ok) throw new Exception(name); };
            string root = Path.Combine(Path.GetDirectoryName(Path.GetFullPath(output)), "repair-fixture-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(root);
            try {
                string source = "; untouched\r\n[Everything]\r\nlvm=1\r\nipc=1\r\nexclude_folders=C:\\test,regex:abc\r\n[Other]\r\nlvm=1\r\n";
                byte[] original = Util.Utf8.GetBytes(source);
                byte[] updated = HangRepair.Updated(original);
                check("only_everything_lvm_changes", Util.Utf8.GetString(updated) == source.Replace("lvm=1\r\nipc", "lvm=0\r\nipc"));
                check("idempotent_bytes", HangRepair.Updated(updated).SequenceEqual(updated));
                var bom = new byte[] {239,187,191}.Concat(original).ToArray();
                check("bom_preserved", HangRepair.Updated(bom).SequenceEqual(new byte[] {239,187,191}.Concat(updated)));
                string mixed = "[Everything]\r\nlvm=1\nother=unchanged\r\n";
                check("mixed_line_endings_preserved", Util.Utf8.GetString(HangRepair.Updated(Util.Utf8.GetBytes(mixed))) == mixed.Replace("lvm=1", "lvm=0"));
                string missing = "[Everything]\nipc=1\n[Other]\nlvm=1\n";
                check("missing_key_inserted_in_correct_section", Util.Utf8.GetString(HangRepair.Updated(Util.Utf8.GetBytes(missing))) == "[Everything]\nipc=1\nlvm=0\n[Other]\nlvm=1\n");
                check("missing_key_at_eof", Util.Utf8.GetString(HangRepair.Updated(Util.Utf8.GetBytes("[Everything]\nipc=1"))) == "[Everything]\nipc=1\nlvm=0\n");
                check("duplicate_keys_consistent", Util.Utf8.GetString(HangRepair.Updated(Util.Utf8.GetBytes("[Everything]\nLVM = 1\nlvm=1"))) == "[Everything]\nLVM = 0\nlvm=0");
                bool rejected = false; try { HangRepair.Updated(Util.Utf8.GetBytes("[Other]\nlvm=1")); } catch (InvalidDataException) { rejected = true; }
                check("wrong_section_rejected", rejected);
                rejected = false; try { HangRepair.Updated(new byte[] {255,255}); } catch (DecoderFallbackException) { rejected = true; }
                check("unknown_encoding_rejected", rejected);
                string config = Path.Combine(root, "Everything.ini"), backups = Path.Combine(root, "backups");
                File.WriteAllBytes(config, bom);
                string backup = HangRepair.WriteSetting(config, backups);
                check("original_backup_exact", File.ReadAllBytes(backup).SequenceEqual(bom));
                check("atomic_write_verified", File.ReadAllBytes(config).SequenceEqual(HangRepair.Updated(bom)));
                var client = new EverythingClient { Config = config, BackupRoot = backups, Executable = "must-not-launch.exe" };
                int prompts = 0;
                string result = HangRepair.Run(client, message => { prompts++; return false; }, message => { });
                check("already_applied_never_prompts_or_launches", prompts == 0 && result.Contains("无需"));
                check("already_applied_no_extra_backup", Directory.GetFiles(backups).Length == 1);
                File.WriteAllBytes(config, original);
                result = HangRepair.Run(client, message => false, message => { });
                check("cancel_keeps_original", result.Contains("取消") && File.ReadAllBytes(config).SequenceEqual(original));
                if (executable != null) {
                    var isolated = new EverythingClient { Executable = executable, Config = Path.Combine(root, "integration.ini"), Instance = "repair-test-" + Guid.NewGuid().ToString("N"), BackupRoot = Path.Combine(root, "integration-backups") };
                    File.WriteAllText(isolated.Config, "[Everything]\r\nrun_as_admin=0\r\nrun_in_background=1\r\nlvm=1\r\nipc=1\r\nexclude_folders=C:\\repair-fixture\r\nexclude_list_enabled=1\r\nntfs_volume_guids=\r\n", Util.Utf8);
                    try {
                        using (var started = isolated.Launch("-startup")) { }
                        isolated.WaitReady();
                        int oldPid = isolated.RunningPid();
                        string integrationResult = HangRepair.Run(isolated, message => true, message => { });
                        check("real_isolated_instance_restarted", isolated.RunningPid() != 0 && isolated.RunningPid() != oldPid);
                        check("real_isolated_setting_applied", HangRepair.IsApplied(isolated.Config));
                        check("real_isolated_exclusions_preserved", isolated.Excluded().SequenceEqual(new[] { @"C:\repair-fixture" }));
                        check("real_isolated_ipc_preserved", new Ini(File.ReadAllText(isolated.Config)).Get("ipc", "0") == "1");
                        byte[] after = File.ReadAllBytes(isolated.Config);
                        int afterPid = isolated.RunningPid();
                        HangRepair.Run(isolated, message => { throw new Exception("Unexpected prompt"); }, message => { });
                        check("real_repeat_preserves_pid_and_config", afterPid == isolated.RunningPid() && File.ReadAllBytes(isolated.Config).SequenceEqual(after));
                    } finally { using (var exit = isolated.Launch("-exit")) { if (exit != null) exit.WaitForExit(5000); } }
                }
                File.WriteAllText(output, new JavaScriptSerializer().Serialize(new { ok = true, checks = checks, count = checks.Count, fixtureOnly = true }), Util.Utf8);
                return 0;
            } catch (Exception error) {
                File.WriteAllText(output, new JavaScriptSerializer().Serialize(new { ok = false, checks = checks, error = error.ToString() }), Util.Utf8);
                return 1;
            }
        }
    }
}
