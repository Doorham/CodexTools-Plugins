using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;
namespace EverythingExclusions {
 internal sealed class SharedProfile {
  public int Version {get;set;} public string Author {get;set;} public List<string> Paths {get;set;} public string UpdatedUtc {get;set;}
  public string Key {get{return SharedProfiles.Key(Author);}}
  internal Dictionary<string,string> CoverHashes=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
  internal int CoverErrors;
  internal bool CoverIndexInvalid;
 }
 internal sealed class SharedCatalog {internal List<SharedProfile> Profiles=new List<SharedProfile>();internal int Invalid;}
 internal sealed class UploadResult {internal SharedProfile Profile;internal int Added,CoversUpdated;internal bool Created;}
 internal sealed class SharedProfiles {
  internal readonly string Root,AvailabilityRoot;
  internal SharedProfiles(string root,string availabilityRoot=null) {Root=Path.GetFullPath(root);AvailabilityRoot=availabilityRoot??Path.GetPathRoot(Root);}
  internal static SharedProfiles Default() {
   string company=Environment.GetEnvironmentVariable("CODEXTOOLS_COMPANY_ROOT");
   if(String.IsNullOrWhiteSpace(company))company=Path.Combine("Y:"+Path.DirectorySeparatorChar,"Development","Codexplugins");
   return new SharedProfiles(Path.Combine(company,"Configurations","EverythingExclusions"),company);
  }
  internal static string AuthorName(string author) {
   if(author==null)throw new InvalidDataException("请填写本次上传的署名。");
   string value=author.Trim().Normalize(NormalizationForm.FormC);
   if(!Regex.IsMatch(value,@"^[\p{L}\p{M}\p{N} _.-]{1,64}$")||value=="."||value==".."||value.EndsWith("."))throw new InvalidDataException("署名请使用 1–64 个字母、汉字、数字、空格、点、横线或下划线。");
   return value;
  }
  internal static string Key(string author) {
   using(var hash=SHA256.Create())return BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(AuthorName(author).ToUpperInvariant()))).Replace("-","").ToLowerInvariant();
  }
  internal static List<string> Paths(IEnumerable<string> paths) {
   if(paths==null)throw new InvalidDataException("配置缺少屏蔽目录。");
   var result=new List<string>();var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
   foreach(string raw in paths) {
    if(String.IsNullOrWhiteSpace(raw)||raw.Length>32760||raw.IndexOfAny(new[]{'*','?','\0','\r','\n','"','<','>','|'})>=0||raw.StartsWith(@"\\?\")||raw.StartsWith(@"\\.\")||!Regex.IsMatch(raw,@"^(?:[A-Za-z]:[\\/]|\\\\[^\\/]+[\\/][^\\/]+(?:[\\/]|$))"))throw new InvalidDataException("共享配置中包含无效目录，未应用任何规则。");
    string full=Util.Normalize(raw);
    if(full.Substring(2).Contains(":"))throw new InvalidDataException("共享配置目录格式无效。");
    if(seen.Add(full))result.Add(full);if(result.Count>10000)throw new InvalidDataException("单个配置最多保存 10000 个目录。");
   }
   return result;
  }
  void Available() {if(!Directory.Exists(AvailabilityRoot))throw new IOException("共享盘不可用，请连接 Y 盘后重试。");}
  string FileFor(string key) {if(key==null||!Regex.IsMatch(key,"^[a-f0-9]{64}$"))throw new InvalidDataException("请选择有效署名配置。");return Path.Combine(Root,key+".json");}
  internal SharedProfile Read(string key) {return ReadProfile(key,true);}
  SharedProfile ReadProfile(string key,bool readCovers) {
   Available();string path=FileFor(key);var info=new FileInfo(path);
   if(!info.Exists)throw new FileNotFoundException("该署名配置已不存在，请刷新列表。");
   if(info.Length>4*1024*1024)throw new InvalidDataException("共享配置过大，未读取。");
   SharedProfile profile;
   try {profile=new JavaScriptSerializer{MaxJsonLength=4*1024*1024}.Deserialize<SharedProfile>(File.ReadAllText(path,Util.Utf8));}
   catch(Exception error){throw new InvalidDataException("共享配置无法读取，原文件已保留。",error);}
   DateTimeOffset date;
   if(profile==null||profile.Version!=1||Key(profile.Author)!=key||!DateTimeOffset.TryParse(profile.UpdatedUtc,out date))throw new InvalidDataException("共享配置格式无效，原文件已保留。");
   profile.Author=AuthorName(profile.Author);profile.Paths=Paths(profile.Paths);
   if(readCovers) {
    try {profile.CoverHashes=SharedCovers.ReadIndex(Root,key,profile.Paths,false);}
    catch(Exception error) {
     if(!CoverFailure(error))throw;
     profile.CoverIndexInvalid=true;profile.CoverErrors++;
    }
   }
   return profile;
  }
  static bool CoverFailure(Exception error) {return error is IOException||error is InvalidDataException||error is UnauthorizedAccessException||error is ArgumentException||error is FormatException;}
  internal byte[] ReadCover(SharedProfile profile,string folder) {
   if(profile==null||profile.Paths==null)return null;
   string normalized=Paths(new[]{folder})[0],hash;
   if(!profile.Paths.Contains(normalized,StringComparer.OrdinalIgnoreCase)||!profile.CoverHashes.TryGetValue(normalized,out hash))return null;
   try {return SharedCovers.ReadBlob(Root,hash);}
   catch(Exception error) {if(!CoverFailure(error))throw;profile.CoverErrors++;return null;}
  }
  internal SharedCatalog List() {
   Available();var result=new SharedCatalog();if(!Directory.Exists(Root))return result;
   foreach(string file in Directory.EnumerateFiles(Root,"*.json").Take(1001)) {
    if(result.Profiles.Count+result.Invalid>=1000)throw new IOException("共享配置数量过多，请整理共享目录。");
    try {result.Profiles.Add(ReadProfile(Path.GetFileNameWithoutExtension(file),false));}catch(Exception error){if(!(error is IOException)&&!(error is InvalidDataException)&&!(error is ArgumentException)&&!(error is FormatException))throw;result.Invalid++;}
   }
   result.Profiles=result.Profiles.OrderBy(p=>p.Author,StringComparer.OrdinalIgnoreCase).ToList();return result;
  }
  internal UploadResult Upload(string author,IEnumerable<string> paths,Dictionary<string,byte[]> covers=null) {
   author=AuthorName(author);var incoming=Paths(paths);if(incoming.Count==0)throw new InvalidDataException("当前还没有可上传的屏蔽目录。");
   var incomingCovers=new Dictionary<string,byte[]>(StringComparer.OrdinalIgnoreCase);long uploadBytes=0;
   if(covers!=null)foreach(var pair in covers) {
    string folder=Paths(new[]{pair.Key})[0];
    if(!incoming.Contains(folder,StringComparer.OrdinalIgnoreCase)||incomingCovers.ContainsKey(folder))throw new InvalidDataException("共享封面必须对应本次上传的唯一屏蔽目录。");
    SharedCovers.ValidateJpeg(pair.Value);uploadBytes+=pair.Value.Length;
    if(uploadBytes>SharedCovers.MaxUploadBytes)throw new InvalidDataException("本次 JPG 封面合计不能超过 64 MB。");
    incomingCovers.Add(folder,pair.Value);
   }
   Available();Directory.CreateDirectory(Root);string key=Key(author),path=FileFor(key);FileStream gate=null;var timer=System.Diagnostics.Stopwatch.StartNew();
   while(gate==null) {
    try {gate=new FileStream(Path.Combine(Root,key+".lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);}
    catch(IOException){if(timer.ElapsedMilliseconds>=5000)throw new IOException("此署名正在上传，请稍后重试。");Thread.Sleep(60);}
   }
   using(gate) {
    bool created=!File.Exists(path);var profile=created?new SharedProfile{Version=1,Author=author,Paths=new List<string>(),UpdatedUtc=DateTimeOffset.UtcNow.ToString("o")}:ReadProfile(key,false);
    int count=profile.Paths.Count;var merged=Paths(profile.Paths.Concat(incoming));
    string indexFile=SharedCovers.IndexPath(Root,key);int coversUpdated=0;
    Dictionary<string,string> coverMap=null;
    if(incomingCovers.Count>0) {
     // Fail before touching either metadata file when an existing sidecar is
     // malformed. A paths-only upload never rewrites or clears the sidecar.
     // A previous process can stop after publishing the sidecar but before
     // publishing new paths. Retrying those same paths must complete that
     // transaction instead of permanently rejecting its ahead-of-profile map.
     coverMap=SharedCovers.ReadIndex(Root,key,merged,true);
     foreach(var pair in incomingCovers) {
      string hash=SharedCovers.Hash(pair.Value),oldHash;
      bool repaired=SharedCovers.StoreBlob(Root,hash,pair.Value);
      if(!coverMap.TryGetValue(pair.Key,out oldHash)||oldHash!=hash||repaired)coversUpdated++;
      coverMap[pair.Key]=hash;
     }
    }
    if(created||merged.Count!=count||coversUpdated>0) {
     string oldProfile=created?null:File.ReadAllText(path,Util.Utf8);
     string oldIndex=incomingCovers.Count==0||!File.Exists(indexFile)?null:File.ReadAllText(indexFile,Util.Utf8);
     bool indexWritten=false,profileWritten=false;
     try {
      // Publish validated blobs first, then atomically replace metadata. Until
      // the path file is replaced, readers ignore sidecar entries outside it.
      if(coversUpdated>0) {
       Util.Atomic(indexFile,SharedCovers.SerializeIndex(key,coverMap));indexWritten=true;
       var verify=SharedCovers.ReadIndex(Root,key,merged,true);
       if(verify.Count!=coverMap.Count||coverMap.Any(p=>!verify.ContainsKey(p.Key)||verify[p.Key]!=p.Value))throw new IOException("共享封面索引回读不一致。");
      }
      profile.Paths=merged;profile.UpdatedUtc=DateTimeOffset.UtcNow.ToString("o");
      // Keep precisely the version-1 payload consumed by existing clients.
      Util.Atomic(path,new JavaScriptSerializer{MaxJsonLength=4*1024*1024}.Serialize(new {Version=profile.Version,Author=profile.Author,Paths=profile.Paths,UpdatedUtc=profile.UpdatedUtc}));profileWritten=true;
      if(!ReadProfile(key,false).Paths.SequenceEqual(merged))throw new IOException("共享配置写入后的核对未通过。");
      foreach(var pair in incomingCovers)SharedCovers.ReadBlob(Root,coverMap[pair.Key]);
     } catch(Exception operationError) {
      try {
       if(profileWritten) {if(oldProfile==null)File.Delete(path);else Util.Atomic(path,oldProfile);}
       if(indexWritten) {if(oldIndex==null)File.Delete(indexFile);else Util.Atomic(indexFile,oldIndex);}
      } catch(Exception restoreError) {throw new IOException("共享上传未完成，原配置恢复也未完成；请重新连接共享盘后重试。恢复错误："+restoreError.Message,operationError);}
      throw new IOException("共享上传未完成，已保留原目录配置和封面索引，请重试。",operationError);
     }
    }
    var resultProfile=Read(key);
    return new UploadResult{Profile=resultProfile,Added=merged.Count-count,CoversUpdated=coversUpdated,Created=created};
   }
  }
 }
}
