using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Threading;
using System.Web.Script.Serialization;

namespace EverythingExclusions {
 internal static partial class Tests {
  static void QueueChecks(string root,MainForm form,Controller model,string es,string instance,string data) {
   var savedContext=SynchronizationContext.Current;SynchronizationContext.SetSynchronizationContext(null);
   int owner=Thread.CurrentThread.ManagedThreadId;bool stayedOnUi=true;
   var queue=new OperationQueue();queue.Changed=()=>{stayedOnUi&=Thread.CurrentThread.ManagedThreadId==owner;};
   var order=new List<int>();var start=new TaskCompletionSource<bool>();int active=0,maximum=0;
   var first=queue.Enqueue("a",async()=>{maximum=Math.Max(maximum,++active);order.Add(1);await start.Task;stayedOnUi&=Thread.CurrentThread.ManagedThreadId==owner;order.Add(2);active--;});
   var second=queue.Enqueue("b",()=>{maximum=Math.Max(maximum,++active);order.Add(3);active--;return Task.FromResult(true);});
   var duplicate=queue.Enqueue("b",()=>{throw new Exception("Duplicate executed");});
   var third=queue.Enqueue("c",()=>{maximum=Math.Max(maximum,++active);order.Add(4);active--;return Task.FromResult(true);});
   Check("queue_coalesces_pending_duplicate",Object.ReferenceEquals(second,duplicate)&&queue.WaitingCount==2&&queue.Keys.Length==3);
   Check("queue_waits_for_whole_async_operation",order.SequenceEqual(new[]{1})&&!second.IsCompleted);
   start.SetResult(true);Pump(Task.WhenAll(first,second,third));
   Check("queue_fifo_and_single_active",order.SequenceEqual(new[]{1,2,3,4})&&maximum==1&&!queue.IsBusy);
   Check("queue_restores_ui_thread_without_ambient_context",stayedOnUi);
   var failure=queue.Enqueue("fail",()=>{throw new IOException("fixture failure");});bool failed=false;
   try{Pump(failure);}catch(IOException){failed=true;}
   var recovered=queue.Enqueue("recover",()=>Task.FromResult(true));Pump(recovered);
   Check("queue_exception_releases_next_turn",failed&&recovered.Result&&!queue.IsBusy);
   start=new TaskCompletionSource<bool>();int ran=0;
   first=queue.Enqueue("cancel-active",async()=>{await start.Task;Check("queue_cancel_count",queue.CancelWaiting()==2);});
   second=queue.Enqueue("cancel-b",()=>{ran++;return Task.FromResult(true);});third=queue.Enqueue("cancel-c",()=>{ran++;return Task.FromResult(true);});
   start.SetResult(true);Pump(Task.WhenAll(first,second,third));
   Check("queue_cancel_only_waiting",first.Result&&!second.Result&&!third.Result&&ran==0&&!queue.IsBusy);
   start=new TaskCompletionSource<bool>();first=queue.Enqueue("bounded-active",()=>start.Task);
   var waiting=new List<Task<bool>>();for(int i=0;i<63;i++)waiting.Add(queue.Enqueue("limit-"+i,()=>Task.FromResult(true)));
   bool limited=false;try{queue.Enqueue("overflow",()=>Task.FromResult(true));}catch(InvalidOperationException){limited=true;}
   Check("queue_bounded_without_dropping_accepted",limited&&queue.Keys.Length==64&&queue.WaitingCount==63);
   queue.CancelWaiting();start.SetResult(true);Pump(first);Pump(Task.WhenAll(waiting));

   SynchronizationContext.SetSynchronizationContext(savedContext);ClearMergeCards(form,model);
   string parent=Path.Combine(data,"queue-fixture");
   string a=MergeFile(Path.Combine(parent,"a"),"queue-fixture-a.txt"),b=MergeFile(Path.Combine(parent,"b"),"queue-fixture-b.txt"),c=MergeFile(Path.Combine(parent,"c"),"queue-fixture-c.txt");
   Pump(Drop(form,new[]{a,b,c}));var cards=model.Cards.ToArray();var client=model.Backend();
   string idA=cards.Single(x=>Util.Same(x.Folder,Path.GetDirectoryName(a))).Id,idB=cards.Single(x=>Util.Same(x.Folder,Path.GetDirectoryName(b))).Id;
   var json=new JavaScriptSerializer();start=new TaskCompletionSource<bool>();first=form.Operations.Enqueue("fixture-hold",()=>start.Task);
   string selectA="document.querySelector('[data-remove=\""+idA+"\"]')",selectB="document.querySelector('[data-remove=\""+idB+"\"]')";
   Check("queue_other_remove_buttons_usable_while_busy",Convert.ToBoolean(Js(form,"!"+selectA+".disabled && !"+selectB+".disabled")));
   Js(form,selectA+".click();"+selectB+".click();send({type:'remove',id:"+json.Serialize(idA)+"});true");
   WaitDom(form,"currentState.queuedCount===2");
   Check("queue_html_same_card_disabled_immediately",Convert.ToBoolean(Js(form,selectA+".disabled && "+selectB+".disabled")));
   Check("queue_html_wait_count_visible",Convert.ToBoolean(Js(form,"document.getElementById('status-text').textContent.includes('等待 2 项')")));
   Check("queue_html_accepts_two_distinct_removes",form.Operations.WaitingCount==2&&model.Cards.Count==3);
   int reloads=client.ReloadCount;start.SetResult(true);Pump(first);
   WaitDom(form,"!currentState.busy && currentState.cards.length===1");
   Check("queue_html_removes_fifo_without_duplicate_reload",client.ReloadCount==reloads+2&&model.Cards.Count==1&&Util.Same(model.Cards[0].Folder,Path.GetDirectoryName(c)));
   WaitCount(es,instance,"queue-fixture-a",1);WaitCount(es,instance,"queue-fixture-b",1);WaitCount(es,instance,"queue-fixture-c",0);
   Check("queue_html_rules_match_remaining_card",true);
   ClearMergeCards(form,model);Pump(Drop(form,new[]{a,b}));
   idA=model.Cards.Single(x=>Util.Same(x.Folder,Path.GetDirectoryName(a))).Id;idB=model.Cards.Single(x=>Util.Same(x.Folder,Path.GetDirectoryName(b))).Id;
   form.PreparePromotion(idA);WaitDom(form,"document.getElementById('promotion-dialog').open");
   start=new TaskCompletionSource<bool>();first=form.Operations.Enqueue("fixture-hold-promote",()=>start.Task);
   Js(form,"send({type:'confirmPromotion',token:promotionToken});send({type:'remove',id:"+json.Serialize(idB)+"});true");
   WaitDom(form,"currentState.queuedCount===2");reloads=client.ReloadCount;start.SetResult(true);Pump(first);
   WaitDom(form,"!currentState.busy && !document.getElementById('promotion-dialog').open");
   Check("queue_revalidates_removed_id_after_promotion",model.Cards.Count==1&&Util.Same(model.Cards[0].Folder,parent)&&client.ReloadCount==reloads+1&&form.LastError==null);
   ClearMergeCards(form,model);Pump(Drop(form,new[]{a,b}));
   var originalCards=model.Cards.ToArray();string originalState=Hash(Path.Combine(model.StateRoot,"cards.json")),originalConfig=Hash(client.Config);var covers=MergeCovers(model);
   idA=originalCards.Single(x=>Util.Same(x.Folder,Path.GetDirectoryName(a))).Id;idB=originalCards.Single(x=>Util.Same(x.Folder,Path.GetDirectoryName(b))).Id;
   start=new TaskCompletionSource<bool>();first=form.Operations.Enqueue("fixture-hold-cancel",()=>start.Task);
   Js(form,"send({type:'remove',id:"+json.Serialize(idA)+"});send({type:'remove',id:"+json.Serialize(idB)+"});true");WaitDom(form,"currentState.queuedCount===2");
   var confirm=model.ConfirmForcedExit;int wait=client.ExitWaitMilliseconds,prompts=0;
   using(var target=Process.GetProcessById(client.RunningPid())) {
    Check("queue_cancel_fixture_isolated",!String.IsNullOrEmpty(client.Instance));
    Check("queue_cancel_fixture_suspended",NtSuspendProcess(target.Handle)==0);
    try {
     client.ExitWaitMilliseconds=250;model.ConfirmForcedExit=message=>{prompts++;return false;};
     start.SetResult(true);Pump(first);WaitDom(form,"!currentState.busy && currentState.error");
     Check("queue_cancel_stops_following_requests",prompts==1&&form.Operations.WaitingCount==0&&model.Cards.SequenceEqual(originalCards));
     Check("queue_cancel_preserves_config_state_covers",Hash(client.Config)==originalConfig&&Hash(Path.Combine(model.StateRoot,"cards.json"))==originalState&&MergeCovers(model).SequenceEqual(covers));
     Check("queue_cancel_explains_dropped_pending_request",Convert.ToBoolean(Js(form,"document.getElementById('status-text').textContent.includes('后续 1 项操作已取消')")));
    } finally {if(!target.HasExited)NtResumeProcess(target.Handle);client.ExitWaitMilliseconds=wait;model.ConfirmForcedExit=confirm;client.ConfirmForcedExit=confirm;}
   }
   ClearMergeCards(form,model);
  }
 }
}
