using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace EverythingExclusions {
 internal static partial class Tests {
  static byte[] CoverFixtureImage(Color color, int width=432, int height=250, bool png=false) {
   using(var bitmap=new Bitmap(width,height))using(var graphics=Graphics.FromImage(bitmap))using(var stream=new MemoryStream()) {
    graphics.Clear(color);graphics.FillRectangle(Brushes.White,width/5,height/3,width/3,Math.Max(1,height/5));
    bitmap.Save(stream,png?ImageFormat.Png:ImageFormat.Jpeg);return stream.ToArray();
   }
  }
  static Dictionary<string,byte[]> CoverFixtureMap(string folder,byte[] bytes) {
   return new Dictionary<string,byte[]>(StringComparer.OrdinalIgnoreCase){{folder,bytes}};
  }
  static bool CoverBytesEqual(byte[] first,byte[] second) {return first!=null&&second!=null&&first.SequenceEqual(second);}
  static void DeleteCoverFixtureFile(string root,string path) {
   string boundary=Path.GetFullPath(root).TrimEnd('\\','/')+Path.DirectorySeparatorChar;
   if(!Path.GetFullPath(path).StartsWith(boundary,StringComparison.OrdinalIgnoreCase))throw new Exception("Cover fixture cleanup escaped its root.");
   if(File.Exists(path))File.Delete(path);
  }
  static bool CoverRejected(Action action) {
   try {action();return false;}catch(InvalidDataException){return true;}catch(ArgumentException){return true;}
  }

  // Storage-only checks use a synthetic local share and never touch the default company store.
  internal static void RunSharedCoverChecks(string root) {
   string suite=Path.Combine(root,"shared-jpeg-store");Directory.CreateDirectory(suite);
   var store=new SharedProfiles(Path.Combine(suite,"profiles"),suite);
   string folderA=Path.Combine(suite,"source-a","frames"),folderB=Path.Combine(suite,"source-b","clips"),folderC=Path.Combine(suite,"old-client-addition");
   string author="封面测试",key=SharedProfiles.Key(author),profileFile=Path.Combine(store.Root,key+".json");
   byte[] first=CoverFixtureImage(Color.CornflowerBlue),second=CoverFixtureImage(Color.Coral);
   var pathsOnly=store.Upload(author,new[]{folderA,folderB});
   Check("jpeg_old_v1_paths_still_read_without_covers",pathsOnly.Profile.Version==1&&store.ReadCover(store.Read(key),folderA)==null);
   var added=store.Upload(author,new[]{folderA,folderB},CoverFixtureMap(folderA,first));
   Check("jpeg_existing_paths_can_receive_cover_without_new_path",added.Added==0&&added.CoversUpdated==1&&CoverBytesEqual(store.ReadCover(store.Read(key),folderA),first));
   var fields=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(profileFile));
   Check("jpeg_v1_public_path_payload_retains_exact_legacy_fields",fields.Keys.OrderBy(k=>k).SequenceEqual(new[]{"Author","Paths","UpdatedUtc","Version"}));
   Check("jpeg_index_does_not_pollute_legacy_profile_listing",Directory.GetFiles(store.Root,"*.json").Length==1&&store.List().Profiles.Count==1&&store.List().Invalid==0);

   string blob=Path.Combine(store.Root,"covers","blobs",SharedCovers.Hash(first)+".jpg");
   Check("jpeg_blob_has_jpeg_extension_and_actual_jpeg_bytes",File.Exists(blob)&&CoverBytesEqual(File.ReadAllBytes(blob),first)&&first[0]==0xff&&first[1]==0xd8);
   DateTime blobTime=File.GetLastWriteTimeUtc(blob);int blobs=Directory.GetFiles(Path.GetDirectoryName(blob),"*.jpg").Length;
   var repeated=store.Upload(author,new[]{folderA,folderB},CoverFixtureMap(folderA,first));
   Check("jpeg_duplicate_upload_preserves_bytes_and_write_time",repeated.Added==0&&repeated.CoversUpdated==0&&Directory.GetFiles(Path.GetDirectoryName(blob),"*.jpg").Length==blobs&&File.GetLastWriteTimeUtc(blob)==blobTime);

   string originCache=Path.Combine(suite,"source-machine-cover.jpg");File.WriteAllBytes(originCache,first);
   var remoteMachine=new SharedProfiles(store.Root,suite);DeleteCoverFixtureFile(suite,originCache);
   Check("jpeg_other_machine_reads_cover_after_origin_cache_removed",!File.Exists(originCache)&&CoverBytesEqual(remoteMachine.ReadCover(remoteMachine.Read(key),folderA),first));
   store.Upload(author,new[]{folderC});
   Check("jpeg_old_client_upload_keeps_existing_sidecar_cover",store.Read(key).Paths.Count==3&&CoverBytesEqual(store.ReadCover(store.Read(key),folderA),first));
   var replaced=store.Upload(author,new[]{folderA},CoverFixtureMap(folderA,second));
   Check("jpeg_same_path_reupload_can_replace_cover",replaced.Added==0&&replaced.CoversUpdated==1&&CoverBytesEqual(store.ReadCover(store.Read(key),folderA),second));

   string currentBlob=Path.Combine(store.Root,"covers","blobs",SharedCovers.Hash(second)+".jpg");
   File.WriteAllBytes(currentBlob,new byte[]{0xff,0xd8,0xff,0xd9});
   var corruptProfile=store.Read(key);
   Check("jpeg_corrupt_blob_falls_back_without_losing_paths",store.ReadCover(corruptProfile,folderA)==null&&corruptProfile.CoverErrors>0&&corruptProfile.Paths.Count==3);
   store.Upload(author,new[]{folderA},CoverFixtureMap(folderA,second));
   Check("jpeg_reupload_repairs_corrupt_same_hash_blob",CoverBytesEqual(store.ReadCover(store.Read(key),folderA),second));
   DeleteCoverFixtureFile(suite,currentBlob);var missingProfile=store.Read(key);
   Check("jpeg_missing_blob_falls_back_without_losing_paths",store.ReadCover(missingProfile,folderA)==null&&missingProfile.Paths.Count==3);
   store.Upload(author,new[]{folderA},CoverFixtureMap(folderA,second));

   string index=Path.Combine(store.Root,"covers",key+".json");string goodIndex=File.ReadAllText(index,Util.Utf8);
   File.WriteAllText(index,"broken cover index",Util.Utf8);
   var invalidIndex=store.Read(key);
   Check("jpeg_invalid_sidecar_still_allows_legacy_directory_sync",invalidIndex.CoverIndexInvalid&&invalidIndex.Paths.Count==3&&store.ReadCover(invalidIndex,folderA)==null&&store.List().Invalid==0);
   string damagedHash=Hash(index),pathHash=Hash(profileFile);
   Check("jpeg_upload_does_not_overwrite_damaged_cover_index",CoverRejected(()=>store.Upload(author,new[]{folderA},CoverFixtureMap(folderA,first)))&&Hash(index)==damagedHash&&Hash(profileFile)==pathHash);
   File.WriteAllText(index,goodIndex,Util.Utf8);

   var serializer=new JavaScriptSerializer();
   File.WriteAllText(index,serializer.Serialize(new {Version=1,ProfileKey=key,UpdatedUtc=DateTimeOffset.UtcNow.ToString("o"),Covers=new Dictionary<string,string>{{folderA,"../outside"}}}),Util.Utf8);
   var traversal=store.Read(key);
   Check("jpeg_cover_reference_cannot_escape_blob_directory",traversal.CoverIndexInvalid&&store.ReadCover(traversal,folderA)==null&&traversal.Paths.Count==3);
   File.WriteAllText(index,goodIndex,Util.Utf8);

   string beforeIndex=Hash(index),beforePaths=Hash(profileFile);
   byte[] oversize=new byte[SharedCovers.MaxBytes+1];Array.Copy(first,oversize,first.Length);
   Check("jpeg_oversize_upload_rejected_before_profile_changes",CoverRejected(()=>store.Upload(author,new[]{folderA},CoverFixtureMap(folderA,oversize)))&&Hash(index)==beforeIndex&&Hash(profileFile)==beforePaths);
   Check("jpeg_oversize_dimensions_rejected",CoverRejected(()=>SharedCovers.ValidateJpeg(CoverFixtureImage(Color.DarkCyan,SharedCovers.MaxWidth+1,SharedCovers.MaxHeight+1))));
   Check("jpeg_png_payload_rejected_from_shared_transport",CoverRejected(()=>SharedCovers.ValidateJpeg(CoverFixtureImage(Color.DarkCyan,432,250,true))));
   Check("jpeg_bad_payload_rejected_from_shared_transport",CoverRejected(()=>SharedCovers.ValidateJpeg(new byte[]{0xff,0xd8,1,2,3,0xff,0xd9})));
   Check("jpeg_cover_for_unsubmitted_directory_rejected",CoverRejected(()=>store.Upload(author,new[]{folderA},CoverFixtureMap(Path.Combine(suite,"not-in-upload"),first)))&&Hash(index)==beforeIndex&&Hash(profileFile)==beforePaths);
   Check("jpeg_valid_bounded_image_retains_exact_bytes",CoverBytesEqual(store.ReadCover(store.Read(key),folderA),second));
   bool blocked=false;
   using(var blockedProfile=new FileStream(profileFile,FileMode.Open,FileAccess.Read,FileShare.Read)) {
    try {store.Upload(author,new[]{folderA},CoverFixtureMap(folderA,first));}catch(IOException){blocked=true;}catch(UnauthorizedAccessException){blocked=true;}
   }
   Check("jpeg_failed_path_publish_restores_original_cover_index",blocked&&Hash(index)==beforeIndex&&Hash(profileFile)==beforePaths&&CoverBytesEqual(store.ReadCover(store.Read(key),folderA),second));
   string pendingFolder=Path.Combine(suite,"interrupted-new-path");
   var interrupted=serializer.Deserialize<SharedCoverIndex>(File.ReadAllText(index,Util.Utf8));interrupted.Covers[pendingFolder]=SharedCovers.Hash(first);
   File.WriteAllText(index,serializer.Serialize(interrupted),Util.Utf8);
   var beforeRecovery=store.Read(key);
   Check("jpeg_unpublished_sidecar_path_is_not_exposed_to_reader",beforeRecovery.Paths.Count==3&&!beforeRecovery.Paths.Contains(pendingFolder)&&store.ReadCover(beforeRecovery,pendingFolder)==null);
   var recovered=store.Upload(author,new[]{pendingFolder},CoverFixtureMap(pendingFolder,first));
   Check("jpeg_retry_completes_interrupted_sidecar_first_publication",recovered.Added==1&&recovered.CoversUpdated==0&&store.Read(key).Paths.Count==4&&CoverBytesEqual(store.ReadCover(store.Read(key),pendingFolder),first));

   var parallelStore=new SharedProfiles(Path.Combine(suite,"parallel-store"),suite);string parallelKey=SharedProfiles.Key("Parallel JPEG");
   Task.WaitAll(Task.Run(()=>parallelStore.Upload("Parallel JPEG",new[]{folderA},CoverFixtureMap(folderA,first))),Task.Run(()=>parallelStore.Upload("parallel jpeg",new[]{folderB},CoverFixtureMap(folderB,second))));
   var parallel=parallelStore.Read(parallelKey);
   Check("jpeg_concurrent_same_author_uploads_keep_both_paths_and_covers",parallel.Paths.Count==2&&CoverBytesEqual(parallelStore.ReadCover(parallel,folderA),first)&&CoverBytesEqual(parallelStore.ReadCover(parallel,folderB),second));

   string legacyRoot=Path.Combine(suite,"legacy-png-state");Directory.CreateDirectory(legacyRoot);
   string legacyId=Guid.NewGuid().ToString("N"),legacyPng=Path.Combine(legacyRoot,legacyId+".png");
   File.WriteAllBytes(legacyPng,CoverFixtureImage(Color.DarkOrchid,432,250,true));
   string pngHash=Hash(legacyPng);
   var oldCard=new CardItem{Id=legacyId,Folder=folderA,FileName="synthetic-file.psd",Cover=legacyId+".png",Scope="directory"};
   File.WriteAllText(Path.Combine(legacyRoot,"cards.json"),serializer.Serialize(new CardState{Version=1,Cards=new List<CardItem>{oldCard}}),Util.Utf8);
   var oldModel=new Controller(legacyRoot,null,store);
   Check("jpeg_old_png_cards_remain_readable_without_migration",oldModel.Cards.Count==1&&oldModel.Cards[0].Cover==oldCard.Cover&&Hash(legacyPng)==pngHash);
   var legacyUpload=oldModel.CoversForUpload();SharedCovers.ValidateJpeg(legacyUpload[folderA]);
   Check("jpeg_old_png_upload_converts_only_transport_copy",legacyUpload.Count==1&&legacyUpload[folderA][0]==0xff&&legacyUpload[folderA][1]==0xd8&&Hash(legacyPng)==pngHash&&oldModel.Cards[0].Cover==oldCard.Cover);
   Check("jpeg_compatible_existing_jpeg_is_not_reencoded",CoverBytesEqual(ShellPreview.JpegBytes(blob),first));
  }

  // Invoke only after the ordinary self-test has created its explicitly named Everything instance.
  internal static void RunSharedCoverControllerChecks(string root,EverythingClient client) {
   string boundary=Path.GetFullPath(root).TrimEnd('\\','/')+Path.DirectorySeparatorChar;
   if(client==null||String.IsNullOrEmpty(client.Instance)||!Path.GetFullPath(client.Config).StartsWith(boundary,StringComparison.OrdinalIgnoreCase))throw new Exception("Cover controller checks require the isolated named Everything fixture.");
   string suite=Path.Combine(root,"shared-jpeg-controller");Directory.CreateDirectory(suite);
   var store=new SharedProfiles(Path.Combine(suite,"profiles"),suite);
   var model=new Controller(Path.Combine(suite,"receiver-state"),client,store);
   string folder=Path.Combine(suite,"shared-frames"),native=Path.Combine(suite,"native-card"),author="JPEG Alice";
   byte[] first=CoverFixtureImage(Color.Teal),second=CoverFixtureImage(Color.Tomato);
   try {
    var initial=store.Upload(author,new[]{folder});int added=model.Import(store.Read(initial.Profile.Key));
    CardItem card=model.Cards.Single();
    Check("jpeg_shared_without_cover_keeps_usable_placeholder",added==1&&card.Scope=="shared"&&String.IsNullOrEmpty(card.SharedCoverHash)&&File.Exists(Path.Combine(model.StateRoot,card.Cover)));
    Check("jpeg_placeholder_is_not_republished_as_real_cover",model.CoversForUpload().Count==0);
    // Recreate a pre-1.7.4 shared placeholder in the isolated state, then sync it.
    string oldPlaceholder=Path.Combine(model.StateRoot,card.Id+".png");ShellPreview.SaveFolder(oldPlaceholder);
    DeleteCoverFixtureFile(suite,Path.Combine(model.StateRoot,card.Cover));card.Cover=card.Id+".png";model.Save();
    model=new Controller(model.StateRoot,client,store);card=model.Cards.Single();
    string oldPngHash=Hash(oldPlaceholder),oldCardsHash=Hash(Path.Combine(model.StateRoot,"cards.json"));
    store.Upload(author,new[]{folder},CoverFixtureMap(folder,first));int reload=client.ReloadCount;
    using(var blockedCards=new FileStream(Path.Combine(model.StateRoot,"cards.json"),FileMode.Open,FileAccess.Read,FileShare.Read))model.Import(store.Read(initial.Profile.Key));
    card=model.Cards.Single();
    Check("jpeg_failed_card_save_keeps_legacy_png_and_metadata",model.LastCoverWarnings>0&&card.Cover.EndsWith(".png",StringComparison.OrdinalIgnoreCase)&&String.IsNullOrEmpty(card.SharedCoverHash)&&Hash(oldPlaceholder)==oldPngHash&&Hash(Path.Combine(model.StateRoot,"cards.json"))==oldCardsHash&&!File.Exists(Path.Combine(model.StateRoot,card.Id+".jpg"))&&client.ReloadCount==reload);
    added=model.Import(store.Read(initial.Profile.Key));card=model.Cards.Single();
    Check("jpeg_existing_shared_card_receives_cover_without_rule_reload",added==0&&model.LastCoversUpdated==1&&client.ReloadCount==reload&&CoverBytesEqual(File.ReadAllBytes(Path.Combine(model.StateRoot,card.Cover)),first));
    Check("jpeg_old_shared_png_replaced_only_after_saved_jpg",!File.Exists(oldPlaceholder)&&new Controller(model.StateRoot,client,store).Cards.Single().Cover==card.Id+".jpg");
    Check("jpeg_imported_card_records_shared_hash_and_jpg_extension",card.Cover.EndsWith(".jpg",StringComparison.OrdinalIgnoreCase)&&card.SharedCoverHash==SharedCovers.Hash(first));
    var reopened=new Controller(model.StateRoot,client,store);
    Check("jpeg_shared_cover_metadata_survives_reopen",reopened.Cards.Single().SharedCoverHash==card.SharedCoverHash&&CoverBytesEqual(reopened.CoversForUpload()[folder],first));
    string cardsBefore=Hash(Path.Combine(model.StateRoot,"cards.json"));
    model.Import(store.Read(initial.Profile.Key));
    Check("jpeg_repeat_sync_is_noop_for_cards_rules_and_cache",model.LastCoversUpdated==0&&client.ReloadCount==reload&&Hash(Path.Combine(model.StateRoot,"cards.json"))==cardsBefore);
    store.Upload(author,new[]{folder},CoverFixtureMap(folder,second));model.Import(store.Read(initial.Profile.Key));card=model.Cards.Single();
    Check("jpeg_same_author_new_cover_updates_existing_card",model.LastCoversUpdated==1&&client.ReloadCount==reload&&CoverBytesEqual(File.ReadAllBytes(Path.Combine(model.StateRoot,card.Cover)),second));

    var other=store.Upload("JPEG Bob",new[]{folder},CoverFixtureMap(folder,first));
    model.Import(store.Read(other.Profile.Key));card=model.Cards.Single();
    Check("jpeg_another_author_cannot_replace_existing_shared_cover",model.LastCoversUpdated==0&&client.ReloadCount==reload&&card.Source==author&&CoverBytesEqual(File.ReadAllBytes(Path.Combine(model.StateRoot,card.Cover)),second));
    string broken=Path.Combine(store.Root,"covers","blobs",SharedCovers.Hash(second)+".jpg");File.WriteAllText(broken,"broken",Util.Utf8);
    model.Import(store.Read(initial.Profile.Key));card=model.Cards.Single();
    Check("jpeg_corrupt_remote_cover_preserves_local_cover_and_rule",model.LastCoverWarnings>0&&client.ReloadCount==reload&&CoverBytesEqual(File.ReadAllBytes(Path.Combine(model.StateRoot,card.Cover)),second)&&client.Excluded().Any(rule=>EverythingClient.SameLiteral(rule,folder)));

    Directory.CreateDirectory(native);string representative=Path.Combine(native,"representative.synthetic");File.WriteAllText(representative,"Synthetic file, not artwork.",Util.Utf8);model.Add(new[]{representative});
    CardItem nativeCard=model.Cards.Single(item=>Util.Same(item.Folder,native));string nativeHash=Hash(Path.Combine(model.StateRoot,nativeCard.Cover));reload=client.ReloadCount;
    var nativeShared=store.Upload("JPEG Native",new[]{native},CoverFixtureMap(native,first));model.Import(store.Read(nativeShared.Profile.Key));
    nativeCard=model.Cards.Single(item=>Util.Same(item.Folder,native));
    Check("jpeg_sync_never_overwrites_existing_local_card_cover",String.IsNullOrEmpty(nativeCard.Source)&&Hash(Path.Combine(model.StateRoot,nativeCard.Cover))==nativeHash&&client.ReloadCount==reload&&model.LastCoversUpdated==0);
    Check("jpeg_new_local_cards_use_jpeg_cache",nativeCard.Cover.EndsWith(".jpg",StringComparison.OrdinalIgnoreCase)&&File.ReadAllBytes(Path.Combine(model.StateRoot,nativeCard.Cover))[0]==0xff);
    string nativeCache=Path.Combine(model.StateRoot,nativeCard.Cover);byte[] savedNative=File.ReadAllBytes(nativeCache);
    try {
     File.WriteAllText(nativeCache,"bad local jpeg",Util.Utf8);var upload=model.CoversForUpload();
     Check("jpeg_corrupt_local_cache_is_skipped_without_aborting_upload",!upload.ContainsKey(native)&&model.LastCoverWarnings>0&&upload.ContainsKey(folder));
    } finally {File.WriteAllBytes(nativeCache,savedNative);}
   } finally {
    foreach(CardItem owned in model.Cards.ToArray())model.Remove(owned);
   }
  }
 }
}
