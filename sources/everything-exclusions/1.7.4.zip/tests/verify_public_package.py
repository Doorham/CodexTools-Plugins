import hashlib
import json
from pathlib import Path
import sys
import threading
from types import SimpleNamespace
from unittest.mock import patch

station = Path(sys.argv[1])
package = Path(sys.argv[2])
base = Path(sys.argv[3])
base.mkdir(parents=True, exist_ok=False)
sys.path.insert(0, str(station))
from core import control, tool_paths, plugin_hub, remote_plugins

checks = {}
def require(name, ok):
    checks[name] = bool(ok)
    if not ok:
        raise AssertionError(name)
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

service = object.__new__(control.ControlService)
service.root = station
service.repo_root = station.parents[3]
service.shared_root = base / 'data/plugins'
service.private_root = base / 'data/CodexTools/PrivatePlugins'
service.developer_root = base / 'data/CodexTools/DeveloperPlugins'
service.test_root = base / 'nas-test'
service._lock = threading.RLock()
service.private_errors = []
service.plugins = {}
service.company_access = SimpleNamespace(active=lambda *_: False)
service._plugin_pids = lambda _: []
hub = object.__new__(plugin_hub.PluginHub)
hub.root = station
hub.plugins_root = service.shared_root
hub.sources = [{'id': 'fixture-public', 'type': 'folder', 'path': str(package.parent), 'enabled': True}]
data = base / 'data'
version = tool_paths.APP_VERSION
with patch.object(control, 'TOOL_DATA_ROOT', data), patch.object(tool_paths, 'TOOL_DATA_ROOT', data), patch.object(control, 'developer_mode_enabled', return_value=False), patch.object(plugin_hub, 'CompanyAccess', lambda: SimpleNamespace(active=lambda: False, repository=lambda: None)):
    result = service.install_hub_plugin(hub, 'everything-exclusions', 'fixture-public')
    require('existing_client_installs_public_package', result['ok'])
    plugin = service.plugins['everything-exclusions']
    require('public_scope_without_developer_mode', plugin['_scope'] == 'shared')
    require('plugin_version_aligned', plugin['moduleVersion'] == '1.7.4')
    runtime = data / 'EverythingExclusions'
    require('exe_deployed_to_stable_runtime', digest(runtime / 'EverythingExclusions.exe') == digest(package / 'bin/EverythingExclusions.exe'))
    for name in ('Microsoft.Web.WebView2.Core.dll', 'Microsoft.Web.WebView2.WinForms.dll', 'WebView2Loader.dll', 'ui/index.html', 'ui/app.js', 'ui/style.css'):
        require('support_' + name, digest(runtime / name) == digest(package / 'bin' / name))
    require('download_folder_contains_no_state', not (service.shared_root / 'everything-exclusions/state').exists())
    state = runtime / 'state'
    state.mkdir()
    (state / 'cards.json').write_text('[]', encoding='utf-8')
    (state / 'cover.bin').write_bytes(b'synthetic cover kept local')
    before = {name: digest(state / name) for name in ('cards.json', 'cover.bin')}
    (runtime / 'ui/app.js').write_bytes(b'outdated synthetic UI')
    result = service.install_hub_plugin(hub, 'everything-exclusions', 'fixture-public', local_only=True)
    require('existing_client_reinstalls_declared_payload', result['ok'])
    require('ui_refreshed_without_client_update', digest(runtime / 'ui/app.js') == digest(package / 'bin/ui/app.js'))
    require('cards_and_covers_survive_plugin_replacement', all(digest(state / name) == value for name, value in before.items()))
    require('client_version_unchanged', tool_paths.APP_VERSION == version)
    require('only_one_public_card_registered', list(service.plugins) == ['everything-exclusions'])
    require('payload_is_current', not service.runtime_update_needed(service.plugins['everything-exclusions']))
report = {'ok': True, 'version': '1.7.4', 'clientVersion': version, 'fixtureOnly': True, 'userDataLoaded': False, 'checks': checks, 'checkCount': len(checks)}
(base / 'verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'ok': True, 'checks': len(checks), 'pluginVersion': '1.7.4', 'clientVersionUnchanged': version}))
