"use strict";
const bridge=window.chrome?.webview;
let busy=false, dragDepth=0, currentState={cards:[],profiles:[]};
const dropzone=document.getElementById("dropzone"),cards=document.getElementById("cards"),empty=document.getElementById("empty"),search=document.getElementById("card-search"),clear=document.getElementById("clear-search");
const send=message=>bridge?.postMessage(message);
window.addEventListener("contextmenu",event=>event.preventDefault());
for(const type of ["dragenter","dragover","dragleave","drop"])document.addEventListener(type,event=>event.preventDefault());
document.addEventListener("dragenter",event=>{if(!busy&&event.dataTransfer?.types.includes("Files")){dragDepth++;dropzone.classList.add("dragging");}});
document.addEventListener("dragover",event=>{if(event.dataTransfer)event.dataTransfer.dropEffect=busy?"none":"copy";});
document.addEventListener("dragleave",()=>{dragDepth=Math.max(0,dragDepth-1);if(!dragDepth)dropzone.classList.remove("dragging");});
document.addEventListener("drop",event=>{dragDepth=0;dropzone.classList.remove("dragging");if(busy)return;const files=Array.from(event.dataTransfer?.files||[]);if(files.length)bridge.postMessageWithAdditionalObjects({type:"drop"},files);});
document.getElementById("titlebar").addEventListener("mousedown",event=>{if(event.button===0&&!event.target.closest("button"))send({type:"dragWindow"});});
document.getElementById("titlebar").addEventListener("dblclick",event=>{if(!event.target.closest("button"))send({type:"maximize"});});
document.querySelectorAll("[data-window]").forEach(button=>button.addEventListener("click",()=>send({type:button.dataset.window})));
search.addEventListener("input",renderCards);
search.addEventListener("keydown",event=>{if(event.key==="Escape"){search.value="";renderCards();}});
clear.addEventListener("click",()=>{search.value="";renderCards();search.focus();});
function renderCards(){
 const query=search.value.trim().toLocaleLowerCase(),all=currentState.cards;
 const visible=all.filter(item=>!query||[item.title,item.fileName,item.path].some(value=>(value||"").toLocaleLowerCase().includes(query)));
 clear.hidden=!search.value;document.getElementById("search-count").textContent=query?`${visible.length} / ${all.length} 个文件夹`:"";
 empty.hidden=visible.length>0;document.getElementById("empty-title").textContent=all.length?"没有匹配的卡片":"这里还没有卡片";
 document.getElementById("empty-text").textContent=all.length?"换个关键词，或清空搜索查看全部。":"拖入一个文件，即可排除它所在的整个文件夹。";
 cards.replaceChildren();
 for(const item of visible){const fragment=document.getElementById("card-template").content.cloneNode(true),card=fragment.querySelector(".card");card.dataset.id=item.id;
  const title=fragment.querySelector(".folder-title");title.textContent=item.title;title.title=item.title;
  const name=fragment.querySelector(".image-name");name.textContent=item.fileName||(item.source?`${item.source} · 目录配置`:"未指定代表文件");name.title=name.textContent;fragment.querySelector(".file-label").textContent=item.fileName?"文件":"来源";
  const path=fragment.querySelector(".folder-path");path.textContent=item.path;path.title=item.path;
  const scope=fragment.querySelector(".cover-tag");scope.textContent={directory:"所在目录",parent:"上一级目录",shared:"共享目录"}[item.scope]||"所在目录";scope.title=`屏蔽范围：${scope.textContent}\n${item.path}`;
  const merged=fragment.querySelector(".merge-count");merged.hidden=!item.mergedCount;merged.textContent=`已合并 ${item.mergedCount||0} 项`;merged.title=(item.mergedPaths||[]).join("\n");
  const cover=fragment.querySelector(".cover");if(item.cover)cover.src=item.cover;else cover.hidden=true;
  const promote=fragment.querySelector(".promote");promote.dataset.promote=item.id;promote.disabled=busy||!item.parent;promote.title=item.parent?`扩大屏蔽至：${item.parent}`:"已经是磁盘或共享根目录";promote.addEventListener("click",()=>{if(!busy&&item.parent)send({type:"promote",id:item.id});});
  const remove=fragment.querySelector(".remove");remove.dataset.remove=item.id;remove.setAttribute("aria-label",`取消排除 ${item.title}`);remove.disabled=busy;remove.addEventListener("click",()=>{if(!busy)send({type:"remove",id:item.id});});cards.append(fragment);
 }
}
function render(state){
 currentState=state;busy=!!state.busy;document.body.classList.toggle("busy",busy);
 document.getElementById("count").textContent=state.cards.length;
 document.getElementById("confirm-exclusion").disabled=busy;document.getElementById("cancel-exclusion").disabled=busy;document.querySelectorAll("#scope-groups input").forEach(input=>input.disabled=busy||input.dataset.unavailable==="true");document.getElementById("open-sharing").disabled=busy;
 document.getElementById("confirm-promotion").disabled=busy;document.getElementById("cancel-promotion").disabled=busy;
 document.getElementById("count-small").textContent=String(state.cards.length).padStart(2,"0");renderCards();renderProfiles();
 const status=document.getElementById("status");status.classList.toggle("error",!!state.error);status.classList.toggle("busy",busy);document.getElementById("status-text").textContent=state.status;document.getElementById("status-text").title=state.status;
 document.body.dataset.ready="true";
}
const uploadDialog=document.getElementById("upload-dialog"),authorInput=document.getElementById("upload-author"),uploadError=document.getElementById("upload-error");
function authorHint(){
 const author=authorInput.value.trim().normalize("NFC"),existing=(currentState.profiles||[]).find(item=>item.author.toLocaleLowerCase()===author.toLocaleLowerCase());
 document.getElementById("author-hint").textContent=existing?`将追加到「${existing.author}」，保留原有目录并自动去重。`:author?`将创建「${author}」的新配置。`:"相同署名追加新目录，新署名创建配置。";
}
function renderProfiles(){
 const state=currentState,list=document.getElementById("profiles");list.replaceChildren();
 document.getElementById("share-status").textContent=state.shareStatus||"正在读取共享配置…";
 document.getElementById("share-status").classList.toggle("unavailable",!state.shareAvailable&&!state.shareLoading);
 document.getElementById("refresh-profiles").disabled=busy||state.shareLoading;document.getElementById("open-upload").disabled=busy;
 document.getElementById("upload-count").textContent=state.cards.length;authorInput.disabled=busy;document.getElementById("submit-upload").disabled=busy;document.getElementById("cancel-upload").disabled=busy;
 const authors=document.getElementById("known-authors");authors.replaceChildren();
 for(const profile of state.profiles||[]){
  const row=document.createElement("article");row.className="profile";
  const text=document.createElement("div"),name=document.createElement("b"),count=document.createElement("span");name.textContent=profile.author;name.title=profile.author;count.textContent=`${profile.count} 个目录`;text.append(name,count);
  const sync=document.createElement("button");sync.type="button";sync.className="secondary-button sync-profile";sync.textContent="一键同步";sync.dataset.profile=profile.key;sync.setAttribute("aria-label",`同步 ${profile.author} 的配置`);sync.disabled=busy||!state.shareAvailable;sync.addEventListener("click",()=>{if(!busy)send({type:"syncProfile",key:profile.key});});row.append(text,sync);list.append(row);
  const option=document.createElement("option");option.value=profile.author;authors.append(option);
 }
 authorHint();
}
document.getElementById("refresh-profiles").addEventListener("click",()=>{if(!busy)send({type:"refreshProfiles"});});
document.getElementById("open-upload").addEventListener("click",()=>{if(busy)return;authorInput.value="";uploadError.hidden=true;authorHint();uploadDialog.showModal();authorInput.focus();});
document.getElementById("cancel-upload").addEventListener("click",()=>{if(!busy)uploadDialog.close();});
uploadDialog.addEventListener("cancel",event=>{if(busy)event.preventDefault();});
authorInput.addEventListener("input",()=>{uploadError.hidden=true;authorHint();});
document.getElementById("upload-form").addEventListener("submit",event=>{event.preventDefault();if(!busy){uploadError.hidden=true;send({type:"uploadProfile",author:authorInput.value.trim()});}});
const sharingDialog=document.getElementById("sharing-dialog"),scopeDialog=document.getElementById("scope-dialog"),scopeGroups=document.getElementById("scope-groups"),scopeError=document.getElementById("scope-error");
let dropToken=null;
document.getElementById("open-sharing").addEventListener("click",()=>{if(!busy){sharingDialog.showModal();send({type:"refreshProfiles"});}});
document.getElementById("close-sharing").addEventListener("click",()=>sharingDialog.close());
function cancelExclusion(){if(busy)return;send({type:"cancelDrop",token:dropToken});dropToken=null;scopeDialog.close();}
document.getElementById("cancel-exclusion").addEventListener("click",cancelExclusion);
scopeDialog.addEventListener("cancel",event=>{if(busy)event.preventDefault();else{send({type:"cancelDrop",token:dropToken});dropToken=null;}});
function showScopeChoice(message){
 dropToken=message.token;scopeError.hidden=true;scopeGroups.replaceChildren();
 for(const item of message.items){
  const group=document.createElement("fieldset");group.className="scope-group";group.dataset.choice=item.id;
  const legend=document.createElement("legend");legend.textContent=item.fileName+(item.count>1?`（同目录 ${item.count} 个文件）`:"");legend.title=item.fileName;group.append(legend);
  for(const [value,title,path] of [["directory","屏蔽所在目录",item.folder],["parent","屏蔽上一级目录",item.parent]]){
   const label=document.createElement("label");label.className="scope-option";
   const radio=document.createElement("input");radio.type="radio";radio.name=`scope-${item.id}`;radio.value=value;radio.checked=value==="directory";radio.disabled=!path;radio.dataset.unavailable=String(!path);
   const text=document.createElement("span"),heading=document.createElement("b"),address=document.createElement("span");heading.textContent=title;address.className="scope-path";address.textContent=path||"所在目录已经是根目录，无上一级可选";text.append(heading,address);
   if(value==="parent"&&path){const hint=document.createElement("small");hint.textContent="包含所在目录及同级的其他文件夹";text.append(hint);}
   label.append(radio,text);group.append(label);
  }
  scopeGroups.append(group);
 }
 if(!scopeDialog.open)scopeDialog.showModal();
}
document.getElementById("scope-form").addEventListener("submit",event=>{
 event.preventDefault();if(busy||!dropToken)return;scopeError.hidden=true;
 const choices=[...scopeGroups.querySelectorAll("[data-choice]")].map(group=>({id:group.dataset.choice,scope:group.querySelector("input:checked").value}));
 send({type:"confirmDrop",token:dropToken,choices});
});
const promotionDialog=document.getElementById("promotion-dialog"),promotionError=document.getElementById("promotion-error");
let promotionToken=null;
function showPromotion(message){
 promotionToken=message.token;promotionError.hidden=true;
 document.getElementById("promotion-parent").textContent=message.parent;
 document.getElementById("promotion-summary").textContent=`将合并以下 ${message.paths.length} 张下级卡片${message.existing?"，并入已有父目录卡片":"，保留一张父目录卡片"}。`;
 document.getElementById("promotion-root-note").hidden=!message.root;
 const paths=document.getElementById("promotion-paths");paths.replaceChildren();
 for(const path of message.paths){const row=document.createElement("li");row.textContent=path;paths.append(row);}
 if(!promotionDialog.open)promotionDialog.showModal();
 document.getElementById("cancel-promotion").focus();
}
function cancelPromotion(){if(busy)return;send({type:"cancelPromotion",token:promotionToken});promotionToken=null;promotionDialog.close();}
document.getElementById("cancel-promotion").addEventListener("click",cancelPromotion);
promotionDialog.addEventListener("cancel",event=>{event.preventDefault();cancelPromotion();});
document.getElementById("promotion-form").addEventListener("submit",event=>{event.preventDefault();if(busy||!promotionToken)return;promotionError.hidden=true;send({type:"confirmPromotion",token:promotionToken});});
bridge.addEventListener("message",event=>{
 const message=event.data;
 if(message.type==="state")render(message);
 else if(message.type==="dropChoice")showScopeChoice(message);
 else if(message.type==="promotionChoice")showPromotion(message);
 else if(message.type==="promotionResult"){if(message.ok){promotionDialog.close();promotionToken=null;}else{promotionError.textContent=message.error;promotionError.hidden=false;}}
 else if(message.type==="dropResult"){if(message.ok){scopeDialog.close();dropToken=null;}else{scopeError.textContent=message.error;scopeError.hidden=false;}}
 else if(message.type==="uploadResult"){if(message.ok)uploadDialog.close();else{uploadError.textContent=message.error;uploadError.hidden=false;}}
});
send({type:"ready"});
