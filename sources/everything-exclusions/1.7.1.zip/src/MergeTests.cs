using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace EverythingExclusions {
 internal static partial class Tests {
  static string MergeFile(string folder,string name) {
   Directory.CreateDirectory(folder);string file=Path.Combine(folder,name);File.WriteAllText(file,"Synthetic merge fixture; no real user file.",Util.Utf8);return file;
  }
  static bool HasMergeRule(EverythingClient client,string folder) {return client.Excluded().Any(rule=>EverythingClient.SameLiteral(rule,folder));}
  static string[] MergeRules(EverythingClient client) {return client.Excluded().OrderBy(value=>value,StringComparer.OrdinalIgnoreCase).ToArray();}
  static string[] MergeCovers(Controller model) {return Directory.GetFiles(model.StateRoot,"*.png").Select(Path.GetFileName).OrderBy(value=>value,StringComparer.OrdinalIgnoreCase).ToArray();}
  static void ClearMergeCards(MainForm form,Controller model) {
   foreach(CardItem card in model.Cards.ToArray())model.Remove(card);form.PushState();WaitDom(form,"document.querySelectorAll('.card').length===0");
  }
  // Test-only rule seeding: the named instance has its own INI under the fresh fixture root.
  // This bypasses literal-only additions solely to exercise preservation of wildcard/regex rules.
  static void SeedMergeRules(string root,EverythingClient client,IEnumerable<string> additions) {
   string fixture=Path.GetFullPath(root).TrimEnd('\\','/')+Path.DirectorySeparatorChar;
   if(String.IsNullOrEmpty(client.Instance)||!Path.GetFullPath(client.Config).StartsWith(fixture,StringComparison.OrdinalIgnoreCase))throw new Exception("Merge rule seed is restricted to the isolated fixture.");
   using(var command=client.Launch("-exit")){if(command!=null)command.WaitForExit(5000);}
   var timer=Stopwatch.StartNew();while(client.RunningPid()!=0){if(timer.ElapsedMilliseconds>12000)throw new TimeoutException("Fixture did not stop for rule seed.");Thread.Sleep(30);}
   var ini=new Ini(File.ReadAllText(client.Config,Util.Utf8));var rules=Ini.ParseList(ini.Get("exclude_folders",""));rules.AddRange(additions);
   Util.Atomic(client.Config,ini.Set("exclude_folders",Ini.EncodeList(rules)));client.Launch("-startup");client.WaitReady();
  }
  static void MergeChecks(string root,MainForm form,Controller model,string es,string instance,string data,string manual) {
   string fixture=Path.GetFullPath(root).TrimEnd('\\','/')+Path.DirectorySeparatorChar;
   if(model.Cards.Count!=0||String.IsNullOrEmpty(instance)||model.Backend().Instance!=instance||!new[]{data,model.StateRoot,model.Backend().Config}.All(path=>Path.GetFullPath(path).StartsWith(fixture,StringComparison.OrdinalIgnoreCase)))throw new Exception("Merge checks require empty cards and the isolated named fixture and state.");
   Check("contains_normalizes_paths_and_uses_separator_boundaries",Util.Contains(@"C:\clips",@"c:\CLIPS\shot")&&!Util.Contains(@"C:\clips",@"C:\clips-other\shot")&&Util.Contains(@"C:\clips\",@"c:\clips")&&!Util.Contains(@"C:\clips",@"C:\clips",false)&&Util.Contains(@"C:\clips",@"C:\clips\temp\..\shot"));
   Check("contains_handles_drive_and_unc_roots",Util.Contains(@"C:\",@"C:\clips\shot")&&Util.Contains(@"\\server\share\",@"\\SERVER\SHARE\clips")&&!Util.Contains(@"\\server\share",@"\\server\share-other\clips"));
   var client=model.Backend();
   string suite=Path.Combine(data,"自动合并测试"),parent=Path.Combine(suite,"序列"),a=Path.Combine(parent,"镜头 A"),b=Path.Combine(parent,"镜头 B"),prefix=Path.Combine(suite,"序列-other"),manualChild=Path.Combine(parent,"手动保留规则");
   string fileA=MergeFile(a,"merge-case-a.txt"),fileB=MergeFile(b,"merge-case-b.txt"),prefixFile=MergeFile(prefix,"merge-prefix.txt"),choiceFile=MergeFile(Path.Combine(parent,"新镜头"),"merge-choice.txt"),manualFile=MergeFile(manualChild,"merge-manual.txt");
   string wildcard=Path.Combine(data,"merge-never-match-*"),regex="regex:^DOORHAM_MERGE_NEVER_MATCH_";
   SeedMergeRules(root,client,new[]{manualChild,wildcard,regex});WaitCount(es,instance,"merge-case-",2);WaitCount(es,instance,"merge-manual",0);
   Pump(Drop(form,new[]{fileA,fileB,prefixFile}));WaitDom(form,"document.querySelectorAll('.card').length===3");
   CardItem oldA=model.Cards.Single(card=>Util.Same(card.Folder,a)),oldB=model.Cards.Single(card=>Util.Same(card.Folder,b)),oldPrefix=model.Cards.Single(card=>Util.Same(card.Folder,prefix));
   string[] removedCovers={Path.Combine(model.StateRoot,oldA.Cover),Path.Combine(model.StateRoot,oldB.Cover)};int reload=client.ReloadCount;
   Pump(Drop(form,new[]{choiceFile},"parent"));WaitDom(form,"document.querySelectorAll('.card').length===2");CardItem merged=model.Cards.Single(card=>Util.Same(card.Folder,parent));
   Check("parent_choice_merges_two_managed_child_cards",model.LastMerged==2&&model.Cards.Count==2&&client.ReloadCount==reload+1);
   Check("merged_parent_replaces_only_owned_exact_child_rules",HasMergeRule(client,parent)&&!HasMergeRule(client,a)&&!HasMergeRule(client,b)&&HasMergeRule(client,prefix));
   Check("same_name_prefix_sibling_is_not_merged",Object.ReferenceEquals(oldPrefix,model.Cards.Single(card=>Util.Same(card.Folder,prefix))));
   Check("merged_parent_records_removed_child_paths",merged.MergedFolders!=null&&merged.MergedFolders.Count==2&&new[]{a,b}.All(path=>merged.MergedFolders.Any(value=>Util.Same(value,path))));
   Check("successful_merge_removes_old_covers_and_keeps_parent_cover",removedCovers.All(path=>!File.Exists(path))&&File.Exists(Path.Combine(model.StateRoot,merged.Cover))&&File.Exists(Path.Combine(model.StateRoot,oldPrefix.Cover)));
   var reopened=new Controller(model.StateRoot,client);CardItem saved=reopened.Cards.Single(card=>Util.Same(card.Folder,parent));
   Check("merged_path_history_persists_after_reopen",saved.Id==merged.Id&&saved.MergedFolders!=null&&saved.MergedFolders.Count==2&&new[]{a,b}.All(path=>saved.MergedFolders.Any(value=>Util.Same(value,path))));
   WaitCount(es,instance,"merge-case-",0);WaitCount(es,instance,"merge-prefix",0);WaitCount(es,instance,"merge-choice",0);
   reload=client.ReloadCount;string stateHash=Hash(Path.Combine(model.StateRoot,"cards.json"));string[] covers=MergeCovers(model);
   Pump(Drop(form,new[]{fileA}));Check("active_managed_parent_skips_child_without_reload",model.Cards.Count==2&&client.ReloadCount==reload&&model.LastMerged==0&&Hash(Path.Combine(model.StateRoot,"cards.json"))==stateHash&&MergeCovers(model).SequenceEqual(covers));

   var profile=new SharedProfile{Version=1,Author="Merge Fixture",UpdatedUtc=DateTimeOffset.UtcNow.ToString("o"),Paths=new List<string>{suite,a}};
   int imported=model.Import(profile);form.PushState();WaitDom(form,"document.querySelectorAll('.card').length===1");CardItem importedParent=model.Cards.Single();
   Check("shared_import_uses_same_parent_merge_behavior",imported==1&&model.LastMerged==2&&Util.Same(importedParent.Folder,suite)&&importedParent.Source=="Merge Fixture"&&HasMergeRule(client,suite)&&!HasMergeRule(client,parent)&&!HasMergeRule(client,prefix));
   Check("later_merge_keeps_accumulated_descendant_history",importedParent.MergedFolders!=null&&new[]{parent,prefix,a,b}.All(path=>importedParent.MergedFolders.Any(value=>Util.Same(value,path))));
   Pump(form.CapturePreview(Path.Combine(root,"merged-card.png")));
   Js(form,"document.querySelector('[data-remove]').click();true");WaitDom(form,"document.querySelectorAll('.card').length===0 && !document.body.classList.contains('busy')");
   WaitCount(es,instance,"merge-case-",2);WaitCount(es,instance,"merge-prefix",1);WaitCount(es,instance,"merge-choice",1);WaitCount(es,instance,"merge-manual",0);
   Check("removing_merged_parent_restores_results_without_old_child_rules",model.Cards.Count==0&&!HasMergeRule(client,suite)&&!HasMergeRule(client,parent)&&!HasMergeRule(client,a)&&!HasMergeRule(client,b)&&!HasMergeRule(client,prefix));

   string batchParent=Path.Combine(data,"批次合并"),batchChild=Path.Combine(batchParent,"深层","子目录"),batchChildFile=MergeFile(batchChild,"merge-batch-child.txt"),batchParentFile=MergeFile(Path.Combine(batchParent,"父级代表"),"merge-batch-parent.txt");
   for(int order=0;order<2;order++) {
    var outer=new ChosenFile{File=batchParentFile,Scope="parent"};var inner=new ChosenFile{File=batchChildFile,Scope="directory"};
    int count=model.Add(order==0?new[]{inner,outer}:new[]{outer,inner});form.PushState();WaitDom(form,"document.querySelectorAll('.card').length===1");
    Check("batch_parent_child_order_"+order+"_keeps_only_outer_path",count==1&&model.Cards.Count==1&&Util.Same(model.Cards[0].Folder,batchParent)&&HasMergeRule(client,batchParent)&&!HasMergeRule(client,batchChild)&&MergeCovers(model).Length==1);
    ClearMergeCards(form,model);
   }

   string externalParent=Path.Combine(data,"外部父规则"),externalChild=Path.Combine(externalParent,"已有子卡"),externalFile=MergeFile(externalChild,"merge-external-child.txt"),externalChoice=MergeFile(Path.Combine(externalParent,"新代表"),"merge-external-choice.txt");
   Pump(Drop(form,new[]{externalFile}));CardItem retained=model.Cards.Single();client.Change(new[]{externalParent},new string[0]);reload=client.ReloadCount;stateHash=Hash(Path.Combine(model.StateRoot,"cards.json"));covers=MergeCovers(model);
   Pump(Drop(form,new[]{externalChoice},"parent"));
   Check("manual_parent_is_not_claimed_or_used_to_swallow_existing_child",model.Cards.Count==1&&Object.ReferenceEquals(model.Cards[0],retained)&&client.ReloadCount==reload&&model.LastMerged==0&&HasMergeRule(client,externalParent)&&HasMergeRule(client,externalChild)&&Hash(Path.Combine(model.StateRoot,"cards.json"))==stateHash&&MergeCovers(model).SequenceEqual(covers));
   ClearMergeCards(form,model);client.Change(new string[0],new[]{externalParent});

   string rollbackParent=Path.Combine(data,"合并回滚"),rollbackA=Path.Combine(rollbackParent,"原卡 A"),rollbackB=Path.Combine(rollbackParent,"原卡 B"),rollbackFileA=MergeFile(rollbackA,"merge-rollback-a.txt"),rollbackFileB=MergeFile(rollbackB,"merge-rollback-b.txt"),rollbackChoice=MergeFile(Path.Combine(rollbackParent,"新增代表"),"merge-rollback-choice.txt");
   Pump(Drop(form,new[]{rollbackFileA,rollbackFileB}));CardItem[] originals=model.Cards.ToArray();string[] originalRules=MergeRules(client);string[] originalCovers=MergeCovers(model);string[] coverHashes=originals.Select(card=>Hash(Path.Combine(model.StateRoot,card.Cover))).ToArray();
   string stateFile=Path.Combine(model.StateRoot,"cards.json"),savedState=Path.Combine(model.StateRoot,"merge-test-saved-cards.json");stateHash=Hash(stateFile);bool failed=false;
   Stage(form,new[]{rollbackChoice});Js(form,"document.querySelector('#scope-groups input[value=parent]').checked=true;true");
   File.Move(stateFile,savedState);Directory.CreateDirectory(stateFile);
   try {
    Js(form,"document.getElementById('confirm-exclusion').click();true");WaitDom(form,"!document.getElementById('scope-error').hidden && !document.body.classList.contains('busy')");failed=form.LastError!=null;
   } finally {
    if(Directory.Exists(stateFile))Directory.Delete(stateFile);if(File.Exists(savedState))File.Move(savedState,stateFile);
    Js(form,"document.getElementById('cancel-exclusion').click();true");WaitDom(form,"!document.getElementById('scope-dialog').open");
   }
   Check("failed_merge_restores_original_card_objects_and_order",failed&&model.Cards.Count==originals.Length&&model.Cards.Select((card,index)=>Object.ReferenceEquals(card,originals[index])).All(value=>value));
   Check("failed_merge_restores_rules_without_parent",MergeRules(client).SequenceEqual(originalRules)&&!HasMergeRule(client,rollbackParent));
   Check("failed_merge_preserves_old_covers_and_removes_candidate_cover",MergeCovers(model).SequenceEqual(originalCovers)&&originals.Select(card=>Hash(Path.Combine(model.StateRoot,card.Cover))).SequenceEqual(coverHashes));
   Check("failed_merge_leaves_saved_card_state_unchanged",Hash(stateFile)==stateHash&&new Controller(model.StateRoot,client).Cards.Select(card=>card.Id).SequenceEqual(originals.Select(card=>card.Id)));
   WaitCount(es,instance,"merge-rollback-a",0);WaitCount(es,instance,"merge-rollback-b",0);WaitCount(es,instance,"merge-rollback-choice",1);ClearMergeCards(form,model);
   Check("all_merge_operations_preserve_external_rules",HasMergeRule(client,manual)&&HasMergeRule(client,manualChild)&&client.Excluded().Contains(wildcard)&&client.Excluded().Contains(regex));
  }
 }
}
