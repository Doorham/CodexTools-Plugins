using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;
namespace EverythingExclusions {
 internal sealed class SharedProfile {
  public int Version {get;set;} public string Author {get;set;} public List<string> Paths {get;set;} public string UpdatedUtc {get;set;}
  public string Key {get{return SharedProfiles.Key(Author);}}
 }
 internal sealed class SharedCatalog {internal List<SharedProfile> Profiles=new List<SharedProfile>();internal int Invalid;}
 internal sealed class UploadResult {internal SharedProfile Profile;internal int Added;internal bool Created;}
 internal sealed class SharedProfiles {
  internal readonly string Root,AvailabilityRoot;
  internal SharedProfiles(string root,string availabilityRoot=null) {Root=Path.GetFullPath(root);AvailabilityRoot=availabilityRoot??Path.GetPathRoot(Root);}
  internal static SharedProfiles Default() {
   string company=Environment.GetEnvironmentVariable("CODEXTOOLS_COMPANY_ROOT");
   if(String.IsNullOrWhiteSpace(company))company=Path.Combine("Y:"+Path.DirectorySeparatorChar,"Development","Codexplugins");
   return new SharedProfiles(Path.Combine(company,"Configurations","EverythingExclusions"),company);
  }
  internal static string AuthorName(string author) {
   if(author==null)throw new InvalidDataException("请填写本次上传的署名。");
   string value=author.Trim().Normalize(NormalizationForm.FormC);
   if(!Regex.IsMatch(value,@"^[\p{L}\p{M}\p{N} _.-]{1,64}$")||value=="."||value==".."||value.EndsWith("."))throw new InvalidDataException("署名请使用 1–64 个字母、汉字、数字、空格、点、横线或下划线。");
   return value;
  }
  internal static string Key(string author) {
   using(var hash=SHA256.Create())return BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(AuthorName(author).ToUpperInvariant()))).Replace("-","").ToLowerInvariant();
  }
  internal static List<string> Paths(IEnumerable<string> paths) {
   if(paths==null)throw new InvalidDataException("配置缺少屏蔽目录。");
   var result=new List<string>();var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
   foreach(string raw in paths) {
    if(String.IsNullOrWhiteSpace(raw)||raw.Length>32760||raw.IndexOfAny(new[]{'*','?','\0','\r','\n','"','<','>','|'})>=0||raw.StartsWith(@"\\?\")||raw.StartsWith(@"\\.\")||!Regex.IsMatch(raw,@"^(?:[A-Za-z]:[\\/]|\\\\[^\\/]+[\\/][^\\/]+(?:[\\/]|$))"))throw new InvalidDataException("共享配置中包含无效目录，未应用任何规则。");
    string full=Util.Normalize(raw);
    if(full.Substring(2).Contains(":"))throw new InvalidDataException("共享配置目录格式无效。");
    if(seen.Add(full))result.Add(full);if(result.Count>10000)throw new InvalidDataException("单个配置最多保存 10000 个目录。");
   }
   return result;
  }
  void Available() {if(!Directory.Exists(AvailabilityRoot))throw new IOException("共享盘不可用，请连接 Y 盘后重试。");}
  string FileFor(string key) {if(key==null||!Regex.IsMatch(key,"^[a-f0-9]{64}$"))throw new InvalidDataException("请选择有效署名配置。");return Path.Combine(Root,key+".json");}
  internal SharedProfile Read(string key) {
   Available();string path=FileFor(key);var info=new FileInfo(path);
   if(!info.Exists)throw new FileNotFoundException("该署名配置已不存在，请刷新列表。");
   if(info.Length>4*1024*1024)throw new InvalidDataException("共享配置过大，未读取。");
   SharedProfile profile;
   try {profile=new JavaScriptSerializer{MaxJsonLength=4*1024*1024}.Deserialize<SharedProfile>(File.ReadAllText(path,Util.Utf8));}
   catch(Exception error){throw new InvalidDataException("共享配置无法读取，原文件已保留。",error);}
   DateTimeOffset date;
   if(profile==null||profile.Version!=1||Key(profile.Author)!=key||!DateTimeOffset.TryParse(profile.UpdatedUtc,out date))throw new InvalidDataException("共享配置格式无效，原文件已保留。");
   profile.Author=AuthorName(profile.Author);profile.Paths=Paths(profile.Paths);return profile;
  }
  internal SharedCatalog List() {
   Available();var result=new SharedCatalog();if(!Directory.Exists(Root))return result;
   foreach(string file in Directory.EnumerateFiles(Root,"*.json").Take(1001)) {
    if(result.Profiles.Count+result.Invalid>=1000)throw new IOException("共享配置数量过多，请整理共享目录。");
    try {result.Profiles.Add(Read(Path.GetFileNameWithoutExtension(file)));}catch(Exception error){if(!(error is IOException)&&!(error is InvalidDataException)&&!(error is ArgumentException)&&!(error is FormatException))throw;result.Invalid++;}
   }
   result.Profiles=result.Profiles.OrderBy(p=>p.Author,StringComparer.OrdinalIgnoreCase).ToList();return result;
  }
  internal UploadResult Upload(string author,IEnumerable<string> paths) {
   author=AuthorName(author);var incoming=Paths(paths);if(incoming.Count==0)throw new InvalidDataException("当前还没有可上传的屏蔽目录。");
   Available();Directory.CreateDirectory(Root);string key=Key(author),path=FileFor(key);FileStream gate=null;var timer=System.Diagnostics.Stopwatch.StartNew();
   while(gate==null) {
    try {gate=new FileStream(Path.Combine(Root,key+".lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);}
    catch(IOException){if(timer.ElapsedMilliseconds>=5000)throw new IOException("此署名正在上传，请稍后重试。");Thread.Sleep(60);}
   }
   using(gate) {
    bool created=!File.Exists(path);var profile=created?new SharedProfile{Version=1,Author=author,Paths=new List<string>(),UpdatedUtc=DateTimeOffset.UtcNow.ToString("o")}:Read(key);
    int count=profile.Paths.Count;var merged=Paths(profile.Paths.Concat(incoming));
    if(created||merged.Count!=count) {
     profile.Paths=merged;profile.UpdatedUtc=DateTimeOffset.UtcNow.ToString("o");
     // Atomic replacement plus a per-signature SMB share lock prevents concurrent uploads from losing additions.
     Util.Atomic(path,new JavaScriptSerializer{MaxJsonLength=4*1024*1024}.Serialize(new {Version=profile.Version,Author=profile.Author,Paths=profile.Paths,UpdatedUtc=profile.UpdatedUtc}));
     if(!Read(key).Paths.SequenceEqual(merged))throw new IOException("共享配置写入后的核对未通过，请刷新后重试。");
    }
    return new UploadResult{Profile=profile,Added=profile.Paths.Count-count,Created=created};
   }
  }
 }
}
