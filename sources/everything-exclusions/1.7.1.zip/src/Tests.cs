using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
namespace EverythingExclusions {
 internal static partial class Tests {
  static Dictionary<string,bool> checks=new Dictionary<string,bool>();
  static void Check(string name,bool value) { checks[name]=value;if(!value)throw new Exception(name); }
  static string Hash(string path) { using(var h=SHA256.Create()) return Convert.ToBase64String(h.ComputeHash(File.ReadAllBytes(path))); }
  static Task Drop(MainForm form,string[] files,string scope="directory") {
   SynchronizationContext.SetSynchronizationContext(new WindowsFormsSynchronizationContext());Pump(form.DropFiles(files));
   if(form.LastError!=null)return Task.FromResult(false);
   WaitDom(form,"document.getElementById('scope-dialog').open");
   if(scope!="directory")Js(form,"document.querySelectorAll('#scope-groups input[value="+scope+"]').forEach(input=>input.checked=true);true");
   Js(form,"document.getElementById('confirm-exclusion').click();true");WaitDom(form,"!document.getElementById('scope-dialog').open || !document.getElementById('scope-error').hidden");
   if(form.LastError!=null)throw new Exception(form.LastError);return Task.FromResult(true);
  }
  static void Stage(MainForm form,string[] files) {SynchronizationContext.SetSynchronizationContext(new WindowsFormsSynchronizationContext());Pump(form.DropFiles(files));if(form.LastError!=null)throw new Exception(form.LastError);WaitDom(form,"document.getElementById('scope-dialog').open");}
  static void Confirm(MainForm form) {Js(form,"document.getElementById('confirm-exclusion').click();true");WaitDom(form,"!document.getElementById('scope-dialog').open || !document.getElementById('scope-error').hidden");if(form.LastError!=null)throw new Exception(form.LastError);}

  static Task Refresh(MainForm form) { SynchronizationContext.SetSynchronizationContext(new WindowsFormsSynchronizationContext());return form.RefreshShared(); }
  static Task Sync(MainForm form,string key) { SynchronizationContext.SetSynchronizationContext(new WindowsFormsSynchronizationContext());return form.SyncProfile(key); }
  static void Pump(Task task) { var watch=Stopwatch.StartNew();while(!task.IsCompleted) {Application.DoEvents();Thread.Sleep(15);if(watch.ElapsedMilliseconds>45000)throw new TimeoutException("UI test timed out");}task.GetAwaiter().GetResult();Application.DoEvents(); }
  static object Js(MainForm form,string script) { var task=form.Evaluate(script);Pump(task);return new JavaScriptSerializer().DeserializeObject(task.Result); }
  static void WaitDom(MainForm form,string expression) {var watch=Stopwatch.StartNew();while(!Convert.ToBoolean(Js(form,expression))){Application.DoEvents();Thread.Sleep(35);if(watch.ElapsedMilliseconds>10000)throw new Exception("HTML state did not update: "+expression);}}
  static int Count(string es,string instance,string query) {
   using(var p=Process.Start(new ProcessStartInfo(es,"-instance "+Util.Quote(instance)+" -timeout 10000 -get-result-count -search "+Util.Quote(query)){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true})) {
    string output=p.StandardOutput.ReadToEnd().Trim();string error=p.StandardError.ReadToEnd();if(!p.WaitForExit(15000)||p.ExitCode!=0)throw new Exception("ES fixture query failed: "+error);
    int count;if(!Int32.TryParse(output,out count))throw new Exception("Invalid ES count: "+output);return count;
   }
  }
  static void WaitCount(string es,string instance,string query,int expected) {
   var watch=Stopwatch.StartNew();int actual=-1;
   while(watch.ElapsedMilliseconds<15000) {try{actual=Count(es,instance,query);if(actual==expected)return;}catch{if(watch.ElapsedMilliseconds>12000)throw;}Thread.Sleep(150);}
   throw new Exception("Fixture count mismatch "+query+": "+actual+" expected "+expected);
  }
  static void ProfileStoreChecks(string root) {
   var store=new SharedProfiles(Path.Combine(root,"store-tests"),root);
   var first=store.Upload("doorham",new[]{@"C:\示例, 目录",@"\\server\share\frames"});
   Check("new_signature_creates_shared_profile",first.Created&&first.Profile.Paths.Count==2);
   var again=store.Upload(" Doorham ",new[]{@"c:\示例, 目录\",@"D:\new"});
   Check("same_signature_case_insensitive_append_and_deduplicate",!again.Created&&again.Added==1&&again.Profile.Paths.Count==3&&store.List().Profiles.Count==1);
   Check("same_signature_preserves_first_display_spelling",again.Profile.Author=="doorham");
   Task.WaitAll(Task.Run(()=>store.Upload("DOORHAM",new[]{@"E:\parallel-one"})),Task.Run(()=>store.Upload("doorham",new[]{@"F:\parallel-two"})));
   Check("concurrent_uploads_keep_both_additions",store.Read(first.Profile.Key).Paths.Count==5);
   store.Upload("其他人",new[]{@"G:\other"});Check("different_signature_creates_separate_profile",store.List().Profiles.Count==2);
   string profileFile=Path.Combine(store.Root,first.Profile.Key+".json");var fields=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(profileFile));
   Check("shared_payload_contains_only_signature_paths_and_metadata",fields.Keys.OrderBy(k=>k).SequenceEqual(new[]{"Author","Paths","UpdatedUtc","Version"}));
   string saved=Hash(profileFile);bool invalid=false;try{store.Upload("doorham",new[]{"relative-path"});}catch(InvalidDataException){invalid=true;}Check("invalid_shared_path_rejected_before_write",invalid&&saved==Hash(profileFile));
   invalid=false;try{store.Upload("../../outside",new[]{@"C:\valid"});}catch(InvalidDataException){invalid=true;}Check("signature_cannot_escape_store",invalid);
   invalid=false;try{store.Read("../outside");}catch(InvalidDataException){invalid=true;}Check("profile_key_cannot_escape_store",invalid);
   invalid=false;try{store.Upload("empty",new string[0]);}catch(InvalidDataException){invalid=true;}Check("empty_upload_not_created",invalid&&store.List().Profiles.Count==2);
   string corruptKey=SharedProfiles.Key("损坏配置"),corruptFile=Path.Combine(store.Root,corruptKey+".json");File.WriteAllText(corruptFile,"broken json");string corruptHash=Hash(corruptFile);
   invalid=false;try{store.Upload("损坏配置",new[]{@"C:\valid"});}catch(InvalidDataException){invalid=true;}Check("corrupt_same_signature_never_overwritten",invalid&&corruptHash==Hash(corruptFile));
   Check("catalog_keeps_valid_profiles_and_reports_invalid",store.List().Profiles.Count==2&&store.List().Invalid==1);
   string unavailable=Path.Combine(root,"unavailable-drive");invalid=false;try{new SharedProfiles(Path.Combine(unavailable,"profiles"),unavailable).Upload("test",new[]{@"C:\valid"});}catch(IOException){invalid=true;}Check("unavailable_share_fails_without_creating_store",invalid&&!Directory.Exists(unavailable));
  }
  static void NasStoreChecks(string artifactRoot) {
   string target=Environment.GetEnvironmentVariable("CODEXTOOLS_TEST_SHARED_ROOT");if(String.IsNullOrEmpty(target))return;
   var defaults=SharedProfiles.Default();string allowed=Path.Combine(Path.GetDirectoryName(defaults.Root),".validation")+Path.DirectorySeparatorChar;target=Path.GetFullPath(target);
   if(!target.StartsWith(allowed,StringComparison.OrdinalIgnoreCase)||Directory.Exists(target))throw new Exception("NAS test requires a fresh dedicated validation directory.");
   var store=new SharedProfiles(target,defaults.AvailabilityRoot);string key=SharedProfiles.Key("self-test");
   try {
    var created=store.Upload("self-test",new[]{Path.Combine(artifactRoot,"synthetic-a")});
    Check("nas_real_share_profile_create_and_readback",created.Created&&store.Read(key).Paths.Count==1);
    store.Upload("SELF-TEST",new[]{Path.Combine(artifactRoot,"synthetic-b")});
    Check("nas_real_share_atomic_append",store.Read(key).Paths.Count==2);
    Task.WaitAll(Task.Run(()=>store.Upload("self-test",new[]{Path.Combine(artifactRoot,"synthetic-c")})),Task.Run(()=>store.Upload("self-test",new[]{Path.Combine(artifactRoot,"synthetic-d")})));
    Check("nas_real_share_concurrent_append",store.Read(key).Paths.Count==4);
   } finally {
    foreach(string suffix in new[]{".json",".lock"}) {string file=Path.Combine(target,key+suffix);if(File.Exists(file))File.Delete(file);}
    if(Directory.Exists(target)&&!Directory.EnumerateFileSystemEntries(target).Any())Directory.Delete(target);
   }
  }
  internal static int Run(string root,string exe,string es) {
   EverythingClient client=null;MainForm form=null;bool ok=false,fixtureCreated=false;string error=null;
   int realPid=0;string realHash=null;string realConfig=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"Everything","Everything.ini");
   try {
    root=Path.GetFullPath(root);string allowed=Path.Combine(Path.GetPathRoot(root),"Works","CodexTools","artifacts")+Path.DirectorySeparatorChar;
    if(!root.StartsWith(allowed,StringComparison.OrdinalIgnoreCase)||Directory.Exists(root))throw new Exception("Self test requires a fresh directory below CodexTools artifacts.");
    Directory.CreateDirectory(root);fixtureCreated=true;ProfileStoreChecks(root);NasStoreChecks(root);
    string publicRuntime=Path.Combine(root,"public-runtime"),localData=Path.Combine(root,"local-data");
    string publicState=Path.Combine(publicRuntime,"state"),legacyState=Path.Combine(localData,"CodexTools","CodexTools","PrivatePlugins","private-everything-exclusions","state");
    Check("public_fresh_install_uses_owned_runtime_state",Program.StateRoot(publicRuntime,localData)==publicState);
    Directory.CreateDirectory(legacyState);File.WriteAllText(Path.Combine(legacyState,"cards.json"),"[]");
    Check("public_reuses_legacy_cards_in_place",Program.StateRoot(publicRuntime,localData)==legacyState);
    Directory.CreateDirectory(publicState);File.WriteAllText(Path.Combine(publicState,"cards.json"),"[]");
    Check("public_owned_state_takes_priority",Program.StateRoot(publicRuntime,localData)==publicState);
    Check("state_selection_does_not_move_or_delete_legacy",File.Exists(Path.Combine(legacyState,"cards.json")));
    IntPtr real=Native.Ipc("");uint pid;if(real!=IntPtr.Zero){Native.GetWindowThreadProcessId(real,out pid);realPid=(int)pid;}if(File.Exists(realConfig))realHash=Hash(realConfig);
    var values=new[]{@"C:\plain",@"C:\序列帧, with spaces",@"\\server\share\序列"};
    Check("ini_comma_unicode_unc_roundtrip",Ini.ParseList(Ini.EncodeList(values)).SequenceEqual(values));
    var ini=new Ini("[Everything]\r\nexclude_folders=C:\\old\r\nuntouched=keep-this\r\n[Other]\r\nexclude_folders=other-section\r\n");
    string changed=ini.Set("exclude_folders","C:\\new");Check("ini_preserves_other_settings_and_sections",changed.Contains("untouched=keep-this")&&changed.Contains("[Other]\r\nexclude_folders=other-section"));
    Check("windows_command_line_quotes",Util.Quote(@"C:\a b\")=="\"C:\\a b\\\\\"" && Util.Quote("a\"b")=="\"a\\\"b\"");
    string data=Path.Combine(root,"files");string frames=Path.Combine(data,"序列帧, 样例");string nested=Path.Combine(frames,"子文件夹");string manual=Path.Combine(data,"原有排除");
    Directory.CreateDirectory(nested);Directory.CreateDirectory(manual);
    string image=Path.Combine(frames,"noise-frame-0001.png"),child=Path.Combine(nested,"noise-frame-0002.png");
    using(var bitmap=new Bitmap(640,360)) using(var g=Graphics.FromImage(bitmap)) using(var brush=new LinearGradientBrush(new Rectangle(0,0,640,360),Color.FromArgb(60,94,166),Color.FromArgb(170,202,228),30)) using(var font=new Font("Segoe UI",38,FontStyle.Bold)) {
     g.FillRectangle(brush,0,0,640,360);g.DrawString("FRAME 0001",font,Brushes.White,38,135);bitmap.Save(image,ImageFormat.Png);
    }
    File.Copy(image,child);File.Copy(image,Path.Combine(frames,"other-cover.png"));File.Copy(image,Path.Combine(data,"keep-frame.png"));File.Copy(image,Path.Combine(manual,"manual-frame.png"));
    string config=Path.Combine(root,"Everything.ini");string instance="DoorhamExclusionsTest"+Guid.NewGuid().ToString("N");
    string conf="[Everything]\r\napp_data=0\r\nrun_as_admin=0\r\nrun_in_background=1\r\nauto_include_fixed_volumes=0\r\nauto_include_removable_volumes=0\r\nauto_include_fixed_refs_volumes=0\r\nauto_include_removable_refs_volumes=0\r\nntfs_volume_guids=\r\nrefs_volume_guids=\r\nfolders="+Ini.EncodeList(new[]{data})+"\r\nfolder_monitor_changes=1\r\nexclude_list_enabled=1\r\nexclude_folders="+Ini.EncodeList(new[]{manual})+"\r\ndb_location="+root+"\r\n";
    File.WriteAllText(config,conf,Util.Utf8);
    client=new EverythingClient{Executable=exe,Config=config,Instance=instance,BackupRoot=Path.Combine(root,"backups")};client.Launch("-startup");client.WaitReady();
    WaitCount(es,instance,"noise-frame-",2);Check("real_everything_indexes_fixture",true);WaitCount(es,instance,"manual-frame",0);Check("preexisting_rule_active",true);
    var model=new Controller(Path.Combine(root,"state"),client,new SharedProfiles(Path.Combine(root,"ui-shared"),root));form=new MainForm(model);SynchronizationContext.SetSynchronizationContext(new WindowsFormsSynchronizationContext());form.Show();Pump(form.Ready.Task);WaitDom(form,"document.body.dataset.ready === 'true'");
    Pump(Drop(form,new[]{image}));Check("drop_creates_one_card",model.Cards.Count==1);WaitCount(es,instance,"noise-frame-",0);Check("excluded_parent_and_child_results_disappear",true);
    WaitCount(es,instance,"keep-frame",1);Check("unrelated_results_remain",true);Check("backups_contain_only_exclusion_fields",Directory.GetFiles(client.BackupRoot).All(f=>f.EndsWith(".json") && new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(f)).Keys.OrderBy(k=>k).SequenceEqual(new[]{"exclude_folders","exclude_list_enabled"})));
    var item=model.Cards[0];Check("card_title_is_folder_name",item.FolderName=="序列帧, 样例");Check("image_filename_preserved",item.FileName=="noise-frame-0001.png");Check("cached_thumbnail_exists",File.Exists(Path.Combine(model.StateRoot,item.Cover)));
    if(form.LastError!=null)throw new Exception(form.LastError);
    WaitDom(form,"document.querySelectorAll('.card').length === 1");
    var json=new JavaScriptSerializer();
    Check("rendered_card_displays_both_names",Convert.ToBoolean(Js(form,"document.querySelector('.folder-title').textContent === "+json.Serialize(item.FolderName)+" && document.querySelector('.image-name').textContent === "+json.Serialize(item.FileName))));
    Check("cross_is_visible_and_not_overlapping_cover",Convert.ToBoolean(Js(form,"(()=>{const x=document.querySelector('.remove').getBoundingClientRect();const cover=document.querySelector('.cover-wrap').getBoundingClientRect();return x.width>0&&x.height>0&&x.bottom<cover.top;})()")));
    Check("actual_html_dark_background",Convert.ToBoolean(Js(form,"getComputedStyle(document.body).backgroundColor === 'rgb(12, 15, 21)' && getComputedStyle(document.querySelector('.card')).backgroundColor === 'rgb(20, 25, 34)'")));
    Check("custom_dark_window_controls_present",Convert.ToBoolean(Js(form,"document.querySelectorAll('[data-window]').length === 3")));
    Check("native_file_drop_bridge_available",Convert.ToBoolean(Js(form,"typeof chrome.webview.postMessageWithAdditionalObjects === 'function'")));
    Js(form,"document.querySelector('[data-window=maximize]').click();true");
    var windowTimer=Stopwatch.StartNew();while(form.WindowState!=FormWindowState.Maximized){Application.DoEvents();Thread.Sleep(20);if(windowTimer.ElapsedMilliseconds>5000)throw new Exception("HTML maximize failed");}
    Check("html_maximize_respects_working_area",Screen.FromHandle(form.Handle).WorkingArea.Contains(form.RectangleToScreen(form.ClientRectangle)));
    Js(form,"document.querySelector('[data-window=maximize]').click();true");
    windowTimer.Restart();while(form.WindowState!=FormWindowState.Normal){Application.DoEvents();Thread.Sleep(20);if(windowTimer.ElapsedMilliseconds>5000)throw new Exception("HTML restore failed");}
    Check("html_restore_button_works",true);
    Pump(form.CapturePreview(Path.Combine(root,"preview.png")));

    int reload=client.ReloadCount;Pump(Drop(form,new[]{Path.Combine(frames,"other-cover.png")}));Check("duplicate_folder_no_card_or_reload",model.Cards.Count==1&&client.ReloadCount==reload);
    var reopened=new Controller(model.StateRoot,client);Check("cards_persist_after_reopen",reopened.Cards.Count==1&&reopened.Cards[0].Id==item.Id);
    File.Move(image,image+".moved");File.Move(image+".moved",image);Check("source_image_not_locked",true);
    Js(form,"document.querySelector('[data-remove]').click();true");var timer=Stopwatch.StartNew();while(form.Busy || model.Cards.Count!=0){Application.DoEvents();Thread.Sleep(15);if(timer.ElapsedMilliseconds>45000)throw new TimeoutException("remove HTML button timed out");}WaitDom(form,"document.querySelectorAll('.card').length === 0");
    Check("cross_removes_card",model.Cards.Count==0);WaitCount(es,instance,"noise-frame-",2);Check("cancel_restores_parent_and_child_results",true);WaitCount(es,instance,"manual-frame",0);Check("cancel_preserves_preexisting_rule",client.Excluded().Any(p=>EverythingClient.SameLiteral(p,manual)));
    Check("removed_card_stays_removed_after_reopen",new Controller(model.StateRoot,client).Cards.Count==0);
    // Dragging a path already excluded outside this plugin must not claim ownership.
    Pump(Drop(form,new[]{Path.Combine(manual,"manual-frame.png")}));Check("manual_rule_not_claimed",model.Cards.Count==0);Check("manual_rule_still_present",client.Excluded().Any(p=>EverythingClient.SameLiteral(p,manual)));
    string[] folders={"音频收藏","设计草稿","其他素材","无扩展名"};
    string[] names={"track-mock.MP3","draft-mock.psd","project-mock.custom","README"};
    var representatives=new List<string>();
    for(int i=0;i<names.Length;i++) {string folder=Path.Combine(data,folders[i]);Directory.CreateDirectory(folder);string path=Path.Combine(folder,names[i]);File.WriteAllText(path,"Representative only: intentionally not decodable media.",Util.Utf8);representatives.Add(path);}
    string[] originalHashes=representatives.Select(Hash).ToArray();
    foreach(string name in names)WaitCount(es,instance,name,1);
    Pump(Drop(form,representatives.ToArray()));if(form.LastError!=null)throw new Exception(form.LastError);
    Check("arbitrary_files_audio_psd_unknown_extensionless_accepted",model.Cards.Count==4&&names.All(n=>model.Cards.Any(c=>c.FileName==n)));
    foreach(string name in names)WaitCount(es,instance,name,0);Check("arbitrary_file_parent_paths_excluded",true);
    WaitDom(form,"document.querySelectorAll('.card').length === 4 && [...document.querySelectorAll('.cover')].every(image=>image.complete && image.naturalWidth>0)");
    Check("windows_preview_or_icon_does_not_require_decodable_contents",true);
    Check("all_cards_display_folder_and_file_names",Convert.ToBoolean(Js(form,"[...document.querySelectorAll('.card')].every(card=>card.querySelector('.folder-title').textContent && card.querySelector('.image-name').textContent)")));
    Check("no_format_whitelist_in_ui",Convert.ToBoolean(Js(form,"document.querySelector('.formats').textContent.includes('不限文件格式')")));
    Pump(form.CapturePreview(Path.Combine(root,"files-and-search.png")));
    int searchReload=client.ReloadCount;string stateHash=Hash(Path.Combine(model.StateRoot,"cards.json"));
    Js(form,"document.getElementById('card-search').value='音频';document.getElementById('card-search').dispatchEvent(new Event('input'));true");
    Check("search_matches_folder_name",Convert.ToBoolean(Js(form,"document.querySelectorAll('.card').length===1 && document.querySelector('.folder-title').textContent==='音频收藏'")));
    Js(form,"document.getElementById('card-search').value='TRACK-MOCK.mp3';document.getElementById('card-search').dispatchEvent(new Event('input'));true");
    Check("search_matches_filename_case_insensitively",Convert.ToBoolean(Js(form,"document.querySelectorAll('.card').length===1 && document.querySelector('.image-name').textContent==='track-mock.MP3'")));
    form.PushState();Application.DoEvents();
    WaitDom(form,"document.getElementById('card-search').value === 'TRACK-MOCK.mp3' && document.querySelectorAll('.card').length === 1");Check("search_preserved_across_host_updates",true);
    Js(form,"document.getElementById('card-search').value="+json.Serialize(data+Path.DirectorySeparatorChar)+";document.getElementById('card-search').dispatchEvent(new Event('input'));true");
    Check("search_matches_full_folder_path",Convert.ToBoolean(Js(form,"document.querySelectorAll('.card').length===4")));
    Js(form,"document.getElementById('card-search').value='no matching card';document.getElementById('card-search').dispatchEvent(new Event('input'));true");
    Check("search_no_match_explains_empty_state",Convert.ToBoolean(Js(form,"document.querySelectorAll('.card').length===0 && !document.getElementById('empty').hidden && document.getElementById('empty-title').textContent==='没有匹配的卡片' && document.getElementById('search-count').textContent==='0 / 4 个文件夹'")));
    Check("search_does_not_change_rules_cards_or_state",client.ReloadCount==searchReload&&model.Cards.Count==4&&stateHash==Hash(Path.Combine(model.StateRoot,"cards.json")));
    Js(form,"document.getElementById('clear-search').click();true");Check("clear_search_restores_all_cards",Convert.ToBoolean(Js(form,"document.querySelectorAll('.card').length===4 && document.getElementById('clear-search').hidden")));
    Js(form,"document.getElementById('card-search').value='draft-mock.psd';document.getElementById('card-search').dispatchEvent(new Event('input'));true");
    Pump(form.CapturePreview(Path.Combine(root,"search-filtered.png")));
    Js(form,"document.querySelector('[data-remove]').click();true");timer.Restart();while(form.Busy||model.Cards.Count!=3){Application.DoEvents();Thread.Sleep(15);if(timer.ElapsedMilliseconds>45000)throw new TimeoutException("Filtered card cancellation timed out");}
    WaitCount(es,instance,"draft-mock.psd",1);WaitCount(es,instance,"track-mock.MP3",0);WaitDom(form,"document.querySelectorAll('.card').length===0");Check("filtered_cross_restores_only_selected_folder",true);
    Check("old_v1_card_state_remains_compatible",new Controller(model.StateRoot,client).Cards.Count==3);
    Js(form,"document.getElementById('card-search').dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}));true");Check("escape_clears_filter",Convert.ToBoolean(Js(form,"document.querySelectorAll('.card').length===3 && document.getElementById('card-search').value===''")));
    foreach(CardItem remaining in model.Cards.ToArray())model.Remove(remaining);form.PushState();
    foreach(string name in names)WaitCount(es,instance,name,1);Check("arbitrary_file_cancel_restores_search",true);
    Check("representative_files_bytes_unchanged",representatives.Select(Hash).SequenceEqual(originalHashes));
    foreach(string path in representatives){File.Move(path,path+".moved");File.Move(path+".moved",path);}Check("representative_files_not_locked",true);
    int beforeMissing=client.ReloadCount;Pump(Drop(form,new[]{Path.Combine(data,"missing.file")}));Check("missing_file_does_not_add_rule",model.Cards.Count==0&&client.ReloadCount==beforeMissing&&form.LastError!=null);
    Check("original_manual_rule_survives_arbitrary_file_operations",client.Excluded().Any(p=>EverythingClient.SameLiteral(p,manual)));
    Check("requested_headline_removed",Convert.ToBoolean(Js(form,"!document.body.textContent.includes('让搜索结果，清爽一点') && !document.querySelector('h1')")));
    WaitDom(form,"!document.getElementById('refresh-profiles').disabled");
    string shareFolderA=Path.Combine(data,"共享目录 A"),shareFolderB=Path.Combine(data,"共享目录 B"),localFolder=Path.Combine(data,"本机保留");Directory.CreateDirectory(shareFolderA);Directory.CreateDirectory(shareFolderB);Directory.CreateDirectory(localFolder);
    string shareA=Path.Combine(shareFolderA,"share-fixture-a.txt"),shareB=Path.Combine(shareFolderB,"share-fixture-b.txt"),localFile=Path.Combine(localFolder,"local-keep.txt");File.WriteAllText(shareA,"sample");File.WriteAllText(shareB,"sample");File.WriteAllText(localFile,"local");
    WaitCount(es,instance,"share-fixture-",2);Pump(Drop(form,new[]{shareA}));
    int uploadReload=client.ReloadCount;string uploadStateHash=Hash(Path.Combine(model.StateRoot,"cards.json"));
    Js(form,"document.getElementById('open-sharing').click();document.getElementById('open-upload').click();true");Check("upload_dialog_requests_signature_each_time",Convert.ToBoolean(Js(form,"document.getElementById('upload-dialog').open && document.getElementById('upload-author').value===''")));
    Js(form,"document.getElementById('upload-author').value='Test Author';document.getElementById('upload-author').dispatchEvent(new Event('input'));document.getElementById('submit-upload').click();true");
    WaitDom(form,"!document.getElementById('upload-dialog').open && document.querySelectorAll('.profile').length===1 && !document.querySelector('.sync-profile').disabled");
    string uiKey=SharedProfiles.Key("Test Author");Check("actual_html_upload_creates_profile",model.Shared.Read(uiKey).Paths.SequenceEqual(new[]{shareFolderA}));
    Check("upload_does_not_change_local_cards_or_everything",client.ReloadCount==uploadReload&&uploadStateHash==Hash(Path.Combine(model.StateRoot,"cards.json")));
    Pump(Drop(form,new[]{shareB}));Js(form,"document.getElementById('open-upload').click();true");Check("next_upload_signature_is_not_silently_reused",Convert.ToBoolean(Js(form,"document.getElementById('upload-author').value===''")));
    Js(form,"document.getElementById('upload-author').value='test author';document.getElementById('upload-author').dispatchEvent(new Event('input'));true");Check("existing_signature_hint_explains_append",Convert.ToBoolean(Js(form,"document.getElementById('author-hint').textContent.includes('追加到')")));
    Js(form,"document.getElementById('submit-upload').click();true");WaitDom(form,"!document.getElementById('upload-dialog').open && document.querySelector('.profile span').textContent==='2 个目录' && !document.querySelector('.sync-profile').disabled");
    Check("actual_html_same_signature_appends_without_replacing",model.Shared.List().Profiles.Count==1&&model.Shared.Read(uiKey).Paths.Count==2);
    Pump(form.CapturePreview(Path.Combine(root,"sharing-ui.png")));
    foreach(CardItem card in model.Cards.ToArray())model.Remove(card);form.PushState();WaitCount(es,instance,"share-fixture-",2);
    model.Shared.Upload("Test Author",new[]{manual});Pump(Refresh(form));Pump(Drop(form,new[]{localFile}));
    Js(form,"document.querySelector('.sync-profile').click();true");WaitDom(form,"document.querySelectorAll('.card').length===3 && !document.querySelector('.sync-profile').disabled");
    WaitCount(es,instance,"share-fixture-",0);WaitCount(es,instance,"local-keep",0);Check("actual_html_one_click_sync_adds_rules_preserving_local",model.Cards.Count==3&&model.Cards.Any(c=>Util.Same(c.Folder,localFolder)));
    Check("synced_paths_have_source_and_folder_icon",model.Cards.Count(c=>c.Source=="Test Author"&&c.FileName==""&&File.Exists(Path.Combine(model.StateRoot,c.Cover)))==2);
    Check("sync_does_not_claim_existing_manual_rule",!model.Cards.Any(c=>Util.Same(c.Folder,manual))&&client.Excluded().Any(rule=>EverythingClient.SameLiteral(rule,manual)));
    int syncReload=client.ReloadCount;Pump(Sync(form,uiKey));Check("repeated_sync_does_not_duplicate_cards_or_reload",model.Cards.Count==3&&client.ReloadCount==syncReload);
    string beforeUnavailable=Hash(Path.Combine(model.StateRoot,"cards.json"));int beforeUnavailableReload=client.ReloadCount;Pump(Sync(form,new string('0',64)));Check("missing_shared_profile_does_not_change_local_state",form.LastError!=null&&Hash(Path.Combine(model.StateRoot,"cards.json"))==beforeUnavailable&&client.ReloadCount==beforeUnavailableReload);
    Js(form,"document.getElementById('close-sharing').click();true");
    Js(form,"document.getElementById('card-search').value='共享目录 A';document.getElementById('card-search').dispatchEvent(new Event('input'));true");WaitDom(form,"document.querySelectorAll('.card').length===1");
    Js(form,"document.querySelector('[data-remove]').click();true");timer.Restart();while(form.Busy||model.Cards.Count!=2){Application.DoEvents();Thread.Sleep(15);if(timer.ElapsedMilliseconds>45000)throw new TimeoutException("Synced card cancellation timed out");}WaitCount(es,instance,"share-fixture-a",1);WaitCount(es,instance,"share-fixture-b",0);
    Check("synced_card_cross_restores_only_its_folder",true);Check("local_cancel_does_not_edit_shared_profile",model.Shared.Read(uiKey).Paths.Count==3);
    foreach(CardItem card in model.Cards.ToArray())model.Remove(card);form.PushState();WaitCount(es,instance,"share-fixture-",2);WaitCount(es,instance,"local-keep",1);
    Js(form,"document.getElementById('clear-search').click();true");WaitDom(form,"document.querySelectorAll('.card').length===0");
    Check("sharing_entry_is_left_of_folder_counter",Convert.ToBoolean(Js(form,"(()=>{let button=document.getElementById('open-sharing').getBoundingClientRect(),counter=document.querySelector('.counter').getBoundingClientRect();return button.right<counter.left && Math.abs(button.top-counter.top)<5 && !document.querySelector('main .sharing') && !document.getElementById('sharing-dialog').open;})()")));
    string scopeRoot=Path.Combine(data,"范围选择"),scopeA=Path.Combine(scopeRoot,"序列 A"),scopeB=Path.Combine(scopeRoot,"序列 B"),scopeDeep=Path.Combine(scopeA,"子目录"),scopeOther=Path.Combine(data,"另一组");Directory.CreateDirectory(scopeDeep);Directory.CreateDirectory(scopeB);Directory.CreateDirectory(scopeOther);
    string scopeFileA=Path.Combine(scopeA,"scope-case-a.txt"),scopeFileB=Path.Combine(scopeB,"scope-case-b.txt"),scopeFileDeep=Path.Combine(scopeDeep,"scope-case-deep.txt"),scopeFileOther=Path.Combine(scopeOther,"scope-other.txt");foreach(string path in new[]{scopeFileA,scopeFileB,scopeFileDeep,scopeFileOther})File.WriteAllText(path,"scope fixture");
    WaitCount(es,instance,"scope-case-",3);WaitCount(es,instance,"scope-other",1);
    int scopeReload=client.ReloadCount;string beforeChoice=Hash(Path.Combine(model.StateRoot,"cards.json"));Stage(form,new[]{scopeFileA});
    Check("drop_waits_for_confirmation_without_rules_or_state_changes",model.Cards.Count==0&&client.ReloadCount==scopeReload&&beforeChoice==Hash(Path.Combine(model.StateRoot,"cards.json")));
    Check("choice_shows_exact_current_and_parent_paths",Convert.ToBoolean(Js(form,"document.querySelectorAll('.scope-option').length===2 && document.querySelectorAll('.scope-path')[0].textContent==="+json.Serialize(scopeA)+" && document.querySelectorAll('.scope-path')[1].textContent==="+json.Serialize(scopeRoot))));
    Pump(form.CapturePreview(Path.Combine(root,"scope-choice.png")));
    Js(form,"document.getElementById('cancel-exclusion').click();true");WaitDom(form,"!document.getElementById('scope-dialog').open");Check("cancel_choice_does_not_apply_rules",model.Cards.Count==0&&client.ReloadCount==scopeReload&&beforeChoice==Hash(Path.Combine(model.StateRoot,"cards.json")));
    Stage(form,new[]{scopeFileA});Js(form,"chrome.webview.postMessage({type:'confirmDrop',token:dropToken,choices:[{id:document.querySelector('[data-choice]').dataset.choice,scope:'invalid'}]});true");WaitDom(form,"!document.getElementById('scope-error').hidden");Check("invalid_scope_is_rejected_before_any_rule_change",client.ReloadCount==scopeReload&&model.Cards.Count==0&&form.LastError!=null);
    Js(form,"document.querySelector('#scope-groups input[value=parent]').checked=true;true");Confirm(form);WaitDom(form,"document.querySelectorAll('.card').length===1");
    WaitCount(es,instance,"scope-case-",0);WaitCount(es,instance,"scope-other",1);Check("parent_choice_excludes_sibling_sequences_and_children",model.Cards.Count==1&&Util.Same(model.Cards[0].Folder,scopeRoot));
    Check("parent_scope_filename_and_title_persist",model.Cards[0].Scope=="parent"&&model.Cards[0].FileName=="scope-case-a.txt"&&model.Cards[0].FolderName=="范围选择"&&new Controller(model.StateRoot,client).Cards[0].Scope=="parent");
    Check("parent_scope_visible_on_card",Convert.ToBoolean(Js(form,"document.querySelector('.cover-tag').textContent==='上一级目录' && document.querySelector('.folder-title').textContent==='范围选择' && document.querySelector('.image-name').textContent==='scope-case-a.txt'")));
    Check("cards_are_compact_in_default_window",Convert.ToBoolean(Js(form,"(()=>{const box=document.querySelector('.card').getBoundingClientRect();return box.width<260 && box.height<235 && document.querySelector('.cover-wrap').getBoundingClientRect().height<=101;})()")));
    Pump(form.CapturePreview(Path.Combine(root,"compact-parent-card.png")));
    Js(form,"document.querySelector('[data-remove]').click();true");WaitDom(form,"document.querySelectorAll('.card').length===0");WaitCount(es,instance,"scope-case-",3);Check("parent_card_cross_restores_all_its_sequences",true);
    Pump(Drop(form,new[]{scopeFileA}));WaitDom(form,"document.querySelectorAll('.card').length===1");WaitCount(es,instance,"scope-case-a",0);WaitCount(es,instance,"scope-case-deep",0);WaitCount(es,instance,"scope-case-b",1);
    Check("current_directory_choice_keeps_sibling_searchable",model.Cards[0].Scope=="directory"&&Util.Same(model.Cards[0].Folder,scopeA));Check("current_directory_scope_visible_on_card",Convert.ToBoolean(Js(form,"document.querySelector('.cover-tag').textContent==='所在目录'")));
    model.Remove(model.Cards[0]);form.PushState();WaitDom(form,"document.querySelectorAll('.card').length===0");
    Stage(form,new[]{scopeFileA,scopeFileOther});Check("batch_drop_offers_each_folder_its_own_choice",Convert.ToBoolean(Js(form,"document.querySelectorAll('[data-choice]').length===2 && document.querySelectorAll('#scope-groups input[type=radio]').length===4")));
    Js(form,"document.querySelectorAll('[data-choice]')[0].querySelector('input[value=parent]').checked=true;true");Confirm(form);WaitDom(form,"document.querySelectorAll('.card').length===2");Check("batch_supports_mixed_directory_and_parent_scopes",model.Cards.Count(c=>c.Scope=="parent")==1&&model.Cards.Count(c=>c.Scope=="directory")==1);WaitCount(es,instance,"scope-case-",0);WaitCount(es,instance,"scope-other",0);
    Pump(form.CapturePreview(Path.Combine(root,"mixed-scope-cards.png")));
    foreach(CardItem card in model.Cards.ToArray())model.Remove(card);form.PushState();WaitDom(form,"document.querySelectorAll('.card').length===0");
    Pump(Drop(form,new[]{scopeFileA,scopeFileB},"parent"));Check("same_parent_batch_deduplicates_target_path",model.Cards.Count==1&&model.Cards[0].Scope=="parent"&&Util.Same(model.Cards[0].Folder,scopeRoot));
    model.Remove(model.Cards[0]);form.PushState();WaitDom(form,"document.querySelectorAll('.card').length===0");WaitCount(es,instance,"scope-case-",3);WaitCount(es,instance,"scope-other",1);
    Check("root_directory_has_no_broader_parent_option",Controller.ParentOf(Path.GetPathRoot(root))==null&&Controller.ParentOf(@"\\server\share\")==null);
    Check("scope_changes_preserve_existing_manual_rule",client.Excluded().Any(rule=>EverythingClient.SameLiteral(rule,manual)));
    Js(form,"document.getElementById('clear-search').click();true");
    MergeChecks(root,form,model,es,instance,data,manual);
    PromotionChecks(root,form,model,es,instance,data);
    ExitRecoveryChecks(root,form,model,es,instance,data);
    string corrupt=Path.Combine(root,"corrupt-state");Directory.CreateDirectory(corrupt);File.WriteAllText(Path.Combine(corrupt,"cards.json"),"broken json");bool rejected=false;try{new Controller(corrupt,client);}catch{rejected=true;}Check("corrupt_state_not_silently_reset",rejected);
    if(realHash!=null)Check("real_everything_config_unchanged",realHash==Hash(realConfig));
    if(realPid!=0){uint now;Native.GetWindowThreadProcessId(Native.Ipc(""),out now);Check("real_everything_process_unchanged",now==realPid);}
    ok=true;
   } catch(Exception e){error=e.ToString();}
   finally {
    if(form!=null){form.Close();form.Dispose();}
    if(client!=null){try{using(var p=client.Launch("-exit")){if(p!=null)p.WaitForExit(8000);}}catch{}}
    if(fixtureCreated)File.WriteAllText(Path.Combine(root,"verification.json"),new JavaScriptSerializer().Serialize(new{ok=ok,version=typeof(Program).Assembly.GetName().Version.ToString(),checks=checks,checkCount=checks.Count,error=error,fixtureOnly=true,realUserRulesModified=false}),Util.Utf8);
   }
   return ok ? 0 : 1;
  }
 }
}


