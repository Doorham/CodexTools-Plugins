using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EverythingExclusions {
    internal static class HangRepair {
        internal static bool ElevateRequested;
        internal static int Open() {
            bool created;
            using (var mutex = new Mutex(true, @"Local\Doorham.EverythingHangRepair.1", out created)) {
                if (!created) {
                    IntPtr window = Native.FindWindow(null, "修复卡死 · Everything");
                    if (window != IntPtr.Zero) { Native.ShowWindow(window, 9); Native.SetForegroundWindow(window); }
                    return 0;
                }
                Application.Run(new HangRepairForm());
            }
            if (ElevateRequested) {
                try { Process.Start(new ProcessStartInfo(Application.ExecutablePath, "--repair-hang") { UseShellExecute = true, Verb = "runas" }); }
                catch (Win32Exception error) { MessageBox.Show("管理员重试未启动：" + error.Message, "修复卡死"); return 1; }
            }
            return 0;
        }

        // Preserve all bytes outside the lvm setting, including BOM, line endings and other sections.
        internal static byte[] Updated(byte[] original) {
            bool bom = original.Length >= 3 && original[0] == 239 && original[1] == 187 && original[2] == 191;
            string text = Util.Utf8.GetString(original, bom ? 3 : 0, original.Length - (bom ? 3 : 0));
            string[] parts = Regex.Split(text, "(\r\n|\n)");
            bool active = false, found = false; int insert = -1;
            for (int i = 0; i < parts.Length; i += 2) {
                string line = parts[i], trimmed = line.Trim();
                if (trimmed.StartsWith("[")) {
                    if (active && insert < 0) insert = i;
                    active = trimmed.Equals("[Everything]", StringComparison.OrdinalIgnoreCase);
                }
                if (!active) continue;
                Match match = Regex.Match(line, @"^([ \t]*lvm[ \t]*=[ \t]*)[^\r\n]*$", RegexOptions.IgnoreCase);
                if (match.Success) { parts[i] = match.Groups[1].Value + "0"; found = true; }
                if (i + 2 >= parts.Length && insert < 0) insert = parts.Length;
            }
            if (!found) {
                if (insert < 0) throw new InvalidDataException("配置缺少 [Everything] 节，尚未修改。");
                string newline = text.Contains("\r\n") ? "\r\n" : "\n";
                string prefix = String.Concat(parts.Take(insert));
                if (prefix.Length > 0 && !prefix.EndsWith("\n")) prefix += newline;
                text = prefix + "lvm=0" + newline + String.Concat(parts.Skip(insert));
            } else text = String.Concat(parts);
            byte[] body = Util.Utf8.GetBytes(text);
            return bom ? new byte[] {239, 187, 191}.Concat(body).ToArray() : body;
        }

        internal static bool IsApplied(string config) {
            return new Ini(Util.Utf8.GetString(File.ReadAllBytes(config))).Get("lvm", "1").Trim() == "0";
        }

        internal static string WriteSetting(string config, string backupRoot) {
            byte[] original = File.ReadAllBytes(config), updated = Updated(original);
            Directory.CreateDirectory(backupRoot);
            string backup = Path.Combine(backupRoot, "before-hang-repair-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fff") + "-" + Guid.NewGuid().ToString("N") + ".ini");
            string temp = config + ".repair-" + Guid.NewGuid().ToString("N") + ".tmp";
            File.WriteAllBytes(backup, original);
            try {
                File.WriteAllBytes(temp, updated);
                // Refuse to overwrite a concurrent edit after reading the original.
                if (!File.ReadAllBytes(config).SequenceEqual(original)) throw new IOException("配置刚刚被其他程序修改，请重试。");
                File.Replace(temp, config, null);
                if (!File.ReadAllBytes(config).SequenceEqual(updated)) throw new IOException("配置回读不一致。原配置备份：" + backup);
            } finally { if (File.Exists(temp)) File.Delete(temp); }
            return backup;
        }

        internal static string Run(EverythingClient client, Func<string, bool> confirm, Action<string> progress) {
            using (var gate = new Mutex(false, @"Local\Doorham.EverythingSettings.1")) {
                bool acquired; try { acquired = gate.WaitOne(0); } catch (AbandonedMutexException) { acquired = true; }
                if (!acquired) throw new IOException("Everything 设置正在修改，请稍后重试。");
                try {
                    if (IsApplied(client.Config)) return "修复设置已启用，无需重复修改或重启。\r\n\r\n如果仍然卡死，需要继续排查其他原因。";
                    if (!confirm("将关闭 Everything 结果列表的无障碍兼容接口，并重启正在运行的 Everything。\r\n\r\n使用屏幕阅读器时可能受影响。排除目录和其他设置保留；修改前会备份配置。\r\n\r\n是否继续？")) return "已取消，未修改设置。";
                    int pid = client.RunningPid(); bool stopped = false; string backup = null;
                    try {
                        if (pid != 0) {
                            using (var target = Process.GetProcessById(pid)) {
                                // Keep the original process handle; never kill a later process that reuses the PID.
                                IntPtr handle = target.Handle;
                                if (!Util.Same(target.MainModule.FileName, client.Executable)) throw new IOException("Everything 进程路径不一致，尚未修改。");
                                progress("正在请求 Everything 退出…");
                                using (var command = client.Launch("-exit")) {
                                    // Some hung instances also leave the exit helper waiting. Retain only our helper handle.
                                    if (command != null && !command.WaitForExit(1500)) { command.Kill(); command.WaitForExit(1500); }
                                }
                                if (!target.WaitForExit(3500)) {
                                    if (!confirm("Everything 没有正常退出。是否结束这个 Everything 进程并继续修复？\r\n\r\n尚未保存的 Everything 窗口设置可能丢失。")) return "Everything 未退出，已取消修复，未修改配置。";
                                    target.Kill();
                                    if (!target.WaitForExit(5000)) throw new IOException("Everything 未能退出，尚未修改配置。");
                                }
                                stopped = true;
                            }
                        }
                        if (client.RunningPid() != 0) throw new IOException("检测到 Everything 再次启动，请稍后重试。");
                        progress("正在备份并应用修复设置…");
                        backup = WriteSetting(client.Config, client.BackupRoot);
                        if (stopped) {
                            progress("正在重新启动 Everything…");
                            using (var started = client.Launch("-startup")) { }
                            client.WaitReady();
                        }
                        return "已应用修复设置。" + (stopped ? "Everything 已重新启动。" : "下次启动 Everything 时生效。") + "\r\n\r\n请试一下搜索框。\r\n原配置备份：\r\n" + backup;
                    } catch (Exception error) {
                        if (stopped && backup == null && client.RunningPid() == 0) {
                            try { using (var restarted = client.Launch("-startup")) { } }
                            catch (Exception restartError) { throw new IOException(error.Message + "\r\nEverything 重新启动也失败：" + restartError.Message, error); }
                        }
                        if (backup != null) throw new IOException("修复设置已写入，但后续步骤未完成：" + error.Message + "\r\n请手动打开 Everything。原配置备份：" + backup, error);
                        throw;
                    }
                } finally { gate.ReleaseMutex(); }
            }
        }
    }

    internal sealed class HangRepairForm : Form {
        readonly Label message;
        readonly Button close;
        bool busy;
        internal HangRepairForm() {
            Text = "修复卡死 · Everything"; StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(520, 270); MinimumSize = new Size(480, 280);
            Font = new Font("Microsoft YaHei UI", 10); MaximizeBox = false;
            message = new Label { Dock = DockStyle.Fill, Padding = new Padding(22), Text = "正在检查 Everything…", AutoEllipsis = false };
            close = new Button { Text = "关闭", Dock = DockStyle.Bottom, Height = 38, Enabled = false };
            close.Click += (s, e) => Close(); Controls.Add(message); Controls.Add(close);
            FormClosing += (s, e) => { if (busy) e.Cancel = true; };
            Shown += async (s, e) => {
                busy = true;
                try {
                    string state = Program.StateRoot(AppDomain.CurrentDomain.BaseDirectory, Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData));
                    message.Text = await Task.Run(() => HangRepair.Run(EverythingClient.Detect(state),
                        text => (bool)Invoke(new Func<bool>(() => MessageBox.Show(this, text, "修复卡死", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)),
                        text => Invoke(new Action(() => message.Text = text))));
                } catch (Exception error) {
                    message.Text = "未完成修复：" + error.Message;
                    if (error is UnauthorizedAccessException || (error is Win32Exception && ((Win32Exception)error).NativeErrorCode == 5)) {
                        var retry = new Button { Text = "以管理员身份重试", Dock = DockStyle.Bottom, Height = 38 };
                        retry.Click += (sender, args) => {
                            try { HangRepair.ElevateRequested = true; Close(); }
                            catch (Win32Exception ex) { message.Text = "管理员重试未启动：" + ex.Message; }
                        };
                        Controls.Add(retry); retry.BringToFront();
                    }
                } finally { busy = false; close.Enabled = true; close.Focus(); }
            };
        }
    }
}
