# Codex 完成提示音 1.2.0

同一个常驻助手现在监听三种 Agent 的回答完成事件：Codex、Kimi 桌面端、DeepSeek Harness。插件 ID、声音选择、开机自启及常驻方式保持不变。

- Codex：监听 `task_complete` 完成事件，每个任务只响一次。
- Kimi：只读 `%APPDATA%/kimi-desktop/kimi-agent/conversation-statuses.json` 的状态映射，已知会话 `running → completed` 才响。首次快照作为基线，历史记录不补响；重复写入不重复响。
- DeepSeek Harness：只读 `%DSH_HOME%\storages\session_projcache\sessions\*.json`（未设置 `DSH_HOME` 时回退 `%USERPROFILE%\.dsh`）。当某个会话多出一个此前没有的、已回答的轮次时响一次；启动时每个文件先取基线，所以历史轮次、首次见到就已完成的会话都不补响。会话文件被整体重写（先写临时文件再替换）时既不重复响也不漏响，两秒一次的补扫作为文件事件的兜底；`File.Replace` 产生的 `*.json~RF*.TMP` 临时名不会被当成会话。

使用同一个常驻 EXE，不创建定时任务，不在每次回答后启动脚本，不读取任何会话正文，不修改三个 Agent 的软件本体。三种 Agent 里哪一个没装，对应监听就自动不启用，其余照常工作。

更新保留当前声音、自启状态和私人配置。安装版声音及运行状态保留在安装目录的 CodexAnswerChime 子目录。

1.2.0 在 1.1.3 图标修订之上新增 DeepSeek Harness 监听；1.1.0／1.1.1 由 Codex 实现并验证，接入思路由 Kimi 提出。原开发者 Doorham / Althy / DRHW 署名保留，本次追加 DeepSeek Harness。
