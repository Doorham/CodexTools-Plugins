# 插件开发记录 · wetype-awesun-bridge

## 2026-10-24 · 1.0.11 → 1.0.12 · Althy；保留原作者 DRHW

- 分离录音／UI 收尾与剪贴板投递；结束录音不再等待复制完成。
- 本机写入与回读验证分开；回读遇到剪贴板占用时仅重读，不重复写入。
- 保留即时复制，结束后针对最新文本快照最多执行一次补发尝试；最近文本保存在内存中，仍可手动“重试复制”。
- 仅当最新普通修订在结束录音前已通过本机回读，才安排一次结束补发；若结束时首次写入／验证仍在重试，结束后的首次成功即完成该次投递，不再额外双写。
- 新录音会话、新文本修订或外部剪贴板序号变化会取消旧的自动任务，避免旧文本覆盖后续操作；不使用固定延迟无限双发。
- 保留原生 Copy 与隐藏复制框 IMC 隔离；不触碰接收框输入上下文。剪贴板序号检查到 WM_COPY 之间并非原子操作，仍存在竞态窗口。
- 本机写入／回读成功不代表向日葵被控端已收到；插件没有远端确认机制。
- NoWriteEvidence 仅表示未取得写入回执，不能等同于剪贴板被占用；状态日志只记录元信息，不记录听写正文。
- 保留绿色双色倒置图标、插件身份、前台承接、自启及正常停止／替换／重启流程；清单仅提升 moduleVersion。
- 最终验证：C# 5 / .NET Framework 4 编译、49项纯内存投递回归、真实控件事件与生命周期回归、私有窗口站生产原生复制回归、独立代码审查及差异检查。仅验证本机状态逻辑和私有非交互Windows剪贴板，未接触交互剪贴板。没有真实WeType录音/composition、Ctrl+Alt+`或AweSun跨机验证；保留无远端ACK、非原子复制竞态及原生回调无录音身份的限制。
- 另一台电脑的 Ctrl+Alt+` 开始／结束切换及真实微信输入法／向日葵端到端效果仍待复测，不据本机验证宣称已修复快捷键或保证远端投递。
- 最低客户端保持 0.32.20，客户端 0.32.22 不变；渠道发布、本机接管以独立回执为准。
- 程序 SHA-256：`26584bb2a4ac84fdfde191d137f3bf2eaa97a3711b343c203a012a8c0778292b`。

---

# 插件开发记录 · wetype-awesun-bridge

## 2026-10-24 · 1.0.10 → 1.0.11 · Althy；保留原作者 DRHW

- 每次 WriteClipboard 前对独立隐藏复制框执行 ImmAssociateContextEx(copySource.Handle, 0, 0)，仅解除该 scratch 控件的 IME 上下文关联。
- 不使用 ImeMode.Disable，不关闭或销毁接收框的输入上下文；不改全局快捷键、接收框、状态机、原生 Copy 或复制时机。
- 沿用既有 MaxLength、sequence 变化及 Unicode 回读、换行、迟到提交、失败缓存与重试；本版没有新增 MaxLength 修复。
- 保留绿色双色倒置图标、插件身份、前台承接、自启及正常停止／替换／重启流程；清单仅提升 moduleVersion。
- 最终验证：Receiver and retry regression、Focused receiver and detached scratch input context、Native clipboard content and notifications preserved。1.0.10 shared default HIMC is confirmed, but its causality for the reported hotkey failure is not. No real WeType recording/composition was started; the other computer's Ctrl+Alt+` start/stop toggle and remote delivery remain unverified. No interactive clipboard was touched.
- 用户反馈另一台电脑使用 Ctrl+Alt+` 切换语音开始／结束失败，具体原因尚未确定。隔离验证证实原隐藏框共享 IMC，当前方案可解除其关联；实际快捷键尚未测试，不据此宣称根治。
- 真实微信输入法／向日葵端到端效果以用户复测为准，隔离验证不替代其他设备验收。
- 最低客户端保持 0.32.20，客户端 0.32.22 不变；渠道发布、本机接管以独立回执为准。
- 程序 SHA-256：`e06d68b169a89c4157fe315fedb188a89bdcf4dbd15be49da240015a7640a05e`。

---

# 插件开发记录 · wetype-awesun-bridge

## 2026-10-24 · 1.0.9 → 1.0.10 · Althy；保留原作者 DRHW

- 自动使用独立隐藏原生 TextBox.Copy 复制文字，并核对剪贴板 sequence 变化及 Unicode 回读；不向其他程序发送 Ctrl+C。
- 提升原生接收框 MaxLength，保留即时复制、换行、迟到提交、失败缓存及重试。该上限修复不作为长短文本均可能同步失败的根因解释。
- 保留绿色双色倒置图标、插件身份、前台承接、自启及正常停止／替换／重启流程；清单仅提升 moduleVersion。
- 最终验证：Existing receiver and retry regression、Native input 40k/200k、Production native Copy in isolated Windows clipboard。No user interactive clipboard access. Native Copy and local content/notification behavior passed; this does not establish why AweSun dropped synchronization or verify delivery on a controlled computer.
- 真实微信输入法／向日葵端到端效果尚未经用户复测，不能据本机隔离验证宣称已经根治。
- 最低客户端保持 0.32.20，客户端 0.32.22 不变；渠道发布、本机接管以独立回执为准。
- 程序 SHA-256：`257359111035bc630e617071cde2df758b78bc3ab306cb25e97fb9e6286ccc31`。

---

# 插件开发记录 · wetype-awesun-bridge

## 2026-10-24 · 1.0.8 → 1.0.9 · Althy

- 按用户要求恢复原微信输入法符号的 180° 倒置形态，替换此前的话筒；背景改为绿色双色线性渐变 #27C97A → #0DA56E。
- 沿用旧版两条白色路径及圆头线条；把旋转、缩放烘焙到坐标，保留现行圆角。原生 SVG，无 transform、位图、滤镜或生图。
- artwork/icon.svg 与清单 iconImage 逐字节一致；SVG 白名单及浅暗背景 32/40 px 检查通过。
- 最低客户端继续为 0.32.20；这枚换图通过插件独立更新，不需要升级客户端。客户端 0.32.22 属于其他独立修复，不是本图标的前置。
- 程序及依赖逐字节沿用本渠道 1.0.8，运行功能、开关与启动配置不变；原署名 Althy、DRHW 及渠道历史日志保留。
- 本条记录包内容与图标检查；渠道发布、本机安装以各自回执为准，不宣称完整业务功能或其他机器验收。

---

# 插件开发记录 · wetype-awesun-bridge

## 2026-10-24 · 1.0.7 → 1.0.8 · Althy

- 用户采用双色矢量方案：原白色功能符号保留，背景改为两个色标的线性渐变。
- 纯 SVG 算法制作，无生图、嵌入位图或分形纹理；源文件 artwork/icon.svg 与清单 iconImage 完全一致。
- 本包需客户端 0.32.20 的通用 SVG 支持；保留原 icon 作为旧协议兜底。以后同协议图标更新无需升级客户端。
- 运行程序及依赖逐字节沿用上一版，程序资源版本未变；包版本因美术交付递增。原作者与本渠道历史日志保留。
- 图标按浅暗界面及 32/40 px 核对；本条记录包内交付，渠道发布和本机更新状态见发布回执，不代替业务功能全量重测。

---

# 插件开发记录 · wetype-awesun-bridge

## 2026-10-24 · 1.0.6 → 1.0.7 · Althy

- 本轮更新插件图标：独立生成的连续胶质色彩背景与可编辑白色符号；附显示图、SVG、背景、完整提示词及美术记录。
- 清单增加图标引用，保留原开发者；运行程序与依赖沿用本渠道上一版，打包时逐字节核对。
- 本条记录包内图标交付内容；渠道上线、客户端安装与实际显示验收分别以本轮发布记录为准，不冒充完整插件功能重测。
