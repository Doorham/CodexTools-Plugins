# 插件变更记录 · wetype-awesun-bridge

## 2026-10-24 · 1.0.10 → 1.0.11 · Althy；保留原作者 DRHW

- 每次 WriteClipboard 前对独立隐藏复制框执行 ImmAssociateContextEx(copySource.Handle, 0, 0)，仅解除该 scratch 控件的 IME 上下文关联。
- 不使用 ImeMode.Disable，不关闭或销毁接收框的输入上下文；不改全局快捷键、接收框、状态机、原生 Copy 或复制时机。
- 沿用既有 MaxLength、sequence 变化及 Unicode 回读、换行、迟到提交、失败缓存与重试；本版没有新增 MaxLength 修复。
- 保留绿色双色倒置图标、插件身份、前台承接、自启及正常停止／替换／重启流程；清单仅提升 moduleVersion。
- 最终验证：Receiver and retry regression、Focused receiver and detached scratch input context、Native clipboard content and notifications preserved。1.0.10 shared default HIMC is confirmed, but its causality for the reported hotkey failure is not. No real WeType recording/composition was started; the other computer's Ctrl+Alt+` start/stop toggle and remote delivery remain unverified. No interactive clipboard was touched.
- 用户反馈另一台电脑使用 Ctrl+Alt+` 切换语音开始／结束失败，具体原因尚未确定。隔离验证证实原隐藏框共享 IMC，当前方案可解除其关联；实际快捷键尚未测试，不据此宣称根治。
- 真实微信输入法／向日葵端到端效果以用户复测为准，隔离验证不替代其他设备验收。
- 最低客户端保持 0.32.20，客户端 0.32.22 不变；渠道发布、本机接管以独立回执为准。
- 程序 SHA-256：`e06d68b169a89c4157fe315fedb188a89bdcf4dbd15be49da240015a7640a05e`。

---

# 插件变更记录 · wetype-awesun-bridge

## 2026-10-24 · 1.0.9 → 1.0.10 · Althy；保留原作者 DRHW

- 自动使用独立隐藏原生 TextBox.Copy 复制文字，并核对剪贴板 sequence 变化及 Unicode 回读；不向其他程序发送 Ctrl+C。
- 提升原生接收框 MaxLength，保留即时复制、换行、迟到提交、失败缓存及重试。该上限修复不作为长短文本均可能同步失败的根因解释。
- 保留绿色双色倒置图标、插件身份、前台承接、自启及正常停止／替换／重启流程；清单仅提升 moduleVersion。
- 最终验证：Existing receiver and retry regression、Native input 40k/200k、Production native Copy in isolated Windows clipboard。No user interactive clipboard access. Native Copy and local content/notification behavior passed; this does not establish why AweSun dropped synchronization or verify delivery on a controlled computer.
- 真实微信输入法／向日葵端到端效果尚未经用户复测，不能据本机隔离验证宣称已经根治。
- 最低客户端保持 0.32.20，客户端 0.32.22 不变；渠道发布、本机接管以独立回执为准。
- 程序 SHA-256：`257359111035bc630e617071cde2df758b78bc3ab306cb25e97fb9e6286ccc31`。

---

# 微信语音输入远程状态监听板 1.0.6

2026-10-23 · 本次开发者 Althy；保留原作者 Althy、DRHW。

- 修复焦点转移等待超过两秒后监听进程主动退出的问题：删除跨进程输入队列绑定与强杀自身的看门狗。申请前台失败时记录状态并继续监听。
- 保留向日葵中英文及改名客户端识别、切走隐藏/切回承接、即时复制、换行、迟到提交、缓冲保留与占用重试。
- 文件版本 1.0.6.0，产品和插件版本 1.0.6。
- 已通过编译及既有内存接收器回归，不接触用户剪贴板。隔离桌面夹具未得到有效结果；不同微信输入法版本及 Windows 前台权限边界未做完整实机验收。
- 根源码历史曾将互斥身份调整标为 1.0.6；本包按实际 NAS 1.0.5 升至 1.0.6，旧包另行归档，不将历史候选当成已分发物。
- 更新沿用客户端公共流程：准备包后停止原来运行的程序，替换，再启动；原来关闭则保持关闭。自启设置不变。

程序 SHA-256：`7DA4ABF8343C737C90A3AA62BF895B458DBDA4A55E5EEA22D508C4115F5ED1DA`。
GitHub 同步记录见仓库 RELEASES/2026-10-23.md；本包程序与 NAS 1.0.6 一致。
