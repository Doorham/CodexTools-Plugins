param([switch]$CompileOnly)
$ErrorActionPreference = 'Stop'
$repoRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..'))
$output = Join-Path $repoRoot 'artifacts\wetype-2.1.1'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
New-Item -ItemType Directory -Path $output -Force | Out-Null
$program = Join-Path $output 'WeTypeAweSunBridge.exe'
$iconBuilder = Join-Path $output 'BuildIcon.exe'
& $compiler /nologo /target:exe /platform:x64 /optimize+ /warnaserror+ "/out:$iconBuilder" /r:System.Drawing.dll (Join-Path $PSScriptRoot 'BuildIcon.cs')
if ($LASTEXITCODE -ne 0) { throw 'Icon packer compilation failed' }
& $iconBuilder (Join-Path $PSScriptRoot 'artwork\icon.svg') $output
if ($LASTEXITCODE -ne 0) { throw 'Original icon packaging failed' }
$icon = Join-Path $output 'voice.ico'
$brand = Join-Path $output 'voice.png'
$shared = @('RemoteClientCatalog.cs','HistoryArchive.cs','HistoryLocation.cs','SpeechHistory.cs','ClipboardDelivery.cs','RecordingPipeline.cs','CompositionSnapshot.cs','CompositionTextBox.cs','HistoryGrouping.cs','HistoryTimeline.cs','SpeechHistoryWindow.cs','UiTheme.cs','VoiceHotkeySettings.cs','VoiceMouseTarget.cs','EndShortcutGate.cs','Win32.cs','ReceiverCapture.cs') | ForEach-Object { Join-Path $PSScriptRoot $_ }
$sources = $shared + @((Join-Path $PSScriptRoot 'SystemClipboard.cs'),(Join-Path $PSScriptRoot 'Program.cs'))
& $compiler /nologo /target:winexe /platform:x64 /optimize+ /warnaserror+ "/out:$program" "/win32icon:$icon" "/resource:$brand,WeTypeVoice2.Brand.png" /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Web.Extensions.dll @sources
if ($LASTEXITCODE -ne 0) { throw 'Release compilation failed' }
$test = Join-Path $output 'WeTypeVoice2Tests.exe'
& $compiler /nologo /target:exe /main:Tests /platform:x64 /optimize+ /warnaserror+ "/out:$test" "/win32icon:$icon" "/resource:$brand,WeTypeVoice2.Brand.png" /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Web.Extensions.dll @sources (Join-Path $PSScriptRoot 'Tests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Test compilation failed' }
if (-not $CompileOnly) {
$testOutput = & $test
$testCode = $LASTEXITCODE
$testOutput | Set-Content -LiteralPath (Join-Path $output 'tests.txt') -Encoding UTF8
$testOutput
if ($testCode -ne 0) { throw 'Simulated tests failed' }
$resultLine = $testOutput | Where-Object { $_ -match '^RESULT (\d+)/(\d+) tests passed;' } | Select-Object -Last 1
if (-not $resultLine -or $resultLine -notmatch '^RESULT (\d+)/\1 tests passed;') { throw 'Missing test count receipt' }
$modelTestCount = [int]$Matches[1]
}

$historyTest = Join-Path $output 'WeTypeHistoryArchiveTests.exe'
& $compiler /nologo /target:exe /main:HistoryArchiveTests /platform:x64 /optimize+ /warnaserror+ "/out:$historyTest" /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Web.Extensions.dll @sources (Join-Path $PSScriptRoot 'Tests.cs') (Join-Path $PSScriptRoot 'HistoryArchiveTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'History test compilation failed' }
if (-not $CompileOnly) {
$historyOutput = & $historyTest
$historyCode = $LASTEXITCODE
$historyOutput | Set-Content -LiteralPath (Join-Path $output 'history-tests.txt') -Encoding UTF8
$historyOutput
if ($historyCode -ne 0) { throw 'History tests failed' }
$historyLine = $historyOutput | Where-Object { $_ -match '^RESULT (\d+)/(\d+) history tests passed;' } | Select-Object -Last 1
if (-not $historyLine -or $historyLine -notmatch '^RESULT (\d+)/\1 history tests passed;') { throw 'Missing history test receipt' }
$historyTestCount = [int]$Matches[1]
}

$nativeTest = Join-Path $output 'WeTypeNativeClipboardTests.exe'
$nativeSources = @('SystemClipboard.cs','ClipboardDelivery.cs','HistoryArchive.cs','HistoryLocation.cs','SpeechHistory.cs','RecordingPipeline.cs','NativeClipboardTests.cs') | ForEach-Object { Join-Path $PSScriptRoot $_ }
& $compiler /nologo /target:exe /platform:x64 /optimize+ /warnaserror+ "/out:$nativeTest" @nativeSources
if ($LASTEXITCODE -ne 0) { throw 'Native test compilation failed' }
if (-not $CompileOnly) {
$nativeOutput = & $nativeTest
$nativeCode = $LASTEXITCODE
$nativeOutput | Set-Content -LiteralPath (Join-Path $output 'native-clipboard-tests.txt') -Encoding UTF8
$nativeOutput
if ($nativeCode -ne 0) { throw 'Isolated native clipboard tests failed' }
$nativeLine = $nativeOutput | Where-Object { $_ -match '^RESULT (\d+)/(\d+) native clipboard tests passed;' } | Select-Object -Last 1
if (-not $nativeLine -or $nativeLine -notmatch '^RESULT (\d+)/\1 native clipboard tests passed;') { throw 'Missing native test count receipt' }
$nativeTestCount = [int]$Matches[1]
}

$gateTest = Join-Path $output 'WeTypeEndGateTests.exe'
$gateSources = @('Win32.cs','VoiceHotkeySettings.cs','VoiceMouseTarget.cs','EndShortcutGate.cs','EndGateTests.cs') | ForEach-Object { Join-Path $PSScriptRoot $_ }
& $compiler /nologo /target:exe /platform:x64 /optimize+ /warnaserror+ "/out:$gateTest" /r:System.Windows.Forms.dll @gateSources
if ($LASTEXITCODE -ne 0) { throw 'End gate test compilation failed' }
if (-not $CompileOnly) {
$gateOutput = & $gateTest
$gateCode = $LASTEXITCODE
$gateOutput | Set-Content -LiteralPath (Join-Path $output 'end-gate-tests.txt') -Encoding UTF8
$gateOutput
if ($gateCode -ne 0) { throw 'End gate tests failed' }
$gateLine = $gateOutput | Where-Object { $_ -match '^RESULT (\d+)/(\d+) end gate tests passed;' } | Select-Object -Last 1
if (-not $gateLine -or $gateLine -notmatch '^RESULT (\d+)/\1 end gate tests passed;') { throw 'Missing end gate receipt' }
$gateTestCount = [int]$Matches[1]
}

$mouseTest = Join-Path $output 'WeTypeMouseTargetTests.exe'
& $compiler /nologo /target:exe /platform:x64 /optimize+ /warnaserror+ "/out:$mouseTest" /r:System.Drawing.dll (Join-Path $PSScriptRoot 'VoiceMouseTarget.cs') (Join-Path $PSScriptRoot 'MouseTargetTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Native mouse target test compilation failed' }
# This test uses 15-pixel nonactivating synthetic targets and must be run with the ordinary-user launcher.
$identityOriginal = Join-Path $output 'AweSun.exe'
$identityTest = Join-Path $output 'RenamedClientIdentityTest.exe'
$identitySources = @('RemoteClientCatalog.cs','Win32.cs','IdentityNativeTest.cs') | ForEach-Object { Join-Path $PSScriptRoot $_ }
& $compiler /nologo /target:exe /platform:x64 /optimize+ /warnaserror+ "/out:$identityOriginal" /r:System.Windows.Forms.dll @identitySources
if ($LASTEXITCODE -ne 0) { throw 'Native identity test compilation failed' }
Copy-Item -LiteralPath $identityOriginal -Destination $identityTest -Force
$uiPreview = Join-Path $output 'WeTypeUiPreview.exe'
$uiSources = @('HistoryArchive.cs','HistoryLocation.cs','SpeechHistory.cs','HistoryGrouping.cs','HistoryTimeline.cs','SpeechHistoryWindow.cs','UiTheme.cs','UiPreview.cs') | ForEach-Object { Join-Path $PSScriptRoot $_ }
& $compiler /nologo /target:winexe /platform:x64 /optimize+ /warnaserror+ "/out:$uiPreview" "/win32icon:$icon" "/resource:$brand,WeTypeVoice2.Brand.png" /r:System.Windows.Forms.dll /r:System.Drawing.dll @uiSources
if ($LASTEXITCODE -ne 0) { throw 'Isolated UI preview compilation failed' }
[ordered]@{ version='2.1.1'; sha256=(Get-FileHash -LiteralPath $program -Algorithm SHA256).Hash; automatedTests=$modelTestCount; nativeClipboardTests=$nativeTestCount; endGateTests=$gateTestCount; historyTests=$historyTestCount; nativeMouseTestsCompiled=$true; artworkSha256=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'artwork\icon.svg')).Hash; realSpeechValidated=$false } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $output 'build.json') -Encoding UTF8
Write-Output $program
