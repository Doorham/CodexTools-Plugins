using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace WeTypeVoice2 {
    internal sealed class ReceiverWindow : Form {protected override bool ShowWithoutActivation{get{return true;}}}
    internal sealed class ReceiverCapture : IDisposable {
        public readonly SpeechRecord Record;
        public readonly ReceiverWindow Window=new ReceiverWindow();
        public readonly CompositionTextBox Input=new CompositionTextBox();
        public readonly IntPtr ReturnWindow;
        public readonly uint ReturnPid;
        public bool FocusOwned,EndRequested,Cancelled;
        public DateTime EndRequestedAt,NextSample;
        public int LastLoggedRevision,ImeResults,Compositions,TextChanges;
        public ReceiverCapture(SpeechRecord record,RecordingPipeline pipeline,IntPtr target){
            Record=record;ReturnWindow=target;uint pid;Native.GetWindowThreadProcessId(target,out pid);ReturnPid=pid;
            Window.FormBorderStyle=FormBorderStyle.None;Window.ShowInTaskbar=false;Window.Opacity=0.02;
            Window.StartPosition=FormStartPosition.Manual;
            var area=Screen.PrimaryScreen.WorkingArea;Window.SetBounds(area.Right-160,area.Bottom-48,150,40);
            Input.Multiline=true;Input.MaxLength=int.MaxValue;Input.Dock=DockStyle.Fill;Input.ImeMode=ImeMode.On;Window.Controls.Add(Input);
            var unused=Window.Handle;unused=Input.Handle;
            // Immutable session binding. This callback only saves text in memory.
            Input.Snapshot=(text,final,source)=>{
                pipeline.Receive(record.Session,text,final,source,DateTime.UtcNow);
                if(source=="ime_result")ImeResults++;else if(source=="ime_composition")Compositions++;else TextChanges++;
            };
        }
        public void Dispose(){Input.Snapshot=null;Window.Dispose();}
        public bool ReadyForEnd(){
            return Native.GetForegroundWindow()==Window.Handle && Native.GetFocus()==Input.Handle && Input.Enabled;
        }
        public bool HasImeContext(){
            IntPtr context=Native.ImmGetContext(Input.Handle);if(context==IntPtr.Zero)return false;
            Native.ImmReleaseContext(Input.Handle,context);return true;
        }
    }
    internal static class FocusTransfer {
        public static bool Try(IntPtr source,IntPtr destination,IntPtr child,string operation,Action<string,object> log){
            if(destination==IntPtr.Zero || !Native.IsWindow(destination) || Native.IsHungAppWindow(destination)){log("focus_target_unavailable",new {operation=operation});return false;}
            uint ownPid,peerPid;uint ownThread=Native.GetWindowThreadProcessId(source,out ownPid);
            if(ownThread!=Native.GetCurrentThreadId()){log("focus_wrong_thread",new {operation=operation});return false;}
            IntPtr peer=destination==source?Native.GetForegroundWindow():destination;
            uint peerThread=Native.GetWindowThreadProcessId(peer,out peerPid);
            bool attached=false,requested=false,focused=false,detached=true;int attachError=0,setError=0;
            log("focus_begin",new {operation=operation,ownThread=ownThread,peerThread=peerThread,peerPid=peerPid});
            try {
                if(peerThread!=0 && peerThread!=ownThread){Native.SetLastError(0);attached=Native.AttachThreadInput(ownThread,peerThread,true);attachError=Marshal.GetLastWin32Error();}
                Native.SetLastError(0);requested=Native.SetForegroundWindow(destination);setError=Marshal.GetLastWin32Error();
                focused=Native.GetForegroundWindow()==destination;
                if(focused && child!=IntPtr.Zero){Native.SetFocus(child);focused=Native.GetFocus()==child;}
            }finally{if(attached)detached=Native.AttachThreadInput(ownThread,peerThread,false);}
            focused=focused && Native.GetForegroundWindow()==destination;
            if(focused && child!=IntPtr.Zero){Native.SetFocus(child);focused=Native.GetFocus()==child;}
            log("focus_result",new {operation=operation,attached=attached,attachError=attachError,requested=requested,lastError=setError,foreground=focused,detached=detached,afterClass=Native.ClassOf(Native.GetForegroundWindow())});
            return focused;
        }
    }
}
