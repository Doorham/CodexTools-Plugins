# 插件变更记录 · wetype-awesun-bridge

## 2026-10-24 · 1.0.13 → 1.0.14 · Althy；保留DRHW

- 结束时为已验证的最新全文取得新提交基线；接受结束前的剪贴板变化，继续保护结束后的新复制。
- 修正同一次Update清空后立即复制的问题，真正分两轮调度。承接框持有焦点时，首次复制尝试后归还，不等待校验/重试；外部焦点保持。
- 仍用现有窗口观察/承接框，没有强制切换输入法或新增按键监听。直接读取微信结果的无焦点方案尚未实现。
- 丢焦点后的真实结束快捷键、微信上传与远端粘贴仍未确认修复；不将模拟焦点边界的测试冒充实机验收。
- 验证：64项状态和真实控件/Unicode输入通过；4项私有窗口站Update全路径通过，使用真实原生剪贴板及明确模拟的焦点边界。未验证真实WeType快捷键、丢焦点结束录音或跨机粘贴；不宣称无焦点读取微信结果已实现。
- 程序SHA256：`9ad72c254fd0e300c4680c573b7aa3f6217585e73b8446d229992a953614f5ab`。
- 客户端0.32.22、最低0.32.20、图标不变；旧包/历史保留，实际发布以回执为准。

---

# 插件变更记录 · wetype-awesun-bridge

## 2026-10-24 · 1.0.12 → 1.0.13 · Althy；保留DRHW

- 按用户要求，结束补发及托盘重试先清空剪贴板，下一轮界面调度再原生复制全文；录制中的即时复制保持。
- 清空在锁内核对并记录自己的序列；失败不写，重试有界；清空到复制之间外部改写或新录音会取消旧任务。复制/校验重试不重复清空。
- final名额在清空前占用，保留原有最多一次、已验证最新文字及序列未变的资格条件。保留原生Copy、scratch IMC隔离和快捷键。
- 显式清空不等于微信强制上传；可能短暂出现空剪贴板。真实微信多端同步、Ctrl+Alt+`与被控端粘贴尚未实测，不能保证跨机成功。
- 验证：59项纯内存状态测试、真实控件/Unicode输入、4项实际清空复制链及既有原生Copy/IMC隔离通过；全部剪贴板实测限私有非交互窗口站。未验证真实微信多端上传、录音快捷键或向日葵被控端粘贴。先清空方案依用户要求直接发布，不能据此保证跨机同步。
- 客户端0.32.22、最低客户端0.32.20、图标不变。旧版日志和包保留，渠道发布状态见独立回执。
- 程序SHA256：`d4bdb9aa20f26441f507ca22a30f8bd0611df65352a890eb7c8faa8b9b084716`。

---

# 插件变更记录 · wetype-awesun-bridge

## 2026-10-24 · 1.0.11 → 1.0.12 · Althy；保留原作者 DRHW

- 分离录音／UI 收尾与剪贴板投递；结束录音不再等待复制完成。
- 本机写入与回读验证分开；回读遇到剪贴板占用时仅重读，不重复写入。
- 保留即时复制，结束后针对最新文本快照最多执行一次补发尝试；最近文本保存在内存中，仍可手动“重试复制”。
- 仅当最新普通修订在结束录音前已通过本机回读，才安排一次结束补发；若结束时首次写入／验证仍在重试，结束后的首次成功即完成该次投递，不再额外双写。
- 新录音会话、新文本修订或外部剪贴板序号变化会取消旧的自动任务，避免旧文本覆盖后续操作；不使用固定延迟无限双发。
- 保留原生 Copy 与隐藏复制框 IMC 隔离；不触碰接收框输入上下文。剪贴板序号检查到 WM_COPY 之间并非原子操作，仍存在竞态窗口。
- 本机写入／回读成功不代表向日葵被控端已收到；插件没有远端确认机制。
- NoWriteEvidence 仅表示未取得写入回执，不能等同于剪贴板被占用；状态日志只记录元信息，不记录听写正文。
- 保留绿色双色倒置图标、插件身份、前台承接、自启及正常停止／替换／重启流程；清单仅提升 moduleVersion。
- 最终验证：C# 5 / .NET Framework 4 编译、49项纯内存投递回归、真实控件事件与生命周期回归、私有窗口站生产原生复制回归、独立代码审查及差异检查。仅验证本机状态逻辑和私有非交互Windows剪贴板，未接触交互剪贴板。没有真实WeType录音/composition、Ctrl+Alt+`或AweSun跨机验证；保留无远端ACK、非原子复制竞态及原生回调无录音身份的限制。
- 另一台电脑的 Ctrl+Alt+` 开始／结束切换及真实微信输入法／向日葵端到端效果仍待复测，不据本机验证宣称已修复快捷键或保证远端投递。
- 最低客户端保持 0.32.20，客户端 0.32.22 不变；渠道发布、本机接管以独立回执为准。
- 程序 SHA-256：`26584bb2a4ac84fdfde191d137f3bf2eaa97a3711b343c203a012a8c0778292b`。

---

# 插件变更记录 · wetype-awesun-bridge

## 2026-10-24 · 1.0.10 → 1.0.11 · Althy；保留原作者 DRHW

- 每次 WriteClipboard 前对独立隐藏复制框执行 ImmAssociateContextEx(copySource.Handle, 0, 0)，仅解除该 scratch 控件的 IME 上下文关联。
- 不使用 ImeMode.Disable，不关闭或销毁接收框的输入上下文；不改全局快捷键、接收框、状态机、原生 Copy 或复制时机。
- 沿用既有 MaxLength、sequence 变化及 Unicode 回读、换行、迟到提交、失败缓存与重试；本版没有新增 MaxLength 修复。
- 保留绿色双色倒置图标、插件身份、前台承接、自启及正常停止／替换／重启流程；清单仅提升 moduleVersion。
- 最终验证：Receiver and retry regression、Focused receiver and detached scratch input context、Native clipboard content and notifications preserved。1.0.10 shared default HIMC is confirmed, but its causality for the reported hotkey failure is not. No real WeType recording/composition was started; the other computer's Ctrl+Alt+` start/stop toggle and remote delivery remain unverified. No interactive clipboard was touched.
- 用户反馈另一台电脑使用 Ctrl+Alt+` 切换语音开始／结束失败，具体原因尚未确定。隔离验证证实原隐藏框共享 IMC，当前方案可解除其关联；实际快捷键尚未测试，不据此宣称根治。
- 真实微信输入法／向日葵端到端效果以用户复测为准，隔离验证不替代其他设备验收。
- 最低客户端保持 0.32.20，客户端 0.32.22 不变；渠道发布、本机接管以独立回执为准。
- 程序 SHA-256：`e06d68b169a89c4157fe315fedb188a89bdcf4dbd15be49da240015a7640a05e`。

---

# 插件变更记录 · wetype-awesun-bridge

## 2026-10-24 · 1.0.9 → 1.0.10 · Althy；保留原作者 DRHW

- 自动使用独立隐藏原生 TextBox.Copy 复制文字，并核对剪贴板 sequence 变化及 Unicode 回读；不向其他程序发送 Ctrl+C。
- 提升原生接收框 MaxLength，保留即时复制、换行、迟到提交、失败缓存及重试。该上限修复不作为长短文本均可能同步失败的根因解释。
- 保留绿色双色倒置图标、插件身份、前台承接、自启及正常停止／替换／重启流程；清单仅提升 moduleVersion。
- 最终验证：Existing receiver and retry regression、Native input 40k/200k、Production native Copy in isolated Windows clipboard。No user interactive clipboard access. Native Copy and local content/notification behavior passed; this does not establish why AweSun dropped synchronization or verify delivery on a controlled computer.
- 真实微信输入法／向日葵端到端效果尚未经用户复测，不能据本机隔离验证宣称已经根治。
- 最低客户端保持 0.32.20，客户端 0.32.22 不变；渠道发布、本机接管以独立回执为准。
- 程序 SHA-256：`257359111035bc630e617071cde2df758b78bc3ab306cb25e97fb9e6286ccc31`。

---

# 微信语音输入远程状态监听板 1.0.6

2026-10-23 · 本次开发者 Althy；保留原作者 Althy、DRHW。

- 修复焦点转移等待超过两秒后监听进程主动退出的问题：删除跨进程输入队列绑定与强杀自身的看门狗。申请前台失败时记录状态并继续监听。
- 保留向日葵中英文及改名客户端识别、切走隐藏/切回承接、即时复制、换行、迟到提交、缓冲保留与占用重试。
- 文件版本 1.0.6.0，产品和插件版本 1.0.6。
- 已通过编译及既有内存接收器回归，不接触用户剪贴板。隔离桌面夹具未得到有效结果；不同微信输入法版本及 Windows 前台权限边界未做完整实机验收。
- 根源码历史曾将互斥身份调整标为 1.0.6；本包按实际 NAS 1.0.5 升至 1.0.6，旧包另行归档，不将历史候选当成已分发物。
- 更新沿用客户端公共流程：准备包后停止原来运行的程序，替换，再启动；原来关闭则保持关闭。自启设置不变。

程序 SHA-256：`7DA4ABF8343C737C90A3AA62BF895B458DBDA4A55E5EEA22D508C4115F5ED1DA`。
GitHub 同步记录见仓库 RELEASES/2026-10-23.md；本包程序与 NAS 1.0.6 一致。
