using System;
using System.Runtime.InteropServices;
using System.Text;

namespace WeTypeVoice2 {
    // Check and write while the clipboard is locked. Never inspect external clipboard content.
    internal sealed class SystemClipboard : IClipboardSink {
        [DllImport("user32.dll",SetLastError=true)] static extern bool OpenClipboard(IntPtr owner);
        [DllImport("user32.dll",SetLastError=true)] static extern bool CloseClipboard();
        [DllImport("user32.dll",SetLastError=true)] static extern bool EmptyClipboard();
        [DllImport("user32.dll",SetLastError=true)] static extern IntPtr SetClipboardData(uint format,IntPtr memory);
        [DllImport("user32.dll")] static extern uint GetClipboardSequenceNumber();
        [DllImport("user32.dll")] static extern IntPtr GetClipboardOwner();
        [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr GlobalAlloc(uint flags,UIntPtr size);
        [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr GlobalLock(IntPtr memory);
        [DllImport("kernel32.dll")] static extern bool GlobalUnlock(IntPtr memory);
        [DllImport("kernel32.dll")] static extern IntPtr GlobalFree(IntPtr memory);
        readonly Func<IntPtr> owner;
        internal SystemClipboard(Func<IntPtr> window){owner=window;}
        public uint Sequence {get{return GetClipboardSequenceNumber();}}
        static ExternalException Failure(string stage){int code=Marshal.GetLastWin32Error();return new ExternalException(stage+" failed ("+code+")",code);}
        public bool TryPut(string text,uint expected,out uint writtenSequence) {
            writtenSequence=expected;
            byte[] bytes=Encoding.Unicode.GetBytes(text+"\0");
            IntPtr memory=GlobalAlloc(2,(UIntPtr)bytes.Length);
            if(memory==IntPtr.Zero)throw Failure("GlobalAlloc");
            bool opened=false;
            try {
                IntPtr address=GlobalLock(memory);if(address==IntPtr.Zero)throw Failure("GlobalLock");
                try {Marshal.Copy(bytes,0,address,bytes.Length);}finally{GlobalUnlock(memory);}
                IntPtr ownWindow=owner();
                if(!OpenClipboard(ownWindow))throw Failure("OpenClipboard");opened=true;
                if(Sequence!=expected)return false;
                if(!EmptyClipboard())throw Failure("EmptyClipboard");
                if(SetClipboardData(13,memory)==IntPtr.Zero)throw Failure("SetClipboardData");
                memory=IntPtr.Zero; // Windows owns this allocation now.
                // Windows may synthesize text formats while closing, changing the sequence again.
                // A receipt taken before CloseClipboard incorrectly looks like an external copy.
                if(!CloseClipboard())throw Failure("CloseClipboard");opened=false;
                writtenSequence=Sequence;
                // Do not adopt a newer external copy as our receipt if another writer won the gap.
                // Any copy after this owner check changes the sequence and is caught on the next write.
                return GetClipboardOwner()==ownWindow;
            }finally {
                if(opened)CloseClipboard();
                if(memory!=IntPtr.Zero)GlobalFree(memory);
            }
        }
    }
}
