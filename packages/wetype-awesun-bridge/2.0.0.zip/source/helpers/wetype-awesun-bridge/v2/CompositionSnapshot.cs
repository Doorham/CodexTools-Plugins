using System;

namespace WeTypeVoice2 {
    internal sealed class CommittedTextGuard {
        string expected;
        public void Expect(string full){expected=full;}
        public bool NativeIsComplete(string text){return expected==null || text==expected;}
        public void Reset(){expected=null;}
        public bool IgnoreNativePrefix(string text){
            if(expected==null)return false;
            bool prefix=expected.StartsWith(text,StringComparison.Ordinal);
            if(!prefix || text==expected)expected=null;
            return prefix;
        }
    }
    internal sealed class CompositionSnapshot {
        string prefix="",suffix="";
        public bool Active {get;private set;}
        public string Latest {get;private set;}
        public void Begin(string text,int start,int selected){
            start=Math.Max(0,Math.Min(start,text.Length));selected=Math.Max(0,Math.Min(selected,text.Length-start));
            prefix=text.Substring(0,start);suffix=text.Substring(start+selected);Latest=text;Active=true;
        }
        public string Update(string value){Latest=prefix+(value??"")+suffix;return Latest;}
        public string Commit(string value){prefix+=value??"";Latest=prefix+suffix;return Latest;}
        public void End(){Active=false;}
    }
}
