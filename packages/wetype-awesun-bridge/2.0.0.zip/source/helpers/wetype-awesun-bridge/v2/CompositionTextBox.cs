using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace WeTypeVoice2 {
    internal sealed class CompositionTextBox : TextBox {
        [DllImport("imm32.dll")] static extern IntPtr ImmGetContext(IntPtr hwnd);
        [DllImport("imm32.dll")] static extern bool ImmReleaseContext(IntPtr hwnd,IntPtr context);
        [DllImport("imm32.dll",CharSet=CharSet.Unicode)] static extern int ImmGetCompositionStringW(IntPtr context,uint kind,byte[] buffer,uint size);
        readonly CompositionSnapshot composition=new CompositionSnapshot();
        readonly CommittedTextGuard committed=new CommittedTextGuard();
        bool processingIme,uncommittedSnapshot;
        public Action<string,bool,string> Snapshot;
        public bool Composing {get{return composition.Active;}}
        public bool NativeEnded {get;private set;}
        public int CompositionSamples {get;private set;}
        public int MaxSampledCharacters {get;private set;}
        void Emit(string value,bool final,string source){if(Snapshot!=null)Snapshot(value,final,source);}
        protected override void OnTextChanged(EventArgs e) {
            base.OnTextChanged(e);
            if(!processingIme && !composition.Active && !committed.IgnoreNativePrefix(Text))Emit(Text,false,"text_changed");
        }
        string ReadComposition(uint kind) {
            IntPtr context=ImmGetContext(Handle);if(context==IntPtr.Zero)return null;
            try {
                int count=ImmGetCompositionStringW(context,kind,null,0);if(count<0)return null;
                byte[] bytes=new byte[count];int received=ImmGetCompositionStringW(context,kind,bytes,(uint)bytes.Length);
                return received<0?null:Encoding.Unicode.GetString(bytes,0,received);
            }finally{ImmReleaseContext(Handle,context);}
        }
        // Availability diagnostic only: do not turn an unverified polling route into captured speech.
        // Query only this receiver's input context, never another application's text or accessibility tree.
        public void SampleComposition(){
            if(NativeEnded)return;
            CompositionSamples++;
            string pending=ReadComposition(8);
            if(string.IsNullOrEmpty(pending))return;
            MaxSampledCharacters=Math.Max(MaxSampledCharacters,pending.Length);
        }
        protected override void WndProc(ref Message m) {
            if(m.Msg==0x10D) { // WM_IME_STARTCOMPOSITION; observe, do not swallow.
                NativeEnded=false;uncommittedSnapshot=false;composition.Begin(Text,SelectionStart,SelectionLength);base.WndProc(ref m);return;
            }
            if(m.Msg==0x10F) {
                if(!composition.Active)composition.Begin(Text,SelectionStart,SelectionLength);
                long flags=m.LParam.ToInt64();
                string result=(flags&0x800)!=0?ReadComposition(0x800):null;
                string pending=(flags&8)!=0?ReadComposition(8):null;
                string fullResult=result!=null?composition.Commit(result):null;
                if(fullResult!=null)committed.Expect(fullResult);
                if(fullResult!=null){uncommittedSnapshot=false;Emit(fullResult,true,"ime_result");}
                if(!string.IsNullOrEmpty(pending)){uncommittedSnapshot=true;Emit(composition.Update(pending),false,"ime_composition");}
                processingIme=true;try{base.WndProc(ref m);}finally{processingIme=false;}
                return;
            }
            if(m.Msg==0x10E) {
                processingIme=true;try{base.WndProc(ref m);}finally{processingIme=false;composition.End();NativeEnded=true;}
                // Cancellation can leave only an earlier committed prefix in Text. Preserve the captured tail.
                if(!uncommittedSnapshot && Text.Length>0 && committed.NativeIsComplete(Text)){
                    Emit(Text,true,"ime_end_text");committed.Reset();
                }
                return;
            }
            base.WndProc(ref m);
        }
    }
}
