using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using System.Web.Script.Serialization;
using WeTypeVoice2;

// Passive, bounded observation: configured shortcut edges, window visibility and clipboard sequence only.
// No key suppression, synthesized input, focus changes, audio samples or text/clipboard payloads.
internal sealed class EndGateProbe : ApplicationContext {
    delegate IntPtr KeyboardProc(int code,IntPtr message,IntPtr data);
    [StructLayout(LayoutKind.Sequential)] struct KeyData {public uint Key,Scan,Flags,Time;public UIntPtr Extra;}
    [DllImport("user32.dll",SetLastError=true)] static extern IntPtr SetWindowsHookEx(int kind,KeyboardProc proc,IntPtr module,uint thread);
    [DllImport("user32.dll")] static extern bool UnhookWindowsHookEx(IntPtr hook);
    [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr hook,int code,IntPtr message,IntPtr data);
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] static extern IntPtr GetModuleHandle(string name);
    readonly KeyboardProc callback;
    readonly IntPtr hook;
    readonly Timer timer=new Timer();
    readonly Stopwatch elapsed=Stopwatch.StartNew();
    readonly StreamWriter output;
    readonly VoiceHotkeySettings settings;
    readonly JavaScriptSerializer json=new JavaScriptSerializer();
    bool visible;
    uint sequence;
    readonly int duration;
    void Log(string kind,object data){output.WriteLine(json.Serialize(new {time=DateTimeOffset.Now.ToString("o"),ms=elapsed.Elapsed.TotalMilliseconds,kind=kind,data=data}));output.Flush();}
    [STAThread] static int Main(string[] args){
        try{
            if(args.Length==1 && args[0]=="--settings"){
                var s=VoiceHotkeySettings.Read();Console.WriteLine(new JavaScriptSerializer().Serialize(new {hold=s.Hold.Label,handsFree=s.HandsFree.Label,holdKeys=s.Hold.Keys,handsFreeKeys=s.HandsFree.Keys}));return 0;
            }
            if(args.Length!=2)return 2;
            Application.Run(new EndGateProbe(args[0],int.Parse(args[1])));return 0;
        }catch(Exception e){Console.Error.WriteLine(e.GetType().Name+": "+e.Message);return 1;}
    }
    EndGateProbe(string path,int seconds){
        if(seconds<1 || seconds>600)throw new ArgumentOutOfRangeException("seconds");duration=seconds;
        settings=VoiceHotkeySettings.Read();output=new StreamWriter(path,false,new UTF8Encoding(false));
        callback=Key;hook=SetWindowsHookEx(13,callback,GetModuleHandle(null),0);
        if(hook==IntPtr.Zero)throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
        sequence=Native.GetClipboardSequenceNumber();
        Log("ready",new {pid=Process.GetCurrentProcess().Id,hold=settings.Hold.Label,handsFree=settings.HandsFree.Label,passive=true});
        timer.Interval=15;timer.Tick+=(s,e)=>Tick();timer.Start();
    }
    IntPtr Key(int code,IntPtr message,IntPtr data){
        if(code>=0){
            var key=(KeyData)Marshal.PtrToStructure(data,typeof(KeyData));
            if(key.Key==settings.HandsFree.Trigger || key.Key==settings.Hold.Trigger){
                // Queue metadata after immediately forwarding; do not delay the observed shortcut with I/O.
                var edge=new {key=key.Key,message=message.ToInt64(),injected=(key.Flags&16)!=0,eventTick=key.Time,voiceVisible=visible,foregroundHandle=Native.GetForegroundWindow().ToInt64()};
                pending.Enqueue(new Receipt{Kind="shortcut_edge",Data=edge,Time=DateTimeOffset.Now,Milliseconds=elapsed.Elapsed.TotalMilliseconds});
            }
        }
        return CallNextHookEx(hook,code,message,data);
    }
    sealed class Receipt {public string Kind;public object Data;public DateTimeOffset Time;public double Milliseconds;}
    readonly System.Collections.Generic.Queue<Receipt> pending=new System.Collections.Generic.Queue<Receipt>();
    void Tick(){
        while(pending.Count>0){var item=pending.Dequeue();output.WriteLine(json.Serialize(new {time=item.Time.ToString("o"),ms=item.Milliseconds,kind=item.Kind,data=item.Data}));}
        bool now=false;
        Native.EnumWindows((h,p)=>{if(!Native.IsWindowVisible(h))return true;var title=new StringBuilder(80);Native.GetWindowText(h,title,title.Capacity);if(title.ToString()=="语音输入" && Native.IsWeType(h)){now=true;return false;}return true;},IntPtr.Zero);
        if(now!=visible){visible=now;Log("voice_visible",new {visible=visible,foreground=Native.NameOf(Native.GetForegroundWindow())});}
        uint next=Native.GetClipboardSequenceNumber();if(next!=sequence){sequence=next;Log("clipboard_sequence",new {sequence=sequence});}
        output.Flush();if(elapsed.Elapsed.TotalSeconds>=duration)ExitThread();
    }
    protected override void ExitThreadCore(){timer.Stop();UnhookWindowsHookEx(hook);Log("finished",new {passive=true});output.Dispose();timer.Dispose();base.ExitThreadCore();}
}
