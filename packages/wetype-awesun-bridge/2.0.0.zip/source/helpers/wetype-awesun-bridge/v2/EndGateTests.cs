using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using WeTypeVoice2;

internal static class EndGateTests {
    static int passed;
    static void Check(bool value,string reason){if(!value)throw new Exception(reason);}
    static void Test(string name,Action run){run();passed++;Console.WriteLine("PASS "+name);}
    static byte[] Field(int number,byte[] value){var b=new List<byte>();b.Add((byte)(number*8+2));uint n=(uint)value.Length;while(n>=128){b.Add((byte)(n|128));n>>=7;}b.Add((byte)n);b.AddRange(value);return b.ToArray();}
    static byte[] Config(string hold,string free){var b=new List<byte>();b.AddRange(Field(3,Encoding.UTF8.GetBytes(hold)));b.AddRange(Field(4,Encoding.UTF8.GetBytes(free)));return Field(8,b.ToArray());}
    static VoiceHotkeySettings Settings(){return VoiceHotkeySettings.Parse(Config("左Ctrl + 左Alt + `","左Ctrl + 左Alt + `"));}
    static EndShortcutState Model(bool voice){var s=new EndShortcutState(Settings());s.Seed(162,true);s.Seed(164,true);s.ObserveVoice(voice);return s;}
    static bool Key(EndShortcutState s,int key,bool down,bool remote,out EndRequest acquire,out EndRequest replay){return s.Key(key,down,remote,new IntPtr(remote?123:456),out acquire,out replay);}
    static void Bad(byte[] bytes){bool rejected=false;try{VoiceHotkeySettings.Parse(bytes);}catch(InvalidDataException){rejected=true;}catch(FormatException){rejected=true;}Check(rejected,"invalid configuration must not guess a key");}
    static int Main(){try{
        Test("parse actual format and a different user's shortcut",()=>{
            var s=Settings();Check(s.HandsFree.Trigger==192 && s.HandsFree.Keys[0]==162,"left modifiers");
            var other=VoiceHotkeySettings.Parse(Config("右Ctrl + F8","Ctrl + Shift + F9"));Check(other.HandsFree.Trigger==120 && other.Hold.Trigger==119,"different mapping");
        });
        Test("skip unrelated binary fields without decoding their content",()=>{
            var bytes=new List<byte>{8,255,255,255,255,255,255,255,255,255,1};bytes.AddRange(Field(4,new byte[]{255,0,255}));bytes.AddRange(Config("左Ctrl + 左Alt + `","左Ctrl + 左Alt + `"));
            Check(VoiceHotkeySettings.Parse(bytes.ToArray()).HandsFree.Trigger==192,"voice fields only");
        });
        Test("missing truncated and unknown configuration fail closed",()=>{Bad(new byte[0]);Bad(new byte[]{66,127,1});Bad(Config("左Ctrl + unknown","Ctrl + F9"));Bad(Config("","Ctrl + F9"));});
        Test("recording start passes through without a capture request",()=>{
            var s=Model(false);EndRequest a,r;Check(!Key(s,192,true,true,out a,out r) && a==null,"start down");Check(!Key(s,192,false,true,out a,out r) && a==null,"start release");s.ObserveVoice(true);Check(s.Pending==null,"window appearance does not acquire");
        });
        Test("local end passes through while AweSun is running",()=>{
            var s=Model(true);EndRequest a,r;Check(!Key(s,192,true,false,out a,out r) && a==null,"local down");Check(!Key(s,192,false,false,out a,out r) && a==null,"local release");
        });
        Test("screenshots paste and unrelated keys do not acquire",()=>{
            var s=Model(true);EndRequest a,r;
            foreach(int key in new[]{86,67,83,44,91,16}){Check(!Key(s,key,true,true,out a,out r) && a==null,"unrelated down");Check(!Key(s,key,false,true,out a,out r),"unrelated up");}
        });
        Test("remote end waits for verified focus and physical release",()=>{
            var s=Model(true);EndRequest a,r;Check(Key(s,192,true,true,out a,out r) && a!=null && r==null,"intercept");var ticket=a;
            Check(s.Acquired(ticket)==null,"still held");Check(Key(s,192,false,true,out a,out r) && r==ticket,"one replay after release");Check(s.Acquired(ticket)==null,"no duplicate");s.Complete(ticket);Check(s.Pending==null,"completed");
        });
        Test("early release is retained until focus succeeds",()=>{
            var s=Model(true);EndRequest a,r;Key(s,192,true,true,out a,out r);var ticket=a;
            Check(Key(s,192,false,true,out a,out r) && r==null,"release suppressed");Check(s.Acquired(ticket)==ticket,"replay after focus");
        });
        Test("key repeat never emits a second finish action",()=>{
            var s=Model(true);EndRequest a,r;Key(s,192,true,true,out a,out r);var ticket=a;
            for(int n=0;n<12;n++)Check(Key(s,192,true,true,out a,out r) && a==null && r==null,"repeat swallowed");
            s.Acquired(ticket);Key(s,192,false,true,out a,out r);Check(r==ticket,"exactly one");
        });
        Test("focus failure does not replay and pairs the suppressed release",()=>{
            var s=Model(true);EndRequest a,r;Key(s,192,true,true,out a,out r);var ticket=a;s.Cancel(ticket);
            Check(Key(s,192,false,true,out a,out r) && r==null,"paired key up");Check(s.Acquired(ticket)==null,"cancelled cannot replay");
        });
        Test("closed or replaced voice session invalidates delayed action",()=>{
            var s=Model(true);EndRequest a,r;Key(s,192,true,true,out a,out r);var ticket=a;s.ObserveVoice(false);Check(!s.Current(ticket),"closed");s.ObserveVoice(true);Check(!s.Current(ticket),"different generation");
        });
        Test("left versus right and extra modifiers are not confused",()=>{
            var s=Model(true);s.Seed(160,true);EndRequest a,r;Check(!Key(s,192,true,true,out a,out r),"extra shift");
            s=Model(true);s.Seed(162,false);s.Seed(163,true);Check(!Key(s,192,true,true,out a,out r),"wrong ctrl side");
        });
        Test("initial release after voice popup is not mistaken for the finish key",()=>{
            var s=Model(true);s.Seed(192,true);EndRequest a,r;
            Check(!Key(s,192,false,true,out a,out r) && a==null && r==null,"starting chord release passes");
            Check(Key(s,192,true,true,out a,out r) && a!=null,"a fresh finish press captures");
        });
        Test("observer closes after voice ends and never abandons a swallowed key release",()=>{
            var s=Model(false);Check(s.CanUnhook,"idle has no hook");s.ObserveVoice(true);Check(!s.CanUnhook,"recording retains observer");
            EndRequest a,r;Key(s,192,true,true,out a,out r);var ticket=a;s.ObserveVoice(false);s.Cancel(ticket);
            Check(!s.CanUnhook,"must pair the withheld key");Key(s,192,false,true,out a,out r);Check(s.CanUnhook,"can detach after release");
        });
        Test("unreadable changed settings stop interception",()=>{
            var s=Model(true);s.Settings(null);EndRequest a,r;Check(!Key(s,192,true,true,out a,out r),"do not use stale configuration");
        });
        Test("native hook exists only within each observed recording",()=>{
            using(var gate=new EndShortcutGate(Settings(),r=>{},r=>{})){
                GateObservation item;Check(!gate.Observation(out item),"no hook on startup");
                for(int n=0;n<2;n++){
                    gate.Observe(true,new uint[0]);item=WaitFor(gate,"end_hook_opened");
                    Check((bool)item.Data.GetType().GetProperty("installed").GetValue(item.Data,null),"native installation");
                    gate.Observe(false,new uint[0]);item=WaitFor(gate,"end_hook_closed");
                    Check((bool)item.Data.GetType().GetProperty("removed").GetValue(item.Data,null),"native removal");
                }
            }
        });
        Console.WriteLine("RESULT "+passed+"/"+passed+" end gate tests passed; state checks and passive native hook lifecycle; no input generated.");return 0;
    }catch(Exception e){Console.Error.WriteLine("FAIL "+e);return 1;}}
    static GateObservation WaitFor(EndShortcutGate gate,string kind){
        var time=System.Diagnostics.Stopwatch.StartNew();
        while(time.ElapsedMilliseconds<2000){GateObservation item;while(gate.Observation(out item))if(item.Kind==kind)return item;System.Threading.Thread.Sleep(5);}
        throw new Exception("Missing native lifecycle event: "+kind);
    }
}
