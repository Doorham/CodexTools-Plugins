using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace WeTypeVoice2 {
    internal sealed class VoiceChord {
        public readonly int[] Keys;
        public readonly string Label;
        public int Trigger {get{return Keys[Keys.Length-1];}}
        VoiceChord(string label,int[] keys){Label=label;Keys=keys;}
        public static VoiceChord Parse(string label){
            if(string.IsNullOrWhiteSpace(label) || label.Length>100)throw new FormatException("快捷键为空或过长");
            var keys=new List<int>();
            foreach(string raw in label.Split('+')){
                string part=raw.Trim();int key=Key(part);
                if(key==0 || keys.Contains(key))throw new FormatException("暂不支持的快捷键格式");
                keys.Add(key);
            }
            if(keys.Count<1 || keys.Count>5)throw new FormatException("快捷键长度不支持");
            for(int n=0;n<keys.Count-1;n++)if(!Modifier(keys[n]))throw new FormatException("快捷键修饰键不支持");
            return new VoiceChord(label,keys.ToArray());
        }
        public static bool Modifier(int key){return key==16 || key==17 || key==18 || key==91 || key==92 || (key>=160 && key<=165);}
        static int Key(string name){
            switch(name.ToUpperInvariant()){
                case "左CTRL":case "左CONTROL":return 162;case "右CTRL":case "右CONTROL":return 163;case "CTRL":case "CONTROL":return 17;
                case "左ALT":return 164;case "右ALT":return 165;case "ALT":return 18;
                case "左SHIFT":return 160;case "右SHIFT":return 161;case "SHIFT":return 16;
                case "左WIN":case "WIN":case "WINDOWS":return 91;case "右WIN":return 92;
                case "空格":case "SPACE":return 32;case "TAB":return 9;case "ESC":case "ESCAPE":return 27;
                case "回车":case "ENTER":return 13;case "`":case "~":return 192;
                case ";":return 186;case "=":return 187;case ",":return 188;case "-":return 189;
                case ".":return 190;case "/":return 191;case "[":return 219;case "\\":return 220;case "]":return 221;case "'":return 222;
            }
            string upper=name.ToUpperInvariant();
            if(upper.Length==1 && ((upper[0]>='A' && upper[0]<='Z') || (upper[0]>='0' && upper[0]<='9')))return upper[0];
            int number;if(upper.StartsWith("F",StringComparison.Ordinal) && int.TryParse(upper.Substring(1),out number) && number>=1 && number<=24)return 111+number;
            return 0;
        }
    }
    internal sealed class VoiceHotkeySettings {
        public readonly VoiceChord Hold,HandsFree;
        VoiceHotkeySettings(VoiceChord hold,VoiceChord handsFree){Hold=hold;HandsFree=handsFree;}
        [DllImport("shell32.dll")] static extern int SHGetKnownFolderPath(ref Guid id,uint flags,IntPtr token,out IntPtr path);
        public static string SettingsPath(){
            Guid id=new Guid("A520A1A4-1780-4FF6-BD18-167343C5AF16");IntPtr p;
            int hr=SHGetKnownFolderPath(ref id,0,IntPtr.Zero,out p);Marshal.ThrowExceptionForHR(hr);
            try{return Path.Combine(Marshal.PtrToStringUni(p),"Tencent","WeType","WeTypeSharedData.pb");}finally{Marshal.FreeCoTaskMem(p);}
        }
        public static VoiceHotkeySettings Read(){
            using(var input=new FileStream(SettingsPath(),FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete)){
                if(input.Length<1 || input.Length>65536)throw new InvalidDataException("微信快捷键配置大小异常");
                var data=new byte[(int)input.Length];int count=0;
                while(count<data.Length){int n=input.Read(data,count,data.Length-count);if(n==0)throw new EndOfStreamException();count+=n;}
                return Parse(data);
            }
        }
        // Only copy the voice-settings submessage. Account/device fields are skipped, never decoded or logged.
        public static VoiceHotkeySettings Parse(byte[] data){
            byte[] voice=Field(data,8);if(voice==null)throw new InvalidDataException("未找到微信语音快捷键配置");
            byte[] hold=Field(voice,3),handsFree=Field(voice,4);
            if(hold==null || handsFree==null)throw new InvalidDataException("微信语音快捷键配置不完整");
            var utf8=new UTF8Encoding(false,true);
            return new VoiceHotkeySettings(VoiceChord.Parse(utf8.GetString(hold)),VoiceChord.Parse(utf8.GetString(handsFree)));
        }
        static ulong Varint(byte[] data,ref int offset){
            ulong value=0;for(int n=0;n<10;n++){
                if(offset>=data.Length)throw new InvalidDataException("配置被截断");
                byte next=data[offset++];if(n==9 && next>1)throw new InvalidDataException("配置数字溢出");
                value|=(ulong)(next&127)<<(7*n);if((next&128)==0)return value;
            }throw new InvalidDataException("配置数字无效");
        }
        static byte[] Field(byte[] data,int wanted){
            int p=0;byte[] result=null;
            while(p<data.Length){
                ulong tag=Varint(data,ref p);int kind=(int)(tag&7);ulong field=tag>>3;
                if(field==0)throw new InvalidDataException("配置字段无效");
                ulong length;
                if(kind==0){Varint(data,ref p);continue;}
                if(kind==1)length=8;else if(kind==5)length=4;else if(kind==2)length=Varint(data,ref p);else throw new InvalidDataException("配置类型不支持");
                if(length>(ulong)(data.Length-p))throw new InvalidDataException("配置长度异常");
                if(field==(ulong)wanted && kind==2){result=new byte[(int)length];Buffer.BlockCopy(data,p,result,0,(int)length);}
                p+=(int)length;
            }return result;
        }
    }
}
