using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
namespace WeTypeVoice2 {
    internal static class Native {
        internal delegate bool WindowProc(IntPtr h,IntPtr unused);
        [DllImport("user32.dll")] internal static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll",SetLastError=true)] internal static extern bool SetForegroundWindow(IntPtr h);
        [DllImport("user32.dll",SetLastError=true)] internal static extern bool AttachThreadInput(uint a,uint b,bool attach);
        [DllImport("user32.dll")] internal static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid);
        [DllImport("kernel32.dll")] internal static extern uint GetCurrentThreadId();
        [DllImport("kernel32.dll")] internal static extern void SetLastError(uint error);
        [DllImport("user32.dll")] internal static extern IntPtr SetFocus(IntPtr h);
        [DllImport("user32.dll")] internal static extern IntPtr GetFocus();
        [DllImport("user32.dll")] internal static extern bool IsWindow(IntPtr h);
        [DllImport("user32.dll")] internal static extern bool IsWindowVisible(IntPtr h);
        [DllImport("user32.dll")] internal static extern bool IsHungAppWindow(IntPtr h);
        [DllImport("user32.dll")] internal static extern bool EnumWindows(WindowProc action,IntPtr unused);
        [DllImport("user32.dll",CharSet=CharSet.Unicode)] internal static extern int GetWindowText(IntPtr h,StringBuilder s,int n);
        [DllImport("user32.dll",CharSet=CharSet.Unicode)] internal static extern int GetClassName(IntPtr h,StringBuilder s,int n);
        [DllImport("user32.dll")] internal static extern uint GetClipboardSequenceNumber();
        [DllImport("user32.dll")] internal static extern IntPtr GetOpenClipboardWindow();
        [DllImport("user32.dll")] static extern short GetAsyncKeyState(int key);
        internal static bool MouseDown(){return (GetAsyncKeyState(1)&0x8000)!=0 || (GetAsyncKeyState(2)&0x8000)!=0 || (GetAsyncKeyState(4)&0x8000)!=0 || (GetAsyncKeyState(5)&0x8000)!=0 || (GetAsyncKeyState(6)&0x8000)!=0;}
        internal static string ClassOf(IntPtr h){var s=new StringBuilder(128);GetClassName(h,s,s.Capacity);return s.ToString();}
        internal static string NameOf(IntPtr h){uint p;GetWindowThreadProcessId(h,out p);try{using(var process=Process.GetProcessById((int)p))return process.ProcessName;}catch{return "";}}
        internal static bool IsWeType(IntPtr h){return h!=IntPtr.Zero && NameOf(h).StartsWith("wetype",StringComparison.OrdinalIgnoreCase);}
    }
}
