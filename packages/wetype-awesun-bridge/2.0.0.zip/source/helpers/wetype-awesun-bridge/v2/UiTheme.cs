using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
namespace WeTypeVoice2 {
    // Palette inherited from CodexTools' adopted native plugin surfaces.
    internal static class UiTheme {
        public static bool Dark=ReadDark();
        static Color Hex(string value){return ColorTranslator.FromHtml(value);}
        public static Color Background {get{return Hex(Dark?"#171820":"#f4f5f8");}}
        public static Color Panel {get{return Hex(Dark?"#22242e":"#ffffff");}}
        public static Color Soft {get{return Hex(Dark?"#2c2e3a":"#eceef5");}}
        public static Color Text {get{return Hex(Dark?"#f0f0f7":"#252735");}}
        public static Color Muted {get{return Hex(Dark?"#abb0c4":"#687087");}}
        public static Color Line {get{return Hex(Dark?"#3a3d4d":"#dfe2ec");}}
        public static Color Accent {get{return Hex(Dark?"#bba6ff":"#6741d9");}}
        public static Color Primary {get{return Hex("#6741d9");}}
        public static Color Selected {get{return Hex(Dark?"#34304c":"#ece5ff");}}
        public static Color Success {get{return Hex(Dark?"#75d6b4":"#16846a");}}
        static bool ReadDark(){
            try {
                var path=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"CodexTools","CodexTools","theme.txt");
                return File.Exists(path) && File.ReadAllText(path).Trim()=="dark";
            }catch(IOException){return false;}catch(UnauthorizedAccessException){return false;}
        }
        public static GraphicsPath Round(RectangleF r,float radius){
            float d=radius*2;var p=new GraphicsPath();
            p.AddArc(r.Left,r.Top,d,d,180,90);p.AddArc(r.Right-d,r.Top,d,d,270,90);
            p.AddArc(r.Right-d,r.Bottom-d,d,d,0,90);p.AddArc(r.Left,r.Bottom-d,d,d,90,90);p.CloseFigure();return p;
        }
        [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr window,int attr,ref int value,int size);
        public static void WindowChrome(Form form){
            if(SystemInformation.HighContrast)return;
            try {
                int dark=Dark?1:0,corner=2,caption=ColorTranslator.ToWin32(Background),text=ColorTranslator.ToWin32(Text),line=ColorTranslator.ToWin32(Line);
                DwmSetWindowAttribute(form.Handle,20,ref dark,4);DwmSetWindowAttribute(form.Handle,33,ref corner,4);
                DwmSetWindowAttribute(form.Handle,34,ref line,4);DwmSetWindowAttribute(form.Handle,35,ref caption,4);DwmSetWindowAttribute(form.Handle,36,ref text,4);
            }catch(DllNotFoundException){}catch(EntryPointNotFoundException){}
        }
        public static Image LoadBrand(){
            using(var s=Assembly.GetExecutingAssembly().GetManifestResourceStream("WeTypeVoice2.Brand.png"))
                if(s!=null)using(var original=Image.FromStream(s))return new Bitmap(original);
            return null;
        }
    }
    internal sealed class SurfacePanel : Panel {
        public SurfacePanel(){DoubleBuffered=true;BackColor=UiTheme.Panel;Padding=new Padding(18);}
        protected override void OnPaintBackground(PaintEventArgs e){
            e.Graphics.Clear(Parent==null?UiTheme.Background:Parent.BackColor);e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;
            using(var p=UiTheme.Round(new RectangleF(0,0,Width-1,Height-1),14)){
                using(var b=new SolidBrush(UiTheme.Panel))e.Graphics.FillPath(b,p);
                using(var pen=new Pen(UiTheme.Line))e.Graphics.DrawPath(pen,p);
            }
        }
    }
    internal sealed class ActionButton : Button {
        public bool Primary {get;set;}
        bool hover;
        public ActionButton(){SetStyle(ControlStyles.UserPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.AllPaintingInWmPaint,true);FlatStyle=FlatStyle.Flat;FlatAppearance.BorderSize=0;Cursor=Cursors.Hand;UseVisualStyleBackColor=false;}
        protected override void OnMouseEnter(EventArgs e){hover=true;Invalidate();base.OnMouseEnter(e);}
        protected override void OnMouseLeave(EventArgs e){hover=false;Invalidate();base.OnMouseLeave(e);}
        protected override void OnPaint(PaintEventArgs e){
            e.Graphics.Clear(Parent==null?UiTheme.Background:Parent.BackColor);e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;
            var fill=!Enabled?UiTheme.Soft:Primary?UiTheme.Primary:hover?UiTheme.Soft:UiTheme.Panel;
            using(var path=UiTheme.Round(new RectangleF(1,1,Width-3,Height-3),9)){
                using(var brush=new SolidBrush(fill))e.Graphics.FillPath(brush,path);
                using(var pen=new Pen(Focused?UiTheme.Accent:Primary?fill:UiTheme.Line,Focused?2:1))e.Graphics.DrawPath(pen,path);
            }
            TextRenderer.DrawText(e.Graphics,Text,Font,ClientRectangle,!Enabled?UiTheme.Muted:Primary?Color.White:UiTheme.Text,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.SingleLine);
        }
    }
}