using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

[assembly:System.Reflection.AssemblyFileVersion("2.0.0.0")]
[assembly:System.Reflection.AssemblyInformationalVersion("2.0.0")]
[assembly:System.Reflection.AssemblyCompany("Althy, DRHW")]
[assembly:System.Reflection.AssemblyProduct("微信语音监听板")]

namespace WeTypeVoice2 {
    internal sealed class VoiceApp : ApplicationContext {
        const string Version="2.0.0";
        readonly EventWaitHandle[] signals;
        readonly SpeechHistoryWindow panel;
        readonly NotifyIcon tray=new NotifyIcon();
        readonly System.Windows.Forms.Timer timer=new System.Windows.Forms.Timer();
        readonly List<ReceiverCapture> retired=new List<ReceiverCapture>();
        readonly RecordingPipeline pipeline;
        readonly string folder=AppDomain.CurrentDomain.BaseDirectory;
        readonly int ownPid=Process.GetCurrentProcess().Id;
        ReceiverCapture active;
        IntPtr voiceWindow;
        EndShortcutGate endGate;
        VoiceHotkeySettings shortcuts;
        uint[] remotePids=new uint[0];
        readonly RemoteClientCatalog remoteClients=new RemoteClientCatalog();
        DateTime nextSettingsScan,nextTargetScan,recordingStarted;
        string shortcutStatus="";
        bool watching,wasVoiceVisible,exiting,inTick;
        DateTime nextScan,lastUiUpdate;
        string message="正在启动监听",lastStatusJson;
        static readonly string[] Commands={"stop","show","start","history"};
        static string BaseName {get{return "Local\\WeTypeVoice2_Stop_"+WindowsIdentity.GetCurrent().User.Value;}}
        static string SignalName(int index){return index==0?BaseName:BaseName+"_"+Commands[index];}
        static int Signal(int index){
            try{using(var signal=EventWaitHandle.OpenExisting(SignalName(index)))signal.Set();return 0;}
            catch(WaitHandleCannotBeOpenedException){return 1;}
        }
        [STAThread] static int Main(string[] args){
            if(args.Length==1){for(int n=0;n<Commands.Length;n++)if(args[0]=="--"+Commands[n])return Signal(n);return 3;}
            if(args.Length>0)return 3;
            bool created;
            using(var singleton=new Mutex(true,BaseName+"_Single",out created)){
                if(!created)return Signal(1);
                var events=new EventWaitHandle[Commands.Length];
                try{
                    for(int n=0;n<events.Length;n++)events[n]=new EventWaitHandle(false,EventResetMode.AutoReset,SignalName(n));
                    Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
                    Application.Run(new VoiceApp(events));
                }finally{foreach(var e in events)if(e!=null)e.Dispose();}
            }
            return 0;
        }
        internal VoiceApp(EventWaitHandle[] events){
            signals=events;
            pipeline=new RecordingPipeline(new SystemClipboard(()=>panel.Handle));
            panel=new SpeechHistoryWindow(pipeline.History,id=>pipeline.Delivery.CopyRecord(id,DateTime.UtcNow));
            panel.ExitRequested+=ExitThread;
            panel.FormClosing+=(s,e)=>{if(!exiting){e.Cancel=true;panel.Hide();}};
            pipeline.Delivery.Report=DeliveryReport;
            var menu=new ContextMenuStrip();
            menu.Items.Add("打开语音历史",null,(s,e)=>ShowPanel());
            menu.Items.Add("复制最近全文",null,(s,e)=>CopyLatest());
            menu.Items.Add("退出",null,(s,e)=>ExitThread());
            tray.Icon=Icon.ExtractAssociatedIcon(Application.ExecutablePath)??SystemIcons.Application;
            tray.Text="微信语音监听板";tray.ContextMenuStrip=menu;tray.Visible=true;
            tray.DoubleClick+=(s,e)=>ShowPanel();tray.BalloonTipClicked+=(s,e)=>ShowPanel();
            timer.Interval=80;timer.Tick+=Tick;timer.Start();
            Log("ready",new {version=Version,pid=ownPid,administrator=new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator),autoListen=true,endOnly=true});
            StartListening();panel.Show();UpdatePanel();SaveStatus();
        }
        void ShowPanel(){panel.Show();panel.Activate();UpdatePanel();}
        void UpdatePanel(){panel.SetActivity(watching,wasVoiceVisible && active==null,active!=null && active.EndRequested,message);}
        void ViewHistory(){ShowPanel();}
        void CopyLatest(){pipeline.Delivery.CopyLatest(DateTime.UtcNow);pipeline.History.FlushChanges();UpdatePanel();}
        bool OwnWindow(IntPtr h){uint pid;Native.GetWindowThreadProcessId(h,out pid);return pid==ownPid;}
        void StartListening(){
            if(watching)return;
            try{
                wasVoiceVisible=false;nextScan=DateTime.MinValue;
                ReloadShortcuts();RefreshTargets();
                endGate=new EndShortcutGate(shortcuts,r=>Post(()=>AcquireAtEnd(r)),r=>Post(()=>ReplayEnd(r)));
                watching=true;
                message=shortcuts==null?shortcutStatus:"监听中；本机正常输入，向日葵在结束时接收";Log("listening_started",new {endOnly=true});
                UpdatePanel();
            }catch(Exception e){message="启动未完成："+e.GetType().Name;Log("start_failed",new {error=e.GetType().Name});UpdatePanel();}
        }
        bool VoiceVisible(DateTime now){
            if(voiceWindow!=IntPtr.Zero && Native.IsWindow(voiceWindow) && Native.IsWindowVisible(voiceWindow))return true;
            voiceWindow=IntPtr.Zero;if(now<nextScan)return false;nextScan=now.AddMilliseconds(160);
            Native.EnumWindows((h,unused)=>{
                if(!Native.IsWindowVisible(h))return true;
                var title=new StringBuilder(128);Native.GetWindowText(h,title,title.Capacity);
                if(title.ToString()=="语音输入" && Native.IsWeType(h)){voiceWindow=h;return false;}return true;
            },IntPtr.Zero);
            return voiceWindow!=IntPtr.Zero;
        }
        void Tick(object sender,EventArgs args){
            if(inTick || exiting)return;
            inTick=true;
            try{
                if(signals[0].WaitOne(0)){ExitThread();return;}
                if(signals[1].WaitOne(0))ShowPanel();
                if(signals[2].WaitOne(0))StartListening();
                if(signals[3].WaitOne(0))ViewHistory();
                DateTime now=DateTime.UtcNow;
                // A later pump handles delivery/UI. Native input callbacks cannot execute this path.
                pipeline.Pump(now);
                FlushReceipts();
                if(endGate!=null){GateObservation observation;while(endGate.Observation(out observation))Log(observation.Kind,observation.Data);}
                if(watching){
                    if(now>=nextSettingsScan){nextSettingsScan=now.AddSeconds(2);ReloadShortcuts();}
                    if(now>=nextTargetScan){nextTargetScan=now.AddSeconds(1);RefreshTargets();}
                    bool visible=VoiceVisible(now);
                    endGate.Observe(visible,remotePids);
                    if(visible && !wasVoiceVisible){
                        if(active!=null)FinishSession("next_recording");
                        foreach(var old in retired)old.Cancelled=true;
                        pipeline.Delivery.Pause();
                        recordingStarted=now;
                        message="录音中，可正常截图、粘贴和切换窗口";
                        Log("voice_observed",new {endOnly=true});
                    }
                    if(!visible && wasVoiceVisible && active==null){message="本段由微信自行结束；监听板未接管";Log("voice_passed_through",new {captured=false});}
                    if(active!=null){
                        var current=active;
                        if(!visible && !current.EndRequested){
                            current.EndRequested=true;current.EndRequestedAt=now;pipeline.End(current.Record.Session);
                            message=current.Record.Text.Length==0?"录音已结束，等待输入法交付文字":"正在处理本段最终提交";
                            Log("voice_window_closed",new {session=current.Record.Session,characters=current.Record.Text.Length,final=current.Record.HasFinal});
                        }
                        if(visible){

                            if(now>=current.NextSample){current.NextSample=now.AddMilliseconds(500);current.Input.SampleComposition();}
                        }
                        if(current.EndRequested && ((!current.Input.Composing && (current.Record.HasFinal || current.Input.NativeEnded)) || (now-current.EndRequestedAt).TotalMilliseconds>=1500))
                            FinishSession(current.Record.HasFinal?"final_received":"ended_without_final");
                    }
                    wasVoiceVisible=visible;
                }
                CollectReceivers();
                pipeline.History.FlushChanges();
                if((now-lastUiUpdate).TotalMilliseconds>=300){lastUiUpdate=now;UpdatePanel();SaveStatus();}
            }finally{inTick=false;}
        }
        void Post(Action action){
            if(exiting)return;
            try{panel.BeginInvoke((MethodInvoker)(()=>{if(!exiting)action();}));}catch(InvalidOperationException){}
        }
        void ReloadShortcuts(){
            try{
                var current=VoiceHotkeySettings.Read();
                if(shortcuts==null || shortcuts.Hold.Label!=current.Hold.Label || shortcuts.HandsFree.Label!=current.HandsFree.Label){
                    shortcuts=current;shortcutStatus="";if(endGate!=null)endGate.Settings(current);
                    Log("shortcut_configured",new {hold=current.Hold.Label,handsFree=current.HandsFree.Label});
                }
            }catch(Exception e){
                shortcuts=null;if(endGate!=null)endGate.Settings(null);
                string error="未能读取微信语音快捷键；自动接管暂不可用";
                if(shortcutStatus!=error)Log("shortcut_config_failed",new {error=e.GetType().Name});
                shortcutStatus=error;message=error;
            }
        }
        void RefreshTargets(){remotePids=remoteClients.Snapshot(DateTime.UtcNow);}
        bool RequestStillValid(EndRequest request){
            return endGate.Current(request) && voiceWindow!=IntPtr.Zero && Native.IsWindowVisible(voiceWindow);
        }
        void AcquireAtEnd(EndRequest request){
            if(!RequestStillValid(request) || Native.GetForegroundWindow()!=request.Target){endGate.Cancel(request);message="目标已改变，未接管本次结束动作；录音状态请以微信为准";return;}
            uint pid;Native.GetWindowThreadProcessId(request.Target,out pid);
            if(Array.IndexOf(remotePids,pid)<0){endGate.Cancel(request);return;}
            if(active!=null)FinishSession("new_end_request");
            var record=pipeline.Begin(DateTime.UtcNow);record.Started=recordingStarted;pipeline.DeferDelivery=true;
            active=new ReceiverCapture(record,pipeline,request.Target);
            active.Window.Show();
            active.FocusOwned=FocusTransfer.Try(active.Window.Handle,active.Window.Handle,active.Input.Handle,"end_acquire",Log);
            Log("end_intercepted",new {session=record.Session,acquired=active.FocusOwned,returnClass=Native.ClassOf(request.Target)});
            if(!active.FocusOwned){
                endGate.Cancel(request);FinishSession("end_focus_failed");
                message="未取得接收焦点，尚未转交结束按键；请留意微信录音状态";
                tray.ShowBalloonTip(4000,"尚未完成语音接管",message,ToolTipIcon.Warning);return;
            }
            message="已接管，等待结束按键松开";endGate.Acquired(request);
        }
        void ReplayEnd(EndRequest request){
            if(!RequestStillValid(request) || active==null || Native.GetForegroundWindow()!=active.Window.Handle){
                endGate.Cancel(request);if(active!=null)FinishSession("end_target_changed");
                message="结束前焦点已改变，未转交结束按键；请留意微信录音状态";return;
            }
            bool sent=VoiceKeyInput.Replay(request);endGate.Complete(request);
            Log("end_replayed",new {session=active.Record.Session,sent=sent});
            if(!sent){FinishSession("end_replay_failed");message="结束按键未能送达；请留意微信录音状态";}
            else message="正在接收本段语音，全文会留在历史中";
        }
        void FinishSession(string reason){
            var current=active;if(current==null)return;
            pipeline.End(current.Record.Session);
            pipeline.DeferDelivery=false;
            FlushReceipt(current);
            if(Native.GetForegroundWindow()==current.Window.Handle && current.ReturnWindow!=IntPtr.Zero){
                uint pid;Native.GetWindowThreadProcessId(current.ReturnWindow,out pid);
                if(pid==current.ReturnPid)FocusTransfer.Try(current.Window.Handle,current.ReturnWindow,IntPtr.Zero,"return",Log);
            }
            current.Window.Hide();retired.Add(current);active=null;
            var record=current.Record;
            message=record.Text.Length==0?"本段未收到文字；历史中的旧段仍保留":"已结束 · 本段保留 "+record.Text.Length+" 字"+(record.HasFinal?"":"（未确认最终提交）");
            if(record.Text.Length>0 && pipeline.Delivery.Pending)message+="；"+(pipeline.Delivery.Paused?"自动复制已暂停":"等待复制");
            Log("session_finished",new {session=record.Session,characters=record.Text.Length,final=record.HasFinal,reason=reason,copyPending=pipeline.Delivery.Pending,copyPaused=pipeline.Delivery.Paused,copyFailed=pipeline.Delivery.Failed,compositionSamples=current.Input.CompositionSamples,maxSampledCharacters=current.Input.MaxSampledCharacters});
        }
        void FlushReceipts(){if(active!=null)FlushReceipt(active);foreach(var r in retired)FlushReceipt(r);}
        void FlushReceipt(ReceiverCapture source){
            var r=source.Record;if(r.Revision==source.LastLoggedRevision)return;
            Log("input_received",new {session=r.Session,characters=r.Text.Length,revision=r.Revision,final=r.HasFinal,composition=r.HadComposition,imeResults=source.ImeResults,compositions=source.Compositions,textChanges=source.TextChanges,afterVoiceEnd=r.Ended});
            source.LastLoggedRevision=r.Revision;
        }
        void CollectReceivers(){
            for(int n=retired.Count-1;n>=0;n--){
                var source=retired[n];
                if(source.Cancelled || (!source.Input.Composing && (source.Record.HasFinal || source.Input.NativeEnded))){source.Dispose();retired.RemoveAt(n);}
            }
        }
        void DeliveryReport(string kind,int session,int count){
            Log(kind,new {session=session,characters=count});
            if(kind=="copied_local" || kind=="history_copied_local")message="已复制到本机剪贴板 · "+count+" 字";
            else if(kind=="external_copy_pause")message="剪贴板已被其他程序更新；全文保留，自动复制暂停";
            else if(kind=="copy_retry_pending")message="剪贴板被占用，全文已保存，正在等待";
            else if(kind=="history_copy_failed")message="复制未成功，选中的全文仍在历史中";
            else if(kind=="copy_failed_retained"){
                IntPtr holder=Native.GetOpenClipboardWindow();uint pid;uint tid=Native.GetWindowThreadProcessId(holder,out pid);
                Log("clipboard_wait",new {error=pipeline.Delivery.LastError,holderPid=pid,holderThread=tid,windowClass=Native.ClassOf(holder)});
                message="剪贴板仍被占用；全文在历史中，释放后继续尝试";
                tray.ShowBalloonTip(5000,"文字已保留，尚未复制",message,ToolTipIcon.Warning);
                if(active==null){panel.Show();UpdatePanel();}
            }
        }
        void Log(string kind,object data){
            try{File.AppendAllText(Path.Combine(folder,"events.jsonl"),new JavaScriptSerializer().Serialize(new {time=DateTimeOffset.Now.ToString("o"),kind=kind,data=data})+Environment.NewLine,new UTF8Encoding(false));}
            catch(IOException){}catch(UnauthorizedAccessException){}
        }
        void SaveStatus(){
            var r=pipeline.History.Current;
            string json=new JavaScriptSerializer().Serialize(new {version=Version,pid=ownPid,watching=watching,voiceVisible=wasVoiceVisible,receiving=active!=null && !active.EndRequested,finishing=active!=null && active.EndRequested,session=r==null?0:r.Session,characters=r==null?0:r.Text.Length,retainedCharacters=pipeline.History.Retained.Length,historyRecords=pipeline.History.Entries.Count,hasFinal=r!=null && r.HasFinal,hadComposition=r!=null && r.HadComposition,copyPending=pipeline.Delivery.Pending,copyPaused=pipeline.Delivery.Paused,copyFailed=pipeline.Delivery.Failed,message=message});
            if(json==lastStatusJson)return;
            try{File.WriteAllText(Path.Combine(folder,"status.json"),json,new UTF8Encoding(false));lastStatusJson=json;}
            catch(IOException){}catch(UnauthorizedAccessException){}
        }
        protected override void ExitThreadCore(){
            exiting=true;watching=false;timer.Stop();if(endGate!=null){endGate.Dispose();endGate=null;}
            if(active!=null)FinishSession("process_exit");
            FlushReceipts();foreach(var r in retired)r.Dispose();retired.Clear();
            Log("exited",new {oldAutoRestored=false});SaveStatus();
            tray.Visible=false;tray.Dispose();panel.Dispose();timer.Dispose();base.ExitThreadCore();
        }
    }
}
