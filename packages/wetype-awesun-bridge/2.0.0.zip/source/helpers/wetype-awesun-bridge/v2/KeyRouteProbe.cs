using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using WeTypeVoice2;

// Read-only keyboard-route comparison. No suppression, synthesis, focus, microphone or text access.
// Only configured shortcut keys get per-event records; all other keys contribute aggregate counts.
internal sealed class KeyRouteProbe : ApplicationContext {
    delegate IntPtr HookProc(int code,IntPtr message,IntPtr data);
    [StructLayout(LayoutKind.Sequential)] struct KeyData {public uint Key,Scan,Flags,Time;public UIntPtr Extra;}
    [StructLayout(LayoutKind.Sequential)] struct Device {public ushort Page,Usage;public uint Flags;public IntPtr Window;}
    [StructLayout(LayoutKind.Sequential)] struct Header {public uint Type,Size;public IntPtr Device;public UIntPtr Parameter;}
    [DllImport("user32.dll",SetLastError=true)] static extern IntPtr SetWindowsHookEx(int kind,HookProc callback,IntPtr module,uint thread);
    [DllImport("user32.dll")] static extern bool UnhookWindowsHookEx(IntPtr hook);
    [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr hook,int code,IntPtr message,IntPtr data);
    [DllImport("user32.dll",SetLastError=true)] static extern bool RegisterRawInputDevices(Device[] devices,uint count,uint size);
    [DllImport("user32.dll",SetLastError=true)] static extern uint GetRawInputData(IntPtr input,uint command,IntPtr data,ref uint size,uint headerSize);
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] static extern IntPtr GetModuleHandle(string name);
    readonly HookProc earlyCallback,lateCallback;
    IntPtr earlyHook,lateHook;
    readonly Sink window;
    readonly Timer timer=new Timer();
    readonly Stopwatch watch=Stopwatch.StartNew();
    readonly VoiceHotkeySettings settings;
    readonly JavaScriptSerializer json=new JavaScriptSerializer();
    readonly StreamWriter output;
    readonly Queue<object> receipts=new Queue<object>();
    readonly bool[][] pressed={new bool[256],new bool[256],new bool[256]};
    readonly long[] total=new long[3],physical=new long[3],trigger=new long[3];
    readonly int seconds;
    bool visible;
    int generation;
    long nextSummary;
    string lastCounts="";
    sealed class Sink : NativeWindow,IDisposable {
        readonly KeyRouteProbe owner;
        internal Sink(KeyRouteProbe probe){owner=probe;CreateHandle(new CreateParams{Caption="WeType key-route observer",Parent=new IntPtr(-3)});}
        protected override void WndProc(ref Message message){if(message.Msg==0xff)owner.Raw(message.LParam);base.WndProc(ref message);}
        public void Dispose(){DestroyHandle();}
    }
    [STAThread] static int Main(string[] args){
        try{if(args.Length!=2)return 2;Application.Run(new KeyRouteProbe(args[0],int.Parse(args[1])));return 0;}
        catch(Exception e){Console.Error.WriteLine(e.GetType().Name+": "+e.Message);return 1;}
    }
    KeyRouteProbe(string path,int duration){
        if(duration<1 || duration>3600)throw new ArgumentOutOfRangeException("duration");seconds=duration;
        settings=VoiceHotkeySettings.Read();output=new StreamWriter(path,false,new UTF8Encoding(false));
        window=new Sink(this);
        var device=new Device{Page=1,Usage=6,Flags=0x100,Window=window.Handle};
        if(!RegisterRawInputDevices(new[]{device},1,(uint)Marshal.SizeOf(typeof(Device))))throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
        earlyCallback=(code,message,data)=>Hook(0,code,message,data);lateCallback=(code,message,data)=>Hook(1,code,message,data);
        earlyHook=SetWindowsHookEx(13,earlyCallback,GetModuleHandle(null),0);
        if(earlyHook==IntPtr.Zero)throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
        Log("ready",new {pid=Process.GetCurrentProcess().Id,hold=settings.Hold.Label,handsFree=settings.HandsFree.Label,configurationWrittenUtc=File.GetLastWriteTimeUtc(VoiceHotkeySettings.SettingsPath()).ToString("o"),passive=true,rawInput=true,duration=seconds});
        timer.Interval=30;timer.Tick+=(s,e)=>Tick();timer.Start();
    }
    void Log(string kind,object data){output.WriteLine(json.Serialize(new {time=DateTimeOffset.Now.ToString("o"),ms=watch.Elapsed.TotalMilliseconds,kind=kind,data=data}));output.Flush();}
    bool Configured(int key){return Array.IndexOf(settings.Hold.Keys,key)>=0 || Array.IndexOf(settings.HandsFree.Keys,key)>=0;}
    int Mask(int source){int result=0,n=0;foreach(int key in new[]{162,163,164,165,160,161,91,92}){if(pressed[source][key])result|=1<<n;n++;}return result;}
    int Normalize(int key,int scan,int flags,bool raw){
        bool extended=(flags&(raw?2:1))!=0;
        if(key==17)return extended?163:162;if(key==18)return extended?165:164;if(key==16)return scan==54?161:160;return key;
    }
    void Observe(int source,int key,int scan,int flags,bool down,bool injected,uint eventTick){
        total[source]++;if(!injected)physical[source]++;
        key=Normalize(key,scan,flags,source==2);if(key>=0 && key<256)pressed[source][key]=down;
        if(!Configured(key))return;
        if(key==settings.HandsFree.Trigger || key==settings.Hold.Trigger)trigger[source]++;
        IntPtr foreground=Native.GetForegroundWindow();uint pid;Native.GetWindowThreadProcessId(foreground,out pid);
        receipts.Enqueue(new {time=DateTimeOffset.Now.ToString("o"),ms=watch.Elapsed.TotalMilliseconds,kind="configured_key",data=new {source=source==0?"initial_hook":source==1?"recording_hook":"raw_input",generation=generation,key=key,scan=scan,down=down,injected=injected,modifiers=Mask(source),visible=visible,pid=pid,foreground=foreground.ToInt64(),eventTick=eventTick}});
    }
    IntPtr Hook(int source,int code,IntPtr message,IntPtr data){
        if(code>=0){var key=(KeyData)Marshal.PtrToStructure(data,typeof(KeyData));int m=message.ToInt32();Observe(source,(int)key.Key,(int)key.Scan,(int)key.Flags,m==0x100||m==0x104,(key.Flags&16)!=0,key.Time);}
        return CallNextHookEx(IntPtr.Zero,code,message,data);
    }
    void Raw(IntPtr handle){
        uint bytes=0,header=(uint)Marshal.SizeOf(typeof(Header));
        if(GetRawInputData(handle,0x10000003,IntPtr.Zero,ref bytes,header)==uint.MaxValue || bytes<header+16 || bytes>1024)return;
        IntPtr memory=Marshal.AllocHGlobal((int)bytes);
        try{
            if(GetRawInputData(handle,0x10000003,memory,ref bytes,header)==uint.MaxValue)return;
            var head=(Header)Marshal.PtrToStructure(memory,typeof(Header));if(head.Type!=1)return;
            IntPtr body=IntPtr.Add(memory,(int)header);int scan=(ushort)Marshal.ReadInt16(body,0),flags=(ushort)Marshal.ReadInt16(body,2),key=(ushort)Marshal.ReadInt16(body,6);
            Observe(2,key,scan,flags,(flags&1)==0,false,0);
        }finally{Marshal.FreeHGlobal(memory);}
    }
    void Summary(){
        string counts=json.Serialize(new {total=total,physical=physical,configuredTrigger=trigger});
        if(counts!=lastCounts){lastCounts=counts;Log("aggregate_counts",new {channels=new[]{"initial_hook","recording_hook","raw_input"},total=total,physical=physical,configuredTrigger=trigger});}
    }
    void Tick(){
        while(receipts.Count>0)output.WriteLine(json.Serialize(receipts.Dequeue()));output.Flush();
        bool now=false;Native.EnumWindows((h,p)=>{if(!Native.IsWindowVisible(h))return true;var title=new StringBuilder(80);Native.GetWindowText(h,title,title.Capacity);if(title.ToString()=="语音输入" && Native.IsWeType(h)){now=true;return false;}return true;},IntPtr.Zero);
        if(now!=visible){
            visible=now;Log("voice_visible",new {visible=visible});
            if(visible){
                generation++;if(lateHook!=IntPtr.Zero)UnhookWindowsHookEx(lateHook);
                lateHook=SetWindowsHookEx(13,lateCallback,GetModuleHandle(null),0);
                Log("recording_observer_installed",new {generation=generation,installed=lateHook!=IntPtr.Zero,error=lateHook==IntPtr.Zero?Marshal.GetLastWin32Error():0});
            }
            Summary();
        }
        if(watch.ElapsedMilliseconds>=nextSummary){nextSummary=watch.ElapsedMilliseconds+10000;Summary();}
        if(watch.Elapsed.TotalSeconds>=seconds)ExitThread();
    }
    protected override void ExitThreadCore(){
        timer.Stop();if(earlyHook!=IntPtr.Zero)UnhookWindowsHookEx(earlyHook);if(lateHook!=IntPtr.Zero)UnhookWindowsHookEx(lateHook);
        RegisterRawInputDevices(new[]{new Device{Page=1,Usage=6,Flags=1,Window=IntPtr.Zero}},1,(uint)Marshal.SizeOf(typeof(Device)));
        while(receipts.Count>0)output.WriteLine(json.Serialize(receipts.Dequeue()));Summary();Log("finished",new {passive=true});
        window.Dispose();output.Dispose();timer.Dispose();base.ExitThreadCore();
    }
}
