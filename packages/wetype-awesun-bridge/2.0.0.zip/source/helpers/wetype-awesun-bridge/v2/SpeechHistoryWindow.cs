using System;
using System.Drawing;
using System.Windows.Forms;
namespace WeTypeVoice2 {
    // The only user-facing window: live history and full-text copy are available immediately.
    internal sealed class SpeechHistoryWindow : Form {
        readonly SpeechHistory history;readonly Func<int,bool> copy;
        readonly ListBox list=new ListBox {Name="historyList",Dock=DockStyle.Fill,IntegralHeight=false,BorderStyle=BorderStyle.None,DrawMode=DrawMode.OwnerDrawFixed};
        readonly TextBox text=new TextBox {Name="historyText",Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Vertical,Dock=DockStyle.Fill,MaxLength=int.MaxValue,BorderStyle=BorderStyle.None};
        readonly CheckBox follow=new CheckBox {Name="followLatest",Text="跟随最新记录",Checked=true,AutoSize=true};
        readonly Label detail=new Label {Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft,AutoEllipsis=true};
        readonly Label activity=new Label {Text="● 正在监听",AutoSize=true};
        readonly Label count=new Label {Size=new Size(60,24),TextAlign=ContentAlignment.MiddleLeft,Location=new Point(90,0)};
        readonly Label selectionTitle=new Label {AutoSize=true,Text="全文"};
        readonly Label selectionMeta=new Label {AutoSize=true};
        readonly ActionButton copyButton=new ActionButton {Name="copySelected",Text="复制全文",Primary=true,Size=new Size(112,38)};
        readonly ActionButton exitButton=new ActionButton {Name="exitApp",Text="退出",Size=new Size(72,34)};
        readonly Label empty=new Label {Text="还没有语音记录\n用原快捷键说一段话，文字会出现在这里。",Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleCenter};
        readonly Label footer=new Label {Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft,AutoEllipsis=true};
        readonly Image brand;
        bool refreshing;int selectedSession;
        public event Action ExitRequested;
        protected override bool ShowWithoutActivation {get{return true;}}
        public SpeechHistoryWindow(SpeechHistory source,Func<int,bool> copier){
            history=source;copy=copier;
            Text="微信语音监听板";ClientSize=new Size(980,620);MinimumSize=new Size(800,500);
            StartPosition=FormStartPosition.CenterScreen;AutoScaleMode=AutoScaleMode.Dpi;AutoScaleDimensions=new SizeF(96,96);
            Font=new Font("Microsoft YaHei UI",10);BackColor=UiTheme.Background;ForeColor=UiTheme.Text;
            Icon=Icon.ExtractAssociatedIcon(Application.ExecutablePath)??SystemIcons.Application;
            brand=UiTheme.LoadBrand();
            var root=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,Padding=new Padding(24,0,24,0),BackColor=UiTheme.Background};
            root.RowStyles.Add(new RowStyle(SizeType.Absolute,100));root.RowStyles.Add(new RowStyle(SizeType.Percent,100));root.RowStyles.Add(new RowStyle(SizeType.Absolute,48));
            Controls.Add(root);
            var header=new Panel {Dock=DockStyle.Fill,Margin=Padding.Empty,BackColor=UiTheme.Background};
            if(brand!=null)header.Controls.Add(new PictureBox {Image=brand,SizeMode=PictureBoxSizeMode.Zoom,Location=new Point(0,27),Size=new Size(46,46)});
            header.Controls.Add(new Label {Text="微信语音监听板",Font=new Font(Font.FontFamily,18,FontStyle.Bold),AutoSize=true,Location=new Point(62,21),ForeColor=UiTheme.Text});
            header.Controls.Add(new Label {Text="本机照常输入 · 向日葵在结束时接收",AutoSize=true,Location=new Point(64,57),ForeColor=UiTheme.Muted});
            activity.ForeColor=UiTheme.Success;header.Controls.Add(activity);header.Controls.Add(exitButton);
            header.Layout+=(s,e)=>{exitButton.Location=new Point(header.ClientSize.Width-exitButton.Width,31);activity.Location=new Point(exitButton.Left-activity.PreferredWidth-20,39);};
            exitButton.Click+=(s,e)=>{if(ExitRequested!=null)ExitRequested();};
            root.Controls.Add(header,0,0);
            var columns=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=2,RowCount=1,Margin=Padding.Empty,BackColor=UiTheme.Background};
            columns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,32));columns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,68));
            root.Controls.Add(columns,0,1);
            var left=new SurfacePanel {Dock=DockStyle.Fill,Margin=new Padding(0,0,16,0)};
            var leftLayout=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,BackColor=UiTheme.Panel,Margin=Padding.Empty};
            leftLayout.RowStyles.Add(new RowStyle(SizeType.Absolute,40));leftLayout.RowStyles.Add(new RowStyle(SizeType.Percent,100));leftLayout.RowStyles.Add(new RowStyle(SizeType.Absolute,40));
            left.Controls.Add(leftLayout);columns.Controls.Add(left,0,0);
            var historyHeading=new Panel {Dock=DockStyle.Fill,Margin=Padding.Empty,BackColor=UiTheme.Panel};
            historyHeading.Controls.Add(new Label {Text="语音历史",AutoSize=true,Font=new Font(Font,FontStyle.Bold),Location=new Point(0,3),ForeColor=UiTheme.Text});
            count.ForeColor=UiTheme.Muted;historyHeading.Controls.Add(count);
            leftLayout.Controls.Add(historyHeading,0,0);
            list.BackColor=UiTheme.Panel;list.ForeColor=UiTheme.Text;list.ItemHeight=88;list.Margin=Padding.Empty;
            list.DrawItem+=DrawRecord;leftLayout.Controls.Add(list,0,1);
            follow.ForeColor=UiTheme.Muted;follow.Anchor=AnchorStyles.Left;follow.Margin=new Padding(2,10,0,0);leftLayout.Controls.Add(follow,0,2);
            var right=new SurfacePanel {Dock=DockStyle.Fill,Margin=Padding.Empty,Padding=new Padding(24,18,24,16)};
            columns.Controls.Add(right,1,0);
            var rightLayout=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,BackColor=UiTheme.Panel,Margin=Padding.Empty};
            rightLayout.RowStyles.Add(new RowStyle(SizeType.Absolute,66));rightLayout.RowStyles.Add(new RowStyle(SizeType.Percent,100));rightLayout.RowStyles.Add(new RowStyle(SizeType.Absolute,38));right.Controls.Add(rightLayout);
            var fullHeader=new Panel {Dock=DockStyle.Fill,BackColor=UiTheme.Panel,Margin=Padding.Empty};
            selectionTitle.Font=new Font(Font.FontFamily,13,FontStyle.Bold);selectionTitle.ForeColor=UiTheme.Text;selectionTitle.Location=new Point(0,0);
            selectionMeta.Location=new Point(0,30);selectionMeta.ForeColor=UiTheme.Muted;
            fullHeader.Controls.AddRange(new Control[]{selectionTitle,selectionMeta,copyButton});
            fullHeader.Layout+=(s,e)=>copyButton.Location=new Point(fullHeader.ClientSize.Width-copyButton.Width,3);
            rightLayout.Controls.Add(fullHeader,0,0);
            var textArea=new Panel {Dock=DockStyle.Fill,Margin=Padding.Empty,BackColor=UiTheme.Panel};
            text.Font=new Font(Font.FontFamily,11);text.BackColor=UiTheme.Panel;text.ForeColor=UiTheme.Text;
            empty.ForeColor=UiTheme.Muted;empty.BackColor=UiTheme.Panel;textArea.Controls.Add(text);textArea.Controls.Add(empty);rightLayout.Controls.Add(textArea,0,1);
            detail.ForeColor=UiTheme.Muted;detail.Font=new Font(Font.FontFamily,9);rightLayout.Controls.Add(detail,0,2);
            footer.Text="历史仅在本次运行保留，退出后清空  ·  关闭窗口后仍可从托盘打开";
            footer.ForeColor=UiTheme.Muted;footer.Font=new Font(Font.FontFamily,9);footer.Margin=Padding.Empty;root.Controls.Add(footer,0,2);
            list.SelectedIndexChanged+=(s,e)=>{
                if(refreshing)return;var entry=list.SelectedItem as SpeechRecord;if(entry==null)return;selectedSession=entry.Session;
                if(history.Entries.Count>0 && entry.Session!=history.Entries[0].Session)follow.Checked=false;
                ShowSelection();
            };
            follow.CheckedChanged+=(s,e)=>{if(!refreshing && follow.Checked)RefreshHistory();};
            copyButton.Click+=(s,e)=>CopySelected();
            history.Changed+=RefreshHistory;RefreshHistory();
        }
        protected override void OnHandleCreated(EventArgs e){base.OnHandleCreated(e);UiTheme.WindowChrome(this);}
        public void SetActivity(bool listening,bool receiving,bool finishing,string message){
            string caption=receiving?"● 正在接收":finishing?"● 正在收尾":listening?"● 正在监听":"● 未开始监听";
            if(activity.Text!=caption){activity.Text=caption;activity.Parent.PerformLayout();}
            activity.ForeColor=listening?UiTheme.Success:UiTheme.Muted;
            activity.AccessibleDescription=message;
            if(!listening)detail.Text=message;
        }
        void DrawRecord(object sender,DrawItemEventArgs e){
            if(e.Index<0 || e.Index>=list.Items.Count)return;
            var r=(SpeechRecord)list.Items[e.Index];bool chosen=(e.State&DrawItemState.Selected)!=0;
            var bounds=new Rectangle(e.Bounds.X,e.Bounds.Y+2,Math.Max(1,e.Bounds.Width-1),e.Bounds.Height-5);
            using(var clear=new SolidBrush(UiTheme.Panel))e.Graphics.FillRectangle(clear,e.Bounds);
            e.Graphics.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            using(var shape=UiTheme.Round(bounds,9))using(var brush=new SolidBrush(chosen?UiTheme.Selected:UiTheme.Panel))e.Graphics.FillPath(brush,shape);
            string time=r.Started.ToLocalTime().ToString("HH:mm:ss");
            TextRenderer.DrawText(e.Graphics,time,Font,new Rectangle(bounds.X+12,bounds.Y+9,110,23),chosen?UiTheme.Accent:UiTheme.Text,TextFormatFlags.Left|TextFormatFlags.SingleLine);
            TextRenderer.DrawText(e.Graphics,r.Text.Length+" 字",Font,new Rectangle(bounds.Right-96,bounds.Y+9,84,23),UiTheme.Muted,TextFormatFlags.Right|TextFormatFlags.SingleLine);
            string preview=r.Text.Length==0?(r.Ended?"本段未收到文字":"等待语音文字…"):r.Text.Substring(0,Math.Min(r.Text.Length,80)).Replace("\r"," ").Replace("\n"," ");
            TextRenderer.DrawText(e.Graphics,preview,Font,new Rectangle(bounds.X+12,bounds.Y+32,bounds.Width-24,23),UiTheme.Text,TextFormatFlags.Left|TextFormatFlags.SingleLine|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPrefix);
            using(var small=new Font(Font.FontFamily,8.5f))
                TextRenderer.DrawText(e.Graphics,r.CopyState,small,new Rectangle(bounds.X+12,bounds.Y+56,bounds.Width-24,20),UiTheme.Muted,TextFormatFlags.Left|TextFormatFlags.SingleLine|TextFormatFlags.EndEllipsis);
            if((e.State&DrawItemState.Focus)!=0)ControlPaint.DrawFocusRectangle(e.Graphics,new Rectangle(bounds.X+3,bounds.Y+3,bounds.Width-6,bounds.Height-6),UiTheme.Accent,chosen?UiTheme.Selected:UiTheme.Panel);
        }
        void RefreshHistory(){
            if(IsDisposed)return;refreshing=true;int top=list.TopIndex;list.BeginUpdate();
            try {
                if(follow.Checked && history.Entries.Count>0)selectedSession=history.Entries[0].Session;
                // Same records keep their items and scroll position; revisions only repaint their rows.
                bool same=list.Items.Count==history.Entries.Count;
                if(same)for(int n=0;n<list.Items.Count;n++)if(!ReferenceEquals(list.Items[n],history.Entries[n])){same=false;break;}
                if(!same){list.Items.Clear();foreach(var entry in history.Entries)list.Items.Add(entry);}
                for(int n=0;n<list.Items.Count;n++)if(((SpeechRecord)list.Items[n]).Session==selectedSession){list.SelectedIndex=n;break;}
                if(list.SelectedIndex<0 && list.Items.Count>0)list.SelectedIndex=0;
                var selected=list.SelectedItem as SpeechRecord;if(selected!=null)selectedSession=selected.Session;
                if(!follow.Checked && list.Items.Count>0)list.TopIndex=Math.Min(top,list.Items.Count-1);
            }finally{list.EndUpdate();refreshing=false;}
            list.Invalidate();count.Text=history.Entries.Count+" 条";ShowSelection();
        }
        void ShowSelection(){
            var entry=list.SelectedItem as SpeechRecord;string value=entry==null?"":entry.Text;
            if(text.Text!=value){
                int selection=text.SelectionStart,length=text.SelectionLength;text.Text=value;
                text.Select(Math.Min(selection,value.Length),Math.Min(length,Math.Max(0,value.Length-selection)));
                if(follow.Checked){text.Select(value.Length,0);text.ScrollToCaret();}
            }
            bool showEmpty=entry==null || value.Length==0;
            empty.Visible=showEmpty;text.Visible=!showEmpty;
            if(showEmpty)empty.BringToFront();
            empty.Text=entry==null?"还没有语音记录\n用原快捷键说一段话，文字会出现在这里。":entry.Ended?"这一段没有收到文字\n之前的记录仍保留在左侧历史中。":"正在等待微信交付文字…";
            selectionTitle.Text=entry==null?"全文":"语音全文";
            selectionMeta.Text=entry==null?"选中一条记录即可查看":entry.Started.ToLocalTime().ToString("MM月dd日  HH:mm:ss")+"  ·  "+entry.Text.Length+" 字";
            detail.Text=entry==null?"收到的文字会自动保留并复制。":entry.CopyState;
            detail.ForeColor=entry!=null && entry.CopyState.Contains("已复制")?UiTheme.Success:UiTheme.Muted;
            copyButton.Enabled=entry!=null && entry.Text.Length>0;
        }
        void CopySelected(){
            var entry=list.SelectedItem as SpeechRecord;if(entry==null)return;
            bool ok=copy(entry.Session);history.FlushChanges();
            detail.Text=ok?"已复制全文到本机剪贴板。":"复制未成功，全文仍保留；请稍后再试。";
            detail.ForeColor=ok?UiTheme.Success:UiTheme.Muted;
        }
        protected override void Dispose(bool disposing){
            if(disposing){history.Changed-=RefreshHistory;if(brand!=null)brand.Dispose();}
            base.Dispose(disposing);
        }
    }
}
