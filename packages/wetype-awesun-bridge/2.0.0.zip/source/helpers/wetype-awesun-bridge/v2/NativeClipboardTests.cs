using System;
using System.Runtime.InteropServices;
using System.Text;
using WeTypeVoice2;

// Real Win32 clipboard tests, exclusively in a newly created noninteractive window station.
// No user clipboard reads/writes, visible windows, desktop switching, input or body logging.
internal static class NativeClipboardTests {
    [DllImport("user32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr CreateWindowStation(string name,uint flags,uint access,IntPtr security);
    [DllImport("user32.dll",SetLastError=true)] static extern bool SetProcessWindowStation(IntPtr station);
    [DllImport("user32.dll")] static extern IntPtr GetProcessWindowStation();
    [DllImport("user32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr CreateDesktop(string name,IntPtr device,IntPtr mode,uint flags,uint access,IntPtr security);
    [DllImport("user32.dll",SetLastError=true)] static extern bool SetThreadDesktop(IntPtr desktop);
    [DllImport("user32.dll")] static extern IntPtr GetThreadDesktop(uint thread);
    [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
    [DllImport("user32.dll")] static extern bool CloseWindowStation(IntPtr station);
    [DllImport("user32.dll")] static extern bool CloseDesktop(IntPtr desktop);
    [DllImport("user32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool GetUserObjectInformation(IntPtr obj,int index,StringBuilder value,uint length,out uint needed);
    [DllImport("user32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr CreateWindowEx(uint ex,string cls,string title,uint style,int x,int y,int w,int h,IntPtr parent,IntPtr menu,IntPtr instance,IntPtr param);
    [DllImport("user32.dll")] static extern bool DestroyWindow(IntPtr hwnd);
    [DllImport("user32.dll",SetLastError=true)] static extern bool OpenClipboard(IntPtr owner);
    [DllImport("user32.dll")] static extern bool CloseClipboard();
    [DllImport("user32.dll")] static extern IntPtr GetClipboardData(uint format);
    [DllImport("kernel32.dll")] static extern IntPtr GlobalLock(IntPtr memory);
    [DllImport("kernel32.dll")] static extern bool GlobalUnlock(IntPtr memory);
    static bool isolated;
    static int passed;
    static void Check(bool ok,string stage){if(!ok)throw new Exception(stage+" (last error "+Marshal.GetLastWin32Error()+")");}
    static void Test(string name,Action run){run();passed++;Console.WriteLine("PASS "+name);}
    static string NameOf(IntPtr station){var name=new StringBuilder(256);uint needed;Check(GetUserObjectInformation(station,2,name,512,out needed),"station name");return name.ToString();}
    static IntPtr Window(){var w=CreateWindowEx(0,"STATIC","Synthetic test owner",0,0,0,1,1,IntPtr.Zero,IntPtr.Zero,IntPtr.Zero,IntPtr.Zero);Check(w!=IntPtr.Zero,"hidden test window");return w;}
    static string ReadSynthetic(){
        Check(isolated,"read must be isolated");Check(OpenClipboard(IntPtr.Zero),"open synthetic clipboard");
        try {
            IntPtr memory=GetClipboardData(13);Check(memory!=IntPtr.Zero,"synthetic Unicode format");
            IntPtr pointer=GlobalLock(memory);Check(pointer!=IntPtr.Zero,"synthetic data lock");
            try{return Marshal.PtrToStringUni(pointer);}finally{GlobalUnlock(memory);}
        }finally{CloseClipboard();}
    }
    // MTA intentionally: STA startup can create an OLE window before desktop isolation.
    static int Main(string[] args){
        IntPtr oldStation=GetProcessWindowStation(),oldDesktop=GetThreadDesktop(GetCurrentThreadId());
        IntPtr station=IntPtr.Zero,desktop=IntPtr.Zero,window=IntPtr.Zero,other=IntPtr.Zero;
        try {
            string original=NameOf(oldStation);
            // CWF_CREATE_ONLY and a unique name: never attach to an existing station.
            // Use the caller's actual rights; fail rather than elevate or use the interactive clipboard.
            if(args.Length==1 && args[0]=="--existing-isolated-station"){
                Check(original.StartsWith("WeTypeRelease_",StringComparison.Ordinal) && original!="WinSta0","launcher-created private station verified");
            }else{
            string privateName="WeTypeSynthetic_"+Guid.NewGuid().ToString("N");
            station=CreateWindowStation(privateName,1,0x37f,IntPtr.Zero);Check(station!=IntPtr.Zero,"create new private station");
            Check(SetProcessWindowStation(station),"assign private station");
            desktop=CreateDesktop("Synthetic",IntPtr.Zero,IntPtr.Zero,0,0x1ff,IntPtr.Zero);Check(desktop!=IntPtr.Zero,"create private desktop");
            Check(SetThreadDesktop(desktop),"assign private desktop");
            string actual=NameOf(GetProcessWindowStation());
            Check(actual==privateName && actual!="WinSta0" && actual!=original,"noninteractive new station verified");
            }
            isolated=true;window=Window();other=Window();
            var sink=new SystemClipboard(()=>window);var external=new SystemClipboard(()=>other);
            Test("write receipt matches real clipboard after CloseClipboard",()=>{
                uint receipt;Check(sink.TryPut("synthetic one",sink.Sequence,out receipt),"first write");
                Check(receipt==sink.Sequence,"post-close sequence receipt");
            });
            Test("second native write accepts first receipt and preserves entire Unicode text",()=>{
                uint receipt;Check(sink.TryPut(new string('a',197),sink.Sequence,out receipt),"partial write");
                string full=new string('\u6587',378)+"\r\n\ud83d\ude42 END";
                uint next;Check(sink.TryPut(full,receipt,out next),"second write");
                Check(ReadSynthetic()==full && next==sink.Sequence,"complete second write");
            });
            Test("reading synthesized text formats does not invalidate the completed receipt",()=>{
                uint receipt;Check(sink.TryPut("synthetic \u6587\r\ntext",sink.Sequence,out receipt),"write synthetic Unicode");
                Check(OpenClipboard(IntPtr.Zero),"open synthetic formats");
                try {Check(GetClipboardData(1)!=IntPtr.Zero && GetClipboardData(7)!=IntPtr.Zero,"read synthesized ANSI and OEM formats");}
                finally{CloseClipboard();}
                Check(receipt==sink.Sequence,"completed receipt still current after format conversion");
            });
            Test("197 to 378 character delivery continues without a false external-copy pause",()=>{
                var p=new RecordingPipeline(sink);DateTime now=DateTime.UtcNow;var r=p.Begin(now);
                p.Receive(r.Session,new string('a',197),false,"text_changed",now);p.Pump(now);
                string full=new string('a',197)+new string('b',181);
                p.Receive(r.Session,full,false,"text_changed",now.AddMilliseconds(160));p.End(r.Session);p.Pump(now.AddMilliseconds(301));
                Check(!p.Delivery.Paused && !p.Delivery.Pending && ReadSynthetic()==full,"continued real delivery");
            });
            Test("actual external owner copy still wins over later speech",()=>{
                var p=new RecordingPipeline(sink);DateTime now=DateTime.UtcNow;var r=p.Begin(now);
                p.Receive(r.Session,"first speech",true,"ime_result",now);p.Pump(now);
                uint written;Check(external.TryPut("synthetic external copy",external.Sequence,out written),"external copy");
                p.Receive(r.Session,"later complete speech",true,"ime_result",now);p.Pump(now);
                Check(p.Delivery.Paused && r.Text=="later complete speech" && ReadSynthetic()=="synthetic external copy","external content protected");
                Check(p.Delivery.CopyRecord(r.Session,now) && ReadSynthetic()=="later complete speech","explicit rescue still works");
            });
            Test("locked stale-sequence rejection does not overwrite the external owner",()=>{
                uint stale=sink.Sequence,written;
                Check(external.TryPut("another synthetic external copy",external.Sequence,out written),"external change");
                Check(!sink.TryPut("must not overwrite",stale,out written),"stale sequence rejected");
                Check(ReadSynthetic()=="another synthetic external copy","external remains exact");
            });
            Test("native clipboard retains a long full Unicode payload including the tail",()=>{
                string full=new string('\u6587',20000)+"\r\n\u3002\ud83d\ude42\nEND";uint written;
                Check(sink.TryPut(full,sink.Sequence,out written),"long write");
                Check(ReadSynthetic()==full,"entire long Unicode payload");
            });
            Console.WriteLine("RESULT "+passed+"/"+passed+" native clipboard tests passed; synthetic private clipboard only, interactive clipboard never opened.");return 0;
        }catch(Exception e){Console.Error.WriteLine("FAIL "+e.Message);return 1;}
        finally{
            if(other!=IntPtr.Zero)DestroyWindow(other);if(window!=IntPtr.Zero)DestroyWindow(window);
            SetProcessWindowStation(oldStation);SetThreadDesktop(oldDesktop);isolated=false;
            if(desktop!=IntPtr.Zero)CloseDesktop(desktop);if(station!=IntPtr.Zero)CloseWindowStation(station);
        }
    }
}
