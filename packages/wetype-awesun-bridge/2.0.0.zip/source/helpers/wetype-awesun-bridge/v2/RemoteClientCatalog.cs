using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
namespace WeTypeVoice2 {
    // Match executable identity, never a remote desktop's title or the dictated text.
    internal sealed class RemoteClientCatalog {
        sealed class Cached {internal string Name;internal bool Match;internal DateTime Until;internal long Started;}
        readonly Dictionary<uint,Cached> cache=new Dictionary<uint,Cached>();
        internal static bool ClientName(string value){
            string name=value??"";int slash=Math.Max(name.LastIndexOf('/'),name.LastIndexOf('\\'));
            if(slash>=0)name=name.Substring(slash+1);
            if(name.EndsWith(".exe",StringComparison.OrdinalIgnoreCase))name=name.Substring(0,name.Length-4);
            return name.Equals("AweSun",StringComparison.OrdinalIgnoreCase)||name.Equals("SunloginClient",StringComparison.OrdinalIgnoreCase);
        }
        static bool Contains(string value,string part){return (value??"").IndexOf(part,StringComparison.OrdinalIgnoreCase)>=0;}
        internal static bool Matches(string name,string original,string product,string description,string company){
            if(ClientName(name))return true;
            if(Contains(name,"service")||Contains(name,"guard")||Contains(name,"update"))return false;
            if(ClientName(original))return true;
            return (Contains(product,"AweSun")||Contains(product,"Sunlogin")||Contains(product,"向日葵"))
                && (Contains(description,"remote control")||Contains(description,"remote desktop")||Contains(description,"远程控制"))
                && (Contains(company,"Oray")||Contains(company,"贝锐"));
        }
        [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint access,bool inherit,uint pid);
        [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool QueryFullProcessImageName(IntPtr process,uint flags,StringBuilder path,ref int size);
        [DllImport("kernel32.dll")] static extern bool GetProcessTimes(IntPtr process,out long created,out long exited,out long kernel,out long user);
        [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
        internal bool IsClient(uint pid,DateTime now){
            IntPtr handle=OpenProcess(0x1000,false,pid);if(handle==IntPtr.Zero)return false;
            try{
                var path=new StringBuilder(32768);int size=path.Capacity;
                if(!QueryFullProcessImageName(handle,0,path,ref size))return false;
                string executable=path.ToString(),name=Path.GetFileNameWithoutExtension(executable);
                if(ClientName(name))return true;
                long started,exited,kernel,user;if(!GetProcessTimes(handle,out started,out exited,out kernel,out user))return false;
                Cached known;if(cache.TryGetValue(pid,out known)&&known.Name==executable&&known.Started==started&&now<known.Until)return known.Match;
                known=new Cached {Name=executable,Started=started,Until=now.AddSeconds(2)};cache[pid]=known;
                var info=FileVersionInfo.GetVersionInfo(executable);
                known.Match=Matches(name,info.OriginalFilename,info.ProductName,info.FileDescription,info.CompanyName);
                // Loaded executable identity is stable; PID reuse is checked against its creation time.
                known.Until=DateTime.MaxValue;
                return known.Match;
            }catch(InvalidOperationException){}catch(System.ComponentModel.Win32Exception){}
            catch(ArgumentException){}catch(IOException){}catch(UnauthorizedAccessException){}catch(System.Security.SecurityException){}
            finally{CloseHandle(handle);}
            return false;
        }
        internal uint[] Snapshot(DateTime now){
            var candidates=new HashSet<uint>();
            // Only visible application windows need metadata inspection; no window text is read.
            Native.EnumWindows((h,unused)=>{if(Native.IsWindowVisible(h)){uint pid;Native.GetWindowThreadProcessId(h,out pid);if(pid!=0)candidates.Add(pid);}return true;},IntPtr.Zero);
            var matches=new List<uint>();foreach(uint pid in candidates)if(IsClient(pid,now))matches.Add(pid);
            foreach(uint pid in new List<uint>(cache.Keys))if(!candidates.Contains(pid))cache.Remove(pid);
            return matches.ToArray();
        }
    }
}
