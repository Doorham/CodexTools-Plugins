using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml;

internal static class BuildIcon {
    static float Number(string s){return float.Parse(s,CultureInfo.InvariantCulture);}
    static GraphicsPath PathOf(string data){
        var tokens=Regex.Matches(data,@"[MLHC]|[-+]?(?:\d*\.)?\d+");int n=0;float x=0,y=0;var path=new GraphicsPath();
        while(n<tokens.Count){
            string command=tokens[n++].Value;
            if(command=="M"){x=Number(tokens[n++].Value);y=Number(tokens[n++].Value);path.StartFigure();}
            else if(command=="L"){float nx=Number(tokens[n++].Value),ny=Number(tokens[n++].Value);path.AddLine(x,y,nx,ny);x=nx;y=ny;}
            else if(command=="H"){float nx=Number(tokens[n++].Value);path.AddLine(x,y,nx,y);x=nx;}
            else if(command=="C"){
                float x1=Number(tokens[n++].Value),y1=Number(tokens[n++].Value),x2=Number(tokens[n++].Value),y2=Number(tokens[n++].Value),nx=Number(tokens[n++].Value),ny=Number(tokens[n++].Value);
                path.AddBezier(x,y,x1,y1,x2,y2,nx,ny);x=nx;y=ny;
            }else throw new InvalidDataException("Unexpected command in adopted icon: "+command);
        }
        return path;
    }
    static GraphicsPath Background(float radius){
        var p=new GraphicsPath();float d=radius*2;
        p.AddArc(0,0,d,d,180,90);p.AddArc(100-d,0,d,d,270,90);p.AddArc(100-d,100-d,d,d,0,90);p.AddArc(0,100-d,d,d,90,90);p.CloseFigure();return p;
    }
    static byte[] Render(XmlDocument svg,int size){
        var ns=new XmlNamespaceManager(svg.NameTable);ns.AddNamespace("s","http://www.w3.org/2000/svg");
        var stops=svg.SelectNodes("//s:stop",ns);var rect=(XmlElement)svg.SelectSingleNode("//s:rect",ns);var paths=svg.SelectNodes("//s:path",ns);
        if(stops.Count!=2 || paths.Count!=2 || svg.DocumentElement.GetAttribute("viewBox")!="0 0 100 100")throw new InvalidDataException("Unexpected adopted SVG structure");
        using(var large=new Bitmap(size*4,size*4,PixelFormat.Format32bppArgb)){
            using(var g=Graphics.FromImage(large)){
                g.Clear(Color.Transparent);g.SmoothingMode=SmoothingMode.AntiAlias;g.ScaleTransform(size*4/100f,size*4/100f);
                using(var bg=Background(Number(rect.GetAttribute("rx"))))
                using(var gradient=new LinearGradientBrush(new PointF(0,0),new PointF(100,100),ColorTranslator.FromHtml(((XmlElement)stops[0]).GetAttribute("stop-color")),ColorTranslator.FromHtml(((XmlElement)stops[1]).GetAttribute("stop-color"))))g.FillPath(gradient,bg);
                foreach(XmlElement element in paths)using(var path=PathOf(element.GetAttribute("d")))using(var pen=new Pen(Color.White,Number(element.GetAttribute("stroke-width")))){
                    pen.StartCap=pen.EndCap=LineCap.Round;pen.LineJoin=LineJoin.Round;g.DrawPath(pen,path);
                }
            }
            using(var image=new Bitmap(size,size,PixelFormat.Format32bppArgb)){
                using(var g=Graphics.FromImage(image)){g.InterpolationMode=InterpolationMode.HighQualityBicubic;g.CompositingQuality=CompositingQuality.HighQuality;g.DrawImage(large,new Rectangle(0,0,size,size));}
                using(var stream=new MemoryStream()){image.Save(stream,ImageFormat.Png);return stream.ToArray();}
            }
        }
    }
    static int Main(string[] args){
        if(args.Length!=2)return 2;var svg=new XmlDocument();svg.XmlResolver=null;svg.Load(args[0]);Directory.CreateDirectory(args[1]);
        int[] sizes={16,24,32,48,64,128,256};var images=new List<byte[]>();foreach(int size in sizes)images.Add(Render(svg,size));
        File.WriteAllBytes(System.IO.Path.Combine(args[1],"voice.png"),images[images.Count-1]);
        using(var f=File.Create(System.IO.Path.Combine(args[1],"voice.ico")))using(var w=new BinaryWriter(f)){
            w.Write((ushort)0);w.Write((ushort)1);w.Write((ushort)sizes.Length);int offset=6+16*sizes.Length;
            for(int n=0;n<sizes.Length;n++){w.Write((byte)(sizes[n]==256?0:sizes[n]));w.Write((byte)(sizes[n]==256?0:sizes[n]));w.Write((byte)0);w.Write((byte)0);w.Write((ushort)1);w.Write((ushort)32);w.Write(images[n].Length);w.Write(offset);offset+=images[n].Length;}
            foreach(var data in images)w.Write(data);
        }
        Console.WriteLine("Adopted SVG rendered to native icon sizes; geometry and two colors read from original SVG.");return 0;
    }
}
