using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace WeTypeVoice2 {
    internal sealed class SpeechRecord {
        public int Session {get;internal set;}
        public DateTime Started {get;internal set;}
        public DateTime LastChange {get;internal set;}
        public string Text {get;internal set;}
        public int Revision {get;internal set;}
        public bool Ended {get;internal set;}
        public bool HasFinal {get;internal set;}
        public bool HadComposition {get;internal set;}
        public string CopyState {get;internal set;}
        public override string ToString(){return Started.ToLocalTime().ToString("HH:mm:ss")+" · "+Text.Length+" 字 · "+(Ended?(Text.Length==0?"未收到文字":"已结束"):"接收中")+" · "+CopyState;}
    }

    // The sole owner of captured speech. No clipboard, focus, files or UI callbacks during Accept.
    internal sealed class SpeechHistory {
        readonly List<SpeechRecord> entries=new List<SpeechRecord>();
        readonly Dictionary<int,SpeechRecord> bySession=new Dictionary<int,SpeechRecord>();
        readonly ReadOnlyCollection<SpeechRecord> view;
        bool dirty;
        public SpeechHistory(){view=entries.AsReadOnly();}
        public event Action Changed;
        public ReadOnlyCollection<SpeechRecord> Entries {get{return view;}}
        public SpeechRecord Current {get;private set;}
        public string Retained {get{foreach(var entry in entries)if(entry.Text.Length>0)return entry.Text;return "";}}
        public SpeechRecord Begin(int session,DateTime now){
            if(bySession.ContainsKey(session))throw new InvalidOperationException("Session id already exists");
            var entry=new SpeechRecord {Session=session,Started=now,LastChange=now,Text="",CopyState="等待文字"};
            entries.Insert(0,entry);bySession.Add(session,entry);Current=entry;dirty=true;return entry;
        }
        public bool Accept(int session,string fullText,bool final,bool composition,DateTime now) {
            SpeechRecord entry=Find(session);
            if(entry==null || string.IsNullOrEmpty(fullText))return false;
            if(entry.Text==fullText && entry.HasFinal==final && (!composition || entry.HadComposition))return false;
            entry.Text=fullText;entry.HasFinal=final;entry.HadComposition|=composition;
            entry.LastChange=now;entry.Revision++;dirty=true;return true;
        }
        public void End(int session){var entry=Find(session);if(entry!=null && !entry.Ended){entry.Ended=true;dirty=true;}}
        public void SetCopyState(int session,string state){var entry=Find(session);if(entry!=null && entry.CopyState!=state){entry.CopyState=state;dirty=true;}}
        public SpeechRecord Find(int session){SpeechRecord entry;return bySession.TryGetValue(session,out entry)?entry:null;}
        public void FlushChanges(){if(!dirty)return;dirty=false;if(Changed!=null)Changed();}
    }
}
