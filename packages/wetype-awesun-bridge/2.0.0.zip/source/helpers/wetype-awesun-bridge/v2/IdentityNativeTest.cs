using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using WeTypeVoice2;
// Compiled as AweSun.exe, then renamed. Verifies the real process/file metadata path.
// A noninteractive station has no visible desktop; do not pretend to validate its visibility.
internal static class IdentityNativeTest {
    [DllImport("user32.dll")] static extern IntPtr GetProcessWindowStation();
    [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern bool GetUserObjectInformation(IntPtr obj,int index,StringBuilder value,uint length,out uint needed);
    static int Main(){
        var station=new StringBuilder(256);uint needed;
        if(!GetUserObjectInformation(GetProcessWindowStation(),2,station,512,out needed)||!station.ToString().StartsWith("WeTypeRelease_",StringComparison.Ordinal))return 2;
        using(var process=Process.GetCurrentProcess()){
            if(RemoteClientCatalog.ClientName(process.ProcessName))return 3;
            if(FileVersionInfo.GetVersionInfo(process.MainModule.FileName).OriginalFilename!="AweSun.exe")return 4;
            bool found=new RemoteClientCatalog().IsClient((uint)process.Id,DateTime.UtcNow);
            Console.WriteLine(found?"PASS renamed real process identified through original executable metadata":"FAIL renamed process identity");
            return found?0:1;
        }
    }
}
