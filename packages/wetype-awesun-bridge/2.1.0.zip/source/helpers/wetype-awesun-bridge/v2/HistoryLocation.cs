using System;
using System.IO;
using System.Security.AccessControl;
using System.Security.Principal;
namespace WeTypeVoice2 {
    internal static class HistoryLocation {
        public static string Database(){
            var sid=WindowsIdentity.GetCurrent().User;
            string folder=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"CodexTools","Users",sid.Value,"WeTypeVoiceHistory");
            if(!Directory.Exists(folder)){
                var acl=new DirectorySecurity();acl.SetAccessRuleProtection(true,false);
                foreach(var identity in new[]{sid,new SecurityIdentifier(WellKnownSidType.LocalSystemSid,null),new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid,null)})
                    acl.AddAccessRule(new FileSystemAccessRule(identity,FileSystemRights.FullControl,InheritanceFlags.ContainerInherit|InheritanceFlags.ObjectInherit,PropagationFlags.None,AccessControlType.Allow));
                Directory.CreateDirectory(folder,acl);
            }
            return Path.Combine(folder,"history.sqlite3");
        }
    }
}
