using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using WeTypeVoice2;

internal static class MouseTargetTests {
    [StructLayout(LayoutKind.Sequential)]struct Rect {public int Left,Top,Right,Bottom;}
    [StructLayout(LayoutKind.Sequential)]struct MonitorInfo {public int Size;public Rect Monitor,Work;public uint Flags;}
    delegate bool MonitorProc(IntPtr monitor,IntPtr dc,ref Rect rect,IntPtr data);
    [DllImport("user32.dll")]static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
    [DllImport("user32.dll")]static extern IntPtr GetThreadDpiAwarenessContext();
    [DllImport("user32.dll")]static extern bool AreDpiAwarenessContextsEqual(IntPtr a,IntPtr b);
    [DllImport("user32.dll")]static extern uint GetDpiForWindow(IntPtr window);
    [DllImport("user32.dll")]static extern bool EnumDisplayMonitors(IntPtr dc,IntPtr clip,MonitorProc callback,IntPtr data);
    [DllImport("user32.dll",CharSet=CharSet.Unicode)]static extern bool GetMonitorInfo(IntPtr monitor,ref MonitorInfo info);
    [DllImport("user32.dll",CharSet=CharSet.Unicode)]static extern IntPtr CreateWindowEx(uint extended,string kind,string title,uint style,int x,int y,int width,int height,IntPtr parent,IntPtr menu,IntPtr instance,IntPtr param);
    [DllImport("user32.dll")]static extern bool DestroyWindow(IntPtr window);
    [DllImport("user32.dll")]static extern bool SetWindowPos(IntPtr window,IntPtr order,int x,int y,int width,int height,uint flags);
    [DllImport("user32.dll")]static extern bool ShowWindow(IntPtr window,int command);
    [DllImport("user32.dll")]static extern bool ClientToScreen(IntPtr window,ref VoiceMouseTarget.Point point);
    [DllImport("user32.dll")]static extern bool ScreenToClient(IntPtr window,ref VoiceMouseTarget.Point point);
    [DllImport("user32.dll")]static extern bool GetWindowRect(IntPtr window,out Rect rect);
    [DllImport("user32.dll")]static extern bool GetClientRect(IntPtr window,out Rect rect);
    [DllImport("user32.dll")]static extern IntPtr WindowFromPoint(VoiceMouseTarget.Point point);
    [DllImport("user32.dll")]static extern IntPtr GetAncestor(IntPtr window,uint kind);
    [DllImport("user32.dll")]static extern IntPtr GetProcessWindowStation();
    [DllImport("user32.dll",CharSet=CharSet.Unicode)]static extern bool GetUserObjectInformation(IntPtr handle,int index,StringBuilder data,int bytes,out int needed);
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode)]static extern IntPtr GetModuleHandle(string name);
    sealed class Sample {public IntPtr Window,Child;public VoiceMouseTarget.Point Client,Caption;public uint Dpi,MonitorDpi;public int TargetContext;}
    static int passed;
    static void Check(bool ok,string message){if(!ok)throw new Exception(message);}
    static void Test(string name,Action run){run();passed++;Console.WriteLine("PASS "+name);}
    static bool Hit(Sample s){int before,during;bool hit=VoiceMouseTarget.Contains(s.Window,s.Client,out before,out during);Check(during==2,"hit test must use per-monitor awareness");return hit;}
    static bool LegacyHit(Sample s){var point=s.Client;if(GetAncestor(WindowFromPoint(point),2)!=s.Window)return false;Rect rect;if(!ScreenToClient(s.Window,ref point)||!GetClientRect(s.Window,out rect))return false;return point.X>=rect.Left&&point.X<rect.Right&&point.Y>=rect.Top&&point.Y<rect.Bottom;}
    [STAThread]static int Main(string[] args){
        var samples=new List<Sample>();IntPtr original=IntPtr.Zero;
        try{
            var station=new StringBuilder(256);int needed;
            Check(args.Length==1&&args[0]=="--tiny-targets"&&GetUserObjectInformation(GetProcessWindowStation(),2,station,station.Capacity*2,out needed)&&station.ToString()=="WinSta0","requires explicitly selected tiny native targets on the interactive desktop");
            Check(!new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator),"requires ordinary user");
            original=SetThreadDpiAwarenessContext(new IntPtr(-4));Check(original!=IntPtr.Zero,"per-monitor context");
            var monitors=new List<Rect>();
            EnumDisplayMonitors(IntPtr.Zero,IntPtr.Zero,(IntPtr h,IntPtr dc,ref Rect r,IntPtr d)=>{var info=new MonitorInfo{Size=Marshal.SizeOf(typeof(MonitorInfo))};if(GetMonitorInfo(h,ref info))monitors.Add(info.Work);return true;},IntPtr.Zero);
            Check(monitors.Count>0,"monitor geometry");
            foreach(var monitor in monitors){
                uint monitorDpi=96;
                foreach(int targetContext in new[]{-4,-1}){
                    SetThreadDpiAwarenessContext(new IntPtr(targetContext));
                    var hwnd=CreateWindowEx(0x08000088,"STATIC","Synthetic voice target",0x80800000,0,0,15,15,IntPtr.Zero,IntPtr.Zero,GetModuleHandle(null),IntPtr.Zero);
                    Check(hwnd!=IntPtr.Zero,"synthetic native window");
                    SetThreadDpiAwarenessContext(new IntPtr(-4));
                    Check(SetWindowPos(hwnd,new IntPtr(-1),monitor.Right-(targetContext==-4?21:41),monitor.Bottom-21,15,15,0x50),"position nonactivating target");
                    if(targetContext==-4)monitorDpi=GetDpiForWindow(hwnd);
                    var sample=new Sample{Window=hwnd,Dpi=GetDpiForWindow(hwnd),MonitorDpi=monitorDpi,TargetContext=targetContext};samples.Add(sample);
                    SetThreadDpiAwarenessContext(new IntPtr(targetContext));
                    sample.Child=CreateWindowEx(0,"EDIT","",0x50000000,0,0,3,3,hwnd,IntPtr.Zero,GetModuleHandle(null),IntPtr.Zero);Check(sample.Child!=IntPtr.Zero,"synthetic child");
                    SetThreadDpiAwarenessContext(new IntPtr(-4));
                    sample.Client=new VoiceMouseTarget.Point{X=1,Y=1};Check(ClientToScreen(hwnd,ref sample.Client),"physical client point");
                    Rect bounds;Check(GetWindowRect(hwnd,out bounds),"physical window bounds");sample.Caption=new VoiceMouseTarget.Point{X=bounds.Left,Y=bounds.Top+4};
                }
            }
            Test("scoped hit testing accepts physical client points from each caller DPI context",()=>{
                foreach(var sample in samples)foreach(int context in new[]{-1,-2,-4}){
                    SetThreadDpiAwarenessContext(new IntPtr(context));Check(Hit(sample),"client hit dpi="+sample.Dpi+" caller="+context);
                }
            });
            Test("old unscoped calculation reproduces a scaled-display miss",()=>{
                bool scaled=false,miss=false;
                SetThreadDpiAwarenessContext(new IntPtr(-1));
                foreach(var sample in samples){
                    bool old=LegacyHit(sample);if(sample.MonitorDpi!=96){scaled=true;if(!old)miss=true;}
                    Console.WriteLine("DISPLAY monitorDpi="+sample.MonitorDpi+" windowDpi="+sample.Dpi+" targetContext="+sample.TargetContext+" legacyHit="+old+" scopedHit="+Hit(sample));
                }
                Check(scaled&&miss,"this regression requires an actual non-100-percent display and a reproduced miss");
            });
            Test("caller DPI is restored after successful and rejected hit tests",()=>{
                foreach(int context in new[]{-1,-2,-4}){
                    SetThreadDpiAwarenessContext(new IntPtr(context));IntPtr before=GetThreadDpiAwarenessContext();
                    Check(Hit(samples[0])&&AreDpiAwarenessContextsEqual(before,GetThreadDpiAwarenessContext()),"restore success");
                    int a,b;Check(!VoiceMouseTarget.Contains(IntPtr.Zero,samples[0].Client,out a,out b)&&AreDpiAwarenessContextsEqual(before,GetThreadDpiAwarenessContext()),"restore rejected target");
                }
            });
            Test("child hit belongs to the expected voice root only",()=>{
                SetThreadDpiAwarenessContext(new IntPtr(-1));Check(Hit(samples[0]),"child resolves to voice root");
                int a,b;Check(!VoiceMouseTarget.Contains(samples[0].Child,samples[0].Client,out a,out b),"child cannot substitute for expected root");
            });
            Test("non-client border outside and hidden targets do not finish speech",()=>{
                SetThreadDpiAwarenessContext(new IntPtr(-1));int a,b;
                foreach(var sample in samples){
                    Check(!VoiceMouseTarget.Contains(sample.Window,sample.Caption,out a,out b),"non-client border excluded");
                    var outside=sample.Client;outside.X+=500;outside.Y+=500;Check(!VoiceMouseTarget.Contains(sample.Window,outside,out a,out b),"outside excluded");
                    ShowWindow(sample.Window,0);Check(!Hit(sample),"hidden recording excluded");
                }
            });
            Console.WriteLine("RESULT "+passed+"/"+passed+" native mouse target tests passed; ordinary user, 15-pixel nonactivating native targets, no input generated.");return 0;
        }catch(Exception e){Console.Error.WriteLine("FAIL "+e.Message);return 1;}
        finally{foreach(var sample in samples)DestroyWindow(sample.Window);if(original!=IntPtr.Zero)SetThreadDpiAwarenessContext(original);}
    }
}
