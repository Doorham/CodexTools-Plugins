using System;
using System.Drawing;
using System.Windows.Forms;
namespace WeTypeVoice2 {
    // The only user-facing window: live history and full-text copy are available immediately.
    internal sealed class SpeechHistoryWindow : Form {
        readonly SpeechHistory history;readonly Func<int,bool> copy;
        readonly HistoryTimeline timeline;
        readonly TextBox text=new TextBox {Name="historyText",Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Vertical,Dock=DockStyle.Fill,MaxLength=int.MaxValue,BorderStyle=BorderStyle.None};
        readonly CheckBox follow=new CheckBox {Name="followLatest",Text="跟随最新记录",Checked=true,AutoSize=true};
        readonly Label detail=new Label {Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft,AutoEllipsis=true};
        readonly Label activity=new Label {Text="● 正在监听",AutoSize=true};
        readonly Label count=new Label {Size=new Size(60,24),TextAlign=ContentAlignment.MiddleLeft,Location=new Point(90,0)};
        readonly Label selectionTitle=new Label {AutoSize=true,Text="全文"};
        readonly Label selectionMeta=new Label {AutoSize=true};
        readonly ActionButton copyButton=new ActionButton {Name="copySelected",Text="复制全文",Primary=true,Size=new Size(112,38)};
        readonly ActionButton exitButton=new ActionButton {Name="exitApp",Text="退出",Size=new Size(72,34)};
        readonly Label empty=new Label {Text="还没有语音记录\n用原快捷键说一段话，文字会出现在这里。",Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleCenter};
        readonly Label footer=new Label {Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft,AutoEllipsis=true};
        readonly Image brand;
        bool refreshing;int selectedSession;string displayedId;int displayedRevision=-1;DateTime shownDate;
        public event Action ExitRequested;
        public long HistoryCount {get{return timeline.TotalCount;}}
        protected override bool ShowWithoutActivation {get{return true;}}
        public SpeechHistoryWindow(SpeechHistory source,Func<int,bool> copier){
            history=source;copy=copier;timeline=new HistoryTimeline(history);
            Text="微信语音监听板";ClientSize=new Size(980,620);MinimumSize=new Size(800,500);
            StartPosition=FormStartPosition.CenterScreen;AutoScaleMode=AutoScaleMode.Dpi;AutoScaleDimensions=new SizeF(96,96);
            Font=new Font("Microsoft YaHei UI",10);BackColor=UiTheme.Background;ForeColor=UiTheme.Text;
            Icon=Icon.ExtractAssociatedIcon(Application.ExecutablePath)??SystemIcons.Application;
            brand=UiTheme.LoadBrand();
            var root=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,Padding=new Padding(24,0,24,0),BackColor=UiTheme.Background};
            root.RowStyles.Add(new RowStyle(SizeType.Absolute,100));root.RowStyles.Add(new RowStyle(SizeType.Percent,100));root.RowStyles.Add(new RowStyle(SizeType.Absolute,48));
            Controls.Add(root);
            var header=new Panel {Dock=DockStyle.Fill,Margin=Padding.Empty,BackColor=UiTheme.Background};
            if(brand!=null)header.Controls.Add(new PictureBox {Image=brand,SizeMode=PictureBoxSizeMode.Zoom,Location=new Point(0,27),Size=new Size(46,46)});
            header.Controls.Add(new Label {Text="微信语音监听板",Font=new Font(Font.FontFamily,18,FontStyle.Bold),AutoSize=true,Location=new Point(62,21),ForeColor=UiTheme.Text});
            header.Controls.Add(new Label {Text="本机照常输入 · 向日葵在结束时接收",AutoSize=true,Location=new Point(64,57),ForeColor=UiTheme.Muted});
            activity.ForeColor=UiTheme.Success;header.Controls.Add(activity);header.Controls.Add(exitButton);
            header.Layout+=(s,e)=>{exitButton.Location=new Point(header.ClientSize.Width-exitButton.Width,31);activity.Location=new Point(exitButton.Left-activity.PreferredWidth-20,39);};
            exitButton.Click+=(s,e)=>{if(ExitRequested!=null)ExitRequested();};
            root.Controls.Add(header,0,0);
            var columns=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=2,RowCount=1,Margin=Padding.Empty,BackColor=UiTheme.Background};
            columns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,32));columns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,68));
            root.Controls.Add(columns,0,1);
            var left=new SurfacePanel {Dock=DockStyle.Fill,Margin=new Padding(0,0,16,0)};
            var leftLayout=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,BackColor=UiTheme.Panel,Margin=Padding.Empty};
            leftLayout.RowStyles.Add(new RowStyle(SizeType.Absolute,40));leftLayout.RowStyles.Add(new RowStyle(SizeType.Percent,100));leftLayout.RowStyles.Add(new RowStyle(SizeType.Absolute,40));
            left.Controls.Add(leftLayout);columns.Controls.Add(left,0,0);
            var historyHeading=new Panel {Dock=DockStyle.Fill,Margin=Padding.Empty,BackColor=UiTheme.Panel};
            historyHeading.Controls.Add(new Label {Text="语音历史",AutoSize=true,Font=new Font(Font,FontStyle.Bold),Location=new Point(0,3),ForeColor=UiTheme.Text});
            count.ForeColor=UiTheme.Muted;historyHeading.Controls.Add(count);
            leftLayout.Controls.Add(historyHeading,0,0);
            timeline.Margin=Padding.Empty;leftLayout.Controls.Add(timeline,0,1);
            follow.ForeColor=UiTheme.Muted;follow.Anchor=AnchorStyles.Left;follow.Margin=new Padding(2,10,0,0);leftLayout.Controls.Add(follow,0,2);
            var right=new SurfacePanel {Dock=DockStyle.Fill,Margin=Padding.Empty,Padding=new Padding(24,18,24,16)};
            columns.Controls.Add(right,1,0);
            var rightLayout=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,BackColor=UiTheme.Panel,Margin=Padding.Empty};
            rightLayout.RowStyles.Add(new RowStyle(SizeType.Absolute,66));rightLayout.RowStyles.Add(new RowStyle(SizeType.Percent,100));rightLayout.RowStyles.Add(new RowStyle(SizeType.Absolute,38));right.Controls.Add(rightLayout);
            var fullHeader=new Panel {Dock=DockStyle.Fill,BackColor=UiTheme.Panel,Margin=Padding.Empty};
            selectionTitle.Font=new Font(Font.FontFamily,13,FontStyle.Bold);selectionTitle.ForeColor=UiTheme.Text;selectionTitle.Location=new Point(0,0);
            selectionMeta.Location=new Point(0,30);selectionMeta.ForeColor=UiTheme.Muted;
            fullHeader.Controls.AddRange(new Control[]{selectionTitle,selectionMeta,copyButton});
            fullHeader.Layout+=(s,e)=>copyButton.Location=new Point(fullHeader.ClientSize.Width-copyButton.Width,3);
            rightLayout.Controls.Add(fullHeader,0,0);
            var textArea=new Panel {Dock=DockStyle.Fill,Margin=Padding.Empty,BackColor=UiTheme.Panel};
            text.Font=new Font(Font.FontFamily,11);text.BackColor=UiTheme.Panel;text.ForeColor=UiTheme.Text;
            empty.ForeColor=UiTheme.Muted;empty.BackColor=UiTheme.Panel;textArea.Controls.Add(text);textArea.Controls.Add(empty);rightLayout.Controls.Add(textArea,0,1);
            detail.ForeColor=UiTheme.Muted;detail.Font=new Font(Font.FontFamily,9);rightLayout.Controls.Add(detail,0,2);
            footer.Text="历史自动保存到本机，退出后仍保留  ·  关闭窗口后仍可从托盘打开";
            footer.ForeColor=UiTheme.Muted;footer.Font=new Font(Font.FontFamily,9);footer.Margin=Padding.Empty;root.Controls.Add(footer,0,2);
            timeline.Selected+=entry=>{
                if(refreshing)return;selectedSession=entry.Session;
                var latest=history.Latest;if(latest!=null&&entry.Id!=latest.Id)follow.Checked=false;
                TryShowSelection();
            };
            follow.CheckedChanged+=(s,e)=>{if(!refreshing && follow.Checked)RefreshHistory();};
            copyButton.Click+=(s,e)=>CopySelected();
            history.Changed+=RefreshHistory;RefreshHistory();
        }
        protected override void OnHandleCreated(EventArgs e){base.OnHandleCreated(e);UiTheme.WindowChrome(this);}
        public void SetActivity(bool listening,bool receiving,bool finishing,string message){
            string caption=receiving?"● 正在接收":finishing?"● 正在收尾":listening?"● 正在监听":"● 未开始监听";
            if(activity.Text!=caption){activity.Text=caption;activity.Parent.PerformLayout();}
            activity.ForeColor=listening?UiTheme.Success:UiTheme.Muted;
            activity.AccessibleDescription=message;
            if(!listening)detail.Text=message;
        }
        public void RefreshDate(){if(shownDate!=DateTime.Today)RefreshHistory();}
        void RefreshHistory(){
            if(IsDisposed)return;refreshing=true;
            try {
                if(follow.Checked){var latest=history.Latest;if(latest!=null)selectedSession=latest.Session;}
                timeline.RefreshRecords(follow.Checked);shownDate=DateTime.Today;
                count.Text=timeline.TotalCount+" 条";
                TryShowSelection();
            }catch(Exception){history.ReportStorageReadError();}
            finally{refreshing=false;}
            footer.Text=!string.IsNullOrEmpty(history.StorageError)?history.StorageError:history.HasUnsaved?"正在保存到本机…":history.Archive==null?"示例记录  ·  关闭窗口后仍可从托盘打开":"历史已保存到本机，退出后仍保留  ·  关闭窗口后仍可从托盘打开";
        }
        void TryShowSelection(){
            try{ShowSelection();}
            catch(Exception){history.ReportStorageReadError();text.Text="";text.Visible=false;empty.Visible=true;empty.Text="这条历史暂时无法读取，原文件未修改。\n请稍后重新选择。";empty.BringToFront();copyButton.Enabled=false;detail.Text=history.StorageError;footer.Text=history.StorageError;}
        }
        void ShowSelection(){
            var entry=history.Find(selectedSession);string value=text.Text;
            if(entry==null){value="";displayedId=null;}else if(displayedId!=entry.Id||displayedRevision!=entry.Revision){value=entry.Text;displayedId=entry.Id;displayedRevision=entry.Revision;}
            if(text.Text!=value){
                int selection=text.SelectionStart,length=text.SelectionLength;text.Text=value;
                text.Select(Math.Min(selection,value.Length),Math.Min(length,Math.Max(0,value.Length-selection)));
                if(follow.Checked){text.Select(value.Length,0);text.ScrollToCaret();}
            }
            bool showEmpty=entry==null || value.Length==0;
            empty.Visible=showEmpty;text.Visible=!showEmpty;
            if(showEmpty)empty.BringToFront();
            empty.Text=entry==null?"还没有语音记录\n用原快捷键说一段话，文字会出现在这里。":entry.Ended?"这一段没有收到文字\n之前的记录仍保留在左侧历史中。":"正在等待微信交付文字…";
            selectionTitle.Text=entry==null?"全文":"语音全文";
            selectionMeta.Text=entry==null?"选中一条记录即可查看":entry.Started.ToLocalTime().ToString("MM月dd日  HH:mm:ss")+"  ·  "+entry.Characters+" 字";
            detail.Text=entry==null?"收到的文字会自动保留并复制。":entry.CopyState;
            detail.ForeColor=entry!=null && entry.CopyState.Contains("已复制")?UiTheme.Success:UiTheme.Muted;
            copyButton.Enabled=entry!=null && entry.Characters>0;
        }
        void CopySelected(){
            var entry=history.Find(selectedSession);if(entry==null)return;
            bool ok;try{ok=copy(entry.Session);}catch(Exception){ok=false;history.ReportStorageReadError();}history.FlushChanges();
            detail.Text=ok?"已复制全文到本机剪贴板。":"复制未成功，全文仍保留；请稍后再试。";
            detail.ForeColor=ok?UiTheme.Success:UiTheme.Muted;
        }
        protected override void Dispose(bool disposing){
            if(disposing){history.Changed-=RefreshHistory;if(brand!=null)brand.Dispose();}
            base.Dispose(disposing);
        }
    }
}
