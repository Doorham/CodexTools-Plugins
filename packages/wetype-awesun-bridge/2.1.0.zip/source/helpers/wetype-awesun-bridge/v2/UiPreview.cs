using System;
using System.Drawing;
using System.Windows.Forms;
using WeTypeVoice2;
internal static class UiPreview {
    [STAThread] static int Main(string[] args){
        Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
        if(Array.IndexOf(args,"--dark")>=0)UiTheme.Dark=true;
        var history=new SpeechHistory();int session=0;DateTime now=DateTime.UtcNow;
        if(Array.IndexOf(args,"--empty")<0){
            foreach(var when in new[]{now.AddYears(-2),now.AddYears(-1),now.AddMonths(-2),now.AddMonths(-1),now.AddDays(-1)}){
                var old=history.Begin(++session,when);history.Accept(old.Session,"用于检查日期折叠的历史示例。",true,false,when);history.End(old.Session);
            }
            string[] examples={
                "这是较早的一条示例记录。查看旧记录时，新语音不会把当前选择切走。",
                "这一段演示原有换行。\r\n\r\n全文保留在右侧，可以直接选择、复制。",
                "这是界面检查用的示例内容。\r\n\r\n打开窗口就能看到左侧语音历史；选中一条，右侧直接显示完整文字。\r\n\r\n新的内容会实时更新。复制按钮只复制当前选中的这一条。"};
            for(int n=0;n<examples.Length;n++){var r=history.Begin(++session,now.AddMinutes(-6+n*2));history.Accept(r.Session,examples[n],true,false,now);history.SetCopyState(r.Session,"已复制到本机");history.End(r.Session);}
        }
        using(var form=new SpeechHistoryWindow(history,id=>true)){
            form.Text="微信语音监听板 · 界面预览（示例数据）";form.SetActivity(true,false,false,"示例状态");
            if(Array.IndexOf(args,"--compact")>=0)form.Size=form.MinimumSize;
            form.ExitRequested+=()=>form.Close();form.KeyPreview=true;
            form.KeyDown+=(s,e)=>{if(e.KeyCode==Keys.F6){var r=history.Begin(++session,DateTime.UtcNow);history.Accept(r.Session,"新加入的示例记录。当前窗口无需重开即可看到更新。",true,false,DateTime.UtcNow);history.SetCopyState(r.Session,"已复制到本机");history.End(r.Session);history.FlushChanges();}};
            int render=Array.IndexOf(args,"--render");
            if(render>=0&&render+1<args.Length){
                form.ShowInTaskbar=false;form.Show();form.PerformLayout();Application.DoEvents();form.Refresh();
                var tree=(TreeView)form.Controls.Find("historyTree",true)[0];
                var metrics=new System.Text.StringBuilder("ItemHeight="+tree.ItemHeight+" Client="+tree.ClientRectangle+"\n");
                for(var node=tree.TopNode;node!=null;node=node.NextVisibleNode)metrics.AppendLine("level="+node.Level+" bounds="+node.Bounds);
                System.IO.File.WriteAllText(args[render+1]+".layout.txt",metrics.ToString());
                using(var bitmap=new Bitmap(form.Width,form.Height)){form.DrawToBitmap(bitmap,new Rectangle(0,0,bitmap.Width,bitmap.Height));bitmap.Save(args[render+1],System.Drawing.Imaging.ImageFormat.Png);}
            }else Application.Run(form);
        }return 0;
    }
}
