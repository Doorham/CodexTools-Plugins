using System;
namespace WeTypeVoice2 {
    internal sealed class RecordingPipeline {
        int nextSession;
        public SpeechHistory History {get;private set;}
        public ClipboardDelivery Delivery {get;private set;}
        public bool DeferDelivery {get;set;}
        public RecordingPipeline(IClipboardSink clipboard):this(clipboard,null){}
        public RecordingPipeline(IClipboardSink clipboard,HistoryArchive archive){History=new SpeechHistory(archive);Delivery=new ClipboardDelivery(clipboard,History);}
        public SpeechRecord Begin(DateTime now){DeferDelivery=false;var record=History.Begin(++nextSession,now);Delivery.Begin(record.Session,now);return record;}
        public void Receive(int session,string fullText,bool final,string source,DateTime now){
            var previous=History.Find(session);bool textChanged=previous!=null && previous.Text!=fullText;
            if(History.Accept(session,fullText,final,source=="ime_composition",now) && textChanged)
                History.SetCopyState(session,History.Current.Session==session?"待复制":"补收到旧段，待手动复制");
        }
        public void End(int session){History.End(session);}
        // Called by the UI pump, never from an input-method callback.
        public void Pump(DateTime now){History.PersistPending();if(!DeferDelivery)Delivery.Tick(now);History.FlushChanges();}
    }
}
