using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;

namespace WeTypeVoice2 {
    internal sealed class SpeechRecord {
        public int Session {get;internal set;}
        public DateTime Started {get;internal set;}
        public DateTime LastChange {get;internal set;}
        string body="";
        internal Func<string> LoadBody;
        internal bool ReleaseWhenSaved;
        public bool Persisted {get;internal set;}
        public string Id {get;internal set;}
        internal string StoredDay;
        public string Day {get{return StoredDay??Started.ToLocalTime().ToString("yyyy-MM-dd");}}
        public int Characters {get;internal set;}
        public string Preview {get;internal set;}
        public string Text {get{return LoadBody==null?body:LoadBody();}internal set{body=value??"";LoadBody=null;Characters=body.Length;Preview=body.Substring(0,Math.Min(body.Length,80)).Replace("\r"," ").Replace("\n"," ");}}
        internal void ReleaseBody(Func<string> loader){body="";LoadBody=loader;}
        public int Revision {get;internal set;}
        public bool Ended {get;internal set;}
        public bool HasFinal {get;internal set;}
        public bool HadComposition {get;internal set;}
        public string CopyState {get;internal set;}
        public override string ToString(){return Started.ToLocalTime().ToString("HH:mm:ss")+" · "+Characters+" 字 · "+(Ended?(Characters==0?"未收到文字":"已结束"):"接收中")+" · "+CopyState;}
    }

    // The sole owner of captured speech. No clipboard, focus, files or UI callbacks during Accept.
    internal sealed class SpeechHistory {
        readonly List<SpeechRecord> entries=new List<SpeechRecord>();
        readonly Dictionary<int,SpeechRecord> bySession=new Dictionary<int,SpeechRecord>();
        readonly ReadOnlyCollection<SpeechRecord> view;
        bool dirty;
        readonly HashSet<int> pending=new HashSet<int>();
        readonly Dictionary<string,SpeechRecord> archived=new Dictionary<string,SpeechRecord>();
        int restoredId;
        DateTime retryAt;
        public HistoryArchive Archive {get;private set;}
        public string StorageError {get;private set;}
        public bool HasUnsaved {get{return pending.Count>0;}}
        bool storageRequired;
        public void StorageUnavailable(string reason){storageRequired=true;StorageError=reason;dirty=true;}
        public void ReportStorageReadError(){StorageError="历史暂时无法读取，原文件未修改";}
        public long CatalogRevision {get;private set;}
        public SpeechHistory(HistoryArchive archive):this(){Archive=archive;storageRequired=archive!=null;}
        public SpeechRecord Restore(HistoryHeader header){
            if(header==null)return null;
            SpeechRecord known;if(archived.TryGetValue(header.Id,out known))return known;
            foreach(var r in entries)if(r.Id==header.Id)return r;
            string id=header.Id;
            var record=new SpeechRecord {Session=--restoredId,Id=id,StoredDay=header.Day,Started=header.Started,LastChange=header.Started,Characters=header.Characters,Preview=header.Preview,HasFinal=header.Final,Ended=true,Revision=header.Revision,CopyState=header.Ended&&header.Final?"已保存到本机":"已保存到本机（未确认最终提交）",Persisted=true};
            record.ReleaseBody(()=>Archive.Body(id));archived.Add(id,record);bySession.Add(record.Session,record);return record;
        }
        public SpeechRecord Latest {get{if(entries.Count>0)return entries[0];return Archive==null?null:Restore(Archive.Latest());}}
        public SpeechRecord LatestWithText {get{foreach(var r in entries)if(r.Characters>0)return r;return Archive==null?null:Restore(Archive.Latest(true));}}
        public bool SavePending(){
            if(Archive==null)return !HasUnsaved;
            if(pending.Count==0)return true;
            try {
                var batch=new List<SpeechRecord>();foreach(int id in pending)batch.Add(bySession[id]);
                Archive.Save(batch);foreach(var saved in batch)saved.Persisted=true;pending.Clear();StorageError="";retryAt=DateTime.MinValue;
                foreach(var r in entries)ReleaseStoredBody(r);
                return true;
            }catch(Exception e){StorageError="历史暂未写入硬盘，文字仍在本次运行中（"+e.GetType().Name+"）";retryAt=DateTime.UtcNow.AddSeconds(1);return false;}
        }
        void ReleaseStoredBody(SpeechRecord r){if(r!=Current&&r.ReleaseWhenSaved&&r.Persisted&&!pending.Contains(r.Session)&&r.LoadBody==null){string id=r.Id;r.ReleaseBody(()=>Archive.Body(id));}}
        public void ReceiverDisposed(int session){var r=Find(session);if(r==null)return;r.ReleaseWhenSaved=true;ReleaseStoredBody(r);}
        public SpeechHistory(){view=entries.AsReadOnly();}
        public event Action Changed;
        public ReadOnlyCollection<SpeechRecord> Entries {get{return view;}}
        public SpeechRecord Current {get;private set;}
        public string Retained {get{foreach(var entry in entries)if(entry.Characters>0)return entry.Text;return "";}}
        public int RetainedCharacterCount {get{foreach(var entry in entries)if(entry.Characters>0)return entry.Characters;return 0;}}
        public SpeechRecord Begin(int session,DateTime now){
            if(bySession.ContainsKey(session))throw new InvalidOperationException("Session id already exists");
            var entry=new SpeechRecord {Session=session,Started=now,LastChange=now,Id=Guid.NewGuid().ToString("N"),Text="",CopyState="等待文字"};
            entries.Insert(0,entry);bySession.Add(session,entry);Current=entry;dirty=true;CatalogRevision++;if(storageRequired)pending.Add(session);return entry;
        }
        public bool Accept(int session,string fullText,bool final,bool composition,DateTime now) {
            SpeechRecord entry=Find(session);
            if(entry==null || string.IsNullOrEmpty(fullText))return false;
            if(entry.Text==fullText && entry.HasFinal==final && (!composition || entry.HadComposition))return false;
            entry.Text=fullText;entry.HasFinal=final;entry.HadComposition|=composition;
            entry.LastChange=now;entry.Revision++;dirty=true;if(storageRequired)pending.Add(session);return true;
        }
        public void End(int session){var entry=Find(session);if(entry!=null && !entry.Ended){entry.Ended=true;dirty=true;if(storageRequired)pending.Add(session);}}
        public void SetCopyState(int session,string state){var entry=Find(session);if(entry!=null && entry.CopyState!=state){entry.CopyState=state;dirty=true;}}
        public SpeechRecord Find(int session){SpeechRecord entry;return bySession.TryGetValue(session,out entry)?entry:null;}
        public void PersistPending(){if(Archive!=null&&pending.Count>0&&DateTime.UtcNow>=retryAt){SavePending();dirty=true;}}
        public void FlushChanges(){PersistPending();if(!dirty)return;dirty=false;if(Changed!=null)Changed();}
    }
}
