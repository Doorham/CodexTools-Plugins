using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using WeTypeVoice2;

internal sealed class FakeClipboard : IClipboardSink {
    public uint Sequence {get;private set;}
    public string Text="";
    public int Writes,Busy,Attempts;
    public bool Race;
    public Action DuringWrite;
    public bool TryPut(string text,uint expected,out uint written) {
        Attempts++;written=Sequence;
        if(Race){Race=false;External();}
        if(expected!=Sequence)return false;
        if(Busy>0){Busy--;throw new ExternalException();}
        if(DuringWrite!=null){var callback=DuringWrite;DuringWrite=null;callback();}
        Text=text;Writes++;written=++Sequence;return true;
    }
    public void External(){Text="external";Sequence++;}
}
internal static class Tests {
    static readonly DateTime Start=new DateTime(2026,1,1,0,0,0,DateTimeKind.Utc);
    static int passed;
    static void Check(bool value,string name){if(!value)throw new Exception(name);}
    static void Test(string name,Action run){run();passed++;Console.WriteLine("PASS "+name);}
    static void Receive(RecordingPipeline p,int id,string text,bool final,int ms){
        p.Receive(id,text,final,final?"ime_result":"ime_composition",Start.AddMilliseconds(ms));
    }
    static void Pump(RecordingPipeline p,int ms){p.Pump(Start.AddMilliseconds(ms));}
    [STAThread] static int Main() {
        try {
            Test("remote identity accepts both official executable names",()=>{
                Check(RemoteClientCatalog.Matches("AweSun","","","",""),"AweSun");
                Check(RemoteClientCatalog.Matches("sunloginclient.EXE","","","",""),"Sunlogin");
            });
            Test("renamed remote client keeps original executable identity",()=>{
                Check(RemoteClientCatalog.Matches("customer-tool","AweSun.exe","","",""),"renamed AweSun");
                Check(RemoteClientCatalog.Matches("customer-tool","SunloginClient.exe","","",""),"renamed Sunlogin");
            });
            Test("renamed client metadata requires vendor product and client purpose",()=>{
                Check(RemoteClientCatalog.Matches("customer-tool","","向日葵","远程控制","贝锐"),"full identity");
                Check(!RemoteClientCatalog.Matches("editor","","向日葵","远程控制","Other"),"wrong vendor");
                Check(!RemoteClientCatalog.Matches("editor","","Other","远程控制","Oray"),"wrong product");
                Check(!RemoteClientCatalog.Matches("editor","","AweSun","Updater","Oray"),"wrong purpose");
            });
            Test("remote service guard updater and unrelated apps never qualify",()=>{
                foreach(string name in new[]{"SunloginService","AweSunGuard","client-update"})
                    Check(!RemoteClientCatalog.Matches(name,"AweSun.exe","AweSun","remote control","Oray"),name);
                Check(!RemoteClientCatalog.Matches("notepad","notepad.exe","Windows","Text editor","Microsoft"),"local application");
            });

            Test("end capture holds partial clipboard output and preserves copies after the end request",()=>{
                var c=new FakeClipboard();c.External();var p=new RecordingPipeline(c);var r=p.Begin(Start);p.DeferDelivery=true;
                Receive(p,r.Session,"first part",true,0);Pump(p,0);Check(c.Text=="external" && p.History.Retained=="first part","retain but do not publish prefix");
                Receive(p,r.Session,"complete speech",false,100);p.End(r.Session);p.DeferDelivery=false;Pump(p,110);
                Check(c.Text=="complete speech" && c.Writes==1,"publish complete snapshot after reception ends");
                r=p.Begin(Start.AddSeconds(1));p.DeferDelivery=true;Receive(p,r.Session,"later speech",true,1100);c.External();p.End(r.Session);p.DeferDelivery=false;Pump(p,1200);
                Check(c.Text=="external" && p.Delivery.Paused,"a new copy after finish request wins");
            });
            Test("receive saves exact long Unicode without clipboard or UI callbacks",()=>{
                var c=new FakeClipboard();var p=new RecordingPipeline(c);var r=p.Begin(Start);
                int refreshes=0;p.History.Changed+=()=>refreshes++;
                string full=new string('\u6587',20000)+"\r\n\u3002\ud83d\ude42\n";
                Receive(p,r.Session,full,true,0);
                Check(r.Text==full && c.Attempts==0 && refreshes==0,"receive must only retain");
                Pump(p,0);Check(c.Text==full && refreshes==1,"delivery and notification deferred");
            });
            Test("continuous snapshots coalesce and final bypasses normal throttle",()=>{
                var c=new FakeClipboard();var p=new RecordingPipeline(c);int id=p.Begin(Start).Session;
                Receive(p,id,"a",false,0);Pump(p,0);Receive(p,id,"ab",false,80);Pump(p,80);
                Receive(p,id,"abc",false,160);Pump(p,160);Check(c.Text=="a","coalesced");
                Pump(p,301);Check(c.Text=="abc","latest snapshot");
                Receive(p,id,"complete",true,320);Pump(p,320);Check(c.Text=="complete","final flush");
            });
            Test("shorter recognition correction replaces full snapshot",()=>{
                var c=new FakeClipboard();var p=new RecordingPipeline(c);int id=p.Begin(Start).Session;
                Receive(p,id,"longer",true,0);Pump(p,0);Receive(p,id,"short",true,10);Pump(p,10);
                Check(c.Text=="short" && p.History.Current.Text=="short","shorter");
            });
            Test("duplicate final keeps copied state without another write",()=>{
                var c=new FakeClipboard();var p=new RecordingPipeline(c);var r=p.Begin(Start);
                Receive(p,r.Session,"same",false,0);Pump(p,0);Receive(p,r.Session,"same",true,10);Pump(p,10);
                Check(c.Writes==1 && r.HasFinal && r.CopyState=="已复制到本机","duplicate final state");
            });
            Test("empty teardown does not erase pending or final speech",()=>{
                var p=new RecordingPipeline(new FakeClipboard());var r=p.Begin(Start);
                Receive(p,r.Session,"prefix",true,0);Receive(p,r.Session,"prefix tail",false,5);
                Receive(p,r.Session,"",true,10);Check(!r.HasFinal && r.Text=="prefix tail","preserve pending");
                Receive(p,r.Session,"final",true,20);Receive(p,r.Session,"",false,30);
                Check(r.HasFinal && r.Text=="final","preserve final");
            });
            Test("end retains record and accepts delayed final into original identity",()=>{
                var c=new FakeClipboard();var p=new RecordingPipeline(c);var r=p.Begin(Start);
                Receive(p,r.Session,"pending",false,0);p.End(r.Session);
                Check(r.Ended && r.Text=="pending" && c.Attempts==0,"end without side effects");
                Receive(p,r.Session,"delayed final",true,1600);Pump(p,1600);
                Check(r.Ended && r.HasFinal && r.Text==c.Text && p.History.Entries.Count==1,"delayed final");
            });
            Test("new empty recording is distinct from previous retained speech",()=>{
                var c=new FakeClipboard();var p=new RecordingPipeline(c);var old=p.Begin(Start);
                Receive(p,old.Session,"previous",true,0);Pump(p,0);p.End(old.Session);
                var current=p.Begin(Start.AddSeconds(1));p.End(current.Session);Pump(p,1000);
                Check(current.Text=="" && current.Ended && p.History.Entries.Count==2 && p.History.Retained=="previous","explicit empty record");
                Check(current.ToString().Contains("未收到文字"),"visible empty state");
                Check(p.Delivery.CopyLatest(Start.AddSeconds(2)) && current.Text=="" && c.Text=="previous","rescue cannot populate current");
            });
            Test("late old result updates only old record and never auto copies over new",()=>{
                var c=new FakeClipboard {Busy=1};var p=new RecordingPipeline(c);var old=p.Begin(Start);
                Receive(p,old.Session,"old pending",true,0);Pump(p,0);p.End(old.Session);
                var current=p.Begin(Start.AddSeconds(1));Receive(p,old.Session,"late previous",true,1100);Pump(p,1100);
                Check(c.Writes==0 && current.Text=="" && old.Text=="late previous","late old isolated");
                Receive(p,current.Session,"new",true,1200);Pump(p,1200);
                Receive(p,old.Session,"older correction",true,1300);Pump(p,1300);
                Check(c.Text=="new" && current.Text=="new" && old.Text=="older correction","new copy stays new");
            });
            Test("unknown session cannot create a record or overwrite current",()=>{
                var p=new RecordingPipeline(new FakeClipboard());var r=p.Begin(Start);
                Receive(p,r.Session+123,"unknown",true,0);Check(r.Text=="" && p.History.Entries.Count==1,"unknown discarded");
            });
            Test("external copy survives final reception and automatic retries",()=>{
                var c=new FakeClipboard();var p=new RecordingPipeline(c);var r=p.Begin(Start);
                Receive(p,r.Session,"old",false,0);Pump(p,0);c.External();
                Receive(p,r.Session,"late full",true,5);Pump(p,5);Pump(p,5000);
                Check(c.Text=="external" && p.Delivery.Paused && r.Text=="late full","external copy preserved");
            });
            Test("clipboard change between checking and locked write is protected",()=>{
                var c=new FakeClipboard {Race=true};var p=new RecordingPipeline(c);var r=p.Begin(Start);
                Receive(p,r.Session,"speech",true,0);Pump(p,0);
                Check(c.Text=="external" && c.Writes==0 && p.Delivery.Paused,"locked sequence check");
            });
            Test("manual rescue deliberately replaces external copy",()=>{
                var c=new FakeClipboard();var p=new RecordingPipeline(c);var r=p.Begin(Start);
                Receive(p,r.Session,"speech",true,0);Pump(p,0);c.External();
                Check(p.Delivery.CopyLatest(Start.AddSeconds(1)) && c.Text=="speech" && !p.Delivery.Paused,"explicit rescue");
            });
            Test("busy clipboard backs off even while new final snapshots arrive",()=>{
                var c=new FakeClipboard {Busy=2};var p=new RecordingPipeline(c);var r=p.Begin(Start);
                Receive(p,r.Session,"saved",true,0);Pump(p,0);
                Receive(p,r.Session,"saved more",true,10);Pump(p,10);Check(c.Attempts==1,"backoff not reset by input");
                Pump(p,201);Pump(p,402);Check(c.Text=="saved more" && !p.Delivery.Pending,"retry newest text");
            });
            Test("extended busy clipboard recovers automatically without losing records",()=>{
                var c=new FakeClipboard {Busy=12};var p=new RecordingPipeline(c);var r=p.Begin(Start);
                Receive(p,r.Session,"saved",true,0);Pump(p,0);
                for(int n=1;n<=9;n++)Pump(p,n*201);
                Check(p.Delivery.Failed && r.Text=="saved","ten failures retained");
                for(int n=1;n<=3;n++)Pump(p,1809+n*1001);
                Check(c.Text=="saved" && !p.Delivery.Failed && !p.Delivery.Pending,"automatic extended recovery");
            });
            Test("manual retry resets failed delivery without changing record",()=>{
                var c=new FakeClipboard {Busy=10};var p=new RecordingPipeline(c);var r=p.Begin(Start);
                Receive(p,r.Session,"saved",true,0);Pump(p,0);
                for(int n=1;n<10;n++)Pump(p,n*201);
                Check(p.Delivery.Failed,"failure state");
                Check(p.Delivery.CopyRecord(r.Session,Start.AddSeconds(2)) && c.Text=="saved" && !p.Delivery.Failed,"manual retry");
            });
            Test("input reentered during a copy remains pending rather than falsely published",()=>{
                var c=new FakeClipboard();var p=new RecordingPipeline(c);var r=p.Begin(Start);
                Receive(p,r.Session,"first",true,0);
                c.DuringWrite=()=>Receive(p,r.Session,"arrived during copy",true,1);
                Pump(p,0);Check(c.Text=="first" && r.Text=="arrived during copy" && p.Delivery.Pending,"exact published snapshot");
                Pump(p,80);Check(c.Text=="arrived during copy" && !p.Delivery.Pending,"later delivery");
            });
            Test("copying an old selected record does not mutate current reception",()=>{
                var c=new FakeClipboard();var p=new RecordingPipeline(c);var old=p.Begin(Start);
                Receive(p,old.Session,"older",true,0);Pump(p,0);p.End(old.Session);
                var current=p.Begin(Start.AddSeconds(1));Receive(p,current.Session,"current",false,1000);Pump(p,1000);
                Check(p.Delivery.CopyRecord(old.Session,Start.AddSeconds(2)) && c.Text=="older","old copied");
                Receive(p,current.Session,"current final",true,2100);Pump(p,2100);
                Check(c.Text=="older" && current.Text=="current final" && p.Delivery.Paused,"selected old protected");
                var next=p.Begin(Start.AddSeconds(3));Receive(p,next.Session,"next",true,3000);Pump(p,3000);
                Check(c.Text=="next","new recording resumes normal delivery");
            });
            Test("failed manual history copy retains all records",()=>{
                var c=new FakeClipboard();var p=new RecordingPipeline(c);var old=p.Begin(Start);
                Receive(p,old.Session,"older",true,0);var current=p.Begin(Start.AddSeconds(1));Receive(p,current.Session,"newer",true,1000);
                c.Busy=1;Check(!p.Delivery.CopyRecord(old.Session,Start.AddSeconds(2)),"expected busy");
                Check(old.Text=="older" && current.Text=="newer" && p.History.Entries.Count==2,"all retained");
            });
            Test("pause allows reception to retain text without automatic delivery",()=>{
                var c=new FakeClipboard();var p=new RecordingPipeline(c);var r=p.Begin(Start);p.Delivery.Pause();
                Receive(p,r.Session,"saved while paused",true,0);Pump(p,0);
                Check(c.Attempts==0 && r.Text=="saved while paused","pause separates source from copy");
            });
            Test("history notifications are coalesced outside reception",()=>{
                var p=new RecordingPipeline(new FakeClipboard());int changes=0;p.History.Changed+=()=>changes++;
                var r=p.Begin(Start);Receive(p,r.Session,"one",false,0);Receive(p,r.Session,"two",false,1);p.End(r.Session);
                Check(changes==0,"no inline UI");Pump(p,2);Check(changes==1,"one pump update");
                Receive(p,r.Session,"two",false,3);Pump(p,3);Check(changes==1,"duplicate quiet");
            });
            Test("live history refreshes without reopening and retains old selection",()=>{
                var p=new RecordingPipeline(new FakeClipboard());
                using(var form=new SpeechHistoryWindow(p.History,id=>p.Delivery.CopyRecord(id,Start))){
                    var box=(TextBox)form.Controls.Find("historyText",true)[0];
                    var tree=(TreeView)form.Controls.Find("historyTree",true)[0];var timeline=(HistoryTimeline)tree.Parent;Check(tree.Handle!=IntPtr.Zero,"hidden tree handle");
                    var follow=(CheckBox)form.Controls.Find("followLatest",true)[0];
                    var first=p.Begin(DateTime.Today.AddHours(12).ToUniversalTime());Receive(p,first.Session,"first",false,0);Pump(p,0);Check(box.Text=="first","live first");
                    Receive(p,first.Session,"first final",true,10);p.End(first.Session);Pump(p,10);
                    Check(box.Text=="first final" && p.History.Entries.Count==1,"same row");
                    var second=p.Begin(DateTime.Today.AddHours(12).ToUniversalTime().AddSeconds(1));Pump(p,1000);Check(box.Text=="" && p.History.Entries.Count==2,"new empty row is current");
                    Receive(p,second.Session,"second",true,1100);Pump(p,1100);Check(box.Text=="second","live second");
                    timeline.SelectRecord(first);Check(!follow.Checked && box.Text=="first final","manual selection");
                    var third=p.Begin(DateTime.Today.AddHours(12).ToUniversalTime().AddSeconds(2));Receive(p,third.Session,"third",true,2000);Pump(p,2000);
                    Check(box.Text=="first final" && p.History.Entries.Count==3,"keep old selection");
                    Receive(p,first.Session,"late first correction",true,2100);Pump(p,2100);
                    Check(box.Text=="late first correction" && p.History.Entries.Count==3,"old row updates in place");
                    follow.Checked=true;Check(box.Text=="third","resume following");
                }
            });
            Test("history copy button sends the selected identity, not latest text",()=>{
                var p=new RecordingPipeline(new FakeClipboard());var a=p.Begin(DateTime.Today.AddHours(12).ToUniversalTime());Receive(p,a.Session,"a",true,0);
                var b=p.Begin(DateTime.Today.AddHours(12).ToUniversalTime());Receive(p,b.Session,"b",true,0);int selected=0;
                using(var form=new SpeechHistoryWindow(p.History,id=>{selected=id;return true;})){
                    var tree=(TreeView)form.Controls.Find("historyTree",true)[0];var timeline=(HistoryTimeline)tree.Parent;Check(tree.Handle!=IntPtr.Zero,"hidden tree handle");timeline.SelectRecord(a);
                    var button=FindButton(form);Check(button!=null && button.Enabled,"copy available");
                    typeof(Button).GetMethod("OnClick",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).Invoke(button,new object[]{EventArgs.Empty});
                    Check(selected==a.Session,"selected id");
                }
            });
            Test("reopening history shares retained records and disposed windows unsubscribe",()=>{
                var p=new RecordingPipeline(new FakeClipboard());var a=p.Begin(DateTime.Today.AddHours(12).ToUniversalTime());Receive(p,a.Session,"saved",true,0);Pump(p,0);
                using(var form=new SpeechHistoryWindow(p.History,id=>true)){}
                var b=p.Begin(DateTime.Today.AddHours(12).ToUniversalTime());Receive(p,b.Session,"later",true,1);Pump(p,1);
                using(var form=new SpeechHistoryWindow(p.History,id=>true)){
                    Check(((TextBox)form.Controls.Find("historyText",true)[0]).Text=="later","latest");
                    Check(p.History.Entries.Count==2,"records shared");
                }
            });
            Test("real hidden receiver callbacks bind each control to its original recording",()=>{
                var c=new FakeClipboard();var p=new RecordingPipeline(c);var first=p.Begin(Start);
                using(var old=new ReceiverCapture(first,p,IntPtr.Zero)){
                    old.Input.Text="old native text";Check(first.Text=="old native text" && c.Attempts==0,"native callback only retains");
                    p.End(first.Session);var second=p.Begin(Start.AddSeconds(1));
                    using(var current=new ReceiverCapture(second,p,IntPtr.Zero)){
                        old.Input.Text="late old native text";current.Input.Text="current native text";
                        Check(first.Text=="late old native text" && second.Text=="current native text" && c.Attempts==0,"native identity isolation");
                        Check(!old.Window.Visible && !current.Window.Visible,"no visible test windows");
                    }
                    Check(second.Text=="current native text","disposing source preserves record");
                }
                Check(first.Text=="late old native text" && p.History.Entries.Count==2,"all records survive source disposal");
            });
            Test("IME snapshot replaces selected span and preserves suffix",()=>{
                var s=new CompositionSnapshot();s.Begin("abXXyz",2,2);
                Check(s.Update("new")=="abnewyz" && s.Commit("final")=="abfinalyz","selection");
                s.End();Check(!s.Active,"end");
            });
            Test("IME committed chunks and changing pending tail preserve full text",()=>{
                var s=new CompositionSnapshot();s.Begin("",0,0);s.Update("first");
                Check(s.Commit("one ")=="one ","first result");
                Check(s.Update("two long")=="one two long" && s.Update("two")=="one two","correction");
                Check(s.Commit("two")=="one two","next result");
            });
            Test("native incremental insertion never truncates saved full result",()=>{
                var g=new CommittedTextGuard();g.Expect("full result");
                Check(!g.NativeIsComplete("full"),"partial not final");
                for(int n=0;n<="full result".Length;n++)Check(g.IgnoreNativePrefix("full result".Substring(0,n)),"native prefix");
                Check(!g.IgnoreNativePrefix("correction") && g.NativeIsComplete("correction"),"later correction");
            });
            Console.WriteLine("RESULT "+passed+"/"+passed+" tests passed; model, hidden native receiver and history controls. No system clipboard, visible windows or focus used.");return 0;
        }catch(Exception e){Console.Error.WriteLine("FAIL "+e);return 1;}
    }
    static Button FindButton(Control root){
        foreach(Control child in root.Controls){var button=child as Button;if(button!=null && button.Name=="copySelected")return button;var nested=FindButton(child);if(nested!=null)return nested;}
        return null;
    }
}
