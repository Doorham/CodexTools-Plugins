using System;
using System.Runtime.InteropServices;

namespace WeTypeVoice2 {
    internal interface IClipboardSink {uint Sequence {get;} bool TryPut(string text,uint expected,out uint writtenSequence);}

    // A consumer of saved records. This never changes speech text or its session identity.
    internal sealed class ClipboardDelivery {
        readonly IClipboardSink clipboard;
        readonly SpeechHistory history;
        uint expectedSequence;
        int session,failures;
        string published="";
        DateTime nextWrite;
        bool paused;
        public bool Paused {get{return paused;}}
        public bool Failed {get{return failures>=10;}}
        public string LastError {get;private set;}
        public bool Pending {get{var r=history.Find(session);return r!=null && r.Text.Length>0 && r.Text!=published;}}
        public Action<string,int,int> Report {get;set;}
        public ClipboardDelivery(IClipboardSink sink,SpeechHistory records){clipboard=sink;history=records;LastError="";}
        public void Begin(int id,DateTime now){
            if(Pending)history.SetCopyState(session,"留在历史，待手动复制");
            session=id;published="";failures=0;paused=false;LastError="";nextWrite=now;expectedSequence=clipboard.Sequence;
        }
        public void Pause(){paused=true;if(Pending)history.SetCopyState(session,"自动复制已暂停");}
        public void Tick(DateTime now){
            var record=history.Find(session);
            if(record==null || !Pending || paused)return;
            if(clipboard.Sequence!=expectedSequence){Pause();Emit("external_copy_pause",record);return;}
            if(now<nextWrite && (failures>0 || !record.HasFinal))return;
            try {
                uint written;string snapshot=record.Text;
                if(!clipboard.TryPut(snapshot,expectedSequence,out written)){Pause();Emit("external_copy_pause",record);return;}
                published=snapshot;expectedSequence=written;failures=0;LastError="";nextWrite=now.AddMilliseconds(300);
                history.SetCopyState(session,Pending?"待复制":"已复制到本机");
                if(Report!=null)Report("copied_local",record.Session,snapshot.Length);
            }catch(ExternalException e){
                LastError=e.Message;failures++;nextWrite=now.AddMilliseconds(failures>=10?1000:200);
                history.SetCopyState(session,"等待剪贴板释放");
                if(failures==1 || failures==10)Emit(failures==1?"copy_retry_pending":"copy_failed_retained",record);
            }
        }
        public bool CopyRecord(int id,DateTime now){
            var record=history.Find(id);if(record==null || record.Text.Length==0)return false;
            if(id==session){paused=false;failures=0;published="";expectedSequence=clipboard.Sequence;nextWrite=now;Tick(now);return !Pending;}
            Pause();
            try {
                uint written;bool ok=clipboard.TryPut(record.Text,clipboard.Sequence,out written);
                history.SetCopyState(id,ok?"已手动复制":"复制失败，文字保留");Emit(ok?"history_copied_local":"history_copy_failed",record);return ok;
            }catch(ExternalException e){LastError=e.Message;history.SetCopyState(id,"复制失败，文字保留");Emit("history_copy_failed",record);return false;}
        }
        public bool CopyLatest(DateTime now){foreach(var r in history.Entries)if(r.Characters>0)return CopyRecord(r.Session,now);var latest=history.LatestWithText;return latest!=null && latest.Characters>0 && CopyRecord(latest.Session,now);}
        void Emit(string kind,SpeechRecord record){if(Report!=null)Report(kind,record.Session,record.Text.Length);}
    }
}
