using System;
using System.Collections.Generic;
using System.Globalization;
namespace WeTypeVoice2 {
    internal sealed class HistoryGroup {
        public string Key,Label,Kind;
        public long Count;
        public readonly List<HistoryGroup> Children=new List<HistoryGroup>();
    }
    internal static class HistoryGrouping {
        public static List<HistoryGroup> Build(IEnumerable<HistoryDay> days,DateTime today){
            var roots=new List<HistoryGroup>();var map=new Dictionary<string,HistoryGroup>();
            string currentYear=today.ToString("yyyy"),currentMonth=today.ToString("yyyy-MM"),currentDay=today.ToString("yyyy-MM-dd");
            foreach(var item in days){
                DateTime date;if(!DateTime.TryParseExact(item.Day,"yyyy-MM-dd",CultureInfo.InvariantCulture,DateTimeStyles.None,out date))continue;
                string year=item.Day.Substring(0,4),month=item.Day.Substring(0,7);
                HistoryGroup parent=null;
                if(string.CompareOrdinal(year,currentYear)<0){
                    if(!map.TryGetValue(year,out parent)){parent=new HistoryGroup {Key=year,Label=year+"年",Kind="year"};map.Add(year,parent);roots.Add(parent);}parent.Count+=item.Count;
                }
                if(string.CompareOrdinal(month,currentMonth)<0){
                    HistoryGroup group;
                    if(!map.TryGetValue(month,out group)){group=new HistoryGroup {Key=month,Label=year+"年"+date.Month+"月",Kind="month"};map.Add(month,group);if(parent==null)roots.Add(group);else parent.Children.Add(group);}
                    group.Count+=item.Count;parent=group;
                }
                var day=new HistoryGroup {Key=item.Day,Label=(item.Day==currentDay?"今天 · ":"")+date.ToString("yyyy年M月d日"),Kind="day",Count=item.Count};
                if(parent==null)roots.Add(day);else parent.Children.Add(day);
            }
            Sort(roots);return roots;
        }
        static void Sort(List<HistoryGroup> groups){groups.Sort((a,b)=>string.CompareOrdinal(b.Key,a.Key));foreach(var g in groups)Sort(g.Children);}
    }
}
