using System;
using System.Runtime.InteropServices;
namespace WeTypeVoice2 {
    internal static class VoiceMouseTarget {
        [StructLayout(LayoutKind.Sequential)]internal struct Point {public int X,Y;}
        [StructLayout(LayoutKind.Sequential)]struct Rect {public int Left,Top,Right,Bottom;}
        [DllImport("user32.dll")]static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
        [DllImport("user32.dll")]static extern IntPtr GetThreadDpiAwarenessContext();
        [DllImport("user32.dll")]static extern int GetAwarenessFromDpiAwarenessContext(IntPtr context);
        [DllImport("user32.dll")]static extern IntPtr WindowFromPoint(Point point);
        [DllImport("user32.dll")]static extern IntPtr GetAncestor(IntPtr window,uint kind);
        [DllImport("user32.dll")]static extern bool IsWindowVisible(IntPtr window);
        [DllImport("user32.dll")]static extern bool GetClientRect(IntPtr window,out Rect rect);
        [DllImport("user32.dll")]static extern bool ClientToScreen(IntPtr window,ref Point point);
        // MSLLHOOKSTRUCT supplies per-monitor-aware screen coordinates. Windows can enter the
        // hook callback with a different context than the one set when its thread was started.
        // Scope every hit test and restore before calling any downstream hook or application code.
        public static bool Contains(IntPtr voice,Point screen,out int before,out int during){
            before=GetAwarenessFromDpiAwarenessContext(GetThreadDpiAwarenessContext());during=-1;
            IntPtr previous=SetThreadDpiAwarenessContext(new IntPtr(-4));
            if(previous==IntPtr.Zero)return false;
            try{
                during=GetAwarenessFromDpiAwarenessContext(GetThreadDpiAwarenessContext());
                if(voice==IntPtr.Zero||!IsWindowVisible(voice)||GetAncestor(WindowFromPoint(screen),2)!=voice)return false;
                Rect rect;if(!GetClientRect(voice,out rect))return false;
                var first=new Point{X=rect.Left,Y=rect.Top};var last=new Point{X=rect.Right,Y=rect.Bottom};
                if(!ClientToScreen(voice,ref first)||!ClientToScreen(voice,ref last))return false;
                return screen.X>=first.X&&screen.X<last.X&&screen.Y>=first.Y&&screen.Y<last.Y;
            }finally{SetThreadDpiAwarenessContext(previous);}
        }
    }
}
