using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using WeTypeVoice2;

internal static class HistoryArchiveTests {
    static int passed;
    static string root;
    static readonly DateTime Today=DateTime.Today.AddHours(12).ToUniversalTime();
    static void Check(bool value,string why){if(!value)throw new Exception(why);}
    static void Test(string name,Action action){action();passed++;Console.WriteLine("PASS "+name);}
    static string Db(){return Path.Combine(root,Guid.NewGuid().ToString("N")+".sqlite3");}
    static SpeechRecord Record(int id,DateTime start,string body){return new SpeechRecord{Id=id.ToString("D8"),Session=id,Started=start,LastChange=start,Text=body,Ended=true,HasFinal=true,Revision=1};}
    static string Sample(){return new string('文',20000)+"\r\n完整尾部🙂\0内嵌零字符之后";}
    [STAThread] static int Main(string[] args){
        Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
        if(args.Length==2&&args[0]=="--committed-child"){
            var store=new HistoryArchive(args[1]);store.Save(new[]{Record(1,Today,Sample())});
            Process.GetCurrentProcess().Kill();return 9;
        }
        try{
            root=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"history-tests",Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);
            Test("receive has no disk work and a pump durably saves exact long Unicode",()=>{
                string file=Db();
                using(var store=new HistoryArchive(file)){
                    var p=new RecordingPipeline(new FakeClipboard(),store);var r=p.Begin(Today);
                    p.Receive(r.Session,Sample(),true,"ime_result",Today);
                    Check(store.Latest()==null,"native reception cannot write files");
                    p.End(r.Session);p.Pump(Today);
                    Check(r.Persisted&&!p.History.HasUnsaved,"committed state");
                }
                using(var store=new HistoryArchive(file))Check(store.Body(store.Latest().Id)==Sample(),"exact persisted body including NUL and tail");
            });
            Test("corrections replace the same recording without losing its start or duplicating rows",()=>{
                using(var store=new HistoryArchive(Db())){
                    var p=new RecordingPipeline(new FakeClipboard(),store);var r=p.Begin(Today);
                    p.Receive(r.Session,"a long pending result",false,"ime_composition",Today);p.Pump(Today);
                    p.Receive(r.Session,"corrected",true,"ime_result",Today.AddSeconds(1));p.End(r.Session);p.Pump(Today.AddSeconds(1));
                    var header=store.Latest();Check(store.Days().Sum(d=>d.Count)==1&&header.Started==Today&&header.Final&&header.Ended&&header.Revision==2,"stable row metadata");
                    Check(store.Body(r.Id)=="corrected","latest snapshot replaces prefix");
                }
            });
            Test("failed batch rolls back every change instead of saving a partial history",()=>{
                using(var store=new HistoryArchive(Db())){
                    var old=Record(1,Today,"before");store.Save(new[]{old});old.Text="after";
                    bool failed=false;try{store.Save(new SpeechRecord[]{old,Record(2,Today,"new"),null});}catch(NullReferenceException){failed=true;}
                    Check(failed&&store.Body(old.Id)=="before"&&store.Days().Sum(d=>d.Count)==1,"whole batch rollback");
                }
            });
            Test("reopen loads history without overwriting clipboard and copies the selected saved identity",()=>{
                string file=Db();using(var store=new HistoryArchive(file))store.Save(new[]{Record(1,Today,"older saved"),Record(2,Today.AddSeconds(1),"")});
                using(var store=new HistoryArchive(file)){
                    var clip=new FakeClipboard();clip.External();var p=new RecordingPipeline(clip,store);p.Pump(Today);
                    Check(clip.Text=="external"&&clip.Writes==0&&p.History.Current==null,"no implicit clipboard delivery on startup");
                    var saved=p.History.Restore(store.DayPage(Today.ToLocalTime().ToString("yyyy-MM-dd"),long.MaxValue,"~",100)[1]);
                    Check(saved.LoadBody!=null&&saved.Session<0,"lazy saved identity");
                    Check(p.Delivery.CopyRecord(saved.Session,Today)&&clip.Text=="older saved","selected old row copied");
                    var empty=p.Begin(Today.AddSeconds(2));p.End(empty.Session);p.Pump(Today);
                    Check(p.Delivery.CopyLatest(Today)&&clip.Text=="older saved","new empty recording still permits most recent nonempty archive rescue");
                }
            });
            Test("write failure retains new text and reports unsaved status in the main history",()=>{
                var store=new HistoryArchive(Db());var p=new RecordingPipeline(new FakeClipboard(),store);store.Dispose();
                var r=p.Begin(Today);p.Receive(r.Session,"still here",true,"ime_result",Today);p.End(r.Session);p.Pump(Today);
                Check(p.History.HasUnsaved&&!r.Persisted&&r.Text=="still here"&&!string.IsNullOrEmpty(p.History.StorageError),"no false saved acknowledgement");
                using(var form=new SpeechHistoryWindow(p.History,id=>true)){
                    Check(((TextBox)form.Controls.Find("historyText",true)[0]).Text=="still here","current text visible even if disk cannot be read");
                    var tree=(TreeView)form.Controls.Find("historyTree",true)[0];Check(tree.Nodes.Count==1,"current history remains accessible");
                }
            });
            Test("corrupt database is not deleted or silently recreated",()=>{
                string file=Db();byte[] bytes=System.Text.Encoding.UTF8.GetBytes("synthetic invalid sqlite file");File.WriteAllBytes(file,bytes);
                bool failed=false;try{using(var ignored=new HistoryArchive(file)){} }catch(IOException){failed=true;}
                Check(failed&&File.ReadAllBytes(file).SequenceEqual(bytes),"original invalid file preserved");
            });
            Test("keyset pages with tied timestamps return each recording exactly once",()=>{
                using(var store=new HistoryArchive(Db())){
                    var records=Enumerable.Range(1,305).Select(id=>Record(id,Today,"sample "+id)).ToArray();store.Save(records);
                    var found=new List<string>();long before=long.MaxValue;string key="~";List<HistoryHeader> page;
                    do{page=store.DayPage(records[0].Day,before,key,100);found.AddRange(page.Select(h=>h.Id));if(page.Count>0){before=page.Last().Started.Ticks;key=page.Last().Id;}}while(page.Count==100);
                    Check(found.Count==305&&found.Distinct().Count()==305&&found[0]=="00000305"&&found.Last()=="00000001","no skips or duplicates at page boundaries");
                }
            });
            Test("calendar groups expose days in this month months in this year and older years",()=>{
                var today=new DateTime(2026,11,2);
                var days=new[]{"2026-11-02","2026-11-01","2026-10-31","2026-10-01","2026-01-01","2025-12-31","1900-01-01"}.Select(d=>new HistoryDay{Day=d,Count=1});
                var groups=HistoryGrouping.Build(days,today);
                Check(string.Join(",",groups.Select(g=>g.Key))=="2026-11-02,2026-11-01,2026-10,2026-01,2025,1900","calendar boundaries");
                Check(groups[2].Count==2&&groups[2].Children.Count==2&&groups[4].Children[0].Key=="2025-12","hierarchy and counts");
                Check(groups.All(g=>g.Key!="2026"&&g.Key!="2026-11"),"current year/month cannot be folded");
            });
            Test("year rollover automatically moves previous December under previous year",()=>{
                var groups=HistoryGrouping.Build(new[]{new HistoryDay{Day="2026-12-31",Count=2},new HistoryDay{Day="2027-01-01",Count=1}},new DateTime(2027,1,1));
                Check(groups[0].Kind=="day"&&groups[1].Key=="2026"&&groups[1].Children[0].Key=="2026-12","year boundary");
            });
            Test("today expands by default and an explicit collapse survives new recordings",()=>{
                using(var store=new HistoryArchive(Db())){
                    store.Save(new[]{Record(1,Today.AddYears(-2),"old"),Record(2,Today,"today")});
                    var p=new RecordingPipeline(new FakeClipboard(),store);
                    using(var form=new SpeechHistoryWindow(p.History,id=>true)){
                        var tree=(TreeView)form.Controls.Find("historyTree",true)[0];Check(tree.Handle!=IntPtr.Zero,"hidden control handle");
                        var today=tree.Nodes[0];Check(today.IsExpanded&&!tree.Nodes[1].IsExpanded,"correct defaults");
                        today.Collapse();var r=p.Begin(Today.AddSeconds(1));p.Receive(r.Session,"new",true,"ime_result",Today);p.End(r.Session);p.Pump(Today);
                        Check(!tree.Nodes[0].IsExpanded,"user collapse kept");Check(((TextBox)form.Controls.Find("historyText",true)[0]).Text=="new","live detail still updates");
                    }
                }
            });
            Test("old-only history remains folded while latest text is available in the main window",()=>{
                using(var store=new HistoryArchive(Db())){
                    store.Save(new[]{Record(1,Today.AddYears(-2),"past full text")});var p=new RecordingPipeline(new FakeClipboard(),store);
                    using(var form=new SpeechHistoryWindow(p.History,id=>true)){
                        var tree=(TreeView)form.Controls.Find("historyTree",true)[0];Check(!tree.Nodes[0].IsExpanded,"no forced unfold of old year");
                        Check(((TextBox)form.Controls.Find("historyText",true)[0]).Text=="past full text","latest full text accessible");
                    }
                }
            });
            Test("history tree loads additional pages and keeps an older selected record as new speech arrives",()=>{
                using(var store=new HistoryArchive(Db())){
                    store.Save(Enumerable.Range(1,205).Select(id=>Record(id,Today.AddSeconds(id),"record "+id)).ToArray());
                    var p=new RecordingPipeline(new FakeClipboard(),store);
                    using(var form=new SpeechHistoryWindow(p.History,id=>true)){
                        var tree=(TreeView)form.Controls.Find("historyTree",true)[0];Check(tree.Handle!=IntPtr.Zero,"hidden handle");var day=tree.Nodes[0];
                        Check(day.Nodes.Count==101,"first page and continuation");
                        tree.SelectedNode=day.Nodes[day.Nodes.Count-1];Check(day.Nodes.Count==201,"second page");
                        tree.SelectedNode=day.Nodes[day.Nodes.Count-1];Check(day.Nodes.Count==205,"last page");
                        tree.SelectedNode=day.Nodes[180];string text=((TextBox)form.Controls.Find("historyText",true)[0]).Text;
                        var r=p.Begin(Today.AddMinutes(10));p.Receive(r.Session,"new recording",true,"ime_result",Today);p.End(r.Session);p.Pump(Today);
                        Check(((TextBox)form.Controls.Find("historyText",true)[0]).Text==text,"older detail is not displaced");
                        Check(tree.SelectedNode!=null&&((SpeechRecord)tree.SelectedNode.Tag).Text==text&&tree.Nodes[0].Nodes.Count==206,"loaded pages and selection survive live insertion");
                    }
                }
            });
            Test("committed text survives process termination without normal dispose",()=>{
                string file=Db();var start=new ProcessStartInfo(Application.ExecutablePath,"--committed-child \""+file+"\""){UseShellExecute=false,CreateNoWindow=true,WindowStyle=ProcessWindowStyle.Hidden};
                using(var child=Process.Start(start)){Check(child.WaitForExit(8000),"child termination timeout");}
                using(var store=new HistoryArchive(file))Check(store.Body(store.Latest().Id)==Sample(),"recover committed WAL after abrupt termination");
            });
            Console.WriteLine("RESULT "+passed+"/"+passed+" history tests passed; synthetic local files only.");return 0;
        }catch(Exception e){Console.Error.WriteLine("FAIL "+e);return 1;}
    }
}
