using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace WeTypeVoice2 {
    internal sealed class EndRequest {
        public readonly VoiceChord Chord;
        public readonly IntPtr Target;
        public readonly int VoiceGeneration;
        public readonly bool Mouse;
        internal bool Released,FocusReady,ReplayPosted,Cancelled;
        public EndRequest(VoiceChord chord,IntPtr target,int generation,bool mouse=false){Chord=chord;Target=target;VoiceGeneration=generation;Mouse=mouse;}
    }
    // Pure key/session state. It neither takes focus nor sends input. Callers serialize access.
    internal sealed class EndShortcutState {
        readonly bool[] down=new bool[256];
        VoiceHotkeySettings settings;
        bool voiceVisible;
        int generation;
        EndRequest pending;
        int swallowedKey;bool swallowedLeft;
        public EndShortcutState(VoiceHotkeySettings value){settings=value;}
        public EndRequest Pending {get{return pending;}}
        public int Generation {get{return generation;}}
        public bool VoiceVisible {get{return voiceVisible;}}
        public bool CanUnhook {get{return !voiceVisible && pending==null && swallowedKey==0 && !swallowedLeft;}}
        public bool IsConfiguredKey(int key){return settings!=null && (key==settings.HandsFree.Trigger || key==settings.Hold.Trigger);}
        public int ModifierMask {get{int mask=0,index=0;foreach(int key in new[]{162,163,164,165,160,161,91,92}){if(down[key])mask|=1<<index;index++;}return mask;}}
        public void Seed(int key,bool pressed){if(key>=0 && key<256)down[key]=pressed;}
        public void Settings(VoiceHotkeySettings value){settings=value;}
        public void ObserveVoice(bool visible){
            if(visible && !voiceVisible)generation++;
            voiceVisible=visible;
        }
        bool Pressed(int key){
            if(key==16)return down[160]||down[161];if(key==17)return down[162]||down[163];if(key==18)return down[164]||down[165];return down[key];
        }
        bool Matches(VoiceChord chord,int key){
            if(chord==null || chord.Trigger!=key)return false;
            foreach(int required in chord.Keys)if(!Pressed(required))return false;
            foreach(int modifier in new[]{160,161,162,163,164,165,91,92}){
                if(!Pressed(modifier))continue;bool allowed=false;
                foreach(int required in chord.Keys)if(required==modifier || (required==16 && (modifier==160||modifier==161)) || (required==17 && (modifier==162||modifier==163)) || (required==18 && (modifier==164||modifier==165)))allowed=true;
                if(!allowed)return false;
            }return true;
        }
        public bool Key(int key,bool pressed,bool remote,IntPtr target,out EndRequest acquire,out EndRequest replay){
            acquire=null;replay=null;if(key<0 || key>=256)return false;
            bool repeated=down[key];if(pressed)down[key]=true;
            bool consume=false;
            if(key==swallowedKey){
                consume=true;
                if(!pressed){swallowedKey=0;if(pending!=null&&!pending.Mouse){pending.Released=true;replay=Ready();}}
            }else if(settings!=null && pending!=null && pressed && !repeated && Matches(settings.HandsFree,key)){
                swallowedKey=key;consume=true;
            }else if(settings!=null && pending==null){
                if(pressed && !repeated && Matches(settings.HandsFree,key)){
                    if(voiceVisible && remote){pending=new EndRequest(settings.HandsFree,target,generation);swallowedKey=key;acquire=pending;consume=true;}
                }
            }
            if(!pressed)down[key]=false;
            return consume;
        }
        public bool MouseButton(bool pressed,bool onVoice,bool remote,IntPtr target,out EndRequest acquire,out EndRequest replay){
            acquire=null;replay=null;
            if(swallowedLeft){
                if(!pressed){swallowedLeft=false;if(pending!=null&&pending.Mouse){pending.Released=true;replay=Ready();}}
                return true;
            }
            if(pressed&&onVoice&&voiceVisible&&pending!=null){swallowedLeft=true;return true;}
            if(pressed&&onVoice&&remote&&voiceVisible&&settings!=null&&pending==null){
                pending=new EndRequest(settings.HandsFree,target,generation,true);swallowedLeft=true;acquire=pending;return true;
            }
            return false;
        }
        EndRequest Ready(){if(pending==null || pending.Cancelled || !pending.Released || !pending.FocusReady || pending.ReplayPosted)return null;pending.ReplayPosted=true;return pending;}
        public EndRequest Acquired(EndRequest request){if(pending!=request || request.Cancelled)return null;request.FocusReady=true;return Ready();}
        public bool Current(EndRequest request){return settings!=null && pending==request && !request.Cancelled && voiceVisible && request.VoiceGeneration==generation && request.Chord.Label==settings.HandsFree.Label;}
        public void Complete(EndRequest request){if(pending==request)pending=null;}
        public void Cancel(EndRequest request){request.Cancelled=true;if(pending==request)pending=null;}
    }
    internal static class VoiceKeyInput {
        internal const uint Marker=0x57455432;
        [StructLayout(LayoutKind.Sequential)] internal struct Keyboard {public ushort Key,Scan;public uint Flags,Time;public UIntPtr Extra;}
        [StructLayout(LayoutKind.Sequential)] struct Mouse {public int X,Y;public uint Data,Flags,Time;public UIntPtr Extra;}
        [StructLayout(LayoutKind.Explicit)] struct Union {[FieldOffset(0)] public Keyboard Keyboard;[FieldOffset(0)] public Mouse Mouse;}
        [StructLayout(LayoutKind.Sequential)] struct Input {public uint Type;public Union Data;}
        [DllImport("user32.dll",SetLastError=true)] static extern uint SendInput(uint count,Input[] inputs,int size);
        [DllImport("user32.dll")] internal static extern short GetAsyncKeyState(int key);
        static Input Make(int key,bool up){return new Input{Type=1,Data=new Union{Keyboard=new Keyboard{Key=(ushort)key,Flags=(up?2u:0u)|((key==163||key==165||key==91||key==92)?1u:0u),Extra=new UIntPtr(Marker)}}};}
        public static bool Replay(EndRequest request){
            var batch=new List<Input>();var added=new List<int>();
            for(int n=0;n<request.Chord.Keys.Length-1;n++){
                int key=request.Chord.Keys[n];if((GetAsyncKeyState(key)&0x8000)!=0)continue;
                batch.Add(Make(key,false));added.Add(key);
            }
            batch.Add(Make(request.Chord.Trigger,false));
            batch.Add(Make(request.Chord.Trigger,true));
            for(int n=added.Count-1;n>=0;n--)batch.Add(Make(added[n],true));
            return SendInput((uint)batch.Count,batch.ToArray(),Marshal.SizeOf(typeof(Input)))==batch.Count;
        }
    }
    internal sealed class GateObservation {
        public readonly string Kind;
        public readonly object Data;
        public GateObservation(string kind,object data){Kind=kind;Data=data;}
    }
    internal sealed class EndShortcutGate : IDisposable {
        delegate IntPtr KeyboardProc(int code,IntPtr message,IntPtr data);
        [StructLayout(LayoutKind.Sequential)] struct MouseData {public VoiceMouseTarget.Point Position;public uint MouseInfo,Flags,Time;public UIntPtr Extra;}
        [StructLayout(LayoutKind.Sequential)] struct KeyData {public uint Key,Scan,Flags,Time;public UIntPtr Extra;}
        [DllImport("user32.dll",SetLastError=true)] static extern IntPtr SetWindowsHookEx(int kind,KeyboardProc proc,IntPtr module,uint thread);
        [DllImport("user32.dll")] static extern bool UnhookWindowsHookEx(IntPtr hook);
        [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr hook,int code,IntPtr message,IntPtr data);
        [DllImport("user32.dll")] static extern bool PostThreadMessage(uint thread,uint message,IntPtr w,IntPtr l);
        [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] static extern IntPtr GetModuleHandle(string name);
        readonly object sync=new object();
        readonly EndShortcutState state;
        readonly Thread thread;
        readonly Action<EndRequest> acquire,replay;
        readonly ManualResetEvent ready=new ManualResetEvent(false);
        readonly KeyboardProc callback,mouseCallback;
        IntPtr hook,mouseHook,voiceWindow;uint threadId;
        Control dispatcher;
        Exception startupError;
        uint[] remotePids=new uint[0];
        readonly System.Collections.Concurrent.ConcurrentQueue<GateObservation> observations=new System.Collections.Concurrent.ConcurrentQueue<GateObservation>();
        public bool Observation(out GateObservation value){return observations.TryDequeue(out value);}
        public EndShortcutGate(VoiceHotkeySettings settings,Action<EndRequest> onAcquire,Action<EndRequest> onReplay){
            state=new EndShortcutState(settings);acquire=onAcquire;replay=onReplay;callback=Key;mouseCallback=Mouse;
            thread=new Thread(Run){IsBackground=true,Name="WeType end shortcut"};thread.SetApartmentState(ApartmentState.STA);thread.Start();
            ready.WaitOne();if(startupError!=null)throw startupError;
        }
        void Run(){
            try{
                threadId=Native.GetCurrentThreadId();
                // Force this thread's message queue to exist before allowing Dispose/PostThreadMessage.
                using(var messageWindow=new Control()){
                    var unused=messageWindow.Handle;
                    dispatcher=messageWindow;
                    ready.Set();Application.Run();
                }
            }catch(Exception e){startupError=e;ready.Set();}finally{if(hook!=IntPtr.Zero)UnhookWindowsHookEx(hook);if(mouseHook!=IntPtr.Zero)UnhookWindowsHookEx(mouseHook);}
        }
        void ScheduleReconcile(){try{dispatcher.BeginInvoke((MethodInvoker)ReconcileHook);}catch(InvalidOperationException){}}
        void ReconcileHook(){
            lock(sync){
                if(state.VoiceVisible && hook==IntPtr.Zero){
                    // A recording owns its observer. Do not compete for hook order during the recording.
                    for(int key=0;key<256;key++)state.Seed(key,(VoiceKeyInput.GetAsyncKeyState(key)&0x8000)!=0);
                    hook=SetWindowsHookEx(13,callback,GetModuleHandle(null),0);
                    mouseHook=SetWindowsHookEx(14,mouseCallback,GetModuleHandle(null),0);
                    observations.Enqueue(new GateObservation("end_hook_opened",new {generation=state.Generation,installed=hook!=IntPtr.Zero,mouseInstalled=mouseHook!=IntPtr.Zero,error=hook==IntPtr.Zero||mouseHook==IntPtr.Zero?Marshal.GetLastWin32Error():0}));
                }else if(state.CanUnhook && (hook!=IntPtr.Zero||mouseHook!=IntPtr.Zero)){
                    bool removed=hook==IntPtr.Zero||UnhookWindowsHookEx(hook);hook=IntPtr.Zero;
                    bool mouseRemoved=mouseHook==IntPtr.Zero||UnhookWindowsHookEx(mouseHook);mouseHook=IntPtr.Zero;
                    observations.Enqueue(new GateObservation("end_hook_closed",new {generation=state.Generation,removed=removed,mouseRemoved=mouseRemoved}));
                }
            }
        }
        public void Observe(bool voiceVisible,uint[] targets){Observe(voiceVisible,targets,IntPtr.Zero);}
        public void Observe(bool voiceVisible,uint[] targets,IntPtr voice){bool changed;lock(sync){changed=voiceVisible!=state.VoiceVisible;state.ObserveVoice(voiceVisible);remotePids=targets;voiceWindow=voice;}if(changed)ScheduleReconcile();}
        public void Settings(VoiceHotkeySettings settings){lock(sync)state.Settings(settings);}
        public bool Current(EndRequest request){lock(sync)return state.Current(request);}
        public void Acquired(EndRequest request){EndRequest next;lock(sync)next=state.Acquired(request);if(next!=null)replay(next);}
        public void Complete(EndRequest request){lock(sync)state.Complete(request);ScheduleReconcile();}
        public void Cancel(EndRequest request){lock(sync)state.Cancel(request);ScheduleReconcile();}
        IntPtr Mouse(int code,IntPtr message,IntPtr data){
            int m=message.ToInt32();bool down=m==0x201,up=m==0x202;
            if(code>=0&&(down||up)){
                var mouse=(MouseData)Marshal.PtrToStructure(data,typeof(MouseData));
                IntPtr foreground=Native.GetForegroundWindow();uint pid;Native.GetWindowThreadProcessId(foreground,out pid);
                EndRequest request,next;bool consume;
                lock(sync){
                    int dpiBefore=-1,dpiDuring=-1;
                    bool onVoice=down&&VoiceMouseTarget.Contains(voiceWindow,mouse.Position,out dpiBefore,out dpiDuring),remote=Array.IndexOf(remotePids,pid)>=0;
                    consume=state.MouseButton(down,onVoice,remote,foreground,out request,out next);
                    if(onVoice||consume)observations.Enqueue(new GateObservation("mouse_end_observed",new {down=down,onVoice=onVoice,remote=remote,consumed=consume,generation=state.Generation,dpiBefore=dpiBefore,dpiDuring=dpiDuring}));
                }
                if(request!=null)acquire(request);if(next!=null)replay(next);
                if(consume){if(up)ScheduleReconcile();return new IntPtr(1);}
            }
            return CallNextHookEx(mouseHook,code,message,data);
        }
        IntPtr Key(int code,IntPtr message,IntPtr data){
            if(code>=0){
                var key=(KeyData)Marshal.PtrToStructure(data,typeof(KeyData));
                if(key.Extra.ToUInt64()!=VoiceKeyInput.Marker){
                    int m=message.ToInt32();bool down=m==0x100||m==0x104;bool up=m==0x101||m==0x105;
                    if(down||up){
                        IntPtr foreground=Native.GetForegroundWindow();uint pid;Native.GetWindowThreadProcessId(foreground,out pid);
                        EndRequest request,next;bool consume;
                        lock(sync){
                            bool remote=Array.IndexOf(remotePids,pid)>=0;bool relevant=state.IsConfiguredKey((int)key.Key);
                            consume=state.Key((int)key.Key,down,remote,foreground,out request,out next);
                            if(relevant)observations.Enqueue(new GateObservation("shortcut_observed",new {time=DateTimeOffset.Now.ToString("o"),key=key.Key,down=down,injected=(key.Flags&16)!=0,visible=state.VoiceVisible,modifiers=state.ModifierMask,foreground=foreground.ToInt64(),pid=pid,remote=remote,consumed=consume}));
                        }
                        if(request!=null)acquire(request);if(next!=null)replay(next);
                        if(consume){if(up)ScheduleReconcile();return new IntPtr(1);}
                    }
                }
            }return CallNextHookEx(hook,code,message,data);
        }
        public void Dispose(){PostThreadMessage(threadId,0x12,IntPtr.Zero,IntPtr.Zero);thread.Join(1000);ready.Dispose();}
    }
}
