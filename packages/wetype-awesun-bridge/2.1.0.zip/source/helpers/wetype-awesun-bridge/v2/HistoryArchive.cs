using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
namespace WeTypeVoice2 {
    internal sealed class HistoryHeader {
        public string Id,Day,Preview;
        public DateTime Started;
        public int Characters,Revision;
        public bool Final,Ended;
    }
    internal sealed class HistoryDay {
        public string Day;public long Count;
    }
    // Local user data only. Never include this database or its journal files in a package or diagnostics.
    internal sealed class HistoryArchive : IDisposable {
        IntPtr db;readonly object sync=new object();
        static class Sql {
            const string Dll="winsqlite3.dll";
            [DllImport(Dll,CallingConvention=CallingConvention.Cdecl,CharSet=CharSet.Unicode,ExactSpelling=true)]internal static extern int sqlite3_open16(string path,out IntPtr db);
            [DllImport(Dll,CallingConvention=CallingConvention.Cdecl)]internal static extern int sqlite3_close(IntPtr db);
            [DllImport(Dll,CallingConvention=CallingConvention.Cdecl,CharSet=CharSet.Unicode,ExactSpelling=true)]internal static extern int sqlite3_prepare16_v2(IntPtr db,string sql,int size,out IntPtr stmt,IntPtr tail);
            [DllImport(Dll,CallingConvention=CallingConvention.Cdecl)]internal static extern int sqlite3_step(IntPtr stmt);
            [DllImport(Dll,CallingConvention=CallingConvention.Cdecl)]internal static extern int sqlite3_finalize(IntPtr stmt);
            [DllImport(Dll,CallingConvention=CallingConvention.Cdecl,CharSet=CharSet.Unicode,ExactSpelling=true)]internal static extern int sqlite3_bind_text16(IntPtr stmt,int n,string value,int bytes,IntPtr destroy);
            [DllImport(Dll,CallingConvention=CallingConvention.Cdecl)]internal static extern int sqlite3_bind_int64(IntPtr stmt,int n,long value);
            [DllImport(Dll,CallingConvention=CallingConvention.Cdecl)]internal static extern IntPtr sqlite3_column_text16(IntPtr stmt,int column);
            [DllImport(Dll,CallingConvention=CallingConvention.Cdecl)]internal static extern int sqlite3_column_bytes16(IntPtr stmt,int column);
            [DllImport(Dll,CallingConvention=CallingConvention.Cdecl)]internal static extern long sqlite3_column_int64(IntPtr stmt,int column);
            [DllImport(Dll,CallingConvention=CallingConvention.Cdecl)]internal static extern int sqlite3_busy_timeout(IntPtr db,int ms);
        }
        sealed class Statement : IDisposable {
            public IntPtr Handle;
            public Statement(IntPtr database,string sql,object[] values){
                Check(Sql.sqlite3_prepare16_v2(database,sql,-1,out Handle,IntPtr.Zero));
                try {for(int n=0;n<values.Length;n++){
                    string text=values[n] as string;
                    Check(text!=null?Sql.sqlite3_bind_text16(Handle,n+1,text,text.Length*2,new IntPtr(-1)):Sql.sqlite3_bind_int64(Handle,n+1,Convert.ToInt64(values[n],CultureInfo.InvariantCulture)));
                }}catch{Dispose();throw;}
            }
            public bool Next(){int code=Sql.sqlite3_step(Handle);if(code==100)return true;if(code==101)return false;Check(code);return false;}
            public long Number(int col){return Sql.sqlite3_column_int64(Handle,col);}
            public string Text(int col){var p=Sql.sqlite3_column_text16(Handle,col);return p==IntPtr.Zero?"":Marshal.PtrToStringUni(p,Sql.sqlite3_column_bytes16(Handle,col)/2);}
            public void Dispose(){if(Handle!=IntPtr.Zero){Sql.sqlite3_finalize(Handle);Handle=IntPtr.Zero;}}
        }
        static void Check(int code){if(code!=0)throw new IOException("历史数据库操作未完成（代码 "+code+"）");}
        public HistoryArchive(string filename){
            Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(filename)));
            try {
                Check(Sql.sqlite3_open16(filename,out db));Check(Sql.sqlite3_busy_timeout(db,40));
                long version=0;using(var query=Query("PRAGMA user_version"))if(query.Next())version=query.Number(0);
                if(version>1)throw new IOException("历史数据来自更新版本，未修改原文件");
                Exec("PRAGMA journal_mode=WAL");Exec("PRAGMA synchronous=FULL");
                Exec("CREATE TABLE IF NOT EXISTS recordings(id TEXT PRIMARY KEY,started INTEGER NOT NULL,day TEXT NOT NULL,body TEXT NOT NULL,preview TEXT NOT NULL,characters INTEGER NOT NULL,final INTEGER NOT NULL,ended INTEGER NOT NULL,revision INTEGER NOT NULL)");
                Exec("CREATE INDEX IF NOT EXISTS history_day_started ON recordings(day,started DESC,id DESC)");
                Exec("CREATE INDEX IF NOT EXISTS history_started ON recordings(started DESC,id DESC)");
                if(version==0)Exec("PRAGMA user_version=1");
            }catch{Dispose();throw;}
        }
        Statement Query(string sql,params object[] values){if(db==IntPtr.Zero)throw new ObjectDisposedException("HistoryArchive");return new Statement(db,sql,values);}
        void Exec(string sql,params object[] values){using(var query=Query(sql,values))while(query.Next()){}}
        public void Save(IList<SpeechRecord> records){
            lock(sync){
                Exec("BEGIN IMMEDIATE");
                try {
                    foreach(var r in records)Exec("INSERT OR REPLACE INTO recordings(id,started,day,body,preview,characters,final,ended,revision) VALUES(?,?,?,?,?,?,?,?,?)",
                        r.Id,r.Started.ToUniversalTime().Ticks,r.Day,r.Text,r.Preview,r.Characters,r.HasFinal?1:0,r.Ended?1:0,r.Revision);
                    Exec("COMMIT");
                }catch{try{Exec("ROLLBACK");}catch{}throw;}
            }
        }
        public List<HistoryDay> Days(){
            lock(sync){var rows=new List<HistoryDay>();using(var q=Query("SELECT day,COUNT(*) FROM recordings GROUP BY day ORDER BY day DESC"))while(q.Next())rows.Add(new HistoryDay{Day=q.Text(0),Count=q.Number(1)});return rows;}
        }
        static HistoryHeader Header(Statement q){return new HistoryHeader {Id=q.Text(0),Started=new DateTime(q.Number(1),DateTimeKind.Utc),Day=q.Text(2),Preview=q.Text(3),Characters=(int)q.Number(4),Final=q.Number(5)!=0,Ended=q.Number(6)!=0,Revision=(int)q.Number(7)};}
        const string Columns="id,started,day,preview,characters,final,ended,revision";
        public List<HistoryHeader> DayPage(string day,long before,string beforeId,int limit){
            if(limit<1||limit>200)throw new ArgumentOutOfRangeException("limit");
            lock(sync){var rows=new List<HistoryHeader>();using(var q=Query("SELECT "+Columns+" FROM recordings WHERE day=? AND (started<? OR (started=? AND id<?)) ORDER BY started DESC,id DESC LIMIT ?",day,before,before,beforeId,limit))while(q.Next())rows.Add(Header(q));return rows;}
        }
        public HistoryHeader Latest(bool withText=false){
            lock(sync){using(var q=Query("SELECT "+Columns+" FROM recordings "+(withText?"WHERE characters>0 ":"")+"ORDER BY started DESC,id DESC LIMIT 1"))return q.Next()?Header(q):null;}
        }
        public string Body(string id){
            lock(sync){using(var q=Query("SELECT body FROM recordings WHERE id=?",id)){if(!q.Next())throw new IOException("这条历史暂时无法读取，原文件未修改");return q.Text(0);}}
        }
        public void Dispose(){lock(sync){if(db!=IntPtr.Zero){Sql.sqlite3_close(db);db=IntPtr.Zero;}}}
    }
}
