using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
namespace WeTypeVoice2 {
    internal sealed class HistoryTree : TreeView {
        public event Action Scrolled;
        protected override void WndProc(ref Message m){base.WndProc(ref m);if((m.Msg==0x115||m.Msg==0x20a)&&Scrolled!=null)Scrolled();}
    }
    internal sealed class HistoryTimeline : UserControl {
        sealed class More {public string Day;public long Before;public string Id;}
        readonly SpeechHistory history;
        readonly HistoryTree tree=new HistoryTree {Name="historyTree",Dock=DockStyle.Fill,BorderStyle=BorderStyle.None,HideSelection=false,ShowLines=false,ShowPlusMinus=true,FullRowSelect=true,ItemHeight=54,Indent=16,DrawMode=TreeViewDrawMode.OwnerDrawAll};
        readonly HashSet<string> expanded=new HashSet<string>();
        readonly HashSet<string> collapsed=new HashSet<string>();
        readonly HashSet<string> liveSeen=new HashSet<string>();
        Dictionary<string,long> savedDays=new Dictionary<string,long>();
        long catalog=-1;DateTime date;bool updating,loading;
        public event Action<SpeechRecord> Selected;
        public SpeechRecord Selection {get{return tree.SelectedNode==null?null:tree.SelectedNode.Tag as SpeechRecord;}}
        public HistoryTimeline(SpeechHistory source){
            history=source;Dock=DockStyle.Fill;Controls.Add(tree);tree.BackColor=UiTheme.Panel;tree.ForeColor=UiTheme.Text;tree.Font=new Font("Microsoft YaHei UI",9.5f);
            tree.BeforeExpand+=(s,e)=>{if(e.Node.Tag is HistoryGroup)Populate(e.Node);};
            tree.AfterExpand+=(s,e)=>{var g=e.Node.Tag as HistoryGroup;if(g!=null&&!updating){expanded.Add(g.Key);collapsed.Remove(g.Key);}};
            tree.AfterCollapse+=(s,e)=>{var g=e.Node.Tag as HistoryGroup;if(g!=null&&!updating){expanded.Remove(g.Key);collapsed.Add(g.Key);}};
            tree.AfterSelect+=(s,e)=>{if(updating)return;if(e.Node.Tag is More){LoadMore(e.Node);return;}var r=e.Node.Tag as SpeechRecord;if(r!=null&&Selected!=null)Selected(r);};
            tree.NodeMouseClick+=(s,e)=>{if(e.Node.Tag is HistoryGroup&&(tree.HitTest(e.Location).Location&TreeViewHitTestLocations.PlusMinus)==0){if(e.Node.IsExpanded)e.Node.Collapse();else e.Node.Expand();}};
            tree.KeyDown+=(s,e)=>{if(e.KeyCode==Keys.Enter&&tree.SelectedNode!=null){var n=tree.SelectedNode;if(n.Tag is HistoryGroup){n.Toggle();e.Handled=true;}else if(n.Tag is More){LoadMore(n);e.Handled=true;}}};
            tree.Scrolled+=()=>{if(loading||updating||!IsHandleCreated)return;BeginInvoke((MethodInvoker)(()=>{var n=tree.TopNode;while(n!=null&&n.Bounds.Y<tree.ClientSize.Height){if(n.Tag is More){LoadMore(n,false);break;}n=n.NextVisibleNode;}}));};
            tree.DrawNode+=Draw;
        }
        public TreeView Tree {get{return tree;}}
        public long TotalCount {get;private set;}
        public void RefreshDate(){if(date!=DateTime.Today)RefreshRecords(false);}
        List<HistoryDay> Days(){
            var map=new Dictionary<string,long>();bool readable=true;
            if(history.Archive!=null)try{foreach(var d in history.Archive.Days())map[d.Day]=d.Count;savedDays=new Dictionary<string,long>(map);}catch(Exception){history.ReportStorageReadError();map=new Dictionary<string,long>(savedDays);readable=false;}
            if(!readable){foreach(var day in history.Entries.GroupBy(r=>r.Day))map[day.Key]=Math.Max(map.ContainsKey(day.Key)?map[day.Key]:0,day.LongCount());return map.Select(pair=>new HistoryDay{Day=pair.Key,Count=pair.Value}).ToList();}
            foreach(var r in history.Entries)if(history.Archive==null||!r.Persisted){if(!map.ContainsKey(r.Day))map[r.Day]=0;map[r.Day]++;}
            return map.Select(pair=>new HistoryDay{Day=pair.Key,Count=pair.Value}).ToList();
        }
        TreeNode GroupNode(HistoryGroup group){var node=new TreeNode(group.Label){Tag=group,Name=group.Key};node.Nodes.Add(new TreeNode("正在加载…"));return node;}
        public void RefreshRecords(bool follow){
            if(IsDisposed)return;
            var old=Selection;string selectedId=old==null?null:old.Id;bool rebuild=catalog!=history.CatalogRevision||date!=DateTime.Today;
            updating=true;tree.BeginUpdate();
            try{
                if(rebuild){
                    if(date!=DateTime.MinValue&&date!=DateTime.Today){expanded.Clear();collapsed.Clear();tree.CollapseAll();}
                    var top=tree.TopNode;string topKey=top==null?null:top.Name;var days=Days();TotalCount=days.Sum(d=>d.Count);MergeGroups(tree.Nodes,HistoryGrouping.Build(days,DateTime.Today));
                    foreach(var r in history.Entries)if(liveSeen.Add(r.Id)){var daysFound=tree.Nodes.Find(r.Day,true);if(daysFound.Length==1){var day=daysFound[0];if(!(day.Nodes.Count==1&&day.Nodes[0].Tag==null)&&day.Nodes.Find(r.Id,false).Length==0)day.Nodes.Insert(0,RecordNode(r));}}
                    date=DateTime.Today;catalog=history.CatalogRevision;
                    foreach(TreeNode n in tree.Nodes)RestoreExpansion(n);
                    if(!follow&&topKey!=null){var found=tree.Nodes.Find(topKey,true);if(found.Length>0)tree.TopNode=found[0];}
                }else RefreshLiveNodes(tree.Nodes);
                var latest=history.Latest;
                if(follow&&latest!=null){
                    // Following new text never overrides an explicit collapse of today's group.
                    if(latest.Day==DateTime.Today.ToString("yyyy-MM-dd")&&!collapsed.Contains(latest.Day))SelectRecord(latest);
                }else if(selectedId!=null){var nodes=tree.Nodes.Find(selectedId,true);if(nodes.Length>0)tree.SelectedNode=nodes[0];}
            }finally{tree.EndUpdate();updating=false;}
            tree.Invalidate();
        }
        void MergeGroups(TreeNodeCollection nodes,List<HistoryGroup> groups){
            var existing=new Dictionary<string,TreeNode>();foreach(TreeNode n in nodes)if(n.Tag is HistoryGroup)existing[n.Name]=n;
            var keep=new HashSet<string>(groups.Select(g=>g.Key));
            for(int i=nodes.Count-1;i>=0;i--)if(!keep.Contains(nodes[i].Name))nodes.RemoveAt(i);
            for(int i=0;i<groups.Count;i++){
                var group=groups[i];TreeNode node;
                if(!existing.TryGetValue(group.Key,out node)){node=GroupNode(group);nodes.Insert(i,node);}
                else {node.Tag=group;node.Text=group.Label;if(node.Index!=i){node.Remove();nodes.Insert(i,node);}
                    if(group.Kind!="day"&&!(node.Nodes.Count==1&&node.Nodes[0].Tag==null))MergeGroups(node.Nodes,group.Children);
                }
            }
        }
        void RestoreExpansion(TreeNode node){
            var g=node.Tag as HistoryGroup;if(g==null)return;
            if(expanded.Contains(g.Key)||(g.Kind=="day"&&g.Key==DateTime.Today.ToString("yyyy-MM-dd")&&!collapsed.Contains(g.Key))){
                Populate(node);node.Expand();foreach(TreeNode child in node.Nodes)RestoreExpansion(child);
            }
        }
        void Populate(TreeNode node){
            if(node.Nodes.Count!=1||node.Nodes[0].Tag!=null)return;
            var group=(HistoryGroup)node.Tag;node.Nodes.Clear();
            if(group.Kind!="day"){foreach(var child in group.Children)node.Nodes.Add(GroupNode(child));return;}
            AddPage(node,group.Key,long.MaxValue,"~",true);
        }
        TreeNode RecordNode(SpeechRecord r){return new TreeNode(r.Started.ToLocalTime().ToString("HH:mm:ss")+" · "+r.Characters+" 字"){Tag=r,Name=r.Id};}
        void AddPage(TreeNode parent,string day,long before,string id,bool first){
            var seen=new HashSet<string>();foreach(TreeNode node in parent.Nodes){var r=node.Tag as SpeechRecord;if(r!=null)seen.Add(r.Id);}
            if(first)foreach(var r in history.Entries)if(r.Day==day&&!r.Persisted&&seen.Add(r.Id))parent.Nodes.Add(RecordNode(r));
            if(history.Archive==null){if(first)foreach(var r in history.Entries)if(r.Day==day&&seen.Add(r.Id))parent.Nodes.Add(RecordNode(r));return;}
            List<HistoryHeader> page;
            try{page=history.Archive.DayPage(day,before,id,100);}
            catch(Exception){history.ReportStorageReadError();foreach(var r in history.Entries)if(r.Day==day&&seen.Add(r.Id))parent.Nodes.Add(RecordNode(r));return;}
            foreach(var header in page)if(seen.Add(header.Id))parent.Nodes.Add(RecordNode(history.Restore(header)));
            if(page.Count==100){var last=page[page.Count-1];parent.Nodes.Add(new TreeNode("继续向下浏览…"){Tag=new More {Day=day,Before=last.Started.Ticks,Id=last.Id}});}
        }
        void LoadMore(TreeNode node){LoadMore(node,true);}
        void LoadMore(TreeNode node,bool select){if(loading)return;loading=true;try{var more=(More)node.Tag;var parent=node.Parent;int index=node.Index;node.Remove();AddPage(parent,more.Day,more.Before,more.Id,false);if(select&&index<parent.Nodes.Count)tree.SelectedNode=parent.Nodes[index];}finally{loading=false;}}
        void RefreshLiveNodes(TreeNodeCollection nodes){foreach(TreeNode node in nodes){var r=node.Tag as SpeechRecord;if(r!=null)node.Text=r.Started.ToLocalTime().ToString("HH:mm:ss")+" · "+r.Characters+" 字";else if(node.IsExpanded)RefreshLiveNodes(node.Nodes);}}
        public void SelectRecord(SpeechRecord record){
            var candidates=tree.Nodes.Find(record.Id,true);if(candidates.Length>0){tree.SelectedNode=candidates[0];return;}
            foreach(TreeNode root in tree.Nodes){
                var g=root.Tag as HistoryGroup;if(g==null||!record.Day.StartsWith(g.Key,StringComparison.Ordinal))continue;
                TreeNode group=root;
                while(((HistoryGroup)group.Tag).Kind!="day"){Populate(group);group.Expand();TreeNode next=null;foreach(TreeNode child in group.Nodes){var c=child.Tag as HistoryGroup;if(c!=null&&record.Day.StartsWith(c.Key,StringComparison.Ordinal)){next=child;break;}}if(next==null)return;group=next;}
                Populate(group);group.Expand();candidates=group.Nodes.Find(record.Id,true);if(candidates.Length==0){var added=RecordNode(record);group.Nodes.Insert(0,added);tree.SelectedNode=added;}else tree.SelectedNode=candidates[0];return;
            }
        }
        void Draw(object sender,DrawTreeNodeEventArgs e){
            bool selected=(e.State&TreeNodeStates.Selected)!=0;
            var row=new Rectangle(0,e.Bounds.Y,tree.ClientSize.Width,tree.ItemHeight);
            var drawing=e.Graphics.Save();e.Graphics.SetClip(Rectangle.Intersect(row,tree.ClientRectangle),System.Drawing.Drawing2D.CombineMode.Intersect);
            using(var brush=new SolidBrush(UiTheme.Panel))e.Graphics.FillRectangle(brush,row);
            if(selected)using(var shape=UiTheme.Round(new RectangleF(1,row.Y+1,Math.Max(1,row.Width-3),row.Height-2),6))using(var brush=new SolidBrush(UiTheme.Selected))e.Graphics.FillPath(brush,shape);
            int left=(e.Node.Level+1)*tree.Indent+4;
            var area=new Rectangle(left,row.Y,Math.Max(1,row.Width-left-6),row.Height);
            var group=e.Node.Tag as HistoryGroup;var record=e.Node.Tag as SpeechRecord;
            if(group!=null){
                int x=left-13,y=row.Y+25;
                using(var pen=new Pen(UiTheme.Muted,1.4f)){
                    if(e.Node.IsExpanded)e.Graphics.DrawLines(pen,new[]{new Point(x-3,y-2),new Point(x,y+1),new Point(x+3,y-2)});
                    else e.Graphics.DrawLines(pen,new[]{new Point(x-2,y-3),new Point(x+1,y),new Point(x-2,y+3)});
                }
                TextRenderer.DrawText(e.Graphics,group.Label,tree.Font,new Rectangle(area.X,area.Y+6,area.Width,22),UiTheme.Text,TextFormatFlags.EndEllipsis|TextFormatFlags.SingleLine|TextFormatFlags.PreserveGraphicsClipping);
                TextRenderer.DrawText(e.Graphics,group.Count+" 条记录",tree.Font,new Rectangle(area.X,area.Y+28,area.Width,20),UiTheme.Muted,TextFormatFlags.EndEllipsis|TextFormatFlags.SingleLine|TextFormatFlags.PreserveGraphicsClipping);
            }else if(record!=null){
                TextRenderer.DrawText(e.Graphics,e.Node.Text,tree.Font,new Rectangle(area.X,area.Y+5,area.Width,22),selected?UiTheme.Accent:UiTheme.Text,TextFormatFlags.EndEllipsis|TextFormatFlags.SingleLine|TextFormatFlags.PreserveGraphicsClipping);
                TextRenderer.DrawText(e.Graphics,record.Preview??"",tree.Font,new Rectangle(area.X,area.Y+27,area.Width,22),UiTheme.Muted,TextFormatFlags.EndEllipsis|TextFormatFlags.NoPrefix|TextFormatFlags.SingleLine|TextFormatFlags.PreserveGraphicsClipping);
            }else TextRenderer.DrawText(e.Graphics,e.Node.Text,tree.Font,area,UiTheme.Muted,TextFormatFlags.VerticalCenter|TextFormatFlags.SingleLine|TextFormatFlags.PreserveGraphicsClipping);
            e.Graphics.Restore(drawing);
        }
    }
}
