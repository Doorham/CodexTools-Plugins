# Everything 界面更新交接 · 1.7.3

- 作者：Althy；保留 Doorham。
- 源码：本目录 src/、ui/、app.manifest、Build.ps1；来自1.7.2已发布源码档案（摘要见DEVLOG）。本目录是恢复的独立源码，不冒充原历史工作树或新的客户端源码。
- 构建：Windows PowerShell 调用 `Build.ps1 -OutputDirectory <artifacts/bin> -WebViewLibrary <同版WebView2依赖目录>`，依赖目录需两个托管DLL和 runtimes/win-x64/native/WebView2Loader.dll。manifest 必须通过 /win32manifest 嵌入，不以旁置无声明文件替代。
- UI测试：`EverythingExclusions.exe --ui-self-test <全新 CodexTools/artifacts 子目录>`。业务测试仍 `--self-test <全新 artifacts 子目录> <Everything.exe> <es.exe>`，使用独立命名实例；修复逻辑测试 `--repair-self-test <输出JSON>`。不使用真实用户数据做操作测试。
- 主题：首次读取 `%LOCALAPPDATA%/CodexTools/CodexTools/theme.txt`，无有效设置时跟随系统；手动选择只写本插件已有WebView profile的localStorage。客户端主题文件不改写。
- DPI：主窗只调原生尺寸，不缩放网页。嵌入PerMonitorV2清单，96DPI设计单位。修复窗使用自绘ModernFrame，所有控件构造后再启用DPI自动缩放。未添加专属4.8 API或新运行时配置文件。
- 已测：完整业务163项（v04），随后仅改修复窗及其测试；最终v07 UI/DPI25项，修复逻辑14项（v05）。本机144 DPI的原生awareness、DPR1.5与页面zoom1实测通过。125/150渲染为隔离CDP夹具，DPI变化为合成消息；未做真实混合DPI多显示器验收。
- 未改：原图标、封面、卡片存放位置、用户规则、共享数据、外部进程退出策略、队列及修复操作。1.7.2存在的偶发Everything退出超时没有借UI改版宣称解决。
- 候选状态：源码/构建/隔离验证已完成；本机接管、NAS/GitHub发布由主任务执行并另留回执。正常插件更新无需客户端升级。

依据：Microsoft [DPI声明](https://learn.microsoft.com/en-us/windows/win32/hidpi/setting-the-default-dpi-awareness-for-a-process)，[WinForms DPI说明](https://learn.microsoft.com/en-us/dotnet/desktop/winforms/high-dpi-support-in-windows-forms)。本实现保留原4.x依赖，采用原生清单和单WebView外框处理，并未引入该文档4.7+专属配置流程。
