# Third-party notices

Microsoft.Web.WebView2 1.0.3856.49, Microsoft Corporation. Unmodified LICENSE.txt and NOTICE.txt from the official NuGet package are retained as WEBVIEW2-LICENSE.txt and WEBVIEW2-NOTICE.txt.
Source: https://api.nuget.org/v3-flatcontainer/microsoft.web.webview2/1.0.3856.49/microsoft.web.webview2.1.0.3856.49.nupkg
Everything and ES are not redistributed.
