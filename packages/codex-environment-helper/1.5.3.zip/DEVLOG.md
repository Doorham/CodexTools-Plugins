# 环境插件开发日志

## 2026-10-23 · 1.5.3 本机接管与 NAS 发布 · Althy

本机通过原客户端 ControlService 更新两个环境插件：1.5.1 → 1.5.3，共用运行文件摘要与受测候选一致。更新前后均未运行，本轮没有自动启动或执行软件安装；不把其他员工电脑视为已更新。

NAS 两项正式插件已从 1.5.2 更新至 1.5.3。发布前核对旧版本及旧 EXE 摘要 AE8D6C7D031826381992D1D0384D6A8367F8B759AB27EF224FFA8B5CEF541913；在发现目录之外校验候选后保留完整旧包并切换目录，发布后逐文件回读一致。旧包在 NAS 根的 Development/Archive/PluginUpdates/environment-tools/1.5.3/before-1.5.2/<插件ID>。未读取或移动员工运行配置、缓存或备份；旧包附带临时文件只留在回退归档，没有带入新包。

确切程序源码提交 dbe06b7f7976e69aeaca582365fd33bb9b9dde83，分支 codex/environment-links-1.5.3。同归档保存最小组件源码 ZIP、既有第三方许可声明、候选与发布摘要、VALIDATION、官方下载来源及已去掉临时签名参数的小文件头检查。该提交没有顶层 LICENSE，没有借用其他组件许可。未上传本机编码值、完整安装收据或运行日志。

GitHub 渠道待单独发布，不能以本次 NAS 成功代替。客户端不变；完整下载、手动安装、真实界面点击和其他电脑网络仍未验收，验证范围沿用下述 1.5.3 记录。

## 2026-10-23 · 1.5.2 → 1.5.3 · Althy

既有作者：Althy、Doorham、DRHW。两个插件继续共用 EnvironmentDetector.exe，客户端版本不变；不需要 Setup。

原因与修复：
- 原 LibreOffice 安装包直链和清华 FFmpeg 镜像实测返回 404。LibreOffice 改为官方归档中已核验的 26.8.1.1 MSI，它与官网当前 26.8.1 稳定包公布的 SHA256 相同；保存名对齐真实文件名。移除失效 FFmpeg 镜像按钮，正常官网与直接下载保留。
- 原 Python 3.13.1 华为直链仍可访问，但版本已落后。改用 Python 官网 3.14.9 Windows x64 安装器，保持现有离线 PyYAML cp314 支持范围；不擅自将依赖升级到 3.15。现有 .NET 8 SDK/桌面运行时别名均通过验证，保留不变。
- 相同公开地址可用，但旧目标框架的 .NET 下载栈出现 TLS 握手错误。按微软建议在本进程关闭旧 TLS 默认兼容开关并交由 Windows 选择协议；不改系统注册表、系统 TLS 或用户配置。
- PowerShell 官方 API 返回正常，旧代码却将实际 ArrayList 强转 IEnumerable<object>，导致解析结果为空。改为实际集合接口并继续选择 Windows x64 MSI。

范围保全：保留用户点击下载、文件写入 Downloads 后由用户手动运行安装包的流程。保持软件安装检查与环境补全的原分类、已有自动配置入口和 1.5.2 按进程 UTF-8/原备份恢复行为；只校准软件清单里与现行分类不符的旧说明。没有扩展网盘下载、自动安装大件软件或系统编码机制。

验证：最终候选编译成功；7 项下载解析/TLS 离线回归、16 项既有编码回归、27 项既有场景回归通过。使用同份源码/.NET 下载解析逐项访问 6 个安装器，每项仅读取前 16 字节，均得到 HTTP 206 与正确 EXE/MSI/7z 文件头；PowerShell 实际解析到 7.6.8 x64 MSI。来源、状态及已核验链接见同目录 DOWNLOAD-SOURCES.json。首次编码测试的合成 Python 子进程未通过，保留错误后单独运行正常；未修改编码实现，最终回归已通过。不将这次短暂失败归因为链接修复。

未验证：完整安装包下载与全文件摘要、真实界面点击、手动安装、其他员工电脑/网络；不把文件头检查当作完整安装验收。

源码：editions/install/helpers/environment-detector；交付清单/文件：editions/install/apps/plugin-station/bundled/software-environment-checker 与 codex-environment-helper。分支 codex/environment-links-1.5.3，准确基线 plugins-environment-v1.5.2 / bed2b8358393c081a19b979a53f2e456125d02fe；最终提交以交付回执为准。构建入口 helpers/environment-detector/build.ps1 -PythonPath <已有Python路径>（从 editions/install 定位），产物 artifacts/environment-detector-1.5.3。

当前状态：两个本地 bundled 候选包已对齐 1.5.3；本轮开发模式加载、本机安装、NAS 与 GitHub 发布尚未执行，交由发布步骤分别登记。回退依据为已发布 1.5.2 包，用户配置和备份不入包。

最终 EXE SHA256：376918C04894C75C58A77D9FD3EE4B997486F7B1F59ACC464A6B98697FE9A120（资源版本 1.5.3.0）。

## 2026-10-23 · 1.5.1 → 1.5.2 · Doorham

既有作者：Althy、Doorham、DRHW。两个插件共用 EnvironmentDetector.exe；软件安装检查仍只读，编码检查/恢复位于 Codex 环境补全。

原因：旧环境补全将 ACP/OEMCP/MACCP 全局设置成 65001，并把未启用全局 UTF-8 误判为需处理，可能使旧软件或 GBK 文本解码异常。已核验问题样本原始 GBK 字节可正常解码，不属于文件内容已损坏。

变更：删除全局启用代码和一键补全目标；旧 --enable-utf8 返回 2 且不修改注册表。UTF-8 范围写在检测卡片和 ENCODING.md：本工具的 Python 检测/pip/venv 使用单次 -X utf8，捕获输出仅设置子进程 PYTHONIOENCODING，PR/Skill/PowerShell 按具体流程指定编码。没有新增持久用户环境、Profile 或系统代码页配置。

恢复：保留按本机原备份恢复入口，备份必须有效且不是全 UTF-8/含 UTF-8 的快照；跳过损坏/无效的较新备份。不猜默认 936，不自动导入退役目录。恢复前安全备份，写入后回读，写入失败尝试回滚；安全备份失败时不触碰注册表。无备份提供 Windows 区域设置操作说明。未做异常写入注入测试，不声称所有恢复失败场景已实测。

验证：最终构建 16 项编码检查通过；原 --enable-utf8 实际执行返回 2，三个代码页前后不变；27 项既有场景自测通过；离线安装 Python 前缀拆分及单次 UTF-8 参数检查通过。维护机按自身历史备份恢复成功、注册表回读一致，用户级 PYTHONUTF8=1 先备份后移除，原问题文件保留并另存 UTF-8 BOM 可读副本。系统恢复仍需择时重启；未做重启后旧应用/其他员工实机验收。原文件、用户备份及恢复记录不进入包。

源码：editions/install/helpers/environment-detector；插件清单/交付文件在 editions/install/apps/plugin-station/bundled/codex-environment-helper。分支 fix/environment-utf8-scope，标签 plugins-environment-v1.5.2。重建入口 helpers/environment-detector/build.ps1 -PythonPath <已有Python路径>，构建输出 artifacts/environment-detector-1.5.2。

交付：本机两个插件清单与共用运行程序均更新到 1.5.2；NAS Plugins/Local 对应两个插件更新到 1.5.2并回读核验。GitHub 渠道本轮未同步，不能把 NAS 状态当成 GitHub 更新。旧版包归档，恢复用户状态不随包发布。客户端 0.32.16 不变，不需要 Setup；员工更新两个环境插件，系统设置需在各自机器恢复。此前 1.5.1 没有该目录日志，本文不补造旧版验收。

最终 EXE SHA256：AE8D6C7D031826381992D1D0384D6A8367F8B759AB27EF224FFA8B5CEF541913（资源版本 1.5.2.0）。
