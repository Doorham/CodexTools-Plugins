﻿# 编码处理范围（1.5.2 及以后）

2026-10-23 · Doorham；原作者 Althy、Doorham、DRHW。

环境检测器不再要求 Windows 全局 UTF-8，也不再提供全局启用动作。GBK、Big5 等原系统代码页均不是“缺少环境”。旧参数 `--enable-utf8` 返回 2，不写注册表。

| 已知流程 | 处理范围 |
| --- | --- |
| Premiere 工程读取 | XML 解析器读取工程原始字节；脚本内文本使用明确编码。需要终端输出适配时，仅该次 Python 使用 `-X utf8`，已有 `--ascii-safe` 可避免终端传输乱码。不得为读 PR 修改系统代码页。 |
| UTF-8 Skill 文档校验 | `py -3 -X utf8 <校验脚本> <Skill目录>`，不设置用户级 `PYTHONUTF8`。 |
| PowerShell 读取已知 UTF-8 文本 | `Get-Content -LiteralPath <文件> -Encoding utf8`，不永久更改 PowerShell Profile、控制台代码页或系统区域。 |
| 本插件的 Python 检测、pip、venv | 仅本次 Python 参数加 `-X utf8`；捕获该子进程输出时，子进程的 `PYTHONIOENCODING=utf-8` 与解码器配套。其他子进程维持原行为。 |
| GBK 等旧 TXT | 按原编码重新打开；先保留原件，确认编码后才另存副本。不能看到乱码就假定文件是 UTF-8。 |

## 恢复旧版影响

1. 更新“Codex 环境补全”和“软件安装检查”至 1.5.2 或更新版本；两者共用 EnvironmentDetector.exe，版本需一致。客户端不需要升级。
2. 在“Codex 环境补全”点击“恢复原编码”。只有本机 `EnvironmentDetector/Backups/utf8-original-*.ini` 中存在有效的非 UTF-8 备份时才提供按钮。恢复前再次保存当前设置，写入后回读；失败则尝试恢复操作前状态。备份只保存在本机。
3. 历史备份若已被退役工具归档，由维护者核对来源和三个代码页后，单独复制到当前 Backups。不自动扫描或导入旧目录其他内容，不猜测每台机器都应恢复成 936。
4. 没有备份时，到 Windows“更改系统区域设置”取消“Beta: 使用 Unicode UTF-8 提供全球语言支持”，核对该机器原系统区域。完成后择时重启 Windows；插件不自动重启。
5. 若另有用户级 `PYTHONUTF8=1`，先记下原值，再移除该用户变量。仅对已知 UTF-8 工作流指定启动参数。已经运行的程序可能保留旧环境，重启后再验证。
6. 显示乱码与数据损坏需分别判断：原始 GBK 字节仍在可重新解码；若已将替代字符保存进文件，需要原件/备份，不能承诺自动还原。

只检查明确的问题文件，不批量改写磁盘文本。不把本机注册表快照、恢复记录、样本文件或用户环境上传到插件包。

实现依据：[Microsoft UTF-8 应用范围文档](https://learn.microsoft.com/windows/apps/design/globalizing/use-utf8-code-page)，[旧 CRT 与全局 UTF-8 的兼容问题](https://support.microsoft.com/en-us/servicing/os/windows/2019/02/apps-using-legacy-crts-don-t-work-properly-with-certain-regional-settings)。
