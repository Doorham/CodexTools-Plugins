# 插件开发记录 · codex-environment-helper

## 2026-10-26 · 1.5.5 包 / 1.5.3 程序 → 1.5.6 · Althy

既有作者 Althy、Doorham、DRHW 保留。两个模块继续共用同一 EnvironmentDetector.exe；本轮是独立插件更新，客户端不升级，不要求 Setup。

- 文字编码按场景处理：保留系统原生编码，不再以全局 UTF-8 作为“就绪”目标。现有代码页警告保留，新增识别用户级 PYTHONUTF8=1 和“系统编码设置”入口；用户选择后先备份这一个变量再清理，需要 UTF-8 的 Python/文本流程继续逐次指定。
- 没有有效原编码备份时打开微软官方“区域”入口，指导保留原系统区域、取消 Beta UTF-8，由 Windows 选原生码页；不伪造历史备份、不猜 936、不自动重启。已有有效备份恢复入口保留。旧 TXT 应按原始 GBK/Big5 重新打开；错误保存与文件已经不可恢复不是同一结论，须先查原始字节，不批量转码或覆盖原件。
- 修复 Git 初始化验收：版本/初始化仓库存在不再代表可以提交。姓名邮箱缺失提供“配置提交身份”，保存先在原生 Git 锁文件中暂存并验证实际 commit/log 与作者、提交者，再一次性应用。配置解析、提交失败和缺身份分别说明；已安装 Git 的配置问题不进入重复安装。
- Git 自检隔离工作树、hooks、attributes/filter、fsmonitor 和继承的作者变量；只在临时提交中指定 UTF-8，保留用户自己的日志/提交编码配置。未给用户代填姓名邮箱，不在用户工作区建仓，未为复现而重装可用 Git。
- 两页改为各跑自己的 8 项软件检查 / 6 项环境检查，按当前步骤显示进度；环境页不顺带创建 Python 虚拟环境或扫描无关开发工具，原 14 项能力与分类保留。
- 下载先写唯一 .part，检查文件头与服务器声明长度后提升正式文件，已有同名完整文件不覆盖。提供取消、响应/空闲超时、后台清理、取消/失败具体原因及进度限频；卡片销毁不阻断临时文件处理。动态 API 失败不再吞异常，PowerShell 使用真实版本文件名。
- 官方六项直链/解析入口均实际读取了16字节并通过文件头检查；保留有效链接和 Python cp314 范围。移除两个 .NET 镜像按钮：原入口 HTTP 200 实际返回门户壳，不能当作下载资源；官方 .NET 8 别名保留。来源及边界见 DOWNLOAD-SOURCES.json。

验证：同一候选 142 项专项（下载解析10、Git51、原编码16、编码策略14、分域扫描8、下载43）及27项既有场景通过；实际只读环境报告、合成卡片/表单保存入口通过。旧全局“启用 UTF-8”仍拒绝执行。未在本轮改变真实系统代码页、用户环境变量或 Git 身份；未做重启后验收、其他设备验收、完整官方安装包下载/签名验证或重新安装 Git。文件头和声明长度不是官方完整 SHA256/签名证明，未知长度下载也不能据此证明原包完整。

程序资源/报告版本均为1.5.6.0 / 1.5.6，图标沿用1.5.5双色SVG。源码分支 codex/git-initialization-1.5.6，标签 plugins-environment-v1.5.6；精确提交与渠道状态见同目录 SOURCE-HANDOFF / PUBLICATION / GITHUB-PUBLICATION。原先 PowerShell 7 外层启动出现 Windows 299/5，使用原生 Python 构建器完成验证；此工具基础设施故障没有记作 Git 或下载链接故障。首轮测试中的只读 Git 对象清理、硬编码报告版本、include覆盖与测试注入前提已分别核实修正，失败原件留本地 artifacts，不伪造历史通过。

发布、本机接管和其他设备分别登记；本条记录交付载荷，不代替渠道回执或真实系统设置变更。现有客户端 Setup 内旧 bundled 兜底不是现行已安装插件：新装/离线用户应先从插件中心更新到本版，下次客户端构建需同步本组件最新输入。本轮不重打客户端安装包。

---

# 插件开发记录 · codex-environment-helper

## 2026-10-24 · 1.5.4 → 1.5.5 · Althy

- 用户采用双色矢量方案：原白色功能符号保留，背景改为两个色标的线性渐变。
- 纯 SVG 算法制作，无生图、嵌入位图或分形纹理；源文件 artwork/icon.svg 与清单 iconImage 完全一致。
- 本包需客户端 0.32.20 的通用 SVG 支持；保留原 icon 作为旧协议兜底。以后同协议图标更新无需升级客户端。
- 运行程序及依赖逐字节沿用上一版，程序资源版本未变；包版本因美术交付递增。原作者与本渠道历史日志保留。
- 图标按浅暗界面及 32/40 px 核对；本条记录包内交付，渠道发布和本机更新状态见发布回执，不代替业务功能全量重测。

---

# Codex 环境补全 · 开发日志

## 2026-10-23 · 1.5.4 · Althy

- 插件包版本：1.5.3 → 1.5.4；本轮仅修改图标交付元数据与资产，既有程序/依赖二进制原样保留，其文件资源版本不因美术包修订伪装为重新编译。
- 采用独立配色、连续胶质能量背景与白色线条/圆润几何。背景使用内置 image_gen 从空白制作（耳机沿用已认可的 v04），白色主体为原生 SVG；源文件与完整提示词见 artwork/，正式显示为 256px PNG。
- 图标通过清单 iconImage PNG 数据与目录同步，客户端 0.32.19 起支持独立显示和更新；旧客户端保持原字符图标兼容。后续换图不要求逐插件改客户端 ID 表。
- 验证：整套浅/暗色、32/40px 目视检查与 PNG 大小/格式校验完成；不以图标检查代替各插件业务功能全量验收。
- 交付状态按各渠道目录及同目录 PUBLICATION.json/GITHUB-PUBLICATION.json 回执分别登记；本条记录本轮制作与验证，不替代本机接管或业务验收。保留既有署名、功能及用户状态。

---

# 环境插件开发日志

## 2026-10-23 · GitHub 公共渠道同步 · Althy（程序版本不变）

GitHub 公共仓库 Doorham/CodexTools-Plugins 已发布本插件 1.5.3。实际远端提交 `f6fcdf7142b73d070c14aca69ced594e08f58f78`，发布于 2026-10-23 19:14:36，于 2026-10-23 19:14:53 回读验证（Asia/Shanghai）：目录版本、实际下载 ZIP 的 SHA256、解压及声明的运行文件均通过。

发布包：`packages/codex-environment-helper/1.5.3.zip`，427262 字节；SHA256：`D727C6CBEF6F761D5D0798F115EF61A2E6A94C2C0A7344E897173B9DDD8D4597`。本次只追加渠道完成记录，已发布 ZIP、插件程序、清单与客户端版本不变；既有本机接管、状态保留和功能验收范围沿用此前记录，没有新增其他电脑或真实功能验收。

当前 GitHub 状态以本节及 [GITHUB-PUBLICATION.json](GITHUB-PUBLICATION.json) 为准；此前“待同步”是相应时间点的记录。脱敏原始回执位于 NAS 根的 `Development/Archive/PluginUpdates/github-sync/2026-10-23`。保留原作者和原有历史，不改用户配置。

## 2026-10-23 · 1.5.3 本机接管与 NAS 发布 · Althy

本机通过原客户端 ControlService 更新两个环境插件：1.5.1 → 1.5.3，共用运行文件摘要与受测候选一致。更新前后均未运行，本轮没有自动启动或执行软件安装；不把其他员工电脑视为已更新。

NAS 两项正式插件已从 1.5.2 更新至 1.5.3。发布前核对旧版本及旧 EXE 摘要 AE8D6C7D031826381992D1D0384D6A8367F8B759AB27EF224FFA8B5CEF541913；在发现目录之外校验候选后保留完整旧包并切换目录，发布后逐文件回读一致。旧包在 NAS 根的 Development/Archive/PluginUpdates/environment-tools/1.5.3/before-1.5.2/<插件ID>。未读取或移动员工运行配置、缓存或备份；旧包附带临时文件只留在回退归档，没有带入新包。

确切程序源码提交 dbe06b7f7976e69aeaca582365fd33bb9b9dde83，分支 codex/environment-links-1.5.3。同归档保存最小组件源码 ZIP、既有第三方许可声明、候选与发布摘要、VALIDATION、官方下载来源及已去掉临时签名参数的小文件头检查。该提交没有顶层 LICENSE，没有借用其他组件许可。未上传本机编码值、完整安装收据或运行日志。

GitHub 渠道待单独发布，不能以本次 NAS 成功代替。客户端不变；完整下载、手动安装、真实界面点击和其他电脑网络仍未验收，验证范围沿用下述 1.5.3 记录。

## 2026-10-23 · 1.5.2 → 1.5.3 · Althy

既有作者：Althy、Doorham、DRHW。两个插件继续共用 EnvironmentDetector.exe，客户端版本不变；不需要 Setup。

原因与修复：
- 原 LibreOffice 安装包直链和清华 FFmpeg 镜像实测返回 404。LibreOffice 改为官方归档中已核验的 26.8.1.1 MSI，它与官网当前 26.8.1 稳定包公布的 SHA256 相同；保存名对齐真实文件名。移除失效 FFmpeg 镜像按钮，正常官网与直接下载保留。
- 原 Python 3.13.1 华为直链仍可访问，但版本已落后。改用 Python 官网 3.14.9 Windows x64 安装器，保持现有离线 PyYAML cp314 支持范围；不擅自将依赖升级到 3.15。现有 .NET 8 SDK/桌面运行时别名均通过验证，保留不变。
- 相同公开地址可用，但旧目标框架的 .NET 下载栈出现 TLS 握手错误。按微软建议在本进程关闭旧 TLS 默认兼容开关并交由 Windows 选择协议；不改系统注册表、系统 TLS 或用户配置。
- PowerShell 官方 API 返回正常，旧代码却将实际 ArrayList 强转 IEnumerable<object>，导致解析结果为空。改为实际集合接口并继续选择 Windows x64 MSI。

范围保全：保留用户点击下载、文件写入 Downloads 后由用户手动运行安装包的流程。保持软件安装检查与环境补全的原分类、已有自动配置入口和 1.5.2 按进程 UTF-8/原备份恢复行为；只校准软件清单里与现行分类不符的旧说明。没有扩展网盘下载、自动安装大件软件或系统编码机制。

验证：最终候选编译成功；7 项下载解析/TLS 离线回归、16 项既有编码回归、27 项既有场景回归通过。使用同份源码/.NET 下载解析逐项访问 6 个安装器，每项仅读取前 16 字节，均得到 HTTP 206 与正确 EXE/MSI/7z 文件头；PowerShell 实际解析到 7.6.8 x64 MSI。来源、状态及已核验链接见同目录 DOWNLOAD-SOURCES.json。首次编码测试的合成 Python 子进程未通过，保留错误后单独运行正常；未修改编码实现，最终回归已通过。不将这次短暂失败归因为链接修复。

未验证：完整安装包下载与全文件摘要、真实界面点击、手动安装、其他员工电脑/网络；不把文件头检查当作完整安装验收。

源码：editions/install/helpers/environment-detector；交付清单/文件：editions/install/apps/plugin-station/bundled/software-environment-checker 与 codex-environment-helper。分支 codex/environment-links-1.5.3，准确基线 plugins-environment-v1.5.2 / bed2b8358393c081a19b979a53f2e456125d02fe；最终提交以交付回执为准。构建入口 helpers/environment-detector/build.ps1 -PythonPath <已有Python路径>（从 editions/install 定位），产物 artifacts/environment-detector-1.5.3。

当前状态：两个本地 bundled 候选包已对齐 1.5.3；本轮开发模式加载、本机安装、NAS 与 GitHub 发布尚未执行，交由发布步骤分别登记。回退依据为已发布 1.5.2 包，用户配置和备份不入包。

最终 EXE SHA256：376918C04894C75C58A77D9FD3EE4B997486F7B1F59ACC464A6B98697FE9A120（资源版本 1.5.3.0）。

## 2026-10-23 · 1.5.1 → 1.5.2 · Doorham

既有作者：Althy、Doorham、DRHW。两个插件共用 EnvironmentDetector.exe；软件安装检查仍只读，编码检查/恢复位于 Codex 环境补全。

原因：旧环境补全将 ACP/OEMCP/MACCP 全局设置成 65001，并把未启用全局 UTF-8 误判为需处理，可能使旧软件或 GBK 文本解码异常。已核验问题样本原始 GBK 字节可正常解码，不属于文件内容已损坏。

变更：删除全局启用代码和一键补全目标；旧 --enable-utf8 返回 2 且不修改注册表。UTF-8 范围写在检测卡片和 ENCODING.md：本工具的 Python 检测/pip/venv 使用单次 -X utf8，捕获输出仅设置子进程 PYTHONIOENCODING，PR/Skill/PowerShell 按具体流程指定编码。没有新增持久用户环境、Profile 或系统代码页配置。

恢复：保留按本机原备份恢复入口，备份必须有效且不是全 UTF-8/含 UTF-8 的快照；跳过损坏/无效的较新备份。不猜默认 936，不自动导入退役目录。恢复前安全备份，写入后回读，写入失败尝试回滚；安全备份失败时不触碰注册表。无备份提供 Windows 区域设置操作说明。未做异常写入注入测试，不声称所有恢复失败场景已实测。

验证：最终构建 16 项编码检查通过；原 --enable-utf8 实际执行返回 2，三个代码页前后不变；27 项既有场景自测通过；离线安装 Python 前缀拆分及单次 UTF-8 参数检查通过。维护机按自身历史备份恢复成功、注册表回读一致，用户级 PYTHONUTF8=1 先备份后移除，原问题文件保留并另存 UTF-8 BOM 可读副本。系统恢复仍需择时重启；未做重启后旧应用/其他员工实机验收。原文件、用户备份及恢复记录不进入包。

源码：editions/install/helpers/environment-detector；插件清单/交付文件在 editions/install/apps/plugin-station/bundled/codex-environment-helper。分支 fix/environment-utf8-scope，标签 plugins-environment-v1.5.2。重建入口 helpers/environment-detector/build.ps1 -PythonPath <已有Python路径>，构建输出 artifacts/environment-detector-1.5.2。

交付：本机两个插件清单与共用运行程序均更新到 1.5.2；NAS Plugins/Local 对应两个插件更新到 1.5.2并回读核验。GitHub 渠道本轮未同步，不能把 NAS 状态当成 GitHub 更新。旧版包归档，恢复用户状态不随包发布。客户端 0.32.16 不变，不需要 Setup；员工更新两个环境插件，系统设置需在各自机器恢复。此前 1.5.1 没有该目录日志，本文不补造旧版验收。

最终 EXE SHA256：AE8D6C7D031826381992D1D0384D6A8367F8B759AB27EF224FFA8B5CEF541913（资源版本 1.5.2.0）。
