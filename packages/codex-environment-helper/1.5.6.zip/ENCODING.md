# 文字编码：系统原生，UTF-8 按场景

版本1.5.6 · Althy；原作者保留。

Windows全局UTF-8开关不会替每份文件识别编码。现代UTF-8文件继续按UTF-8读写；旧软件和GBK/Big5文本保留原编码。工具的Python检测/pip/venv等需要UTF-8的调用逐次指定，不再强制全部Windows或Python进程。

## 使用“系统编码设置”

如果检测到用户级PYTHONUTF8=1，工具先让使用者选择是否备份并移除此单个变量；选择否时保留。备份成功才修改，失败保留/恢复原值。备份在本机程序目录Backups，不随插件更新删除或上传。已经运行的进程可能保留旧环境，需自行重开应用或终端。

系统全局UTF-8需到Windows“区域”→“管理”→“更改系统区域设置”操作。保留本机原系统区域，取消Beta“使用Unicode UTF-8提供全球语言支持”；Windows会选择该区域的原生代码页。先保存工作，再自行安排重启。工具不自动重启，也不把按区域查到的默认值冒充历史备份。已有有效原始备份时，旧“恢复原编码”入口继续可用。

## 文本已经乱码

先保留原件。VS Code中点击右下角编码，选择“以编码重新打开”，再选“简体中文GBK”等原始编码。重新打开用于纠正显示；“以编码保存”会改字节，两者不能混用。保存过不必然已经毁坏，须看原始字节；如果真正已写入替换字符，改系统设置不能找回丢失内容，应找原件/备份。需要转成UTF-8时另存副本，不批量覆盖原文。

## 开发约束

旧 `--enable-utf8` 仍返回2且不写系统配置。ACP/OEMCP/MACCP没有被本版猜测写入；用户级环境清理只针对明确的PYTHONUTF8=1，保留其他值与变量。临时Git提交单独指定UTF-8并禁用用户hooks/filter/fsmonitor，用户Git编码配置保留。

官方依据：
- https://learn.microsoft.com/en-us/windows/win32/shell/controlpanel-canonical-names
- https://learn.microsoft.com/en-us/windows/win32/api/winnls/nf-winnls-getacp
- https://learn.microsoft.com/en-us/windows/win32/api/winnls/nf-winnls-getlocaleinfoex
- https://docs.python.org/3/using/cmdline.html#envvar-PYTHONUTF8
