# PowerShell 7 独立 MSI 配置 · 1.5.10

开发者 Althy，保留 Doorham、DRHW。

“软件安装检查”的 PowerShell 7 卡片新增“安装/修复 MSI”。使用微软官方 x64 MSI；当前明确验证的包为 7.6.9。安装会核对固定 SHA256 和微软签名；只有缺失或损坏时才安装。已有可用 MSI 只补 PATH，完整时不重复安装。

配置完成必须同时满足：独立安装目录有 pwsh.exe、Windows 有 MSI 登记、新进程 PATH 优先找到该程序、PowerShell Core/版本/1+1=2 子进程自检通过。商店/MSIX 别名、Codex 随附版本、仅有文件或安装器退出0都不单独算完成。安装前已经打开的 DSH/终端需要重开后继承 PATH；本工具不替用户关闭这些应用，也不声称已经替其验证所有受限运行环境。

需要写系统配置时按 Windows 正常流程请求管理员权限。只处理 PowerShell 自身的安装和 PATH；保留其他 PATH 条目、Windows PowerShell 5.1、现有商店包、全局编码和执行策略，不启用远程管理。下载失败、签名/摘要不符、UAC取消或自检失败会明确报告，不能显示已就绪。

离线使用：在明确选择的安装包库根目录或 packages 子目录放置 PowerShell-7.6.9-win-x64.msi，仍须通过同样摘要和签名校验。未选择安装包库时，从官方 GitHub 下载，并缓存到 %LOCALAPPDATA%/CodexTools/EnvironmentDetector/installer-cache。旧库的 MSIX PowerShell 分支已在执行前拒绝；兼容锁文件为库内其他软件保留，不再允许它把 PowerShell 安装成商店包。

代码入口：src/PowerShellSetup.cs（判断与动作）、configure-powershell-msi.ps1（MSI配置）、src/Program.cs（卡片接入）；原 helpers/environment-detector/install-from-library.ps1 增加旧MSIX拒绝。安装/更新仅通过现有插件协议，客户端版本不变。两个插件共用同一程序，因此一起升至1.5.10。

验证：16项PowerShell专项、8项扫描范围及6项Git就绪UI回归通过；真实微软MSI校验、当前机器完整配置和生产检测通过，已经正确的系统PATH保持原样。Git UI首次夹具因漏带已有图片资源失败，补齐资源后通过；未改Git逻辑。没有冒充DSH重启后受限环境实测，也没有通过插件重新安装当前已完整的PowerShell。
