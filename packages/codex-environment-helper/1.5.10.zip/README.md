# 环境工具 1.5.10

PowerShell 7 现在提供“安装/修复 MSI”，配置独立版和 PATH，并做实际启动、版本及计算自检。仅有商店版不再显示完整就绪。详见 [PowerShell 配置说明](POWERSHELL.md)。保留1.5.9的界面、编码和Git功能，客户端无需更新。

---

# 环境组件 1.5.9 · 源码与交接

本组件交付“Codex 环境补全”和“软件安装检查”两个独立插件，包版本/实际程序/报告均为1.5.9（程序资源1.5.9.0）。只更新插件，不升级客户端。署名Althy；保留Doorham、DRHW。

有效源码标签 `plugins-environment-v1.5.9`，分支 `codex/environment-modern-ui-1.5.9`。本分支从独立环境组件的1.5.3源码与后续日志接续；不要按本分支根目录旧客户端指针重打整套客户端。客户端现行入口始终看 NAS Development/Docs/DEVELOPMENT.md。下一次客户端构建先同步本组件最新源码及两个bundled输入，避免恢复旧全局UTF-8能力。

## 构建

在本目录运行 `build.ps1 -PythonPath <本机Python完整路径>`。依赖Windows内置.NET Framework编译器，资源在assets/fluent-emoji-3d，许可见THIRD-PARTY-NOTICES。支持Windows PowerShell5.1；若维护宿主出现Windows299进程启动故障，先区分宿主问题，不据此重装Git。产物只进入仓库artifacts/environment-detector-1.5.9。

## 验证与范围

测试入口在tests：NativeEncodingRepairTests、GitSetupTests、EncodingPolicyTests、ScanPlanTests、SafePackageDownloadTests、EncodingScopeTests、DownloadResolutionTests。使用合成配置/临时仓库/loopback，不能把测试值写进用户真实全局配置。程序 `--mode codex --report <文件>` 或 `--mode software --report <文件>` 仅生成本机报告；`--self-test-scenarios <文件>`运行原场景回归。报告可能含本机路径，仅留本机，不自动上传。

行为、失败记录与交付状态见DEVLOG.md；编码使用见ENCODING.md；下载审查见DOWNLOAD-SOURCES.json。用户编码备份、安装源选择、配置与缓存均不在源码包或插件包中。

新机器Git必须完成一次本人身份配置，详见 [Git首次配置与换机说明](GIT-FIRST-RUN.md)。未打开检测或未完成填写不能算就绪；无跨机自动身份恢复。

## 界面与主题

主窗和组件自有对话框采用平面自绘标题栏，宽窗两列、窄窗一列；右上角可切换浅/暗色。未设置时继承客户端主题，插件切换不改客户端主题。安装/配置期间的退出保护继续有效。报告和“配置提交身份”“拨乱反正”“系统编码设置”等入口保持。

高DPI采用当前.NET Framework架构支持的系统DPI感知和原生控件缩放，避免整窗位图放大。144DPI夹具已核对；混合DPI跨屏动态缩放不作为本版已完成能力。依据：[Microsoft WinForms High DPI说明](https://learn.microsoft.com/en-us/dotnet/desktop/winforms/high-dpi-support-in-windows-forms?view=netframeworkdesktop-4.8)。

ModernUiTests生成合成数据界面并检查按钮/网格/窗口样式；不读写用户检测数据。测试以PrintWindow客户区捕获，不能使用Form.DrawToBitmap的虚假经典非客户区作为新框架的视觉结论。生产启动与测试截图无关。
