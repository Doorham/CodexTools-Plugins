# 钉钉直连覆盖范围 · 1.2.20

2026-10-28 · Doorham。通过公开钉钉文档站、Web 版入口、官网下载页和登录页及其 JS/CSS 核对依赖；证据映射见 DOMAIN-EVIDENCE.json。

- dingtalk.com：统一覆盖 alidocs、login、im、oa、docs、table、page、pages、static、down、api/oapi、preview/trans 等全部子域；无需逐个重复登记。
- alidocs.oss-cn-zhangjiakou.aliyuncs.com：公开钉钉使用手册中的文档快照和图片资源。
- dingtalk-h5.cn-zhangjiakou.log.aliyuncs.com：生产登录脚本引用的 H5 登录诊断上报服务。
- ai-alimebot.lydaas.com：文档站明确链接的在线客服入口。

阿里静态资源、统计、账号辅助等现有 alicdn.com、mmstat.com、taobao.com、aliapp.org、alipay.com 规则继续覆盖。只增加有本轮官方页面/脚本证据的域名，不把整个阿里云存储或阿里内部域名加入直连。

本轮不是全业务抓包或登录验收。企业自建应用、登录后动态上传存储、会议/原生客户端等尚未实际操作；第三方转载清单未直接采用。受测插件包与 NAS/GitHub 状态见独立发布回执。本机自定义规则不随包上传；更新插件即可，客户端无变化。
