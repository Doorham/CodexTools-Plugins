# 国内网站直连（cn-proxy-bypass）更新记录

## 1.2.14 · 2026-10-14 · Kimi

在 1.2.13 基础上补全 Kimi 桌面端（3.2.16）域名，公共主域 127 → 133：

- `volccdn.com` — 客户端火山引擎 CDN 资源（`lf3-data.volccdn.com`），实测经代理超时
- `trustdecision.com` — 充值/支付页加载的 TrustDecision 风控 SDK（`static.trustdecision.com`）
- `kimi.page`、`kimi.site` — Kimi 分享/跳转域名（程序包内嵌，实测存活）
- `msh.team`、`kimi.team` — 月之暗面内部/开发域名（`dev.msh.team`、`kimi-oversea.kimi.team` 等）

域名来源：客户端主日志与历史日志真实流量、daimon 运行时配置、程序包内嵌字符串、自动更新配置（`kimi-img.moonshot.cn/app/upgrade/`）。

同步修复：Clash Verge 运行中会用内存旧配置重写 verge.yaml 与注册表，冲掉外部写入的白名单（1.2.13 的规则曾因此被覆盖）。需在 Clash 关闭状态写入 verge.yaml 后重启 Clash，让其自行加载全部 295 条规则。验证：9 组 Kimi 域名在 verge.yaml 与注册表均为精确+通配双规则；会员接口由 33–43 秒超时恢复为 302–345ms，充值页正常加载。

## 1.2.13 · 2026-10-14 · Codex

- 新增 `kimi.com`、`kimi.ai`、`moonshot.cn` 三个主域及全部子域通配（公共主域 124 → 127），含 auth.kimi.com、kimi-img.moonshot.cn、statics.moonshot.cn 等认证与静态资源子域
- 配套工具箱 0.32.6：修复宿主启动时用旧内置插件覆盖新版已安装插件的问题（有效且版本更高的已安装插件保留）
- Windows 与 Clash 两侧各 6 条 Kimi 规则生效，官网直连验证通过
