## 2026-10-27 · 1.2.18 → 1.2.19 · Doorham

- 按用户要求，将已在本机添加的 moonshot.ai、kimi.cn、kimi.com.cn 纳入公共内置白名单，主域和全部子域沿用既有处理器生成规则；保留原有内置域名、作者、图标与本机自定义配置。
- 仅插件数据和版本更新，无客户端或处理器改动，不需要更新 EXE/Setup。公共分发不包含用户自定义白名单、注册表、Clash 配置或备份。
- 验证范围：与 1.2.18 对比只增加这三个域名；核对主域/通配规则、原规则保留、ZIP CRC/SHA256、现有客户端解包及更新协议。实际渠道发布与本机安装以同目录 PUBLICATION.json / GITHUB-PUBLICATION.json 回执为准；不将白名单存在等同于所有 Kimi 请求或模型速度已验收。
- 有效维护输入为本插件的 1.2.18 已发布 ZIP；本轮完整 1.2.19 包和交接证据保存在 Development/Archive/PluginUpdates/cn-proxy-bypass/1.2.19。沿用同 ID 正式入口，不创建开发卡片。

# 国内网站直连（cn-proxy-bypass）更新记录

## 1.2.16 · 2026-10-22 · DeepSeek Harness

补入 DeepSeek 开放平台充值/用量页的静态资源主机 `fe-static.deepseek.com`，公共主域 160 → 161。

该页面 HTML 由 `platform.deepseek.com` 返回，但 bundle、图标等全部资源来自 `fe-static.deepseek.com`（`/platform/static/main.*.js`、`/platform/favicon.svg`）。1.2.15 只列了 `platform.deepseek.com`，靠 `*.deepseek.com` 通配才间接覆盖到它，没有独立条目；本次补成显式规则。

现场另确认一个容易被误判成“白名单漏了”的现象：**经代理访问 `platform.deepseek.com` 会返回 `202 Accepted` 且响应体为空**（响应头 `x-amzn-waf-action: challenge`、`X-Cache: Error from cloudfront`，Amazon CloudFront WAF 人机校验）。在内嵌 Platform 视图里就是白屏转圈、一直加载。所以该域必须直连；如果诊断时看到 202 或空白页，先查绕过清单是否真的生效，而不是继续加域名。

## 1.2.15 · 2026-10-20 · DeepSeek Harness

按用户实际使用反馈补全 DeepSeek 官方站与 QQ 邮箱的直连规则，公共主域 133 → 160（+27）：

- DeepSeek：`deepseek.com` 主域及 `www` / `chat` / `platform` / `api` / `api-docs` / `download` / `cdn` / `static` / `status` / `talent` 子域，遥测域 `deepseeksvc.com`、`dsh-otel-collector.deepseeksvc.com`
- QQ 邮箱：`qq.com` 主域及 `mail` / `wx.mail` / `res.mail` / `ssl.ptlogin2` / `ssl.ptlogin2.mail` / `ptlogin2` / `xui.ptlogin2` / `imgcache` / `captcha` / `t.captcha` / `ssl.captcha` / `graph` / `appimg2`
- 未纳入浏览器记录中的非官方近似域名 `deepseek-ai.net`、`deepseek-en.com`、`deepseeka.com.cn`

实测依据（本机 Windows + Clash Verge，代理 127.0.0.1:7897）：

- `imgcache.qq.com` 经代理连接失败（curl 56），直连 200 — 对应“一个资源不通、整页加载不出来”
- `mail.qq.com` 105ms vs 2363ms；`wx.mail.qq.com` 103ms vs 2547ms；`ssl.ptlogin2.mail.qq.com` 76ms vs 2684ms
- `chat.deepseek.com`、`platform.deepseek.com` 经代理 403，直连可达

只修改 `moduleVersion` 与 `domains`，处理器、权限与私人数据策略不变；个人自定义白名单未复制到共享目录。1.2.14 记录的 Clash 运行中覆盖外部写入问题同样适用：更新后若白名单条数与内置数不符，按该条处理方式重启 Clash 后再刷新一次。

## 1.2.14 · 2026-10-14 · Kimi

在 1.2.13 基础上补全 Kimi 桌面端（3.2.16）域名，公共主域 127 → 133：

- `volccdn.com` — 客户端火山引擎 CDN 资源（`lf3-data.volccdn.com`），实测经代理超时
- `trustdecision.com` — 充值/支付页加载的 TrustDecision 风控 SDK（`static.trustdecision.com`）
- `kimi.page`、`kimi.site` — Kimi 分享/跳转域名（程序包内嵌，实测存活）
- `msh.team`、`kimi.team` — 月之暗面内部/开发域名（`dev.msh.team`、`kimi-oversea.kimi.team` 等）

域名来源：客户端主日志与历史日志真实流量、daimon 运行时配置、程序包内嵌字符串、自动更新配置（`kimi-img.moonshot.cn/app/upgrade/`）。

同步修复：Clash Verge 运行中会用内存旧配置重写 verge.yaml 与注册表，冲掉外部写入的白名单（1.2.13 的规则曾因此被覆盖）。需在 Clash 关闭状态写入 verge.yaml 后重启 Clash，让其自行加载全部 295 条规则。验证：9 组 Kimi 域名在 verge.yaml 与注册表均为精确+通配双规则；会员接口由 33–43 秒超时恢复为 302–345ms，充值页正常加载。

## 1.2.13 · 2026-10-14 · Codex

- 新增 `kimi.com`、`kimi.ai`、`moonshot.cn` 三个主域及全部子域通配（公共主域 124 → 127），含 auth.kimi.com、kimi-img.moonshot.cn、statics.moonshot.cn 等认证与静态资源子域
- 配套工具箱 0.32.6：修复宿主启动时用旧内置插件覆盖新版已安装插件的问题（有效且版本更高的已安装插件保留）
- Windows 与 Clash 两侧各 6 条 Kimi 规则生效，官网直连验证通过
