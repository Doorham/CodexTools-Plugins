# PowerShell 7 独立 MSI 配置 · 1.5.11

保留开发者 Althy、Doorham、DRHW。

“软件安装检查”的 PowerShell 7 卡片使用“安装/修复 MSI”配置微软官方 x64 独立版，当前维护基线为 7.6.10 LTS。微软从 7.7 起取消 MSI，因此下载目标固定在已核验、仍提供 MSI 的 LTS 分支，不追随 GitHub 的 latest。SourceForge 备选镜像指向同版同文件名 MSI。

配置时先核对安装包固定 SHA256 和微软签名。低于维护基线、缺失或损坏时执行安装；达到基线且可运行时只检查 PATH，完整时不重复安装。仅打开检测不会自动安装或升级 PowerShell。

完成条件：独立目录有 pwsh.exe、Windows 有 MSI 登记、新进程 PATH 优先找到该程序、PowerShell Core/版本/1+1=2 自检通过，版本不低于 7.6.10。商店/MSIX 别名、Codex 随附版本、仅有文件或安装器退出 0 都不单独算完成。此前已打开的 DSH/终端需重开以继承 PATH；插件不替用户关闭应用，也不据此声称所有受限调用环境都通过。

需要修改系统配置时使用正常 Windows 管理员授权流程。只处理 PowerShell 安装和 PATH，保留其他 PATH 条目、Windows PowerShell 5.1、商店包、全局编码和执行策略，不启用远程管理。下载失败、签名/摘要不符、UAC 取消或自检失败均明确报告。

离线使用：在明确选择的安装包库根目录或 packages 子目录放置 PowerShell-7.6.10-win-x64.msi，仍需同样摘要和签名校验。未选择库时从官方 GitHub 下载，缓存到 %LOCALAPPDATA%/CodexTools/EnvironmentDetector/installer-cache。旧库 MSIX 分支继续拒绝执行；其他软件的离线快照锁保留。

本次验证：17 项 PowerShell 判断、22 项下载来源/兼容判断、8 项扫描范围、43 项安全下载和 6 项 Git 就绪 UI 检查通过。7.6.10 MSI 完整 SHA256 与微软 Authenticode 签名通过；以 -ValidateOnly 验证，未安装 MSI、未改 PATH。两个插件同时更新至 1.5.11，宿主无需更新。

代码入口：src/PowerShellSetup.cs、configure-powershell-msi.ps1、src/Program.cs。旧离线 MSI 拒绝规则在 helpers/environment-detector/install-from-library.ps1 中。

## 1.5.10 历史验证（不计入本轮）

验证：16项PowerShell专项、8项扫描范围及6项Git就绪UI回归通过；真实微软MSI校验、当前机器完整配置和生产检测通过，已经正确的系统PATH保持原样。Git UI首次夹具因漏带已有图片资源失败，补齐资源后通过；未改Git逻辑。没有冒充DSH重启后受限环境实测，也没有通过插件重新安装当前已完整的PowerShell。
