## 1.5.13 · LibreOffice 实际转 PDF 后判定就绪

软件安装检查在隔离配置目录用 LibreOffice 把一页文档导出为 PDF，并核对文件头、交叉引用及结束标记。程序、转换结果与 PATH 均通过才显示已就绪。LibreOffice 卡片的“转 PDF”可使用同一条路径处理本地文档。

本机故障发生在初始化崩溃报告时查询代理例外地址的 DNS 反向解析。仅导出进程使用 LibreOffice 的 CrashDumpEnable=false 启动选项，保留系统代理和用户日常 LibreOffice 配置。技术细节见 LibreOffice desktop/source/app/crashreport.cxx。两个环境插件独立更新至 1.5.13。

## 1.5.12 · 软件卡片自助安装与配置（2026-11-18）

软件页可直接安装 LibreOffice、Python 3.14、.NET SDK、.NET 8 桌面兼容运行时、FFmpeg，也可选择安装 VS Code。LibreOffice 在线安装使用完整 SHA256 校验的 MSI，已选择的离线库继续使用原有锁定安装包。已安装时按需补 PATH，并用 soffice.com 复检。点击安装后的系统授权由 Windows 提示，返回页面自动更新检测状态。Codex 补全 Python 组件时可连带安装所缺 Python。PowerShell 专用 MSI、Git 身份和编码操作保留各自入口。

# 环境工具 1.5.11

本组件提供“Codex 环境补全”和“软件安装检查”两个独立插件，共用程序版本 1.5.11.0。只更新插件，客户端无需升级；保留原署名 Althy、Doorham、DRHW。

2026-11-18 维护：Python 下载更新到 3.14.10，LibreOffice 到 26.8.3，并让镜像入口直接指向对应 Windows 安装文件。PowerShell 维持仍提供 MSI 的 7.6 LTS，更新到 7.6.10；不再通过已无 MSI 的 7.7 latest 解析下载。.NET 开发 SDK 推荐 10 LTS；现有旧插件依赖的 .NET 8 桌面运行时单独保留为兼容项，10 不能冒充满足 8 的依赖。

在线补全仍使用软件官方源和既有 pip --upgrade 流程。手动选择的离线安装库是固定快照，不承诺最新版；本次未改写离线库清单或用户选择。Git 首次身份配置、编码修复、主题、下载取消和文件校验功能保持。

## 构建与验证

有效源码分支 `codex/environment-maintenance-1.5.11`，从 1.5.10 的 f76eadd 接续。请维护本目录源码和两个 bundled 插件输入，不按旧客户端指针重打整套客户端。

运行 `build.ps1 -PythonPath <本机Python完整路径>`；可用 `-TestNames` 指定相关专项。使用 Windows 内置 .NET Framework 编译器，资源在 assets/fluent-emoji-3d，许可见 THIRD-PARTY-NOTICES.md。产物进入仓库 artifacts/environment-detector-1.5.11。

程序 `--mode codex --report <文件>` 或 `--mode software --report <文件>` 仅生成本机报告；`--self-test-scenarios <文件>` 运行原场景回归。检测报告可能含本机路径，仅留本机。测试不得向真实 Git 配置写入合成身份，也不为验收安装或升级用户软件。

本次 96 项相关检查通过，覆盖 MSI 判断、下载来源、SDK 与桌面运行时兼容边界、扫描范围、安全下载及 Git 就绪状态。真实 PowerShell 7.6.10 MSI 完整 SHA256 和微软签名验证通过，未执行安装。下载来源与核验深度见 DOWNLOAD-SOURCES.json；历史和交付状态见 DEVLOG.md。

新机器仍需本人完成一次 Git 身份配置，详见 GIT-FIRST-RUN.md；PowerShell 独立 MSI 配置见 POWERSHELL.md；编码规则见 ENCODING.md。用户状态、主题偏好、安装源选择、备份和安装缓存不随包分发。

## 界面与主题

主窗和组件自有对话框采用平面自绘标题栏，宽窗两列、窄窗一列；右上角可切换浅/暗色。未设置时继承客户端主题，插件切换不改客户端主题。安装/配置期间的退出保护继续有效。报告和“配置提交身份”“拨乱反正”“系统编码设置”等入口保持。

高DPI采用当前.NET Framework架构支持的系统DPI感知和原生控件缩放，避免整窗位图放大。144DPI夹具已核对；混合DPI跨屏动态缩放不作为本版已完成能力。依据：[Microsoft WinForms High DPI说明](https://learn.microsoft.com/en-us/dotnet/desktop/winforms/high-dpi-support-in-windows-forms?view=netframeworkdesktop-4.8)。

ModernUiTests生成合成数据界面并检查按钮/网格/窗口样式；不读写用户检测数据。测试以PrintWindow客户区捕获，不能使用Form.DrawToBitmap的虚假经典非客户区作为新框架的视觉结论。生产启动与测试截图无关。
